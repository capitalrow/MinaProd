"""
Post-Transcription Pipeline for Mina Pro
GPT-4o powered analysis triggered after final Whisper transcript completion
"""
import os
import json
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional
import tiktoken
from openai import OpenAI
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from models import AnalysisResult, TranscriptSession
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize OpenAI client
openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Database setup
DATABASE_URL = os.environ.get("DATABASE_URL")
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class PostTranscriptionPipeline:
    def __init__(self):
        self.encoding = tiktoken.get_encoding("cl100k_base")  # GPT-4 encoding
        self.max_tokens = 128000  # GPT-4o context limit
        self.max_retries = 3
        
    def count_tokens(self, text: str) -> int:
        """Count tokens in text using tiktoken"""
        return len(self.encoding.encode(text))
    
    def chunk_transcript(self, transcript: str, max_chunk_tokens: int = 100000) -> list:
        """Chunk transcript if it exceeds token limits"""
        total_tokens = self.count_tokens(transcript)
        
        if total_tokens <= max_chunk_tokens:
            return [transcript]
        
        # Split by sentences for better context preservation
        sentences = transcript.split('. ')
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            sentence_tokens = self.count_tokens(sentence + '. ')
            current_tokens = self.count_tokens(current_chunk)
            
            if current_tokens + sentence_tokens > max_chunk_tokens and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = sentence + '. '
            else:
                current_chunk += sentence + '. '
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    async def retry_with_backoff(self, func, *args, **kwargs):
        """Retry function with exponential backoff"""
        for attempt in range(self.max_retries):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                if attempt == self.max_retries - 1:
                    raise e
                wait_time = 2 ** attempt
                logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {wait_time}s...")
                await asyncio.sleep(wait_time)
    
    async def generate_summary(self, transcript: str) -> Dict[str, Any]:
        """Generate comprehensive summary using GPT-4o"""
        try:
            chunks = self.chunk_transcript(transcript)
            
            if len(chunks) == 1:
                # Single chunk processing
                response = openai_client.chat.completions.create(
                    model="gpt-4",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are an expert meeting analyst. Generate a comprehensive summary including key points, decisions made, and overall themes. Be concise but thorough."
                        },
                        {
                            "role": "user",
                            "content": f"Please summarize this meeting transcript:\n\n{transcript}"
                        }
                    ],
                    max_tokens=1000,
                    temperature=0.3
                )
                
                summary = response.choices[0].message.content
                tokens_used = response.usage.total_tokens
                
            else:
                # Multi-chunk processing - summarize each chunk then combine
                chunk_summaries = []
                total_tokens = 0
                
                for i, chunk in enumerate(chunks):
                    response = openai_client.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {
                                "role": "system",
                                "content": f"Summarize this portion (part {i+1} of {len(chunks)}) of a meeting transcript. Focus on key points and decisions."
                            },
                            {
                                "role": "user",
                                "content": chunk
                            }
                        ],
                        max_tokens=500,
                        temperature=0.3
                    )
                    
                    chunk_summaries.append(response.choices[0].message.content)
                    total_tokens += response.usage.total_tokens
                
                # Combine chunk summaries
                combined_summary = "\n\n".join([f"Part {i+1}: {summary}" for i, summary in enumerate(chunk_summaries)])
                
                # Final consolidation
                final_response = openai_client.chat.completions.create(
                    model="gpt-4",
                    messages=[
                        {
                            "role": "system",
                            "content": "Consolidate these partial summaries into one coherent comprehensive summary."
                        },
                        {
                            "role": "user",
                            "content": combined_summary
                        }
                    ],
                    max_tokens=800,
                    temperature=0.3
                )
                
                summary = final_response.choices[0].message.content
                tokens_used = total_tokens + final_response.usage.total_tokens
            
            return {
                "summary": summary,
                "tokens_used": tokens_used,
                "status": "complete"
            }
            
        except Exception as e:
            logger.error(f"Summary generation failed: {e}")
            return {
                "summary": None,
                "tokens_used": 0,
                "status": "error",
                "error": str(e)
            }
    
    async def extract_action_items(self, transcript: str) -> Dict[str, Any]:
        """Extract action items using GPT-4o"""
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": "Extract action items from this meeting transcript. Return as a JSON list with fields: 'task', 'assignee' (if mentioned), 'deadline' (if mentioned), 'priority' (high/medium/low)."
                    },
                    {
                        "role": "user",
                        "content": f"Extract action items from:\n\n{transcript}"
                    }
                ],
                max_tokens=800,
                temperature=0.2,
                response_format={"type": "json_object"}
            )
            
            action_items = json.loads(response.choices[0].message.content)
            
            return {
                "action_items": action_items.get("action_items", []),
                "tokens_used": response.usage.total_tokens,
                "status": "complete"
            }
            
        except Exception as e:
            logger.error(f"Action item extraction failed: {e}")
            return {
                "action_items": [],
                "tokens_used": 0,
                "status": "error",
                "error": str(e)
            }
    
    async def analyze_sentiment(self, transcript: str) -> Dict[str, Any]:
        """Analyze meeting sentiment using GPT-4o"""
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": "Analyze the sentiment and tone of this meeting. Return JSON with: 'overall_sentiment': 'positive/neutral/negative', 'confidence': 0.0-1.0, 'key_emotions': list, 'tone_analysis': string description."
                    },
                    {
                        "role": "user",
                        "content": f"Analyze sentiment:\n\n{transcript}"
                    }
                ],
                max_tokens=400,
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            sentiment_data = json.loads(response.choices[0].message.content)
            
            return {
                "sentiment": sentiment_data,
                "tokens_used": response.usage.total_tokens,
                "status": "complete"
            }
            
        except Exception as e:
            logger.error(f"Sentiment analysis failed: {e}")
            return {
                "sentiment": {"overall_sentiment": "neutral", "confidence": 0.0},
                "tokens_used": 0,
                "status": "error",
                "error": str(e)
            }

def trigger_ai_analysis(session_id: str, final_transcript: str) -> bool:
    """
    Main entry point: trigger complete AI analysis pipeline
    Called after final transcript is saved
    """
    try:
        logger.info(f"Starting AI analysis for session {session_id}")
        
        db_session = SessionLocal()
        
        # Create analysis record
        analysis = AnalysisResult(
            session_id=session_id,
            status="in_progress",
            created_at=datetime.utcnow()
        )
        
        db_session.add(analysis)
        db_session.commit()
        
        # Run analysis pipeline
        pipeline = PostTranscriptionPipeline()
        
        async def run_analysis():
            start_time = time.time()
            
            # Run all analyses in parallel
            summary_task = pipeline.generate_summary(final_transcript)
            actions_task = pipeline.extract_action_items(final_transcript)
            sentiment_task = pipeline.analyze_sentiment(final_transcript)
            
            summary_result, actions_result, sentiment_result = await asyncio.gather(
                summary_task, actions_task, sentiment_task, return_exceptions=True
            )
            
            processing_time = time.time() - start_time
            
            # Update analysis record
            analysis.summary = summary_result.get("summary") if isinstance(summary_result, dict) else None
            analysis.action_items = json.dumps(actions_result.get("action_items", [])) if isinstance(actions_result, dict) else "[]"
            analysis.sentiment = json.dumps(sentiment_result.get("sentiment", {})) if isinstance(sentiment_result, dict) else "{}"
            analysis.tokens_used = sum([
                result.get("tokens_used", 0) for result in [summary_result, actions_result, sentiment_result]
                if isinstance(result, dict)
            ])
            analysis.processing_time = processing_time
            analysis.status = "complete"
            analysis.updated_at = datetime.utcnow()
            
            db_session.commit()
            
            logger.info(f"AI analysis completed for session {session_id} in {processing_time:.2f}s")
            
            # Emit Socket.IO event (if available)
            try:
                from flask_socketio import emit
                emit('post_transcription_complete', {
                    'session_id': session_id,
                    'status': 'complete',
                    'summary': analysis.summary,
                    'action_items': json.loads(analysis.action_items),
                    'sentiment': json.loads(analysis.sentiment)
                }, broadcast=True)
            except ImportError:
                logger.info("Socket.IO not available, skipping event emission")
            
            return True
        
        # Run async analysis
        asyncio.run(run_analysis())
        
        db_session.close()
        return True
        
    except Exception as e:
        logger.error(f"AI analysis failed for session {session_id}: {e}")
        
        # Update analysis status to error
        try:
            analysis.status = "error"
            analysis.error_message = str(e)
            analysis.updated_at = datetime.utcnow()
            db_session.commit()
        except:
            pass
        
        if 'db_session' in locals():
            db_session.close()
        
        return False

# Async version for direct usage
async def trigger_ai_analysis_async(session_id: str, final_transcript: str) -> bool:
    """Async version of trigger_ai_analysis"""
    return trigger_ai_analysis(session_id, final_transcript)