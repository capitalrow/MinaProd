"""
Production Database Models for Mina Pro
Clean, focused models for user management and transcription history
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import uuid

Base = declarative_base()

class User(Base):
    """User accounts with authentication and usage tracking"""
    __tablename__ = 'users'
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    
    # ✅ REQUIREMENT: Usage tracking with free-tier limits (30 mins/month)
    created_at = Column(DateTime, default=datetime.utcnow)
    sessions_used = Column(Integer, default=0)
    transcribed_minutes = Column(Float, default=0.0)  # Track minutes for free-tier limits
    monthly_reset = Column(DateTime, default=datetime.utcnow)
    is_premium = Column(Boolean, default=False)
    user_tier = Column(String(20), default="free")  # "free" or "pro" tiers
    
    # User preferences
    preferred_model = Column(String(50), default="whisper-1")
    auto_summary = Column(Boolean, default=True)
    default_meeting_type = Column(String(50), default="general")
    ui_theme = Column(String(20), default="light")
    default_export_format = Column(String(10), default="txt")
    enable_emotion_detection = Column(Boolean, default=True)
    enable_action_extraction = Column(Boolean, default=True)
    enable_topic_segmentation = Column(Boolean, default=True)
    auto_email_transcript = Column(Boolean, default=False)
    clean_filler_words = Column(Boolean, default=False)
    session_history_limit = Column(Integer, default=50)
    
    # Relationships
    transcripts = relationship("TranscriptSession", back_populates="user", cascade="all, delete-orphan")

class TranscriptSession(Base):
    """Individual transcription sessions with full metadata"""
    __tablename__ = 'transcript_sessions'
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey('users.id'), nullable=False)
    
    # Session metadata
    title = Column(String(200), nullable=True)
    meeting_type = Column(String(50), default="general")
    created_at = Column(DateTime, default=datetime.utcnow)
    duration = Column(Float, default=0.0)  # seconds
    
    # Transcription data
    transcript = Column(Text, nullable=True)
    confidence = Column(Float, default=0.0)
    word_count = Column(Integer, default=0)
    model_used = Column(String(50), default="whisper-1")
    fallback_used = Column(Boolean, default=False)
    
    # Intelligence features
    smart_title = Column(String(200), nullable=True)
    summary = Column(Text, nullable=True)
    action_items = Column(JSON, nullable=True)  # List of action items
    tags = Column(JSON, nullable=True)          # List of tags
    
    # Export tracking
    exported_formats = Column(JSON, nullable=True)
    last_exported = Column(DateTime, nullable=True)
    
    # Public sharing
    public_uuid = Column(String, nullable=True, unique=True)
    is_public = Column(Boolean, default=False)
    
    # Relationships
    user = relationship("User", back_populates="transcripts")

class AnalysisResult(Base):
    """Post-transcription AI analysis results - GPT-4o powered intelligence"""
    __tablename__ = 'analysis_results'
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String, ForeignKey('transcript_sessions.id'), nullable=False, unique=True)
    
    # Analysis status tracking
    status = Column(String(20), default="pending")  # pending, in_progress, complete, error
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=True)
    
    # AI-powered analysis results
    summary = Column(Text, nullable=True)
    action_items = Column(Text, nullable=True)  # JSON string of action items
    sentiment = Column(Text, nullable=True)  # JSON string of sentiment analysis
    
    # Processing metadata
    tokens_used = Column(Integer, default=0)
    processing_time = Column(Float, nullable=True)  # Processing time in seconds
    
    # Error handling
    error_message = Column(Text, nullable=True)
    
    # Relationships
    session = relationship("TranscriptSession", backref="analysis_result")

class UsageLog(Base):
    """Track API usage and system performance"""
    __tablename__ = 'usage_logs'
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey('users.id'), nullable=True)
    session_id = Column(String, ForeignKey('transcript_sessions.id'), nullable=True)
    
    action = Column(String(100), nullable=False)  # TRANSCRIBE, EXPORT, SUMMARY
    model_used = Column(String(50), nullable=True)
    processing_time_ms = Column(Integer, nullable=True)
    success = Column(Boolean, default=True)
    error_message = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)