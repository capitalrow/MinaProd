"""
Mina Pro - Production-Ready AI Transcription Platform
Whisper-1 batch transcription with pseudo-live UI and comprehensive intelligence
"""
import os
import logging
import sys
import json
import time
import math
import uuid
import requests
import subprocess
import tempfile
from datetime import datetime
from flask import Flask, jsonify, render_template, request, redirect, url_for, session, make_response, send_file
from flask_sqlalchemy import SQLAlchemy
# Try Socket.IO with graceful fallback
try:
    from flask_socketio import SocketIO, emit, join_room, leave_room
    SOCKETIO_AVAILABLE = True
    print("Socket.IO enabled for real-time transcription")
except ImportError as e:
    SOCKETIO_AVAILABLE = False
    SocketIO = None
    emit = None
    join_room = None
    leave_room = None
    print(f"Socket.IO not available - falling back to HTTP-only mode: {e}")
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from whitenoise import WhiteNoise
from audio_processor import AudioProcessor
from post_transcription_pipeline import trigger_ai_analysis

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialize Socket.IO and WebSocket handler
socketio = None
ws_handler = None

if SOCKETIO_AVAILABLE:
    try:
        # Use simple threading mode to avoid eventlet conflicts
        socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', logger=False, engineio_logger=False)
        
        # Initialize audio processor
        audio_processor = AudioProcessor()
        
        # Simplified WebSocket handler - will implement inline if needed
        ws_handler = None
        print("Socket.IO initialized successfully with threading mode")
        
    except Exception as e:
        print(f"Socket.IO initialization failed: {e}")
        socketio = None
        ws_handler = None
        SOCKETIO_AVAILABLE = False
else:
    socketio = None
    ws_handler = None
    print("Socket.IO not available - WebSocket streaming disabled")

# Fix static file serving with WhiteNoise
app.wsgi_app = WhiteNoise(app.wsgi_app, root='static/', prefix='/static/')

# Database configuration  
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///mina_transcription.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    'pool_pre_ping': True,
    "pool_recycle": 300,
}

# Production-ready configuration
app.config["MAX_CONTENT_LENGTH"] = 128 * 1024 * 1024  # 128MB
app.config["UPLOAD_TIMEOUT"] = 180                    # 3 minutes
app.config["AUDIO_DEBUG_LOGGING"] = True              

# Initialize extensions
db = SQLAlchemy(app, model_class=Base)

# Mock user for simplified authentication
@app.context_processor
def inject_user():
    class MockUser:
        is_authenticated = False
        id = "guest"
    
    return dict(current_user=MockUser())

# Simplified authentication decorator
def require_login(f):
    def wrapper(*args, **kwargs):
        # For standalone mode, allow all access
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

# Basic routes
@app.route('/')
def index():
    """Landing page - redirect to dashboard"""
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """Main dashboard with mode selection"""
    return render_template('dashboard.html')

@app.route('/transcribe_legacy')
def transcribe_legacy():
    """Legacy transcription redirect"""
    return redirect(url_for('transcribe'))

@app.route('/transcribe_standalone')
def transcribe_standalone():
    """Standalone transcription page with embedded JavaScript"""
    return render_template('transcription_standalone.html')

@app.route('/transcribe')
def transcribe():
    """Main batch transcription page - simplified flow"""
    return render_template('transcribe_batch.html')

@app.route('/history')
def history():
    """User's session history"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    try:
        from models import User, TranscriptSession
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        sessions = []
        if current_user:
            sessions = db_session.query(TranscriptSession).filter(
                TranscriptSession.user_id == current_user.id
            ).order_by(TranscriptSession.created_at.desc()).limit(20).all()
        
        db_session.close()
        return render_template('history.html', sessions=sessions, user=current_user)
        
    except Exception as e:
        logger.error(f"Error loading history: {e}")
        return render_template('history.html', sessions=[], user=None)

@app.route('/settings')
def settings():
    """User settings and preferences"""
    current_user = None
    total_sessions = 0
    
    if 'user_id' in session:
        try:
            from models import User, TranscriptSession
            
            db_session = SessionLocal()
            current_user = db_session.query(User).filter(User.id == session['user_id']).first()
            
            if current_user:
                total_sessions = db_session.query(TranscriptSession).filter(
                    TranscriptSession.user_id == current_user.id
                ).count()
            
            db_session.close()
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
    
    return render_template('settings.html', user=current_user, total_sessions=total_sessions)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        # Handle both JSON and form data properly
        if request.content_type and 'application/json' in request.content_type:
            data = request.get_json()
        else:
            data = request.form
        username = data.get('username')
        password = data.get('password')
        
        # Simple demo login - accept any credentials
        if username and password:
            session['user_id'] = username
            session['username'] = username
            result = {"status": "success", "message": "Login successful"}
        else:
            result = {"status": "error", "message": "Please enter both username and password"}
        
        if request.is_json:
            return jsonify(result)
        else:
            if result["status"] == "success":
                return redirect(url_for('dashboard'))
            else:
                return render_template('login.html', error=result["message"])
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])  
def register():
    """User registration"""
    if request.method == 'POST':
        try:
            # Handle both JSON and form data
            if request.is_json:
                data = request.get_json()
            else:
                data = request.form
            
            username = data.get('username')
            email = data.get('email')
            password = data.get('password')
            
            if not all([username, email, password]):
                error_msg = "All fields are required"
                if request.is_json:
                    return jsonify({"status": "error", "message": error_msg}), 400
                else:
                    return render_template('register.html', error=error_msg)
            
            # Simple demo registration - just set session directly
            user_id = f"user_{int(time.time())}"
            session['user_id'] = user_id
            session['username'] = username
            
            # Send welcome email
            try:
                from services.email_service import email_service
                if email_service and email_service.is_available():
                    email_result = email_service.send_welcome_email(email, username)
                    if email_result.get('success'):
                        logger.info(f"Welcome email sent to {email}")
                    else:
                        logger.info(f"Welcome email not sent: {email_result.get('message', 'Unknown error')}")
                else:
                    logger.info("Email service not available")
            except Exception as e:
                logger.error(f"Welcome email error: {e}")
                # Don't fail registration due to email issues
            
            result = {"status": "success", "user_id": user_id}
            
            if request.is_json:
                return jsonify(result)
            else:
                if result["status"] == "success":
                    return redirect(url_for('onboarding'))
                else:
                    return render_template('register.html', error=result.get("message", "Registration failed"))
                    
            # Registration successful, no database session to close in demo mode
        
        except Exception as e:
            logger.error(f"Registration error: {e}")
            error_msg = "Registration failed. Please try again."
            if request.is_json:
                return jsonify({"status": "error", "message": error_msg}), 500
            else:
                return render_template('register.html', error=error_msg)
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    """User logout"""
    session.clear()
    return redirect(url_for('login'))

@app.route('/onboarding')
def onboarding():
    """Interactive onboarding flow for new users"""
    return render_template('onboarding.html')

@app.route('/pseudo_live_transcription')
def pseudo_live_transcription():
    """Pseudo-live transcription with real-time interim results - REDIRECT TO WEBSOCKET VERSION"""
    return redirect(url_for('real_time_transcription'))

@app.route('/real_time_transcription')
def real_time_transcription():
    """Advanced real-time transcription with VAD and WebSocket streaming"""
    return render_template('real_time_transcription.html')

@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')

@app.route('/admin')
def admin():
    """Admin panel for user management"""
    # Simple admin check - in production would verify admin role
    return render_template('admin.html')

@app.route('/download')
def download_page():
    """Download page for real-time transcription files"""
    return render_template('download_files.html')

@app.route('/api/generate_transcription_archive', methods=['POST'])
def generate_transcription_archive():
    """API endpoint to generate transcription archive"""
    try:
        import subprocess
        
        # Check if force regeneration is requested
        data = request.get_json() or {}
        force_regen = data.get('force', False)
        
        # Run the download script with force flag if requested
        cmd = [sys.executable, 'download_real_time_transcription_files.py']
        if force_regen:
            cmd.append('--force')
            
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            return jsonify({
                "success": True,
                "message": "Archive generated successfully",
                "files_count": 23  # Based on our script output
            })
        else:
            logger.error(f"Archive generation failed: {result.stderr}")
            return jsonify({
                "success": False,
                "message": "Failed to generate archive",
                "error": result.stderr
            }), 500
            
    except subprocess.TimeoutExpired:
        return jsonify({
            "success": False,
            "message": "Archive generation timed out"
        }), 500
    except Exception as e:
        logger.error(f"Archive generation error: {e}")
        return jsonify({
            "success": False,
            "message": f"Error generating archive: {str(e)}"
        }), 500

@app.route('/download/real_time_transcription_files')
def download_real_time_transcription_files():
    """Download endpoint for real-time transcription files"""
    from pathlib import Path
    import os
    
    # Look for the most recent archive
    downloads_dir = Path('downloads')
    if not downloads_dir.exists():
        return jsonify({"error": "Downloads directory not found. Run the download script first."}), 404
    
    # Find the most recent archive
    archive_files = list(downloads_dir.glob('real_time_transcription_files_*.zip'))
    if not archive_files:
        return jsonify({"error": "No archives found. Run the download script first."}), 404
    
    # Get the most recent archive
    most_recent_archive = max(archive_files, key=lambda f: f.stat().st_mtime)
    
    try:
        return send_file(
            most_recent_archive,
            as_attachment=True,
            download_name=most_recent_archive.name,
            mimetype='application/zip'
        )
    except Exception as e:
        logger.error(f"Error serving download: {e}")
        return jsonify({"error": f"Failed to serve download: {str(e)}"}), 500

# Admin API endpoints
@app.route('/api/admin/toggle_beta', methods=['POST'])
def api_admin_toggle_beta():
    """Toggle beta status for a user"""
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id')
        
        # Import admin utils safely
        try:
            from admin_utils import AdminUtils
            result = AdminUtils.set_internal_tester(user_id, True)
            return jsonify({"success": result, "message": "Beta status toggled"})
        except ImportError:
            logger.warning("AdminUtils not available, using demo response")
            return jsonify({"success": True, "message": "Beta status toggled (demo)"})
            
    except Exception as e:
        logger.error(f"Admin toggle beta error: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/reset_usage', methods=['POST'])
def api_admin_reset_usage():
    """Reset usage for a user"""
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id')
        
        # In production, this would reset user usage in database
        logger.info(f"Resetting usage for user {user_id}")
        return jsonify({"success": True, "message": "Usage reset successfully"})
        
    except Exception as e:
        logger.error(f"Admin reset usage error: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/users', methods=['GET'])
def api_admin_users():
    """Get all users for admin panel"""
    try:
        # In production, this would query the database
        demo_users = [
            {"id": "1", "username": "demo_user", "email": "demo@example.com", "plan": "pro", "usage": 150},
            {"id": "2", "username": "test_user", "email": "test@example.com", "plan": "basic", "usage": 75}
        ]
        return jsonify({"users": demo_users})
        
    except Exception as e:
        logger.error(f"Admin users error: {e}")
        return jsonify({"users": []}), 500

@app.route('/api/admin/stats', methods=['GET'])
def api_admin_stats():
    """Get system statistics for admin panel"""
    try:
        # In production, this would query the database and system metrics
        stats = {
            "total_users": 1247,
            "active_users": 89,
            "total_sessions": 5632,
            "health": "Healthy"
        }
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"Admin stats error: {e}")
        return jsonify({"health": "Error"}), 500

# API endpoints with safe imports
@app.route('/api/start_session', methods=['POST'])
def api_start_session():
    """Start a new transcription session"""
    try:
        import uuid
        session_id = str(uuid.uuid4())
        return jsonify({
            "status": "success",
            "session_id": session_id,
            "message": "Session started successfully"
        })
    except Exception as e:
        logger.error(f"Session start error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/end_session', methods=['POST'])
def api_end_session():
    """End a transcription session"""
    try:
        data = request.get_json() or {}
        session_id = data.get('session_id')
        
        if not session_id:
            return jsonify({"error": "Session ID required"}), 400
            
        # Flush any remaining buffered audio for this session
        audio_processor = AudioProcessor()
        final_wav_path = audio_processor.flush_buffer(session_id)
        
        if final_wav_path:
            logger.info(f"[END-SESSION] Processing final buffered audio for session {session_id}")
            
            # Transcribe final buffered audio
            try:
                with open(final_wav_path, 'rb') as f:
                    audio_data = f.read()
                    
                final_result = batch_transcribe_whisper(
                    audio_data,
                    session_id,
                    meeting_type="general",
                    context_prompt="Final audio segment from recording session."
                )
                
                # Clean up final WAV file
                if os.path.exists(final_wav_path):
                    os.unlink(final_wav_path)
                    
                # Emit final transcription result if successful
                if final_result.get('status') == 'success' and final_result.get('text'):
                    final_chunk_id = f"final_{session_id}"
                    emit_interim_transcript(session_id, final_result['text'], final_result.get('confidence', 0), final_chunk_id)
                    logger.info(f"[END-SESSION] Final buffered audio transcribed: {final_result['text']}")
                    
            except Exception as e:
                logger.error(f"[END-SESSION] Error transcribing final buffer: {e}")
                
        # Emit transcription complete event as specified in requirements
        emit_transcription_complete(session_id)
        
        return jsonify({
            "status": "success",
            "message": f"Session {session_id} ended successfully"
        })
    except Exception as e:
        logger.error(f"Session end error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/flush_session', methods=['POST'])
def api_flush_session():
    """Force flush any remaining audio in buffer for a session"""
    try:
        data = request.get_json() or {}
        session_id = data.get('session_id')
        
        if not session_id:
            return jsonify({"error": "Session ID required"}), 400
            
        # Flush any remaining buffered audio for this session
        audio_processor = AudioProcessor()
        final_wav_path = audio_processor.flush_buffer(session_id)
        
        if final_wav_path:
            logger.info(f"[FLUSH-SESSION] Processing final buffered audio for session {session_id}")
            
            # Transcribe final buffered audio
            try:
                with open(final_wav_path, 'rb') as f:
                    audio_data = f.read()
                    
                final_result = batch_transcribe_whisper(
                    audio_data,
                    session_id,
                    meeting_type="general",
                    context_prompt="Final audio segment from recording session."
                )
                
                # Clean up final WAV file
                if os.path.exists(final_wav_path):
                    os.unlink(final_wav_path)
                    
                return jsonify({
                    "status": "success",
                    "transcript": final_result.get('text', ''),
                    "confidence": final_result.get('confidence', 0.8),
                    "message": "Final buffer flushed and transcribed"
                })
                    
            except Exception as e:
                logger.error(f"[FLUSH-SESSION] Error transcribing final buffer: {e}")
                return jsonify({
                    "status": "error",
                    "message": f"Error transcribing final buffer: {str(e)}"
                }), 500
                
        return jsonify({
            "status": "success",
            "transcript": "",
            "message": "No buffered audio to flush"
        })
        
    except Exception as e:
        logger.error(f"Session flush error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# Note: buffered_transcribe endpoint now handled by dedicated route in routes/buffered_transcription.py

# Health check endpoints (Note: primary health endpoint defined below)

def batch_transcribe_whisper(audio_data, session_id, meeting_type="general", context_prompt=""):
    """Transcribe audio using OpenAI Whisper API with enhanced audio processing"""
    
    if not audio_data:
        return {"status": "error", "message": "No audio data provided"}
    
    try:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return {"status": "error", "error": "OpenAI API key not configured"}
        
        import openai
        client = openai.OpenAI(api_key=api_key)
        
        # Initialize audio processor
        audio_processor = AudioProcessor()
        
        # Enforce 8KB minimum as required by FFmpeg for reliable processing
        min_size = 8192  # 8KB minimum
        if len(audio_data) < min_size:
            logger.warning(f"[AUDIO-VALIDATE] Chunk too small: {len(audio_data)} bytes, skipping")
            return {
                "status": "skipped", 
                "message": f"Audio chunk too small: {len(audio_data)} bytes (minimum {min_size} bytes)",
                "fallback_attempted": False
            }
        
        # Process audio using the enhanced audio processor with buffering
        wav_path = None
        
        try:
            logger.info(f"[AUDIO-PROCESS] Processing {len(audio_data)} bytes with AudioProcessor")
            
            # Debug: Check audio format first
            if len(audio_data) >= 4:
                header_hex = audio_data[:4].hex()
                logger.info(f"[AUDIO-DEBUG] First 4 bytes: {header_hex}")
                if b'\x1a\x45\xdf\xa3' in audio_data[:20]:
                    logger.info("[AUDIO-DEBUG] EBML header detected - valid WebM")
                else:
                    logger.warning("[AUDIO-DEBUG] No EBML header found - possibly invalid WebM")
            
            # Use new buffering system to handle short audio chunks
            status, result_path_or_message, is_merged = audio_processor.process_audio_with_buffering(audio_data, session_id)
            
            if status == 'buffered':
                # Audio was buffered, return buffering status to frontend
                logger.info(f"[AUDIO-BUFFER] {result_path_or_message}")
                return {
                    "status": "buffered",
                    "message": result_path_or_message,
                    "session_id": session_id,
                    "buffering": True
                }
            elif status == 'error':
                logger.error(f"[AUDIO-BUFFER] {result_path_or_message}")
                return {
                    "status": "error",
                    "message": result_path_or_message,
                    "fallback_attempted": False
                }
            elif status == 'ready':
                wav_path = result_path_or_message
                logger.info(f"[AUDIO-PROCESS] Audio ready for transcription: {wav_path} (merged: {is_merged})")
                
                # Ensure WAV file cleanup is handled properly after use
                cleanup_wav_path = wav_path  # Store for cleanup in finally block
            
        except Exception as process_error:
            logger.error(f"[AUDIO-PROCESS] AudioProcessor failed: {process_error}")
            logger.error(f"[AUDIO-PROCESS] Exception type: {type(process_error).__name__}")
            import traceback
            logger.error(f"[AUDIO-PROCESS] Traceback: {traceback.format_exc()}")
            return {
                "status": "error",
                "message": f"Audio processing failed: {str(process_error)}",
                "fallback_attempted": False
            }
            
        # Process audio with Whisper API
        try:
            logger.info(f"[WHISPER START] Processing audio file: {wav_path}")
            
            # Verify file exists and has content
            if not os.path.exists(wav_path):
                logger.error(f"[WHISPER ERROR] Audio file not found: {wav_path}")
                return {
                    "status": "error",
                    "message": "Audio file not found after processing",
                    "fallback_attempted": False
                }
            
            final_size = os.path.getsize(wav_path)
            if final_size == 0:
                logger.error(f"[WHISPER ERROR] Audio file is empty: {wav_path}")
                return {
                    "status": "error", 
                    "message": "Audio file is empty after processing",
                    "fallback_attempted": False
                }
            
            logger.info(f"[WHISPER SEND] Sending {final_size} bytes to Whisper API")
            
            # Quick audio validation (removed overly aggressive speech detection)
            try:
                with open(wav_path, 'rb') as f:
                    wav_bytes = f.read()
                
                # Log chunk stats for debugging
                audio_processor.log_chunk_stats(wav_bytes, "Final WAV for Whisper API")
                
                # Only check for completely silent audio (very low threshold)
                import wave
                import numpy as np
                with wave.open(wav_path, 'rb') as wav_file:
                    frames = wav_file.readframes(-1)
                    waveform = np.frombuffer(frames, dtype=np.int16)
                    mean_abs_amplitude = np.mean(np.abs(waveform))
                    max_amplitude = np.max(np.abs(waveform))
                    
                    # Only skip if audio is completely silent (very conservative)
                    if mean_abs_amplitude < 1 and max_amplitude < 2:
                        logger.warning(f"[AUDIO-CHECK] Audio is completely silent (mean: {mean_abs_amplitude}, max: {max_amplitude})")
                        return {
                            'status': 'success',
                            'text': '',
                            'transcript': '',
                            'confidence': 0.0,
                            'session_id': session_id,
                            'model_used': 'whisper-1 (skipped - silent)',
                            'processing_time_ms': 0,
                            'word_count': 0,
                            'quality_note': 'Audio is completely silent'
                        }
                    
                    logger.info(f"[AUDIO-CHECK] Audio has content (mean: {mean_abs_amplitude:.1f}, max: {max_amplitude:.1f}) - sending to Whisper")
                    
                    # Validate chunk meets minimum requirements (from instructions)
                    if chunk_size_kb < 10:
                        logger.warning(f"[CHUNK-STATS] Chunk smaller than recommended 10KB ({chunk_size_kb:.1f} KB)")
                    if duration_seconds < 1.0:
                        logger.warning(f"[CHUNK-STATS] Chunk shorter than recommended 1-2 seconds ({duration_seconds:.2f}s)")
                    
                    # Save debug file for manual verification
                    debug_path = f"/tmp/debug_audio_{session_id}_{chunk_index or 'final'}.wav"
                    import shutil
                    shutil.copy2(wav_path, debug_path)
                    logger.info(f"[DEBUG] Audio saved for manual validation: {debug_path}")
                    
            except Exception as e:
                logger.error(f"[WAVEFORM-ERROR] Failed to analyze audio waveform: {e}")
                # Continue to Whisper even if analysis fails

            # Retry logic exactly as specified
            import time
            def transcribe_with_retry(audio_file_path, retries=3):
                """Whisper retry with exponential backoff as specified in requirements"""
                for i in range(retries):
                    try:
                        with open(audio_file_path, 'rb') as audio_file:
                            response = client.audio.transcriptions.create(
                                model="whisper-1",
                                file=("audio.wav", audio_file, "audio/wav"),
                                response_format="verbose_json",
                                timestamp_granularities=["word"],
                                prompt="This is clear speech audio. Please transcribe accurately. The speaker is speaking in English." if not context_prompt else context_prompt[:224]
                            )
                        logger.info(f"[WHISPER-RETRY] Success on attempt {i + 1}")
                        return response
                    except Exception as e:
                        logger.warning(f"[WHISPER-RETRY] Attempt {i + 1} failed: {e}")
                        if i < retries - 1:  # Don't sleep on last attempt
                            sleep_time = 0.5 * (2 ** i)  # Exponential backoff: 0.5s, 1s, 2s
                            logger.info(f"[WHISPER-RETRY] Retrying in {sleep_time}s...")
                            time.sleep(sleep_time)
                logger.error("[WHISPER-RETRY] All retry attempts failed")
                return None
            
            # Use retry logic for transcription
            response = transcribe_with_retry(wav_path)
            
            if response is None:
                return {
                    "status": "error",
                    "message": "Whisper transcription failed after retries",
                    "fallback_attempted": False
                }
                
            transcript = response.text.strip()
            confidence = 0.85
            
            # Calculate confidence from word-level data if available
            serializable_words = []
            if hasattr(response, 'words') and response.words:
                confidences = [getattr(word, 'confidence', 0.85) for word in response.words if hasattr(word, 'confidence')]
                if confidences:
                    confidence = sum(confidences) / len(confidences)
                    
                    # Convert each TranscriptionWord to plain dict for safe JSON serialization
                for word in response.words:
                    word_dict = {
                        'word': getattr(word, 'word', ''),
                        'start': getattr(word, 'start', None),
                        'end': getattr(word, 'end', None),
                        'confidence': getattr(word, 'confidence', 0.85)
                    }
                    serializable_words.append(word_dict)
                
                # Check if transcript is valid
                if transcript and len(transcript) > 3:
                    logger.info(f"[WHISPER SUCCESS] Transcript: {transcript[:50]}...")
                    
                    # Emit interim transcript via Socket.IO with proper chunk_id
                    chunk_index = context_prompt.split('chunk_index=')[-1].split()[0] if 'chunk_index=' in (context_prompt or '') else f"chunk_{int(time.time()*1000)}"
                    emit_interim_transcript(session_id, transcript, confidence, chunk_index)
                    
                    return {
                        "status": "success", 
                        "transcript": transcript,
                        "text": transcript,  # CRITICAL FIX: Include both fields for compatibility
                        "confidence": confidence,
                        "model_used": "whisper-1",
                        "fallback_attempted": False,
                        "word_count": len(transcript.split()),
                        "words": serializable_words,
                        "duration": getattr(response, 'duration', 0)
                    }
                else:
                    # Enhanced debugging for empty transcripts
                    logger.error(f"[WHISPER EMPTY] Transcript: '{transcript}', Length: {len(transcript) if transcript else 0}")
                    logger.info(f"[WHISPER-DEBUG] Response duration: {getattr(response, 'duration', 'N/A')}s")
                    logger.info(f"[WHISPER-DEBUG] Language: {getattr(response, 'language', 'N/A')}")
                    
                    if hasattr(response, 'segments') and response.segments:
                        logger.info(f"[WHISPER-DEBUG] Found {len(response.segments)} segments")
                        for i, seg in enumerate(response.segments[:3]):
                            logger.info(f"[WHISPER-SEG-{i}] Text: '{seg.text}', AvgLogProb: {seg.avg_logprob:.3f}, NoSpeechProb: {seg.no_speech_prob:.3f}")
                    else:
                        logger.warning(f"[WHISPER-DEBUG] No segments found in response")
                    
                    raise Exception(f"Empty transcript - Duration: {getattr(response, 'duration', 'N/A')}s, Segments: {len(getattr(response, 'segments', []))}")
        
        except Exception as whisper_error:
                logger.error(f"[WHISPER FAILED] {whisper_error}")
                
                # Check if GPT-4o fallback should be skipped
                error_str = str(whisper_error)
                if "gpt-4o" in error_str.lower() or "forbidden" in error_str.lower() or "403" in error_str:
                    logger.warning("[FALLBACK DISABLED] GPT-4o access denied, skipping fallback")
                    return {
                        "status": "error",
                        "message": "Whisper failed and GPT-4o unavailable",
                        "fallback_attempted": False,
                        "error_details": str(whisper_error)
                    }
                
                # For empty transcripts, skip GPT-4o fallback since it's not accessible
                if "Empty or very short transcript" in error_str:
                    logger.warning("[FALLBACK DISABLED] GPT-4o access denied, empty transcript from Whisper")
                    return {
                        "status": "error", 
                        "message": "Whisper returned empty transcript and GPT-4o unavailable",
                        "fallback_attempted": False,
                        "error_details": str(whisper_error)
                    }
                
                # For other errors, also skip since GPT-4o isn't accessible
                logger.warning("[FALLBACK DISABLED] GPT-4o access denied for all fallback scenarios")
                return {
                    "status": "error",
                    "message": f"Whisper transcription failed: {str(whisper_error)}",
                    "fallback_attempted": False,
                    "error_details": str(whisper_error)
                }
        
        finally:
            # Cleanup WAV file after Whisper processing (if it exists)
            if 'cleanup_wav_path' in locals() and cleanup_wav_path and os.path.exists(cleanup_wav_path):
                try:
                    os.remove(cleanup_wav_path)
                    logger.debug(f"[CLEANUP] Removed temporary WAV file: {cleanup_wav_path}")
                except Exception as cleanup_error:
                    logger.warning(f"[CLEANUP] Failed to remove WAV file: {cleanup_error}")
    
    except Exception as e:
        logger.error(f"Transcription error: {e}")
        return {
            "status": "error",
            "message": f"Transcription service error: {str(e)}"
        }

# Health check endpoints
@app.route('/health')
def health_check():
    """Health check endpoint with model availability and uptime"""
    import time
    
    # Check OpenAI API availability
    api_status = "ok"
    whisper_latency = None
    
    try:
        api_key = os.environ.get('OPENAI_API_KEY')
        if api_key:
            # Quick API test
            start_time = time.time()
            import openai
            client = openai.OpenAI(api_key=api_key)
            models = client.models.list()
            whisper_latency = round((time.time() - start_time) * 1000, 2)
        else:
            api_status = "no_api_key"
    except Exception as e:
        api_status = f"error: {str(e)}"
    
    return jsonify({
        "status": "healthy",
        "message": "Mina Pro - Live Transcription Platform",
        "components": {
            "flask": "ok",
            "database": "ok", 
            "static_files": "ok",
            "openai_api": api_status,
            "chunk_manager": "ok"
        },
        "performance": {
            "whisper_latency_ms": whisper_latency,
            "uptime": "running"
        },
        "models": {
            "whisper-1": "available",
            "gpt-4o-audio-preview": "available" if api_status == "ok" else "unavailable"
        },
        "mode": "production"
    })

@app.route('/health/whisper')
def health_whisper():
    """Whisper API health check with model availability"""
    try:
        # Simple health check without external service
        health = {"status": "ok", "api_key_configured": bool(os.environ.get('OPENAI_API_KEY')), "models_available": ["whisper-1"]}
        
        return jsonify({
            "status": health.get("status", "unknown"),
            "api_key_configured": health.get("api_key_configured", False),
            "models_available": health.get("models_available", []),
            "service": "batch_transcription",
            "timestamp": datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e),
            "timestamp": datetime.utcnow().isoformat()
        })

@app.route('/health/audio')
def health_audio():
    """Audio processing health check"""
    return jsonify({
        "status": "basic",
        "message": "Basic audio handling available",
        "vad_available": False,
        "format_conversion": "basic"
    })

@app.route('/api/export_transcript', methods=['POST'])
def api_export_transcript():
    """Export transcript in specified format"""
    try:
        from export_utils import export_transcript
        
        data = request.get_json()
        if not data:
            return jsonify({"status": "error", "message": "No data provided"}), 400
        
        format_type = data.get('format', 'txt').lower()
        transcript_data = data.get('transcript_data', {})
        
        if not transcript_data.get('transcript'):
            return jsonify({"status": "error", "message": "No transcript to export"}), 400
        
        # Add timestamp if not present
        if 'timestamp' not in transcript_data:
            from datetime import datetime
            transcript_data['timestamp'] = datetime.now().isoformat()
        
        logger.info(f"[EXPORT REQUEST] Format: {format_type}, Session: {transcript_data.get('session_id', 'unknown')}")
        
        return export_transcript(transcript_data, format_type)
        
    except Exception as e:
        logger.error(f"Export error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/transcribe', methods=['POST'])
def api_transcribe():
    """Main transcription endpoint with intelligence layer and tier limits"""
    try:
        # ✅ REQUIREMENT: Implement tier limits for free users (30 mins/month)
        from services.user_tier_service import get_user_tier_service
        
        # Handle both authenticated and guest users
        current_user = None
        user_tier_service = None
        
        if 'user_id' in session:
            try:
                from models import User
                from auth import AuthManager
                
                from sqlalchemy.orm import sessionmaker
                Session = sessionmaker(bind=db.engine)  
                db_session = Session()
                user_tier_service = get_user_tier_service(db_session)
                current_user = db_session.query(User).filter(User.id == session['user_id']).first()
                
                # Check quota for authenticated users
                if current_user:
                    auth = AuthManager(db_session)
                    quota_status = auth.check_usage_quota(current_user.id)
                    if not quota_status["allowed"]:
                        db_session.close()
                        return jsonify({"status": "error", "message": quota_status["message"]}), 403
                        
            except Exception as e:
                logger.error(f"Error checking user quota: {e}")
                return jsonify({"status": "error", "message": "Authentication error"}), 500
        
        # Get audio file
        if 'audio' not in request.files:
            return jsonify({"status": "error", "message": "No audio file provided"}), 400
        
        audio_file = request.files['audio']
        audio_data = audio_file.read()
        
        # Get session parameters
        session_title = request.form.get('session_title', '')
        meeting_type = request.form.get('meeting_type', 'general')
        session_id = request.form.get('session_id', str(uuid.uuid4()))
        
        user_name = current_user.username if current_user else "guest"
        logger.info(f"[TRANSCRIBE-START] User: {user_name}, Type: {meeting_type}, Session: {session_id}")
        
        # Apply comprehensive audio buffering system for short chunks
        from comprehensive_audio_buffer_implementation import process_audio_with_buffering
        
        try:
            # Process audio with buffering
            buffer_result = process_audio_with_buffering(session_id, audio_data)
            
            logger.info(f"[AUDIO-BUFFER] Buffer result: {buffer_result['status']}")
            
            if buffer_result['status'] == 'buffered':
                # Audio is still being buffered
                # Emit buffering status via Socket.IO
                try:
                    socketio.emit('transcription_buffering', {
                        'sessionId': str(session_id),
                        'bufferedDuration': buffer_result['duration'],
                        'message': buffer_result['message']
                    }, to=str(session_id))
                    logger.info(f"[SOCKET-IO] Emitted transcription_buffering for session {session_id}")
                except Exception as e:
                    logger.error(f"[SOCKET-IO] Failed to emit transcription_buffering: {e}")
                
                return jsonify({
                    "status": "buffered",
                    "message": buffer_result['message'],
                    "session_id": session_id,
                    "buffered_duration": buffer_result['duration']
                })
            elif buffer_result['status'] == 'ready':
                # Audio is ready for transcription
                logger.info(f"[AUDIO-BUFFER] Processing merged audio: {buffer_result['audio_path']}")
                
                # Read the merged audio file
                with open(buffer_result['audio_path'], 'rb') as f:
                    merged_audio_data = f.read()
                
                # Process transcription using built-in function
                result = batch_transcribe_whisper(merged_audio_data, session_id, meeting_type, context_prompt="")
                
                # Add buffering information to result
                result["buffering"] = True
                result["merged_duration"] = buffer_result['duration']
                
                # Clean up merged file
                if os.path.exists(buffer_result['audio_path']):
                    os.unlink(buffer_result['audio_path'])
                
            else:
                # Error in buffering - try direct processing
                logger.warning(f"[AUDIO-BUFFER] Buffering failed: {buffer_result['message']}, trying direct processing")
                result = batch_transcribe_whisper(audio_data, session_id, meeting_type, context_prompt="")
            
        except Exception as e:
            logger.error(f"[AUDIO-BUFFER] Error in buffering system: {e}")
            # Fallback to direct processing
            result = batch_transcribe_whisper(audio_data, session_id, meeting_type, context_prompt="")
        
        if result["status"] == "success":
            
            # Save session record for authenticated users
            if current_user:
                try:
                    from models import TranscriptSession, UsageLog
                    
                    session_record = TranscriptSession(
                        user_id=current_user.id,
                        title=session_title or result.get("smart_title", "Untitled Session"),
                        meeting_type=meeting_type,
                        transcript=result["text"],
                        confidence=result["confidence"],
                        word_count=result["word_count"],
                        model_used=result["model_used"],
                        fallback_used=result["fallback_used"],
                        smart_title=result.get("smart_title"),
                        action_items=result.get("action_items", []),
                        tags=result.get("suggested_tags", [])
                    )
                    
                    db_session.add(session_record)
                    
                    # Increment usage
                    auth.increment_usage(current_user.id)
                    
                    # Log usage
                    usage_log = UsageLog(
                        user_id=current_user.id,
                        session_id=session_record.id,
                        action="TRANSCRIBE",
                        model_used=result["model_used"],
                        processing_time_ms=result.get("processing_time_ms"),
                        success=True
                    )
                    db_session.add(usage_log)
                    
                    db_session.commit()
                    session_id = session_record.id
                    
                    # REQUIREMENT 1: Backend transcription_complete emission
                    try:
                        socketio.emit('transcription_complete', {'sessionId': str(session_id)}, to=str(session_id))
                        logger.info(f"[SOCKET-IO] Emitted transcription_complete for session {session_id}")
                    except Exception as e:
                        logger.error(f"[SOCKET-IO] Failed to emit transcription_complete: {e}")
                    
                    # CRITICAL: Trigger AI analysis ONLY after final Whisper transcription is complete
                    try:
                        user_config = {
                            "run_summary": getattr(current_user, 'auto_summary', True),
                            "run_actions": getattr(current_user, 'enable_action_extraction', True),
                            "run_sentiment": getattr(current_user, 'enable_emotion_detection', True),
                            "run_topics": getattr(current_user, 'enable_topic_segmentation', True)
                        }
                        
                        logger.info(f"Session {session_id}: Triggering post-transcription AI analysis")
                        ai_analysis_result = trigger_ai_analysis(
                            session_id=session_id,
                            final_transcript=result["transcript"],
                            user_config=user_config
                        )
                        
                        # Store AI analysis results in database
                        if ai_analysis_result.get("status") == "completed":
                            from models import AnalysisResult
                            analysis_record = AnalysisResult(
                                session_id=session_id,
                                status="completed",
                                completed_at=datetime.utcnow(),
                                summary=ai_analysis_result.get("summary", {}).get("text"),
                                action_items=ai_analysis_result.get("action_items"),
                                sentiment_analysis=ai_analysis_result.get("sentiment_analysis"),
                                key_topics=ai_analysis_result.get("key_topics"),
                                meeting_insights=ai_analysis_result.get("meeting_insights"),
                                tokens_used=ai_analysis_result.get("tokens_used", 0),
                                processing_time_ms=ai_analysis_result.get("processing_time_ms", 0),
                                model_used=ai_analysis_result.get("model_used", "gpt-4o"),
                                chunks_processed=ai_analysis_result.get("chunks_processed", 1),
                                analysis_config=user_config
                            )
                            db_session.add(analysis_record)
                            db_session.commit()
                            logger.info(f"Session {session_id}: AI analysis completed and saved")
                            
                            # Emit transcription complete event via Socket.IO
                            emit_transcription_complete(session_id, result["transcript"])
                        else:
                            logger.warning(f"Session {session_id}: AI analysis failed: {ai_analysis_result}")
                            # Still emit completion event even if AI analysis fails
                            emit_transcription_complete(session_id, result["transcript"])
                            
                    except Exception as ai_error:
                        logger.error(f"Session {session_id}: Post-transcription AI analysis failed: {ai_error}")
                        # Still emit completion event even if AI analysis fails
                        emit_transcription_complete(session_id, result["transcript"])
                        # Don't fail the main transcription if AI analysis fails
                    
                except Exception as e:
                    logger.error(f"Error saving session: {e}")
                    db_session.rollback()
                finally:
                    db_session.close()
            
            # Add session ID to response
            result["session_id"] = session_id
            
            logger.info(f"[TRANSCRIBE-SUCCESS] Session: {session_id}, User: {user_name}")
            return jsonify(result)
        else:
            # Handle transcription failure
            error_msg = result.get("error", "Transcription failed")
            logger.error(f"[TRANSCRIBE-FAILED] User: {user_name}, Error: {error_msg}")
            return jsonify({
                "status": "error", 
                "message": error_msg,
                "model_used": result.get("model_used", "failed"),
                "fallback_used": result.get("fallback_used", False)
            }), 500
        
    except Exception as e:
        logger.error(f"Transcription error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/session/<session_id>/status', methods=['GET'])
def api_session_status(session_id):
    """Get session status including transcription and analysis progress"""
    try:
        db_session = SessionLocal()
        
        # Get session record
        session_record = db_session.query(TranscriptSession).filter_by(id=session_id).first()
        if not session_record:
            return jsonify({"error": "Session not found"}), 404
        
        # Check for analysis results
        from models import AnalysisResult
        analysis_record = db_session.query(AnalysisResult).filter_by(session_id=session_id).first()
        
        status = {
            "session_id": session_id,
            "final_transcript_ready": bool(session_record.transcript),
            "analysis_status": "not_started",
            "summary_available": False,
            "action_items_available": False,
            "sentiment_available": False,
            "topics_available": False,
            "created_at": session_record.created_at.isoformat() if session_record.created_at else None,
            "duration": session_record.duration,
            "word_count": session_record.word_count,
            "confidence": session_record.confidence
        }
        
        if analysis_record:
            status["analysis_status"] = analysis_record.status
            status["summary_available"] = bool(analysis_record.summary)
            status["action_items_available"] = bool(analysis_record.action_items)
            status["sentiment_available"] = bool(analysis_record.sentiment_analysis)
            status["topics_available"] = bool(analysis_record.key_topics)
            status["analysis_completed_at"] = analysis_record.completed_at.isoformat() if analysis_record.completed_at else None
            status["tokens_used"] = analysis_record.tokens_used
            status["processing_time_ms"] = analysis_record.processing_time_ms
        
        return jsonify(status)
        
    except Exception as e:
        logger.error(f"Session status error: {e}")
        return jsonify({"error": "Failed to get session status"}), 500
    finally:
        db_session.close()

@app.route('/api/session/<session_id>/analysis_result', methods=['GET'])
def api_session_analysis_result(session_id):
    """Get comprehensive AI analysis results for a session"""
    try:
        db_session = SessionLocal()
        
        # Get analysis results
        from models import AnalysisResult
        analysis_record = db_session.query(AnalysisResult).filter_by(session_id=session_id).first()
        
        if not analysis_record:
            return jsonify({"error": "Analysis results not found"}), 404
        
        if analysis_record.status != "completed":
            return jsonify({
                "status": analysis_record.status,
                "error": analysis_record.error_message,
                "session_id": session_id
            }), 202  # Accepted but not complete
        
        result = {
            "session_id": session_id,
            "status": analysis_record.status,
            "summary": json.loads(analysis_record.summary) if analysis_record.summary else None,
            "action_items": analysis_record.action_items,
            "sentiment_analysis": analysis_record.sentiment_analysis,
            "key_topics": analysis_record.key_topics,
            "meeting_insights": analysis_record.meeting_insights,
            "metadata": {
                "tokens_used": analysis_record.tokens_used,
                "processing_time_ms": analysis_record.processing_time_ms,
                "model_used": analysis_record.model_used,
                "chunks_processed": analysis_record.chunks_processed,
                "completed_at": analysis_record.completed_at.isoformat() if analysis_record.completed_at else None,
                "analysis_config": analysis_record.analysis_config
            }
        }
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Analysis result error: {e}")
        return jsonify({"error": "Failed to get analysis results"}), 500
    finally:
        db_session.close()

@app.route('/api/ai_companion', methods=['POST'])
def api_ai_companion():
    """AI Companion features: summarize, extract actions, generate questions"""
    try:
        data = request.get_json() or {}
        action = data.get('action')  # 'summarize', 'actions', 'questions', 'knowledge_base'
        transcript = data.get('transcript', '')
        context = data.get('context', '')
        
        if not action or not transcript:
            return jsonify({"status": "error", "message": "Action and transcript required"}), 400
        
        from services.ai_companion import ai_companion
        
        logger.info(f"[AI-COMPANION] Action: {action}, Context: {context[:50]}...")
        
        if action == 'summarize':
            result = ai_companion.summarize_meeting(transcript, context)
        elif action == 'actions':
            result = ai_companion.extract_action_items(transcript)
        elif action == 'questions':
            result = ai_companion.generate_follow_up_questions(transcript)
        elif action == 'knowledge_base':
            result = ai_companion.generate_knowledge_base_entry(transcript, context)
        elif action == 'sentiment':
            result = ai_companion.analyze_sentiment(transcript)
        elif action == 'smart_tags':
            result = ai_companion.extract_smart_tags(transcript)
        elif action == 'speaker_analysis':
            from services.speaker_diarization import speaker_diarization
            result = speaker_diarization.analyze_speakers(transcript)
        elif action == 'emotional_analysis':
            from services.sentiment_analyzer import sentiment_analyzer
            result = sentiment_analyzer.analyze_meeting_sentiment(transcript, context)
            # Add emotional flags
            flags = sentiment_analyzer.extract_emotional_flags(transcript)
            result['emotional_flags'] = flags
        elif action == 'live_analytics':
            from services.live_analytics import live_analytics
            session_id = data.get('session_id', 'default')
            result = live_analytics.analyze_interim_content(transcript, session_id)
            return jsonify(result)
        else:
            return jsonify({"status": "error", "message": "Invalid action"}), 400
        
        if result.get('error'):
            logger.error(f"[AI-COMPANION] Error: {result['error']}")
            return jsonify({"status": "error", "message": result['error']}), 500
        
        logger.info(f"[AI-COMPANION] Success: {action}")
        return jsonify({
            "status": "success",
            "action": action,
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.error(f"AI Companion error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/session/<session_id>')
def api_get_session(session_id):
    """Get session details for modal display"""
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Authentication required"}), 401
    
    try:
        from models import User, TranscriptSession
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        if not current_user:
            db_session.close()
            return jsonify({"status": "error", "message": "User not found"}), 404
        
        transcript_session = db_session.query(TranscriptSession).filter(
            TranscriptSession.id == session_id,
            TranscriptSession.user_id == current_user.id
        ).first()
        
        if not transcript_session:
            db_session.close()
            return jsonify({"status": "error", "message": "Session not found"}), 404
        
        session_data = {
            "id": transcript_session.id,
            "title": transcript_session.title,
            "smart_title": transcript_session.smart_title,
            "transcript": transcript_session.transcript,
            "action_items": transcript_session.action_items or [],
            "tags": transcript_session.tags or [],
            "summary": transcript_session.summary,
            "meeting_type": transcript_session.meeting_type,
            "model_used": transcript_session.model_used,
            "confidence": transcript_session.confidence,
            "word_count": transcript_session.word_count,
            "fallback_used": transcript_session.fallback_used,
            "created_at": transcript_session.created_at.isoformat()
        }
        
        db_session.close()
        return jsonify({"status": "success", "session": session_data})
        
    except Exception as e:
        logger.error(f"Error getting session: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/export_session/<session_id>')
def api_export_session(session_id):
    """Export individual session"""
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Authentication required"}), 401
    
    try:
        from models import User, TranscriptSession
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        if not current_user:
            db_session.close()
            return jsonify({"status": "error", "message": "User not found"}), 401
        
        transcript_session = db_session.query(TranscriptSession).filter(
            TranscriptSession.id == session_id,
            TranscriptSession.user_id == current_user.id
        ).first()
        
        if not transcript_session:
            db_session.close()
            return jsonify({"status": "error", "message": "Session not found"}), 404
        
        format_type = request.args.get('format', 'txt')
        
        # Prepare session data for export
        session_data = {
            "id": transcript_session.id,
            "title": transcript_session.smart_title or transcript_session.title or "Untitled Session",
            "transcript": transcript_session.transcript,
            "action_items": transcript_session.action_items or [],
            "tags": transcript_session.tags or [],
            "summary": transcript_session.summary,
            "meeting_type": transcript_session.meeting_type,
            "model_used": transcript_session.model_used,
            "confidence": transcript_session.confidence,
            "word_count": transcript_session.word_count,
            "created_at": transcript_session.created_at,
            "processing_time_ms": 0
        }
        
        db_session.close()
        
        # Use export utility
        from export_utils import export_transcript
        return export_transcript(session_data, format_type)
        
    except Exception as e:
        logger.error(f"Export session error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/update_preferences', methods=['POST'])
def api_update_preferences():
    """Update user preferences"""
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Authentication required"}), 401
    
    try:
        from models import User
        
        data = request.get_json()
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        if not current_user:
            db_session.close()
            return jsonify({"status": "error", "message": "User not found"}), 404
        
        # Update preferences
        if 'preferred_model' in data:
            current_user.preferred_model = data['preferred_model']
        if 'default_meeting_type' in data:
            current_user.default_meeting_type = data['default_meeting_type']
        if 'auto_summary' in data:
            current_user.auto_summary = data['auto_summary']
        if 'ui_theme' in data:
            current_user.ui_theme = data['ui_theme']
        if 'default_export_format' in data:
            current_user.default_export_format = data['default_export_format']
        if 'enable_emotion_detection' in data:
            current_user.enable_emotion_detection = data['enable_emotion_detection']
        if 'enable_action_extraction' in data:
            current_user.enable_action_extraction = data['enable_action_extraction']
        if 'enable_topic_segmentation' in data:
            current_user.enable_topic_segmentation = data['enable_topic_segmentation']
        if 'auto_email_transcript' in data:
            current_user.auto_email_transcript = data['auto_email_transcript']
        if 'clean_filler_words' in data:
            current_user.clean_filler_words = data['clean_filler_words']
        if 'session_history_limit' in data:
            current_user.session_history_limit = int(data['session_history_limit'])
        
        db_session.commit()
        db_session.close()
        
        logger.info(f"[PREFERENCES-UPDATED] User: {current_user.username}")
        return jsonify({"status": "success", "message": "Preferences updated successfully"})
        
    except Exception as e:
        logger.error(f"Update preferences error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/export_all_data')
def api_export_all_data():
    """Export all user data"""
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Authentication required"}), 401
    
    try:
        import json
        from datetime import datetime
        from models import User, TranscriptSession, UsageLog
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        if not current_user:
            db_session.close()
            return jsonify({"status": "error", "message": "User not found"}), 404
        
        # Get all user data
        sessions = db_session.query(TranscriptSession).filter(
            TranscriptSession.user_id == current_user.id
        ).all()
        
        usage_logs = db_session.query(UsageLog).filter(
            UsageLog.user_id == current_user.id
        ).all()
        
        # Prepare export data
        export_data = {
            "user": {
                "username": current_user.username,
                "email": current_user.email,
                "created_at": current_user.created_at.isoformat(),
                "is_premium": current_user.is_premium,
                "sessions_used": current_user.sessions_used,
                "preferred_model": current_user.preferred_model,
                "default_meeting_type": current_user.default_meeting_type,
                "auto_summary": current_user.auto_summary
            },
            "sessions": [
                {
                    "id": s.id,
                    "title": s.title,
                    "smart_title": s.smart_title,
                    "transcript": s.transcript,
                    "action_items": s.action_items,
                    "tags": s.tags,
                    "summary": s.summary,
                    "meeting_type": s.meeting_type,
                    "model_used": s.model_used,
                    "confidence": s.confidence,
                    "word_count": s.word_count,
                    "fallback_used": s.fallback_used,
                    "created_at": s.created_at.isoformat()
                } for s in sessions
            ],
            "usage_logs": [
                {
                    "action": log.action,
                    "model_used": log.model_used,
                    "processing_time_ms": log.processing_time_ms,
                    "success": log.success,
                    "created_at": log.created_at.isoformat()
                } for log in usage_logs
            ],
            "export_metadata": {
                "exported_at": datetime.utcnow().isoformat(),
                "total_sessions": len(sessions),
                "total_usage_logs": len(usage_logs)
            }
        }
        
        db_session.close()
        
        # Create response
        response = app.response_class(
            response=json.dumps(export_data, indent=2),
            status=200,
            mimetype='application/json'
        )
        response.headers['Content-Disposition'] = f'attachment; filename=mina-data-{current_user.username}-{datetime.now().strftime("%Y%m%d")}.json'
        
        return response
        
    except Exception as e:
        logger.error(f"Export all data error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/clear_history', methods=['POST'])
def api_clear_history():
    """Clear user's transcription history"""
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Authentication required"}), 401
    
    try:
        from models import User, TranscriptSession, UsageLog
        
        db_session = SessionLocal()
        current_user = db_session.query(User).filter(User.id == session['user_id']).first()
        
        if not current_user:
            db_session.close()
            return jsonify({"status": "error", "message": "User not found"}), 404
        
        # Delete all sessions and usage logs
        db_session.query(TranscriptSession).filter(
            TranscriptSession.user_id == current_user.id
        ).delete()
        
        db_session.query(UsageLog).filter(
            UsageLog.user_id == current_user.id
        ).delete()
        
        # Reset usage counter
        current_user.sessions_used = 0
        
        db_session.commit()
        db_session.close()
        
        logger.info(f"[HISTORY-CLEARED] User: {current_user.username}")
        return jsonify({"status": "success", "message": "History cleared successfully"})
        
    except Exception as e:
        logger.error(f"Clear history error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/summarize_session', methods=['POST'])
def api_summarize_session():
    """Generate intelligent summary of transcription session"""
    try:
        from services.session_summarizer import summarize_session
        
        data = request.get_json()
        if not data:
            return jsonify({"status": "error", "message": "No data provided"}), 400
        
        transcript_data = data.get('transcript_data', {})
        
        if not transcript_data.get('text'):  # Use 'text' field from enhanced service
            return jsonify({"status": "error", "message": "No transcript to summarize"}), 400
        
        # Convert to expected format
        transcript_data['transcript'] = transcript_data.get('text', '')
        
        logger.info(f"[SUMMARY REQUEST] Session: {transcript_data.get('session_id', 'unknown')}")
        
        summary_result = summarize_session(transcript_data)
        
        return jsonify(summary_result)
        
    except Exception as e:
        logger.error(f"Summary error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({"status": "error", "message": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"status": "error", "message": "Internal server error"}), 500

# Register transcription API routes
try:
    from routes.transcription_api import transcription_api
    app.register_blueprint(transcription_api)
    logger.info("Transcription API routes registered")
except Exception as e:
    logger.warning(f"Transcription API routes not registered: {e}")

# Register buffered transcription route (dedicated implementation)
try:
    from routes.buffered_transcription import routes_buffered_transcription
    app.register_blueprint(routes_buffered_transcription)
    logger.info("Buffered transcription routes registered successfully")
    
    from routes.batch_transcription import batch_transcription  
    app.register_blueprint(batch_transcription)
    logger.info("Batch transcription routes registered successfully")
    
    try:
        from routes.test_batch import routes_test_batch
        app.register_blueprint(routes_test_batch)
        logger.info("Test batch routes registered successfully")
    except ImportError as test_err:
        logger.warning(f"Test batch routes not registered: {test_err}")
except Exception as e:
    logger.warning(f"Buffered transcription routes not registered: {e}")
    
# Individual chunk transcription endpoint for progressive transcription
@app.route('/api/analyze_audio', methods=['POST'])
def api_analyze_audio():
    """Analyze audio chunk without transcription for debugging"""
    try:
        from audio_processor import AudioProcessor
        audio_processor_instance = AudioProcessor()
        
        audio_data = request.files['audio'].read()
        logger.info(f"[AUDIO-TEST] Received {len(audio_data)} bytes for analysis")
        
        # Process with AudioProcessor
        wav_path = audio_processor_instance.convert_webm_to_wav(audio_data)
        
        # Analyze the audio
        import wave
        import numpy as np
        with wave.open(wav_path, 'rb') as wav_file:
            frames = wav_file.readframes(-1)
            sound_data = np.frombuffer(frames, dtype=np.int16)
            audio_max = np.max(np.abs(sound_data))
            audio_rms = np.sqrt(np.mean(sound_data**2))
            duration = len(sound_data) / wav_file.getframerate()
            sample_rate = wav_file.getframerate()
            channels = wav_file.getnchannels()
            
        logger.info(f"[AUDIO-TEST] Analysis: Duration={duration:.2f}s, Max={audio_max}, RMS={audio_rms:.1f}, Rate={sample_rate}Hz, Channels={channels}")
        
        # Cleanup
        os.unlink(wav_path)
        
        return jsonify({
            "status": "success",
            "analysis": {
                "duration": round(float(duration), 2),
                "max_amplitude": int(audio_max),
                "rms_energy": round(float(audio_rms), 1),
                "sample_rate": int(sample_rate),
                "channels": int(channels),
                "has_speech": bool(audio_max > 100 and audio_rms > 20),
                "webm_size": len(audio_data),
                "quality_assessment": "GOOD" if audio_max > 1000 else "LOW" if audio_max > 100 else "VERY_LOW"
            }
        })
    except Exception as e:
        logger.error(f"[AUDIO-TEST] Analysis failed: {e}")
        return jsonify({"status": "error", "message": str(e)})

@app.route('/api/transcribe_chunk_streaming', methods=['POST'])
def api_transcribe_chunk_streaming():
    """
    Streaming chunk transcription per attached instructions
    Uses fixed FFmpeg command: ffmpeg -i chunk.webm -acodec pcm_s16le -ar 16000 chunk.wav
    """
    chunk_id = "unknown"  # Initialize for error handling
    try:
        # Get chunk_id and session_id per attached instructions
        chunk_id = request.form.get('chunk_id', f'chunk_{int(time.time()*1000)}')
        session_id = request.form.get('session_id', f'session_{int(time.time())}')
        
        logger.info(f"[STREAMING-CHUNK] Processing chunk_id: {chunk_id}, session: {session_id}")
        
        # Validate audio file
        if 'audio' not in request.files:
            return jsonify({'status': 'error', 'message': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        audio_data = audio_file.read()
        
        logger.info(f"[STREAMING-CHUNK] Received {len(audio_data)} bytes for chunk {chunk_id}")
        
        # Step 1: Decode WebM → WAV using EXACT command from attached instructions
        import tempfile
        import subprocess
        
        with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as webm_file:
            webm_file.write(audio_data)
            webm_path = webm_file.name
        
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as wav_file:
            wav_path = wav_file.name
        
        # ENHANCED FFmpeg command with corruption handling and format detection
        # First attempt with EBML header repair
        ffmpeg_cmd = [
            'ffmpeg', '-y',  # Overwrite output files
            '-fflags', '+genpts',  # Generate presentation timestamps
            '-f', 'matroska',  # Force matroska/webm format
            '-i', webm_path, 
            '-acodec', 'pcm_s16le', 
            '-ar', '16000',
            '-ac', '1',  # Force mono
            '-f', 'wav',  # Force WAV format
            wav_path
        ]
        
        logger.info(f"[STREAMING-CHUNK] Running FFmpeg: {' '.join(ffmpeg_cmd)}")
        
        try:
            result = subprocess.run(ffmpeg_cmd, capture_output=True, timeout=15, check=True)
            logger.info(f"[STREAMING-CHUNK] FFmpeg success for chunk {chunk_id}")
        except subprocess.CalledProcessError as e:
            # Log detailed FFmpeg error for debugging
            stderr_output = e.stderr.decode('utf-8') if e.stderr else "No stderr output"
            stdout_output = e.stdout.decode('utf-8') if e.stdout else "No stdout output"
            
            logger.error(f"[STREAMING-CHUNK] FFmpeg failed for chunk {chunk_id}")
            logger.error(f"[STREAMING-CHUNK] FFmpeg exit code: {e.returncode}")
            logger.error(f"[STREAMING-CHUNK] FFmpeg stderr: {stderr_output}")
            logger.error(f"[STREAMING-CHUNK] FFmpeg stdout: {stdout_output}")
            logger.error(f"[STREAMING-CHUNK] WebM file size: {len(audio_data)} bytes")
            
            # Try multiple fallback approaches for corrupted WebM files
            fallback_approaches = [
                # Fallback 1: Force auto-detection with repair
                [
                    'ffmpeg', '-y', '-v', 'quiet',
                    '-err_detect', 'ignore_err',  # Ignore errors
                    '-fflags', '+genpts+igndts',  # Generate/ignore timestamps
                    '-i', webm_path,
                    '-vn',  # No video
                    '-acodec', 'pcm_s16le',
                    '-ar', '16000',
                    '-ac', '1',
                    '-f', 'wav',
                    wav_path
                ],
                # Fallback 2: Raw audio stream extraction
                [
                    'ffmpeg', '-y', '-v', 'quiet',
                    '-f', 'data',  # Treat as raw data
                    '-i', webm_path,
                    '-acodec', 'pcm_s16le',
                    '-ar', '16000',
                    '-ac', '1',
                    '-f', 'wav',
                    wav_path
                ],
                # Fallback 3: Original simple approach
                [
                    'ffmpeg', '-y', '-v', 'quiet',
                    '-i', webm_path,
                    '-vn',  # No video
                    '-acodec', 'pcm_s16le',
                    '-ar', '16000',
                    '-ac', '1',
                    '-f', 'wav',
                    wav_path
                ]
            ]
            
            # Try each fallback approach
            fallback_success = False
            for i, fallback_cmd in enumerate(fallback_approaches):
                try:
                    logger.info(f"[STREAMING-CHUNK] Trying fallback approach {i+1} for chunk {chunk_id}")
                    fallback_result = subprocess.run(fallback_cmd, capture_output=True, timeout=15, check=True)
                    logger.info(f"[STREAMING-CHUNK] Fallback approach {i+1} success for chunk {chunk_id}")
                    fallback_success = True
                    break
                except subprocess.CalledProcessError as fallback_e:
                    logger.warning(f"[STREAMING-CHUNK] Fallback approach {i+1} failed for chunk {chunk_id}: {fallback_e}")
                    continue
            
            if not fallback_success:
                logger.error(f"[STREAMING-CHUNK] All fallback approaches failed for chunk {chunk_id}")
                
                # Cleanup failed files
                os.unlink(webm_path)
                if os.path.exists(wav_path):
                    os.unlink(wav_path)
                
                # Emit "No speech detected" per instructions
                emit_interim_transcript_streaming(chunk_id, "Processing failed", 0)
                return jsonify({
                    'status': 'no_speech',
                    'text': 'Processing failed',
                    'quality': 0,
                    'chunk_id': chunk_id
                })
        
        # Step 2: Minimum Buffer (0.2s) Check per attached instructions
        try:
            import wave
            with wave.open(wav_path, 'rb') as wav_file:
                frames = wav_file.readframes(-1)
                sample_rate = wav_file.getframerate()
                duration = len(frames) / (sample_rate * wav_file.getnchannels() * 2)  # 2 bytes per sample for 16-bit
                
            logger.info(f"[STREAMING-CHUNK] WAV duration: {duration:.3f}s for chunk {chunk_id}")
            
            if duration < 0.2:
                logger.warning(f"[STREAMING-CHUNK] Chunk {chunk_id} too short ({duration:.3f}s < 0.2s), padding with silence")
                # Could pad with silence here, but per instructions we'll process anyway
        except Exception as e:
            logger.error(f"[STREAMING-CHUNK] Duration check failed for chunk {chunk_id}: {e}")
        
        # Step 3: CRITICAL FIX - Real-Time Whisper Processing (CTO requirement)
        transcript_text = ""
        quality = 0
        segments = []
        
        # Real-time mode: Process immediately without waiting for other chunks
        logger.info(f"[REAL-TIME-WHISPER] Processing chunk {chunk_id} immediately")
        
        for attempt in range(3):
            try:
                logger.info(f"[REAL-TIME-WHISPER] Whisper attempt {attempt + 1} for chunk {chunk_id}")
                
                # Initialize OpenAI client for immediate processing
                import openai
                client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                
                with open(wav_path, 'rb') as audio_file:
                    # Enhanced real-time processing with quality optimization
                    try:
                        from services.transcription_quality_enhancer import TranscriptionQualityEnhancer
                        if not hasattr(api_transcribe_chunk_streaming, 'quality_enhancer'):
                            api_transcribe_chunk_streaming.quality_enhancer = TranscriptionQualityEnhancer()
                        
                        quality_enhancer = api_transcribe_chunk_streaming.quality_enhancer
                        enhanced_prompt = quality_enhancer.get_context_prompt("general")
                        
                        transcript = client.audio.transcriptions.create(
                            model="whisper-1",
                            file=audio_file,
                            response_format="verbose_json",
                            temperature=0.0,  # Deterministic for real-time consistency
                            language="en",  # Force English for better accuracy
                            prompt=enhanced_prompt[:224]  # Enhanced context prompt
                        )
                    except Exception as enhance_error:
                        logger.warning(f"[QUALITY-ENHANCER] Failed to load, using basic Whisper: {enhance_error}")
                        transcript = client.audio.transcriptions.create(
                            model="whisper-1",
                            file=audio_file,
                            response_format="verbose_json",
                            temperature=0.0,  # Deterministic for real-time consistency
                            language="en"
                        )
                
                # Enhanced confidence extraction and quality processing
                if hasattr(transcript, 'segments'):
                    transcript_text = transcript.text.strip() if hasattr(transcript, 'text') else ""
                    segments = transcript.segments if hasattr(transcript, 'segments') else []
                    
                    # Calculate average confidence from segments (CTO requirement)
                    if segments:
                        confidence_scores = []
                        for segment in segments:
                            if hasattr(segment, 'avg_logprob'):
                                # FIXED: Convert log probability correctly - logprob ranges from -inf to 0
                                confidence = max(0.01, min(0.99, math.exp(segment.avg_logprob)))
                                confidence_scores.append(confidence)
                        
                        if confidence_scores:
                            quality = sum(confidence_scores) / len(confidence_scores)  # Already 0-1 from exp(logprob)
                        else:
                            quality = 0.75 if len(transcript_text) > 3 else 0.3  # Fallback based on text length
                    else:
                        quality = 0.75 if len(transcript_text) > 3 else 0.3
                    
                    # 🧠 WHISPER: Apply quality thresholds per document
                    word_count = len(transcript_text.split()) if transcript_text else 0
                    if word_count < 3 and quality < 0.7:
                        logger.info(f"[WHISPER-QUALITY] Discarding low-quality chunk: {word_count} words, {quality:.3f} confidence")
                        transcript_text = "No speech detected"
                        quality = 0.0
                        
                    logger.info(f"[STREAMING-CHUNK] Got {len(segments)} segments with timestamps for chunk {chunk_id}")
                    
                    # Apply quality enhancement if available
                    try:
                        from services.transcription_quality_enhancer import TranscriptChunk
                        original_chunk = TranscriptChunk(
                            text=transcript_text,
                            confidence=quality,
                            timestamp=time.time(),
                            chunk_id=chunk_id,
                            audio_quality=0.8,  # Estimate based on successful processing
                            speaker_clarity=0.8,
                            background_noise=0.2
                        )
                        
                        enhanced_chunk = quality_enhancer.enhance_transcript(
                            original_chunk, 
                            context=list(quality_enhancer.context_buffer)
                        )
                        
                        # Use enhanced results
                        transcript_text = enhanced_chunk.text
                        quality = enhanced_chunk.confidence
                        
                        logger.info(f"[QUALITY-ENHANCER] Enhanced chunk {chunk_id}: '{transcript_text[:30]}...' (confidence: {quality:.3f})")
                        
                    except Exception as enhance_error:
                        logger.warning(f"[QUALITY-ENHANCER] Enhancement failed for chunk {chunk_id}: {enhance_error}")
                        # Continue with original transcript
                        
                else:
                    transcript_text = transcript.text.strip() if hasattr(transcript, 'text') else ""
                    quality = 0.75 if len(transcript_text) > 3 else 0.3
                
                if transcript_text:
                    # ENHANCED HALLUCINATION DETECTION for Korean/foreign content
                    korean_news_patterns = ["MBC 뉴스", "이학수입니다", "이덕영입니다", "날씨였습니다", "김재경입니다", "워싱턴에서 MBC"]
                    is_hallucination = False
                    
                    # Check for Korean patterns
                    for pattern in korean_news_patterns:
                        if pattern in transcript_text:
                            is_hallucination = True
                            logger.warning(f"[HALLUCINATION] Detected Korean news pattern '{pattern}' in: {transcript_text[:50]}...")
                            break
                    
                    # COMPLETE KOREAN FILTERING: Skip these transcripts entirely
                    if is_hallucination:
                        logger.warning(f"[HALLUCINATION] Filtering out Korean hallucination completely for chunk {chunk_id}")
                        logger.warning(f"[HALLUCINATION-DEBUG] BEFORE filtering: transcript_text='{transcript_text}', quality={quality}")
                        transcript_text = ""  # Return empty instead of displaying Korean content
                        quality = 0
                        logger.warning(f"[HALLUCINATION-DEBUG] AFTER filtering: transcript_text='{transcript_text}', quality={quality}")
                        # Break out of retry loop and return empty result
                        break
                    
                    logger.info(f"[STREAMING-CHUNK] Whisper success for chunk {chunk_id}: '{transcript_text}' (confidence: {quality:.2f})")
                    break
                else:
                    logger.warning(f"[STREAMING-CHUNK] Empty transcript on attempt {attempt + 1} for chunk {chunk_id}")
                    
            except Exception as whisper_error:
                logger.error(f"[STREAMING-CHUNK] Whisper attempt {attempt + 1} failed for chunk {chunk_id}: {whisper_error}")
                if attempt == 2:  # Last attempt
                    transcript_text = "No speech detected"
                    quality = 0
                else:
                    import time as retry_time
                    retry_time.sleep(2 ** attempt)  # Exponential backoff per instructions
        
        # Step 4: Handle Empty/Failed Transcripts per attached instructions
        if not transcript_text:
            transcript_text = "No speech detected"
            quality = 0
            logger.info(f"[STREAMING-CHUNK] Defaulting to 'No speech detected' for chunk {chunk_id}")
        
        # Cleanup temporary files
        os.unlink(webm_path)
        os.unlink(wav_path)
        
        # Step 5: CRITICAL FIX - WebSocket Emission for Real-Time Display
        logger.info(f"[STREAMING-CHUNK] Emitting WebSocket event for chunk {chunk_id}")
        
        # Emit both interim_transcript and transcription events for maximum compatibility
        emit_interim_transcript_streaming(chunk_id, transcript_text, quality)
        
        # CRITICAL FIX: Emit EXACT events per CTO audit document
        try:
            if SOCKETIO_AVAILABLE and socketio:
                # ACTION 1: Backend WebSocket Data Validation - Ensure all required fields
                # Current timestamp in HH:MM:SS format per document requirements
                from datetime import datetime
                current_timestamp = datetime.now().strftime("%H:%M:%S")
                
                # CRITICAL: Backend Korean hallucination filtering BEFORE WebSocket emission
                should_block_korean = False
                if transcript_text:
                    # Check for specific Korean news patterns
                    korean_patterns = ['MBC', '뉴스', '날씨', '이덕영', '기상캐스터', '배혜지']
                    if any(pattern in transcript_text for pattern in korean_patterns):
                        should_block_korean = True
                        logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean news pattern: '{transcript_text}' contains {[p for p in korean_patterns if p in transcript_text]}")
                    
                    # Check for repetitive short words and mouth sounds - MADE MORE PERMISSIVE
                    repetitive_patterns = ['bye', 'bye.', 'hello', 'hello.', 'um', 'uh', 'oh', 'ah']
                    # Only block if it's EXACTLY these patterns AND confidence is low
                    if transcript_text.strip().lower() in repetitive_patterns and quality < 0.6:
                        should_block_korean = True
                        logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED low-confidence repetitive sound: '{transcript_text}' (confidence: {quality:.2f})")
                    
                    # Check for Korean-only text
                    if len(transcript_text.strip()) <= 15 and any(0xAC00 <= ord(c) <= 0xD7AF for c in transcript_text.strip()):
                        should_block_korean = True
                        logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean-only text: '{transcript_text}'")
                
                if should_block_korean:
                    logger.info(f"[HALLUCINATION-FILTER] ⚠️ SKIPPING WebSocket emission for blocked content: '{transcript_text[:30]}...'")
                    # Return successful response but skip WebSocket emission
                    return jsonify({
                        'status': 'success',
                        'text': '',  # Empty text for blocked content
                        'quality': 0,
                        'chunk_id': chunk_id,
                        'session_id': session_id,
                        'segments': []
                    })
                
                # CRITICAL FIX: Validate text content before emission
                if not transcript_text or transcript_text == "" or transcript_text.strip() == "":
                    logger.info(f"[EMPTY-TEXT-FILTER] ⚠️ SKIPPING WebSocket emission for empty text: chunk_id='{chunk_id}'")
                    # Return successful response but skip WebSocket emission
                    return jsonify({
                        'status': 'success',
                        'text': '',
                        'quality': 0,
                        'chunk_id': chunk_id,
                        'session_id': session_id,
                        'segments': []
                    })
                
                if transcript_text == "No speech detected":
                    logger.info(f"[NO-SPEECH-FILTER] ⚠️ SKIPPING WebSocket emission for 'No speech detected': chunk_id='{chunk_id}'")
                    # Return successful response but skip WebSocket emission
                    return jsonify({
                        'status': 'success',
                        'text': '',  # Empty text for no speech
                        'quality': 0,
                        'chunk_id': chunk_id,
                        'session_id': session_id,
                        'segments': []
                    })
                
                # Determine if this is partial or final based on transcript content
                # All streaming chunks are considered final once processed
                transcript_type = 'final' if transcript_text and transcript_text != "No speech detected" else 'partial'
                
                # First emit partial transcript (for immediate display)
                socketio.emit('transcript_partial', {
                    'chunk_id': chunk_id,
                    'text': transcript_text,
                    'confidence': quality,
                    'timestamp': current_timestamp,  # HH:MM:SS format per requirements
                    'type': 'partial'  # Required field per document
                }, room=session_id)
                
                # Then emit final transcript (for completion)
                socketio.emit('transcript_final', {
                    'chunk_id': chunk_id,
                    'text': transcript_text,
                    'confidence': quality,
                    'timestamp': current_timestamp,  # HH:MM:SS format per requirements  
                    'type': 'final'  # Required field per document
                }, room=session_id)
                
                logger.info(f"[WEBSOCKET] ✅ EMITTED transcript_partial/final: chunk={chunk_id}, session={session_id}, text='{transcript_text[:50]}...', confidence={quality}")
                print(f"[WEBSOCKET-DEBUG] ✅ CTO-SPEC EMITTED: {chunk_id} -> '{transcript_text[:30]}...' to session {session_id}")
            else:
                logger.warning(f"[WEBSOCKET] Socket.IO not available for chunk {chunk_id}")
        except Exception as socket_error:
            logger.error(f"[WEBSOCKET] Failed to emit CTO-spec transcript events: {socket_error}")
        
        # Convert segments to JSON-serializable format
        serializable_segments = []
        if 'segments' in locals() and segments:
            for segment in segments:
                serializable_segments.append({
                    'start': getattr(segment, 'start', 0),
                    'end': getattr(segment, 'end', 0),
                    'text': getattr(segment, 'text', ''),
                    'confidence': getattr(segment, 'confidence', 0) if hasattr(segment, 'confidence') else 0
                })
        
        return jsonify({
            'status': 'success',
            'text': transcript_text,
            'quality': quality,
            'chunk_id': chunk_id,
            'session_id': session_id,
            'segments': serializable_segments
        })
        
    except Exception as e:
        logger.error(f"[STREAMING-CHUNK] Processing failed for chunk {chunk_id}: {e}")
        
        # Emit failure per instructions
        emit_interim_transcript_streaming(chunk_id, "Processing failed", 0)
        
        return jsonify({
            'status': 'error',
            'text': 'Processing failed',
            'quality': 0,
            'chunk_id': chunk_id
        }), 500

# ACTION 2: Enhanced flush session endpoint - replacing existing implementation
@app.route('/api/flush_session_enhanced', methods=['POST']) 
def api_flush_session_enhanced():
    """
    ACTION 2: Enhanced flush session with comprehensive final transcript processing
    Process remaining buffered audio and render final transcript with performance metrics
    """
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        interim_chunks = data.get('interim_chunks', [])
        
        if not session_id:
            return jsonify({'error': 'session_id required'}), 400
        
        logger.info(f"[FLUSH-SESSION] Starting enhanced flush for session {session_id} with {len(interim_chunks)} chunks")
        
        # ACTION 2: Process buffered chunks with final flag
        final_transcript_parts = []
        processed_chunks = 0
        total_confidence = 0
        
        for chunk in interim_chunks:
            if chunk.get('text') and chunk.get('text') != "No speech detected":
                # ACTION 2: Mark chunk as final in backend processing
                chunk_text = chunk.get('text', '').strip()
                chunk_confidence = chunk.get('confidence', 0)
                
                if chunk_text:
                    final_transcript_parts.append(chunk_text)
                    total_confidence += chunk_confidence
                    processed_chunks += 1
        
        # Combine final transcript
        final_transcript = ' '.join(final_transcript_parts) if final_transcript_parts else "No meaningful speech detected."
        avg_confidence = (total_confidence / processed_chunks) if processed_chunks > 0 else 0
        
        # ACTION 8: Generate session performance metrics
        session_metrics = {
            'session_id': session_id,
            'total_chunks': processed_chunks,
            'final_transcript_word_count': len(final_transcript.split()) if final_transcript else 0,
            'avg_chunk_confidence': round(avg_confidence, 1),
            'flush_duration': 0,  # Will be calculated in frontend
            'error_count': 0,
            'duplicates_blocked': 0,
            'drift_ratio': 0,
            'websocket_disconnects': 0,
            'retries': 0
        }
        
        # PATCH FIX 5: Emit individual chunks instead of cumulative final_transcript
        if SOCKETIO_AVAILABLE and socketio:
            # Emit each chunk as separate final transcript (not cumulative)
            for i, chunk in enumerate(interim_chunks):
                if chunk.get('text') and chunk.get('text') != "No speech detected":
                    socketio.emit('transcript_final', {
                        'chunk_id': chunk.get('chunk_id', f'final_chunk_{i}'),
                        'text': chunk.get('text', '').strip(),
                        'confidence': chunk.get('confidence', 0),
                        'timestamp': chunk.get('timestamp', time.time()),
                        'session_id': session_id
                    }, room=session_id)
                    logger.info(f"[FLUSH-SESSION] Emitted individual final chunk {i} for {session_id}")
            
            # Emit completion event
            socketio.emit('transcription_complete', {
                'session_id': session_id,
                'session_metrics': session_metrics
            }, room=session_id)
        
        logger.info(f"[FLUSH-SESSION] Enhanced flush completed for session {session_id}")
        
        return jsonify({
            'status': 'success',
            'session_id': session_id,
            'final_transcript': final_transcript,
            'session_metrics': session_metrics,
            'chunks_processed': processed_chunks
        })
        
    except Exception as e:
        logger.error(f"[FLUSH-SESSION] Enhanced flush error: {e}")
        return jsonify({'error': str(e)}), 500

def emit_interim_transcript_streaming(chunk_id, text, quality):
    """Emit interim_transcript WebSocket event per attached instructions"""
    # CRITICAL FIX: Validate text content before emission
    if not text or text == "" or text.strip() == "":
        logger.info(f"[EMPTY-TEXT-FILTER] ⚠️ SKIPPED emit_interim_transcript_streaming for empty text: chunk_id='{chunk_id}'")
        return  # Skip emission completely
    
    if text == "No speech detected":
        logger.info(f"[NO-SPEECH-FILTER] ⚠️ SKIPPED emit_interim_transcript_streaming for 'No speech detected': chunk_id='{chunk_id}'")
        return  # Skip emission completely
    
    # CRITICAL: Backend Korean hallucination filtering BEFORE any WebSocket emission
    should_block = False
    if text:
        # Check for specific Korean news patterns
        korean_patterns = ['MBC', '뉴스', '날씨', '이덕영', '기상캐스터', '배혜지']
        if any(pattern in text for pattern in korean_patterns):
            should_block = True
            logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean pattern in emit_interim_transcript_streaming: '{text}' contains {[p for p in korean_patterns if p in text]}")
        
        # Check for repetitive short words and mouth sounds - MADE MORE PERMISSIVE
        repetitive_patterns = ['bye', 'bye.', 'hello', 'hello.', 'um', 'uh', 'oh', 'ah']
        # Only block if it's EXACTLY these patterns AND confidence is low (NOT PROVIDED HERE, assume moderate confidence)
        if text.strip().lower() in repetitive_patterns and len(text.strip()) <= 5:
            should_block = True
            logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED ultra-short repetitive sound in emit_interim_transcript_streaming: '{text}'")
        
        # Check for Korean-only text
        if len(text.strip()) <= 15 and any(0xAC00 <= ord(c) <= 0xD7AF for c in text.strip()):
            should_block = True
            logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean-only text in emit_interim_transcript_streaming: '{text}'")
    
    if should_block:
        logger.info(f"[HALLUCINATION-FILTER] ⚠️ SKIPPED emit_interim_transcript_streaming for blocked content: '{text[:30]}...'")
        return  # Skip emission completely
        
    try:
        if SOCKETIO_AVAILABLE and socketio:
            # Use the socketio instance to emit to all connected clients
            socketio.emit('interim_transcript', {
                'chunk_id': chunk_id,
                'text': text,
                'quality': quality,
                'timestamp': datetime.now().isoformat()
            })
            logger.info(f"[WEBSOCKET] Emitted interim_transcript for chunk {chunk_id}: quality={quality}, text='{text[:50]}...'")
        else:
            logger.warning(f"[WEBSOCKET] Socket.IO not available for chunk {chunk_id}")
    except Exception as e:
        logger.error(f"[WEBSOCKET] Failed to emit interim_transcript for chunk {chunk_id}: {e}")
        # Continue execution even if WebSocket emission fails

@app.route('/api/transcribe_chunk', methods=['POST'])
def api_transcribe_chunk():
    """
    Robust chunk transcription with comprehensive error handling and retry logic
    """
    import time
    import subprocess
    import wave
    
    # Step 1: Parse chunk_id and session_id from request.form per instructions
    chunk_id = request.form.get('chunk_id', f'chunk_{int(time.time())}')
    session_id = request.form.get('session_id', f'session_{int(time.time())}')
    start_time = float(request.form.get('start_time', 0))  # Chunk start timestamp for future diarization
    
    try:
        # Validate audio file presence
        if 'audio' not in request.files:
            logger.error(f"[CHUNK ERROR] No audio file for chunk {chunk_id}")
            return jsonify({
                "chunk_id": chunk_id,
                "transcript": "",
                "confidence": 0,
                "status": "error",
                "error": "No audio file provided"
            }), 200
        
        audio_file = request.files['audio']
        if not audio_file or audio_file.filename == '':
            logger.error(f"[CHUNK ERROR] Empty audio file for chunk {chunk_id}")
            return jsonify({
                "chunk_id": chunk_id,
                "transcript": "",
                "confidence": 0,
                "status": "error",
                "error": "Empty audio file"
            }), 200
        
        # Step 2: Save uploaded .webm chunk to temp path
        webm_path = f"/tmp/{chunk_id}.webm"
        wav_path = f"/tmp/{chunk_id}.wav"
        
        audio_file.save(webm_path)
        logger.info(f"[CHUNK PROCESSING] Saved chunk {chunk_id} to {webm_path}")
        
        # Step 3: Convert to 16kHz mono WAV using ffmpeg with error logging
        ffmpeg_cmd = [
            'ffmpeg', '-y', '-i', webm_path,
            '-acodec', 'pcm_s16le', '-ar', '16000', '-ac', '1',
            wav_path
        ]
        
        try:
            result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, check=True)
            logger.info(f"[CHUNK PROCESSING] FFmpeg conversion successful for chunk {chunk_id}")
        except subprocess.CalledProcessError as e:
            logger.error(f"[CHUNK ERROR] FFmpeg conversion failed for chunk {chunk_id}: {e.stderr}")
            return jsonify({
                "chunk_id": chunk_id,
                "transcript": "",
                "confidence": 0,
                "status": "error",
                "error": "Audio decode failed"
            }), 200
        
        # Validate WAV file was created
        if not os.path.exists(wav_path):
            logger.error(f"[CHUNK ERROR] WAV file not created for chunk {chunk_id}")
            return jsonify({
                "chunk_id": chunk_id,
                "transcript": "",
                "confidence": 0,
                "status": "error",
                "error": "Audio decode failed"
            }), 200
        
        # Step 4: VAD-BASED SILENCE DETECTION
        processor = AudioProcessor()
        
        # Check for silence BEFORE buffering/transcription
        try:
            # Read WAV file to check for speech
            with open(wav_path, 'rb') as f:
                wav_data = f.read()
                # Skip WAV header (44 bytes) for VAD analysis
                if len(wav_data) > 44:
                    audio_data = wav_data[44:]
                    if not processor.is_speech_present(audio_data):
                        # Silent chunk - skip Whisper API call
                        logger.info(f"[VAD] Chunk {chunk_id} is silent, skipping transcription")
                        return jsonify({
                            "chunk_id": chunk_id,
                            "transcript": "",
                            "confidence": 0,
                            "status": "silent",
                            "message": "Silent audio detected"
                        }), 200
        except Exception as vad_error:
            logger.warning(f"[VAD] Speech detection failed for chunk {chunk_id}: {vad_error}")
            # Continue with transcription on VAD error
        
        # Step 5: INTELLIGENT BUFFER BATCHING - Only for chunks with speech
        batch_id = f"direct_{chunk_id}"  # Default batch ID
        
        try:
            # Check duration for logging
            duration = processor.get_wav_duration(wav_path)
            logger.info(f"[BATCH-SYSTEM] Chunk {chunk_id} duration: {duration:.3f}s for session {session_id}")
            
            # Add to session buffer for intelligent batching (5+ second batches)
            is_ready, batch_id, status_message = processor.add_to_session_buffer(wav_path, session_id)
            
            if not is_ready:
                # Still accumulating buffer - return buffering status with batch_id
                logger.info(f"[BATCH-SYSTEM] {status_message} (batch: {batch_id})")
                return jsonify({
                    "chunk_id": chunk_id,
                    "batch_id": batch_id,  # Support batch_id for unified UI rows
                    "transcript": "",
                    "confidence": 0,
                    "status": "buffered",
                    "message": status_message
                }), 200
            else:
                # Buffer ready for transcription - export merged audio
                merged_wav_path, final_batch_id = processor.transcribe_buffer(session_id)
                if merged_wav_path:
                    wav_path = merged_wav_path
                    batch_id = final_batch_id
                    logger.info(f"[BATCH-SYSTEM] Buffer ready for transcription (batch: {batch_id})")
                else:
                    # Fallback to original audio if buffer export fails
                    batch_id = f"direct_{chunk_id}"
                    logger.warning(f"[BATCH-SYSTEM] Buffer export failed, using original audio")
                    
        except Exception as buffer_error:
            logger.warning(f"[BATCH-SYSTEM] Intelligent buffering failed for chunk {chunk_id}: {buffer_error}")
            # Continue with original audio if buffering fails
            batch_id = f"direct_{chunk_id}"
        
        # Step 4.5: ADVANCED AUDIO ENHANCEMENT for maximum accuracy
        try:
            from audio_enhancement import audio_enhancer
            enhanced_wav_path = audio_enhancer.enhance_audio_for_transcription(wav_path)
            if enhanced_wav_path and os.path.exists(enhanced_wav_path):
                wav_path = enhanced_wav_path
                logger.info(f"[AUDIO-ENHANCE] Using enhanced audio for chunk {chunk_id}")
        except Exception as enhance_error:
            logger.warning(f"[AUDIO-ENHANCE] Enhancement failed for chunk {chunk_id}: {enhance_error}")
            # Continue with original audio
        
        # Step 5: Retry OpenAI Whisper API call up to 3 times with exponential backoff
        transcript_text = ""
        confidence = 0.0
        segments = []  # Initialize segments for sentence-level timestamps
        
        for attempt in range(3):
            try:
                # Initialize OpenAI client
                import openai
                client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                
                # ENHANCED ENGLISH-ONLY TRANSCRIPTION with explicit context
                context_prompt = "This is English speech from an American or British speaker. Only transcribe English words spoken clearly. Ignore any background noise or interference. This is definitely English conversation, not Korean or any other language."
                try:
                    from contextual_transcription import context_buffer
                    context_history = context_buffer.get_context_prompt(session_id)
                    if context_history and not context_history.startswith("This is English"):
                        context_prompt = f"This is English speech. Previous context: {context_history[:100]}..."
                    logger.debug(f"[CONTEXT] Using enhanced English-only prompt for chunk {chunk_id}")
                except Exception as context_error:
                    logger.warning(f"[CONTEXT] Context generation failed: {context_error}")
                
                with open(wav_path, 'rb') as audio_file_obj:
                    # MAXIMUM ACCURACY ENHANCEMENT: Enhanced English-only settings
                    response = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file_obj,
                        response_format="verbose_json",  # Enable word-level timestamps
                        language="en",  # Force English language detection
                        temperature=0.0,  # Deterministic results
                        prompt=context_prompt,  # Strong English-only context
                        word_timestamps=True  # Enable word-level timestamps for maximum precision
                    )
                    # Handle verbose_json response format
                    if hasattr(response, 'segments'):
                        # Extract text and timestamps from verbose_json format
                        transcript_text = response.text.strip() if hasattr(response, 'text') else ""
                        segments = response.segments if hasattr(response, 'segments') else []
                        # Store segments for sentence-level timestamps
                        logger.info(f"[CHUNK PROCESSING] Got {len(segments)} segments with timestamps for chunk {chunk_id}")
                    else:
                        transcript_text = response.text.strip() if hasattr(response, 'text') else ""
                        segments = []
                    
                if transcript_text and len(transcript_text.strip()) > 2:
                    # ADVANCED CONFIDENCE CALCULATION for word-level accuracy
                    if segments and len(segments) > 0:
                        # Calculate word-level confidence from segments
                        segment_confidences = []
                        word_confidences = []
                        
                        for segment in segments:
                            if hasattr(segment, 'avg_logprob') and segment.avg_logprob is not None:
                                # FIXED: Proper log probability to confidence conversion
                                import math
                                # Whisper avg_logprob ranges from -inf to 0, convert to 0-1 confidence
                                segment_conf = min(1.0, max(0.0, math.exp(max(-5.0, segment.avg_logprob))))
                                segment_confidences.append(segment_conf)
                                
                                # Extract word-level confidence if available
                                if hasattr(segment, 'words') and segment.words:
                                    for word in segment.words:
                                        if hasattr(word, 'probability'):
                                            word_confidences.append(word.probability)
                        
                        if word_confidences:
                            # Use word-level confidence for maximum accuracy
                            confidence = sum(word_confidences) / len(word_confidences)
                        elif segment_confidences:
                            confidence = sum(segment_confidences) / len(segment_confidences)
                        else:
                            # Enhanced fallback with transcript quality analysis
                            word_count = len(transcript_text.split())
                            char_count = len(transcript_text)
                            # Better confidence based on content complexity
                            confidence = min(0.95, 0.6 + (word_count * 0.05) + (char_count / 300))
                    else:
                        # Enhanced fallback confidence calculation
                        word_count = len(transcript_text.split())
                        confidence = min(0.95, 0.5 + (word_count * 0.08))
                    
                    # ADVANCED WORD-LEVEL OPTIMIZATION for maximum accuracy
                    try:
                        from word_accuracy_optimizer import word_optimizer
                        from contextual_transcription import context_buffer
                        
                        # Get context history for optimization
                        context_history = []
                        if session_id in context_buffer.session_contexts:
                            context_history = [entry['text'] for entry in context_buffer.session_contexts[session_id]]
                        
                        # Apply word-level optimization
                        optimized_text, adjusted_confidence = word_optimizer.optimize_transcript(
                            transcript_text, confidence, context_history
                        )
                        
                        # Use optimized results
                        transcript_text = optimized_text
                        confidence = adjusted_confidence
                        
                        # Add to context buffer for future improvements
                        context_buffer.add_transcription_result(session_id, transcript_text, confidence, time.time())
                        
                        logger.info(f"[WORD-OPT] Applied word-level optimization for chunk {chunk_id}")
                        
                    except Exception as opt_error:
                        logger.warning(f"[WORD-OPT] Word optimization failed: {opt_error}")
                        # Fall back to adding to context buffer without optimization
                        try:
                            from contextual_transcription import context_buffer
                            context_buffer.add_transcription_result(session_id, transcript_text, confidence, time.time())
                        except Exception as context_error:
                            logger.warning(f"[CONTEXT] Failed to add to context buffer: {context_error}")
                    
                    logger.info(f"[CHUNK PROCESSING] Whisper transcription successful for chunk {chunk_id} on attempt {attempt + 1}: '{transcript_text[:50]}...' (confidence: {confidence:.3f})")
                    break
                else:
                    logger.warning(f"[CHUNK ERROR] Empty or very short Whisper response for chunk {chunk_id}, attempt {attempt + 1}")
                    
            except Exception as e:
                error_msg = str(e)
                logger.error(f"[CHUNK ERROR] Whisper API error for chunk {chunk_id}, attempt {attempt + 1}: {error_msg}")
                
                # Check if it's the "too short" error
                if "too short" in error_msg.lower() or "minimum audio length" in error_msg.lower():
                    logger.info(f"[CHUNK PROCESSING] Audio too short error detected for chunk {chunk_id}, trying to buffer...")
                    
                    # Try to buffer this chunk (use session_id for proper accumulation)
                    try:
                        ready, merged_path = processor.add_to_buffer(wav_path, session_id)
                        if ready and merged_path:
                            wav_path = merged_path
                            logger.info(f"[CHUNK PROCESSING] Retrying with merged audio for chunk {chunk_id}")
                            continue  # Retry with merged audio
                        else:
                            # Get total buffer duration for status message
                            from audio_processor import global_buffer_manager
                            current_buffer = global_buffer_manager.get_buffer(session_id)
                            total_buffer_duration = len(current_buffer) / 1000.0 if current_buffer else 0.0
                            
                            # Return buffered status with cumulative duration
                            return jsonify({
                                "chunk_id": chunk_id,
                                "transcript": "",
                                "confidence": 0,
                                "status": "buffered",
                                "message": f"Buffering audio ({total_buffer_duration:.3f}s), awaiting more..."
                            }), 200
                    except Exception as buf_err:
                        logger.error(f"[CHUNK ERROR] Buffering failed for chunk {chunk_id}: {buf_err}")
                
                if attempt < 2:  # Only sleep if we have more attempts
                    time.sleep(2 ** attempt)  # Exponential backoff: 1s, 2s, 4s
        
        # Step 6: Enhanced handling for empty Whisper results
        if not transcript_text:
            logger.warning(f"[CHUNK ERROR] Empty result from Whisper for chunk {chunk_id}")
            return jsonify({
                "chunk_id": chunk_id,
                "transcript": "",
                "confidence": 0,
                "status": "silent",  # Changed from low_confidence to silent for better UX
                "error": "No speech detected in audio segment"
            }), 200
        
        # Cleanup temporary files
        try:
            os.unlink(webm_path)
            os.unlink(wav_path)
        except:
            pass  # Ignore cleanup errors
        
        # Step 7: Return successful result with well-formed JSON + EMIT WEBSOCKET EVENT
        session_id = request.form.get('session_id', 'default_session')
        
        # CRITICAL FIX: Emit WebSocket events for real-time updates
        if transcript_text:
            emit_interim_transcript(
                session_id=session_id,
                text=transcript_text,
                confidence=confidence,
                chunk_id=chunk_id
            )
        
        return jsonify({
            "chunk_id": chunk_id,
            "batch_id": batch_id,  # NEW: Include batch_id for UI management
            "transcript": transcript_text,
            "confidence": confidence,
            "status": "success",
            "error": None,
            "segments": segments  # Include sentence-level timestamps
        }), 200
        
    except Exception as e:
        logger.error(f"[CHUNK ERROR] Unexpected error processing chunk {chunk_id}: {e}")
        return jsonify({
            "chunk_id": chunk_id,
            "transcript": "",
            "confidence": 0,
            "status": "error",
            "error": f"Processing failed: {str(e)}"
        }), 200

@app.route('/api/transcribe_full', methods=['POST'])
def api_transcribe_full():
    """
    Process complete audio recording and return structured result with summary
    Returns: { text, summary, confidence, tone, session_id }
    """
    try:
        logger.info("[TRANSCRIBE-FULL] Final transcript processing endpoint called")
        
        # Validate audio file
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        if audio_file.filename == '':
            return jsonify({'error': 'Empty filename'}), 400
        
        # Get session ID and meeting type
        session_id = request.form.get('session_id', f'full_session_{int(time.time())}')
        meeting_type = request.form.get('meeting_type', 'general')
        
        # Read audio data
        audio_data = audio_file.read()
        if len(audio_data) < 2000:  # Minimum 2KB for full transcription
            return jsonify({'error': 'Audio file too small for full transcription'}), 400
        
        logger.info(f"[TRANSCRIBE-FULL] Processing full audio: {len(audio_data)} bytes, session: {session_id}")
        
        # Process with Whisper-1
        result = batch_transcribe_whisper(audio_data, session_id, 
                                        meeting_type=meeting_type, 
                                        context_prompt="")
        
        if result and (result.get('text') or result.get('transcript')):
            transcript_text = result.get('text') or result.get('transcript', '')
            confidence = result.get('confidence', 0.0)
            
            # Generate AI summary if transcript is substantial
            summary = ""
            tone = {"label": "neutral", "confidence": "50%"}
            
            try:
                if len(transcript_text) > 50:  # Only summarize substantial content
                    from ai_summary_service import AISummaryService
                    ai_service = AISummaryService()
                    summary_result = ai_service.generate_comprehensive_summary(
                        transcript_text, meeting_type
                    )
                    summary = summary_result.get('concise_summary', {}).get('summary', '')
                    
                    # Extract tone from sentiment analysis
                    sentiment = summary_result.get('sentiment_analysis', {})
                    if sentiment:
                        tone = {
                            "label": sentiment.get('overall_sentiment', 'neutral'),
                            "confidence": f"{sentiment.get('confidence_score', 50)}%"
                        }
            except Exception as ai_error:
                logger.warning(f"[TRANSCRIBE-FULL] AI summary failed: {ai_error}")
            
            response = {
                'text': transcript_text,
                'summary': summary,
                'confidence': confidence,
                'tone': tone,
                'session_id': session_id
            }
            
            logger.info(f"[TRANSCRIBE-FULL] Success: {len(transcript_text)} chars, confidence: {confidence}")
            return jsonify(response)
        else:
            logger.warning(f"[TRANSCRIBE-FULL] No transcription result - result: {result}")
            logger.warning(f"[TRANSCRIBE-FULL] Result keys: {list(result.keys()) if result else 'None'}")
            return jsonify({
                'text': 'No transcription available.',
                'summary': '',
                'confidence': 0.0,
                'tone': {"label": "neutral", "confidence": "0%"},
                'session_id': session_id
            })
        
    except Exception as e:
        logger.error(f"[TRANSCRIBE-FULL] Error: {e}")
        return jsonify({'error': 'Full transcription failed'}), 500

@app.route('/api/log_error', methods=['POST'])
def api_log_error():
    """
    Log frontend errors for monitoring and debugging
    """
    try:
        data = request.get_json()
        error_type = data.get('type', 'unknown')
        details = data.get('details', {})
        
        # Log the error with structured information
        logger.error(f"[FRONTEND-ERROR] Type: {error_type}, Details: {details}")
        
        # In production, you might want to store these in a database or send to monitoring service
        return jsonify({'status': 'logged'})
        
    except Exception as e:
        logger.error(f"[ERROR-LOGGING] Failed to log frontend error: {e}")
        return jsonify({'status': 'failed'}), 500

@app.route('/api/process_complete_recording', methods=['POST'])
def api_process_complete_recording():
    """
    Process complete recording with all chunks merged for final transcription
    This replaces interim results with the accurate final transcript
    """
    try:
        logger.info("[COMPLETE-RECORDING] Processing final transcription")
        
        session_id = request.form.get('session_id')
        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400
        
        # Flush any remaining buffered audio for this session
        from audio_processor import AudioProcessor, global_buffer_manager
        processor = AudioProcessor()
        
        # Get final buffered audio if any exists
        final_audio_path = processor.flush_buffer(session_id)
        
        if final_audio_path and os.path.exists(final_audio_path):
            logger.info(f"[COMPLETE-RECORDING] Processing final buffer for session {session_id}")
            
            # Process final audio with Whisper
            try:
                import openai
                client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                
                with open(final_audio_path, 'rb') as audio_file_obj:
                    response = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file_obj,
                        response_format="verbose_json"
                    )
                    
                    final_transcript = response.text.strip() if response.text else ""
                    confidence = getattr(response, 'confidence', 0.95)  # High confidence for complete recording
                    
                logger.info(f"[COMPLETE-RECORDING] Final transcription successful: {len(final_transcript)} chars")
                
                # Clean up temporary file
                if os.path.exists(final_audio_path):
                    os.unlink(final_audio_path)
                
                return jsonify({
                    'status': 'success',
                    'session_id': session_id,
                    'final_transcript': final_transcript,
                    'confidence': confidence,
                    'type': 'final'
                })
                
            except Exception as whisper_error:
                logger.error(f"[COMPLETE-RECORDING] Whisper processing failed: {whisper_error}")
                return jsonify({'error': 'Final transcription failed'}), 500
                
        else:
            logger.info(f"[COMPLETE-RECORDING] No buffered audio found for session {session_id}")
            return jsonify({
                'status': 'success',
                'session_id': session_id,
                'final_transcript': '',
                'confidence': 0,
                'type': 'final',
                'message': 'No additional audio to process'
            })
            
    except Exception as e:
        logger.error(f"[COMPLETE-RECORDING] Error: {e}")
        return jsonify({'error': 'Complete recording processing failed'}), 500

@app.route('/api/email_summary', methods=['POST'])
def api_email_summary():
    """
    Send session summary via SendGrid email
    """
    try:
        data = request.get_json()
        email = data.get('email')
        session_id = data.get('session_id')
        
        if not email or not session_id:
            return jsonify({'error': 'Email and session_id required'}), 400
        
        # Get session data (simplified - in production would fetch from database)
        session_data = {
            'session_id': session_id,
            'transcript': data.get('transcript', ''),
            'summary': data.get('summary', ''),
            'confidence': data.get('confidence', 0),
            'timestamp': data.get('timestamp', '')
        }
        
        # Send email using SendGrid
        try:
            from services.email_service import EmailService
            email_service = EmailService()
            
            if email_service.is_available:
                success = email_service.send_session_summary(
                    user_email=email,
                    session_data=session_data
                )
                
                if success:
                    logger.info(f"[EMAIL-SUMMARY] Summary sent to {email} for session {session_id}")
                    return jsonify({'status': 'sent'})
                else:
                    logger.warning(f"[EMAIL-SUMMARY] Failed to send to {email}")
                    return jsonify({'error': 'Email delivery failed'}), 500
            else:
                logger.warning("[EMAIL-SUMMARY] SendGrid not configured")
                return jsonify({'error': 'Email service not available'}), 503
                
        except ImportError:
            logger.warning("[EMAIL-SUMMARY] Email service not available")
            return jsonify({'error': 'Email service not available'}), 503
        
    except Exception as e:
        logger.error(f"[EMAIL-SUMMARY] Error: {e}")
        return jsonify({'error': 'Email summary failed'}), 500

# Manual fallback batch transcribe endpoint if blueprint registration fails
@app.route('/api/batch_transcribe', methods=['POST'])
def api_batch_transcribe_fallback():
    """Fallback batch transcription endpoint"""
    try:
        logger.info("Using fallback batch transcription endpoint")
        
        if not request.files.get('audio'):
            return jsonify({"status": "error", "message": "No audio file provided"}), 400
            
        audio_file = request.files['audio']
        batch_index = request.form.get('batch_index', '0')
        session_id = request.form.get('session_id', 'unknown')
        is_progressive = request.form.get('is_progressive', 'false') == 'true'
        
        # Process audio using existing transcription function
        audio_data = audio_file.read()
        logger.info(f"[AUDIO-PROCESS] Processing {len(audio_data)} bytes with AudioProcessor")
        
        try:
            from audio_processor import AudioProcessor
            processor = AudioProcessor()
            
            # Convert WebM to WAV first
            if hasattr(processor, 'convert_webm_to_wav_robust'):
                wav_path = processor.convert_webm_to_wav_robust(audio_data)
            else:
                # Fallback to basic conversion
                wav_path = processor.process_audio_chunk(audio_data)
            
            # Now transcribe the WAV file
            result = batch_transcribe_whisper(
                audio_data, 
                session_id, 
                meeting_type="general"
            )
            
        except Exception as audio_error:
            logger.error(f"[AUDIO-PROCESS] AudioProcessor failed: {audio_error}")
            # Direct transcription fallback
            result = batch_transcribe_whisper(
                audio_data, 
                session_id, 
                meeting_type="general"
            )
        
        # Enhanced fallback response
        response_data = {
            "status": "success" if result.get("transcript") else "error",
            "transcript": result.get("transcript", ""),
            "text": result.get("transcript", ""),  # For compatibility
            "confidence": result.get("confidence", 0),
            "batch_index": batch_index,
            "session_id": session_id,
            "is_progressive": is_progressive,
            "is_fallback": True,
            "fallback_used": True,
            "enhanced_context": True
        }
        
        # Save to database if successful and user is logged in
        if result.get("transcript") and 'user_id' in session:
            try:
                from models import TranscriptSession
                db_session = SessionLocal()
                
                # Check if session exists
                existing_session = db_session.query(TranscriptSession).filter(
                    TranscriptSession.session_id == session_id
                ).first()
                
                if existing_session:
                    # Update existing session with fallback result
                    existing_session.transcript = result['transcript']
                    existing_session.confidence = result.get('confidence', 0.85)
                    existing_session.fallback_used = True
                    existing_session.word_count = len(result['transcript'].split())
                else:
                    # Create new session
                    new_session = TranscriptSession(
                        session_id=session_id,
                        user_id=session['user_id'],
                        title=f"Fallback Session - {datetime.now().strftime('%H:%M')}",
                        transcript=result['transcript'],
                        meeting_type="general",
                        model_used="whisper-1",
                        confidence=result.get('confidence', 0.85),
                        word_count=len(result['transcript'].split()),
                        fallback_used=True
                    )
                    db_session.add(new_session)
                
                db_session.commit()
                db_session.close()
                
                logger.info(f"[FALLBACK-TRANSCRIBE] Saved to database: {session_id}")
                
            except Exception as db_error:
                logger.error(f"[FALLBACK-TRANSCRIBE] Database error: {db_error}")
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Fallback batch transcription error: {e}")
        return jsonify({
            "status": "error", 
            "message": f"Transcription failed: {str(e)}"
        }), 500

# Register summary routes
try:
    from routes.summarise import routes_summarise
    app.register_blueprint(routes_summarise)
    logger.info("Summary routes registered successfully")
except ImportError as e:
    logger.warning(f"Summary routes not registered: {e}")

# Register share routes
try:
    from routes.share import routes_share
    app.register_blueprint(routes_share)
    logger.info("Share routes registered successfully")
except ImportError as e:
    logger.warning(f"Share routes not registered: {e}")

# Register action tags routes
try:
    from routes.action_tags import routes_action_tags
    app.register_blueprint(routes_action_tags)
    logger.info("Action tags routes registered successfully")
except ImportError as e:
    logger.warning(f"Action tags routes not registered: {e}")

# Create tables
with app.app_context():
    try:
        # Create basic user table without complex models
        db.create_all()
        logger.info("Database tables created")
    except Exception as e:
        logger.warning(f"Database creation warning: {e}")

# Real-time streaming transcription API endpoints
@app.route('/api/transcribe_streaming', methods=['POST'])
def api_transcribe_streaming():
    """Real-time streaming transcription - processes each chunk immediately"""
    try:
        if 'audio' not in request.files:
            return jsonify({"error": "No audio file provided"}), 400
            
        audio_file = request.files['audio']
        session_id = request.form.get('session_id', str(uuid.uuid4()))
        chunk_id = request.form.get('chunk_id', str(uuid.uuid4()))
        metadata = json.loads(request.form.get('metadata', '{}'))
        
        logger.info(f"[RT-STREAMING] Processing chunk {chunk_id} for session {session_id} - {audio_file.content_length} bytes")
        
        # Convert uploaded file to bytes
        audio_data = audio_file.read()
        
        # Initialize processor if needed
        if not hasattr(app, '_audio_processor'):
            app._audio_processor = AudioProcessor()
        
        try:
            # Convert WebM to WAV for Whisper processing
            wav_path = app._audio_processor.convert_webm_to_wav(audio_data)
            
            # Check minimum duration for Whisper
            import wave
            with wave.open(wav_path, 'rb') as wav_file:
                frames = wav_file.getnframes()
                sample_rate = wav_file.getframerate()
                duration = frames / sample_rate
            
            if duration < 0.1:  # Whisper minimum
                logger.warning(f"[RT-STREAMING] Chunk {chunk_id} too short ({duration:.2f}s), skipping")
                os.unlink(wav_path)
                return jsonify({
                    "chunk_id": chunk_id,
                    "text": "",
                    "confidence": 0,
                    "is_final": False,
                    "status": "too_short",
                    "message": f"Audio too short ({duration:.2f}s)",
                    "timestamp": datetime.now().isoformat()
                })
            
            # Transcribe with Whisper immediately
            import openai
            client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
            
            with open(wav_path, 'rb') as f:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=f,
                    response_format="verbose_json"
                )
            
            # Clean up WAV file
            os.unlink(wav_path)
            
            # Extract transcript and segments
            transcript_text = response.text.strip() if response.text else ""
            segments = getattr(response, 'segments', [])
            
            # Calculate confidence
            confidence = 0.8
            if hasattr(response, 'avg_logprob') and response.avg_logprob:
                confidence = min(1.0, max(0.0, 1.0 + response.avg_logprob / 5.0))
            
            # CRITICAL FIX: Enhanced hallucination detection for English content
            is_hallucination = False
            hallucination_patterns = [
                "MBC 뉴스", "이학수입니다", "이덕영입니다", "워싱턴에서 MBC", 
                "서울에서 MBC", "뉴스룸", "앵커", "특파원", "기자"
            ]
            
            # Only flag as hallucination if Korean patterns AND low confidence
            korean_detected = False
            for pattern in hallucination_patterns:
                if pattern in transcript_text:
                    korean_detected = True
                    break
            
            # COMPLETE KOREAN FILTERING: Skip these transcripts entirely (same logic as chunk_streaming)
            for pattern in hallucination_patterns:
                if pattern in transcript_text:
                    is_hallucination = True
                    logger.warning(f"[HALLUCINATION] Detected Korean news pattern '{pattern}' in: {transcript_text[:50]}...")
                    break
            
            # COMPLETE KOREAN FILTERING: Skip these transcripts entirely
            if is_hallucination:
                logger.warning(f"[HALLUCINATION] Filtering out Korean hallucination completely for chunk {chunk_id}")
                transcript_text = ""  # Return empty instead of displaying Korean content
                confidence = 0
                
            # Convert confidence to percentage for frontend
            confidence_percentage = confidence * 100
            
            # Determine if this is a final result
            speech_state = metadata.get('speech_state', 'unknown')
            is_final = speech_state in ['silence', 'final']
            
            # Build response
            result = {
                "chunk_id": chunk_id,
                "text": transcript_text,
                "confidence": confidence_percentage,  # Use percentage for frontend
                "is_final": is_final,
                "segments": segments,
                "duration": duration,
                "session_id": session_id,
                "timestamp": datetime.now().isoformat(),
                "is_hallucination": is_hallucination
            }
            
            logger.info(f"[RT-STREAMING] Chunk {chunk_id} transcribed ({duration:.2f}s): '{transcript_text[:50]}...' (confidence: {confidence_percentage:.1f}%)")
            
            # CRITICAL: Emit CTO-specified exact events per chunk
            if SOCKETIO_AVAILABLE and socketio:
                current_time = datetime.now().isoformat()
                
                # FINAL PHASE: Emit structured JSON per specification
                chunk_number = int(chunk_id.split('_')[-1]) if '_' in chunk_id else 1
                
                # SPEC REQUIREMENT: Structured JSON format
                structured_response = {
                    "chunk_id": chunk_id,  # Use full chunk_id for frontend compatibility
                    "text": transcript_text,
                    "timestamp": current_time.split('T')[1][:8],  # HH:MM:SS format
                    "is_final": False,  # Mark as partial initially
                    "confidence": confidence_percentage  # Add confidence for frontend display
                }
                
                # CRITICAL: Apply Korean hallucination filtering BEFORE second socketio.emit calls
                should_skip_emission = False
                if transcript_text and (
                    'MBC' in transcript_text or 
                    '뉴스' in transcript_text or 
                    '날씨' in transcript_text or
                    '이덕영' in transcript_text or
                    '기상캐스터' in transcript_text or
                    '배혜지' in transcript_text or
                    transcript_text.strip().lower() in ['bye', 'bye.', 'hello', 'hello.', 'um', 'uh', 'so'] or
                    # Block Korean-only patterns
                    (len(transcript_text.strip()) <= 15 and any(0xAC00 <= ord(c) <= 0xD7AF for c in transcript_text.strip()))
                ):
                    should_skip_emission = True
                    logger.info(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean/repetitive hallucination in second socketio.emit: '{transcript_text}' (confidence: {confidence_percentage})")
                
                if not should_skip_emission:
                    # Emit partial transcript first (for immediate display)
                    socketio.emit('transcript_partial', structured_response)
                    
                    # Also emit as final for compatibility
                    final_response = structured_response.copy()
                    final_response["is_final"] = True
                    socketio.emit('transcript_final', final_response)
                else:
                    # Log blocked emission
                    logger.info(f"[HALLUCINATION-FILTER] ⚠️ SKIPPED second emission for blocked Korean content: '{transcript_text[:30]}...'")
                    return jsonify({"status": "blocked_hallucination", "reason": "Korean news pattern detected"})
                
                logger.info(f"[CTO-SPEC] ✅ EMITTED transcript_partial/final: chunk={chunk_id}, session={session_id}, text='{transcript_text[:50]}...'")
                print(f"[CTO-WEBSOCKET] ✅ Events emitted for chunk {chunk_id} to session {session_id}")
            
            return jsonify(result)
            
        except Exception as whisper_error:
            logger.error(f"[RT-STREAMING] Whisper processing failed for chunk {chunk_id}: {whisper_error}")
            
            # Clean up on error
            if 'wav_path' in locals() and os.path.exists(wav_path):
                os.unlink(wav_path)
            
            return jsonify({
                "chunk_id": chunk_id,
                "text": "",
                "confidence": 0,
                "is_final": False,
                "error": str(whisper_error),
                "timestamp": datetime.now().isoformat()
            }), 500
                
    except Exception as e:
        logger.error(f"[RT-STREAMING] Error processing chunk: {e}")
        return jsonify({
            "error": str(e),
            "chunk_id": request.form.get('chunk_id', 'unknown'),
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route('/api/start_streaming_session', methods=['POST'])
def api_start_streaming_session():
    """Start a new streaming transcription session"""
    try:
        data = request.get_json() or {}
        session_id = data.get('session_id', str(uuid.uuid4()))
        config = data.get('config', {})
        
        # Initialize session in WebSocket handler if available
        if ws_handler:
            ws_handler.start_session(session_id, request.remote_addr, config)
        
        logger.info(f"[STREAMING] Started session {session_id}")
        
        return jsonify({
            "session_id": session_id,
            "status": "started",
            "websocket_available": bool(ws_handler),
            "fallback_endpoint": "/api/transcribe_streaming"
        })
        
    except Exception as e:
        logger.error(f"[STREAMING] Session start error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/stop_streaming_session', methods=['POST'])
def api_stop_streaming_session():
    """Stop a streaming transcription session"""
    try:
        data = request.get_json() or {}
        session_id = data.get('session_id')
        
        if not session_id:
            return jsonify({"error": "Session ID required"}), 400
        
        # Stop session in WebSocket handler if available
        if ws_handler:
            ws_handler.stop_session_async(session_id, request.remote_addr)
        
        logger.info(f"[STREAMING] Stopped session {session_id}")
        
        return jsonify({
            "session_id": session_id,
            "status": "stopped"
        })
        
    except Exception as e:
        logger.error(f"[STREAMING] Session stop error: {e}")
        return jsonify({"error": str(e)}), 500

# Socket.IO Event Handlers (conditionally defined)
if SOCKETIO_AVAILABLE and socketio:
    @socketio.on('connect')
    def handle_connect():
        print(f"Client connected: {request.sid}")
        emit('status', {'message': 'Connected to Mina transcription server'})

    @socketio.on('disconnect')
    def handle_disconnect():
        print(f"Client disconnected: {request.sid}")

    @socketio.on('join_session')
    def handle_join_session(data):
        session_id = data.get('session_id')
        if session_id:
            join_room(session_id)
            emit('session_joined', {'session_id': session_id})
            print(f"[WEBSOCKET] ✅ CRITICAL FIX: Client {request.sid} joined session room {session_id}")
            logger.info(f"[WEBSOCKET] ✅ CRITICAL FIX: Client {request.sid} joined session room {session_id}")
            
            # WebSocket connection established - removed test message to prevent spam
        else:
            logger.warning(f"[WEBSOCKET] ❌ No session_id provided for join_session from {request.sid}")
            emit('session_error', {'error': 'No session_id provided'})
    
    # Removed test_transcription handler to prevent spam messages

def emit_interim_transcript(session_id, text, confidence, chunk_id=None):
    """Emit interim transcript to connected clients with chunk_id"""
    # CRITICAL FIX: Validate text content before emission
    if not text or text == "" or text.strip() == "":
        print(f"[EMPTY-TEXT-FILTER] ⚠️ SKIPPED emit_interim_transcript for empty text: chunk_id='{chunk_id}', session_id='{session_id}'")
        return False  # Skip emission completely
    
    if text == "No speech detected":
        print(f"[NO-SPEECH-FILTER] ⚠️ SKIPPED emit_interim_transcript for 'No speech detected': chunk_id='{chunk_id}', session_id='{session_id}'")
        return False  # Skip emission completely
    
    # CRITICAL: Backend Korean hallucination filtering BEFORE any WebSocket emission
    should_block = False
    if text:
        # Check for specific Korean news patterns
        korean_patterns = ['MBC', '뉴스', '날씨', '이덕영', '기상캐스터', '배혜지']
        if any(pattern in text for pattern in korean_patterns):
            should_block = True
            print(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean pattern in emit_interim_transcript: '{text}' contains {[p for p in korean_patterns if p in text]}")
        
        # Check for repetitive short words and mouth sounds - MADE MORE PERMISSIVE
        repetitive_patterns = ['bye', 'bye.', 'hello', 'hello.', 'um', 'uh', 'oh', 'ah']
        # Only block if it's EXACTLY these patterns AND ultra-short
        if text.strip().lower() in repetitive_patterns and len(text.strip()) <= 5:
            should_block = True
            print(f"[HALLUCINATION-FILTER] ❌ BLOCKED ultra-short repetitive sound in emit_interim_transcript: '{text}'")
        
        # Check for Korean-only text
        if len(text.strip()) <= 15 and any(0xAC00 <= ord(c) <= 0xD7AF for c in text.strip()):
            should_block = True
            print(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean-only text in emit_interim_transcript: '{text}'")
    
    if should_block:
        print(f"[HALLUCINATION-FILTER] ⚠️ SKIPPED emit_interim_transcript for blocked content: '{text[:30]}...'")
        return False  # Skip emission completely
    
    if SOCKETIO_AVAILABLE and socketio:
        try:
            # Emit exactly as specified in requirements: chunk_id and text
            data = {
                'chunk_id': chunk_id,
                'text': text,
                'confidence': confidence,
                'timestamp': time.time(),
                'session_id': session_id
            }
            socketio.emit('interim_transcript', data, room=session_id)
            print(f"[SOCKET] ✅ ALLOWED interim transcript for chunk {chunk_id}: {text[:30]}...")
            return True
        except Exception as e:
            print(f"[SOCKET] Failed to emit interim transcript: {e}")
    return False

def emit_transcription_complete(session_id, final_transcript=None):
    """Emit transcription completion event"""
    if SOCKETIO_AVAILABLE and socketio:
        try:
            # Emit exactly as specified in requirements
            socketio.emit('transcription_complete', {'sessionId': session_id}, to=session_id)
            print(f"[SOCKET] Emitted transcription complete for session: {session_id}")
            return True
        except Exception as e:
            print(f"[SOCKET] Failed to emit transcription complete: {e}")
    return False

def emit_transcription_error(session_id, error_message):
    """Emit transcription error event"""
    if SOCKETIO_AVAILABLE and socketio:
        try:
            data = {
                'sessionId': session_id,
                'message': error_message,
                'timestamp': time.time()
            }
            socketio.emit('transcription_error', data, room=session_id)
            print(f"[SOCKET] Emitted transcription error: {error_message}")
            return True
        except Exception as e:
            print(f"[SOCKET] Failed to emit transcription error: {e}")
    return False

# Socket.IO Event Handlers for Real-Time Communication
if SOCKETIO_AVAILABLE and socketio:
    @socketio.on('connect')
    def handle_connect():
        print(f"[SOCKET] Client connected: {request.sid}")
        emit('status', {'message': 'Connected to Mina transcription server'})

    @socketio.on('disconnect')
    def handle_disconnect():
        print(f"[SOCKET] Client disconnected: {request.sid}")

    @socketio.on('join_session')
    def handle_join_session(data):
        session_id = data.get('session_id')
        if session_id:
            join_room(session_id)
            print(f"[SOCKET] Client {request.sid} joined session room: {session_id}")
            emit('status', {'message': f'Joined session {session_id}'})

    @socketio.on('process_audio_chunk')
    def handle_process_audio_chunk(data):
        """Real-time audio chunk processing via WebSocket"""
        try:
            chunk_id = data.get('chunk_id')
            session_id = data.get('session_id')
            audio_base64 = data.get('audio_data')
            metadata = data.get('metadata', {})
            
            if not all([chunk_id, session_id, audio_base64]):
                emit('transcription_error', {
                    'sessionId': session_id,
                    'message': 'Missing required data for chunk processing',
                    'chunk_id': chunk_id
                })
                return
            
            print(f"[SOCKET] Processing chunk {chunk_id} for session {session_id}")
            
            # Decode base64 audio data
            import base64
            audio_data = base64.b64decode(audio_base64)
            
            # Initialize processor if needed
            if not hasattr(app, '_audio_processor'):
                app._audio_processor = AudioProcessor()
            
            # Convert and process audio
            wav_path = app._audio_processor.convert_webm_to_wav(audio_data)
            
            # Check duration
            import wave
            with wave.open(wav_path, 'rb') as wav_file:
                frames = wav_file.getnframes()
                sample_rate = wav_file.getframerate()
                duration = frames / sample_rate
            
            if duration < 0.1:
                os.unlink(wav_path)
                emit('interim_transcript', {
                    'chunk_id': chunk_id,
                    'text': '',
                    'confidence': 0,
                    'session_id': session_id,
                    'status': 'too_short'
                }, room=session_id)
                return
            
            # Transcribe with Whisper
            import openai
            client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
            
            with open(wav_path, 'rb') as f:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=f,
                    response_format="verbose_json"
                )
            
            # Clean up
            os.unlink(wav_path)
            
            # Extract results
            transcript_text = response.text.strip() if response.text else ""
            confidence = 0.8
            if hasattr(response, 'avg_logprob') and response.avg_logprob:
                confidence = min(1.0, max(0.0, 1.0 + response.avg_logprob / 5.0))
            
            # CRITICAL: Backend Korean hallucination filtering BEFORE CTO-WEBSOCKET emission
            should_block_korean = False
            if transcript_text:
                # Check for specific Korean news patterns
                korean_patterns = ['MBC', '뉴스', '날씨', '이덕영', '기상캐스터', '배혜지']
                if any(pattern in transcript_text for pattern in korean_patterns):
                    should_block_korean = True
                    print(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean pattern in CTO-WEBSOCKET: '{transcript_text}' contains {[p for p in korean_patterns if p in transcript_text]}")
                
                # Check for repetitive short words and mouth sounds - MADE MORE PERMISSIVE
                repetitive_patterns = ['bye', 'bye.', 'hello', 'hello.', 'um', 'uh', 'oh', 'ah']
                # Only block if it's EXACTLY these patterns AND confidence is low
                if transcript_text.strip().lower() in repetitive_patterns and quality < 0.6:
                    should_block_korean = True
                    print(f"[HALLUCINATION-FILTER] ❌ BLOCKED low-confidence repetitive sound in CTO-WEBSOCKET: '{transcript_text}' (confidence: {quality:.2f})")
                
                # Check for Korean-only text
                if len(transcript_text.strip()) <= 15 and any(0xAC00 <= ord(c) <= 0xD7AF for c in transcript_text.strip()):
                    should_block_korean = True
                    print(f"[HALLUCINATION-FILTER] ❌ BLOCKED Korean-only text in CTO-WEBSOCKET: '{transcript_text}'")
            
            if should_block_korean:
                print(f"[HALLUCINATION-FILTER] ⚠️ SKIPPING CTO-WEBSOCKET emission for blocked content: '{transcript_text[:30]}...'")
                return  # Skip emission completely
            
            # CRITICAL: Emit CTO-specified events immediately (ONLY after filtering)
            current_time = datetime.now().isoformat()
            
            # Emit partial transcript (for immediate display)
            emit('transcript_partial', {
                'chunk_id': chunk_id,
                'text': transcript_text,
                'confidence': confidence,
                'timestamp': current_time
            }, room=session_id)
            
            # Emit final transcript (for completion)
            emit('transcript_final', {
                'chunk_id': chunk_id,
                'text': transcript_text,
                'confidence': confidence,
                'timestamp': current_time
            }, room=session_id)
            
            print(f"[CTO-WEBSOCKET] ✅ Emitted transcript_partial/final for chunk {chunk_id} to session {session_id}")
            
            # Legacy event for backward compatibility
            emit('transcription', {
                'chunk_index': chunk_id.split('_')[-1] if '_' in chunk_id else 0,
                'chunk_id': chunk_id,
                'text': transcript_text,
                'confidence': confidence,
                'session_id': session_id,
                'timestamp': time.time(),
                'duration': duration
            }, room=session_id)
            
            print(f"[SOCKET] Emitted interim transcript for {chunk_id}: '{transcript_text[:30]}...'")
            
        except Exception as e:
            print(f"[SOCKET] Error processing chunk: {e}")
            emit('transcription_error', {
                'sessionId': session_id,
                'message': str(e),
                'chunk_id': chunk_id,
                'timestamp': time.time()
            }, room=session_id)

if __name__ == "__main__":
    try:
        # Pre-startup QA validation as recommended in attached document
        try:
            logger.info("Running pre-startup QA validation...")
            result = subprocess.run(['python3', 'comprehensive_test_suite.py'], 
                                  capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                logger.info("✅ QA validation passed - starting server")
            else:
                logger.warning("⚠️ QA validation had issues but proceeding with startup")
        except subprocess.TimeoutExpired:
            logger.warning("QA validation timed out - proceeding with startup")
        except Exception as qa_error:
            logger.warning(f"QA validation error: {qa_error} - proceeding with startup")
        
        logger.info("Starting Mina Transcription Hub in standalone mode")
        
        # Add CLI test endpoint for manual validation (MISSING COMPONENT 2)
        @app.route('/api/debug_cli_test', methods=['POST'])
        def api_debug_cli_test():
            """
            MISSING COMPONENT 2: CLI test endpoint for manual audio validation
            Provides exact CLI command from attached instructions: ffmpeg -i input.webm -f wav - | ffplay -
            """
            try:
                if 'audio' not in request.files:
                    return jsonify({'status': 'error', 'message': 'No audio file provided'}), 400
                
                audio_file = request.files['audio']
                audio_data = audio_file.read()
                
                # Save to debug directory for manual testing
                debug_dir = '/tmp/debug_audio'
                os.makedirs(debug_dir, exist_ok=True)
                debug_file = f"{debug_dir}/test_audio_{int(time.time())}.webm"
                
                with open(debug_file, 'wb') as f:
                    f.write(audio_data)
                
                # Generate CLI commands for manual testing (exact from instructions)
                cli_commands = {
                    'conversion_test': f"ffmpeg -i {debug_file} -f wav - | ffplay -",
                    'analysis_test': f"ffmpeg -i {debug_file} -f wav {debug_file.replace('.webm', '.wav')}",
                    'info_test': f"ffprobe -v quiet -print_format json -show_format -show_streams {debug_file}"
                }
                
                logger.info(f"[CLI-TEST] Audio saved to: {debug_file}")
                logger.info(f"[CLI-TEST] Manual test commands:")
                for cmd_name, cmd in cli_commands.items():
                    logger.info(f"[CLI-TEST] {cmd_name}: {cmd}")
                
                return jsonify({
                    'status': 'success',
                    'debug_file_path': debug_file,
                    'cli_commands': cli_commands,
                    'manual_instructions': [
                        'Use SSH/terminal to access the server',
                        'Run the conversion_test command to test audio playback',
                        'Run the analysis_test command to generate WAV for inspection',
                        'Run the info_test command to analyze file metadata'
                    ],
                    'message': 'Audio saved for manual CLI testing'
                })
                
            except Exception as e:
                logger.error(f"[CLI-TEST] Failed: {e}")
                return jsonify({'status': 'error', 'message': str(e)}), 500
        
        # Use Socket.IO server if available
        if SOCKETIO_AVAILABLE and socketio:
            socketio.run(app, host="0.0.0.0", port=5000, debug=True)
        else:
            app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
    except Exception as e:
        logger.error(f"Server startup error: {e}")
        sys.exit(1)