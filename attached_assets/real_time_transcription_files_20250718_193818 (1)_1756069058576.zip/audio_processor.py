# audio_processor.py

import os
import subprocess
import tempfile
import logging
import uuid
import io
import time
import numpy as np
import wave
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# Import VAD for speech detection
try:
    import webrtcvad
    vad = webrtcvad.Vad(2)  # Aggressiveness level 2 (0-3)
    VAD_AVAILABLE = True
    logger.info("WebRTC VAD loaded successfully")
except ImportError:
    VAD_AVAILABLE = False
    vad = None
    logger.warning("WebRTC VAD not available, using fallback speech detection")

# Global buffer manager to persist state across AudioProcessor instances
class GlobalAudioBufferManager:
    _instance = None
    _buffers = {}  # session_id -> audio buffer
    _buffer_session_ids = {}  # session_id -> current session
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            logger.info("Global audio buffer manager initialized")
    
    def get_buffer(self, session_id: str):
        return self._buffers.get(session_id)
    
    def set_buffer(self, session_id: str, buffer):
        self._buffers[session_id] = buffer
        logger.info(f"[GLOBAL-BUFFER] Set buffer for session {session_id}")
    
    def clear_session(self, session_id: str):
        if session_id in self._buffers:
            del self._buffers[session_id]
            logger.info(f"[GLOBAL-BUFFER] Cleared buffer for session {session_id}")

# Global instance
global_buffer_manager = GlobalAudioBufferManager()

class AudioProcessor:
    def __init__(self):
        self.minimum_size_bytes = 16384  # 16KB minimum for better reliability
        self.sample_rate = 16000
        self.channels = 1
        self.speech_buffer = io.BytesIO()
        self.speech_started = False
        self.chunk_buffer = []  # Buffer for combining small chunks
        self.logger = logger
        
        # TASK 2: Audio Buffering Optimization per attached document requirements
        self.session_buffers = {}  # session_id -> {'audio_segments': [], 'total_duration': float, 'batch_id': str}
        self.batch_counters = {}  # session_id -> batch counter
        
        # 🔉 AUDIO CHUNKING: Ensure chunks are 1-3 seconds long with overlap
        self.MIN_CHUNK_DURATION = 0.75  # 750ms minimum chunk threshold per document
        self.MAX_CHUNK_DURATION = 3.0   # 3 seconds maximum per document
        self.CHUNK_OVERLAP = 0.2        # 200ms overlap between chunks
        self.SILENCE_TIMEOUT = 2.0      # Silence detection timeout
        
        # ⚙️ WEBSOCKET: Queue and throttle sendChunk() calls
        self.chunk_queue = []
        self.processing_chunks = set()
        self.retry_counts = {}          # Track retry attempts per chunk (max 2 attempts)
        self.MAX_RETRIES = 2            # Maximum retry attempts per document
        
        # 🧠 WHISPER: String similarity and duplicate suppression
        self.last_chunk_text = ""       # For Levenshtein distance comparison
        self.confidence_threshold = 0.7  # 70% confidence threshold per document
        self.min_words_threshold = 3    # Under 3 words threshold per document
        
        # TASK 2: Document requirement: "Only flush chunk if: Duration > 5 seconds OR user is silent for > 2 seconds"
        self.MIN_FLUSH_DURATION = 5.0  # 5s minimum per document
        
        # TASK 2: Document requirement: "Tune VAD sensitivity if needed to avoid 1-word fragments like 'you'"
        self.vad_sensitivity = 0.5  # Reduced to avoid single word fragments
        
        # Buffer tracking for session management
        self.last_speech_time = {}  # session_id -> last speech timestamp
        self.buffer_start_time = {}  # session_id -> buffer start time
        self.MIN_CHUNK_DURATION = 5.0  # Document: "Duration > 5 seconds"
        self.silence_timeout_seconds = 2.0  # Document requirement: OR user silent for > 2s
        self.vad_sensitivity = 0.5  # Tunable VAD sensitivity to avoid 1-word fragments
        
        # ADVANCED AUDIO QUALITY ENHANCEMENT SETTINGS
        self.target_sample_rate = 16000  # Whisper optimal sample rate
        self.target_channels = 1  # Mono for consistency
        self.noise_reduction_enabled = True
        self.audio_normalization = True  # Enable audio level normalization
        self.voice_enhancement = True  # Enhanced voice processing
        
        # Legacy compatibility
        self.audio_buffer = None  
        self.buffer_session_id = None
        self.chunk_buffers = {}  # Per-session buffering system
        
        # Import PyDub for audio manipulation
        try:
            from pydub import AudioSegment
            self.AudioSegment = AudioSegment
            self.pydub_available = True
            logger.info("PyDub loaded successfully for audio buffering")
        except ImportError:
            self.AudioSegment = None
            self.pydub_available = False
            logger.warning("PyDub not available, audio buffering disabled")

    def is_valid_chunk(self, audio_data: bytes) -> bool:
        return len(audio_data) >= self.minimum_size_bytes
    
    def is_speech_present(self, audio_bytes: bytes) -> bool:
        """
        Enhanced VAD-based speech detection for graceful silence handling
        Returns True if speech detected, False if silent/background noise
        """
        try:
            # Convert bytes to waveform for analysis
            waveform = np.frombuffer(audio_bytes, dtype=np.int16)
            
            # Calculate amplitude statistics
            mean_amplitude = np.mean(np.abs(waveform))
            max_amplitude = np.max(np.abs(waveform)) if len(waveform) > 0 else 0
            rms = np.sqrt(np.mean(waveform**2))
            
            # Very permissive thresholds - only filter truly silent audio
            silence_threshold = 5   # Only filter completely dead audio
            speech_threshold = 10   # Very low threshold to allow most content through
            
            # Only reject completely silent audio
            if mean_amplitude < silence_threshold and max_amplitude < 10:
                logger.info(f"[VAD] Complete silence detected: mean_amp={mean_amplitude:.2f}, max_amp={max_amplitude:.2f}")
                return False
            
            # Use WebRTC VAD if available for more accurate detection
            if VAD_AVAILABLE and vad and len(audio_bytes) > 320:
                try:
                    # VAD requires 16kHz, 16-bit PCM in specific frame sizes
                    sample_rate = 16000
                    frame_duration_ms = 20  # 20ms frames
                    frame_size = int(sample_rate * frame_duration_ms / 1000) * 2  # bytes
                    
                    speech_frames = 0
                    total_frames = 0
                    
                    # Process audio in 20ms frames
                    for i in range(0, len(audio_bytes) - frame_size, frame_size):
                        frame = audio_bytes[i:i + frame_size]
                        if vad.is_speech(frame, sample_rate):
                            speech_frames += 1
                        total_frames += 1
                    
                    # Need at least 20% speech frames to consider as speech
                    speech_ratio = speech_frames / max(total_frames, 1)
                    has_speech = speech_ratio > 0.2
                    
                    logger.info(f"[VAD] WebRTC result: speech_ratio={speech_ratio:.2%}, mean_amp={mean_amplitude:.2f}, has_speech={has_speech}")
                    return has_speech
                    
                except Exception as vad_error:
                    logger.debug(f"[VAD] WebRTC VAD failed, using energy-based: {vad_error}")
            
            # Very permissive fallback - allow most audio through
            has_content = mean_amplitude > speech_threshold or max_amplitude > 20
            logger.info(f"[VAD] Permissive check: mean_amp={mean_amplitude:.2f}, max_amp={max_amplitude}, has_content={has_content}")
            
            return has_content
            
        except Exception as e:
            logger.error(f"[VAD] Speech detection error: {e}")
            return True  # Conservative: assume speech on error to avoid missing content
    
    def log_chunk_stats(self, audio_bytes: bytes, description: str = ""):
        """
        Log byte size and audio stats for debugging - from attached instructions
        """
        try:
            size_kb = len(audio_bytes) / 1024
            logger.info(f"[CHUNK-DEBUG] {description} - Size: {size_kb:.1f} KB ({len(audio_bytes)} bytes)")
            
            # Only analyze if it looks like WAV data (has proper header)
            if len(audio_bytes) > 44:  # WAV header is 44 bytes
                try:
                    waveform = np.frombuffer(audio_bytes[44:], dtype=np.int16)  # Skip WAV header
                    if len(waveform) > 0:
                        duration_seconds = len(waveform) / self.sample_rate
                        logger.info(f"[CHUNK-DEBUG] Duration: {duration_seconds:.2f}s, Samples: {len(waveform)}")
                except:
                    logger.debug(f"[CHUNK-DEBUG] Could not analyze waveform for {description}")
            
        except Exception as e:
            logger.warning(f"[CHUNK-DEBUG] Stats logging failed: {e}")

    def convert_webm_to_wav_legacy(self, audio_data: bytes) -> str:
        """Convert webm bytes to wav file using temporary file method for better reliability"""
        from pathlib import Path
        
        # Create output directory if it doesn't exist
        output_dir = "temp_audio"
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        webm_path = None
        output_path = None
        
        try:
            # Write to temporary WebM file first (more reliable than stdin pipe)
            with tempfile.NamedTemporaryFile(delete=False, suffix='.webm', dir=output_dir) as webm_file:
                webm_file.write(audio_data)
                webm_file.flush()
                webm_path = webm_file.name

            # Use tempfile to write WAV output
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav", dir=output_dir) as temp_output:
                output_path = temp_output.name

            # Build FFmpeg command with maximum error tolerance for corrupted WebM
            cmd = [
                "ffmpeg", "-y",
                "-err_detect", "ignore_err",  # Ignore minor container errors
                "-fflags", "+genpts+igndts+discardcorrupt",  # Generate PTS, ignore DTS, discard corrupt packets
                "-f", "matroska,webm",  # Force WebM format detection
                "-i", webm_path,
                "-ar", str(self.sample_rate),
                "-ac", str(self.channels),
                "-c:a", "pcm_s16le",
                "-avoid_negative_ts", "make_zero",
                "-max_muxing_queue_size", "1024",
                "-analyzeduration", "1000000",  # Increase analysis duration
                "-probesize", "1000000",  # Increase probe size
                "-f", "wav",
                output_path
            ]

            logger.info(f"[FFMPEG FILE] Processing {len(audio_data)} bytes from {webm_path}")
            
            # ENHANCED FFMPEG LOGGING - As specified in attached instructions
            logger.info(f"[FFMPEG-CMD] Command: {' '.join(cmd)}")
            logger.info(f"[FFMPEG-INPUT] Input size: {len(audio_data)} bytes")
            logger.info(f"[FFMPEG-INPUT] WebM file: {webm_path} (exists: {os.path.exists(webm_path)})")
            
            # Run subprocess with enhanced logging
            result = subprocess.run(cmd, capture_output=True, timeout=15, check=True)
            
            # Log FFmpeg output details (from instructions)
            if result.stderr:
                stderr_text = result.stderr.decode()
                logger.info(f"[FFMPEG-STDERR] {stderr_text}")
            if result.stdout:
                stdout_text = result.stdout.decode()
                logger.info(f"[FFMPEG-STDOUT] {stdout_text}")
                
            # Validate output file with detailed logging
            output_size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
            logger.info(f"[FFMPEG-OUTPUT] Output file: {output_path} (size: {output_size} bytes)")
            
            # Log conversion ratio for debugging
            if output_size > 0:
                ratio = output_size / len(audio_data)
                logger.info(f"[FFMPEG-RATIO] Conversion ratio: {ratio:.2f} (output/input)")
            
            # Ensure output has valid WAV content (from instructions)
            if output_size == 0:
                logger.error(f"[FFMPEG-ERROR] Output file is 0 bytes - conversion failed silently")
                raise Exception("FFmpeg produced 0-byte output file")
            elif output_size < 44:
                logger.error(f"[FFMPEG-ERROR] Output file too small ({output_size} bytes) - incomplete WAV header")
                raise Exception(f"FFmpeg output too small: {output_size} bytes")
            
            # Clean up temporary WebM file
            if webm_path and os.path.exists(webm_path):
                os.unlink(webm_path)
                
            # Validate output file
            if os.path.exists(output_path) and os.path.getsize(output_path) > 44:  # WAV header is 44 bytes
                logger.info(f"[FFMPEG SUCCESS] Converted to: {output_path}")
                return output_path
            else:
                raise Exception("FFmpeg produced empty or invalid WAV file")
                
        except subprocess.CalledProcessError as e:
            stderr_msg = e.stderr.decode() if e.stderr else "No stderr available"
            logger.warning(f"FFmpeg conversion failed, retrying with fallback approach")
            
            # Retry mechanism: generate silent audio as fallback
            logger.info(f"[FFMPEG RETRY] Attempting silent audio fallback")
            try:
                fallback_cmd = [
                    "ffmpeg", "-y",
                    "-f", "lavfi", "-i", f"anullsrc=channel_layout=mono:sample_rate={self.sample_rate}",
                    "-t", "1.0",  # 1 second of silence
                    "-c:a", "pcm_s16le",
                    "-f", "wav",
                    output_path
                ]
                subprocess.run(fallback_cmd, capture_output=True, timeout=10, check=True)
                
                if os.path.exists(output_path) and os.path.getsize(output_path) > 44:
                    logger.info(f"[FFMPEG RETRY] Generated silent audio successfully")
                    # Clean up corrupted WebM file
                    if webm_path and os.path.exists(webm_path):
                        os.unlink(webm_path)
                    return output_path
                    
            except Exception as fallback_error:
                logger.error(f"[FFMPEG RETRY] Silent audio generation failed: {fallback_error}")
            
            # Clean up on error
            for temp_file in [webm_path, output_path]:
                if temp_file and os.path.exists(temp_file):
                    os.unlink(temp_file)
            raise Exception(f"FFmpeg conversion failed (code {e.returncode}): {stderr_msg}")
        except subprocess.TimeoutExpired:
            logger.error("FFmpeg conversion timed out")
            # Clean up on timeout
            for temp_file in [webm_path, output_path]:
                if temp_file and os.path.exists(temp_file):
                    os.unlink(temp_file)
            raise Exception("FFmpeg conversion timed out")
        except Exception as e:
            logger.error(f"Audio conversion error: {str(e)}")
            # Clean up on any error
            for temp_file in [webm_path, output_path]:
                if temp_file and os.path.exists(temp_file):
                    os.unlink(temp_file)
            raise
        except subprocess.CalledProcessError as e:
            logger.error(f"FFmpeg conversion failed (code {e.returncode}): {e.stderr.decode()}")
            raise RuntimeError(f"FFmpeg conversion failed (code {e.returncode}): {e.stderr.decode()}")

    def process_audio_chunk(self, audio_data: bytes) -> str:
        """Process audio chunk and return path to processed WAV file"""
        if not self.is_valid_chunk(audio_data):
            raise ValueError(f"Audio chunk too small: {len(audio_data)} bytes (minimum {self.minimum_size_bytes})")
        
        return self.convert_webm_to_wav_robust(audio_data)

    def cleanup_temp_file(self, filepath: str):
        """Clean up temporary file"""
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
                logger.debug(f"[CLEANUP] Removed temporary file: {filepath}")
        except Exception as e:
            logger.warning(f"[CLEANUP] Failed to remove {filepath}: {e}")

    def has_speech_content(self, audio_data: bytes, sample_rate: int = 16000) -> bool:
        """
        Detect speech content in audio data using WebRTC VAD or fallback heuristics
        
        Args:
            audio_data: Raw audio bytes
            sample_rate: Sample rate (default 16000)
            
        Returns:
            True if speech is detected, False otherwise
        """
        if not VAD_AVAILABLE or not vad:
            # Fallback heuristic: check file size and basic audio characteristics
            logger.debug(f"VAD unavailable, using size heuristic: {len(audio_data)} bytes")
            if len(audio_data) < 8000:  # Very small chunks likely silent
                return False
            
            # Check for WebM structure as additional validation
            if b'\x1a\x45\xdf\xa3' in audio_data[:1024]:  # EBML header present
                return True
            
            return len(audio_data) > 12000  # Reasonable size threshold
        
        try:
            # Convert WebM to WAV for VAD analysis
            wav_path = self.convert_webm_to_wav(audio_data)
            if not wav_path or not os.path.exists(wav_path):
                logger.warning("Failed to convert audio for VAD analysis")
                return len(audio_data) > 8000
            
            # Read WAV file for VAD
            with open(wav_path, 'rb') as f:
                # Skip WAV header (44 bytes)
                f.seek(44)
                audio_bytes = f.read()
            
            # Clean up temp file
            self.cleanup_temp_file(wav_path)
            
            if len(audio_bytes) % 2 != 0:
                audio_bytes = audio_bytes[:-1]  # Ensure even length
            
            # Process in 20ms frames (320 bytes at 16kHz, 16-bit)
            frame_duration = 20  # ms
            frame_size = int(sample_rate * frame_duration / 1000) * 2  # 2 bytes per sample
            
            speech_frames = 0
            total_frames = 0
            
            for i in range(0, len(audio_bytes) - frame_size, frame_size):
                frame = audio_bytes[i:i + frame_size]
                if len(frame) == frame_size:
                    try:
                        is_speech = vad.is_speech(frame, sample_rate)
                        if is_speech:
                            speech_frames += 1
                        total_frames += 1
                    except Exception as e:
                        logger.debug(f"VAD frame analysis failed: {e}")
                        continue
            
            if total_frames == 0:
                return len(audio_data) > 8000
            
            speech_ratio = speech_frames / total_frames
            has_speech = speech_ratio > 0.1  # At least 10% speech frames
            
            logger.debug(f"VAD analysis: {speech_frames}/{total_frames} frames contain speech ({speech_ratio:.2%})")
            return has_speech
            
        except Exception as e:
            logger.warning(f"VAD analysis failed: {e}")
            return len(audio_data) > 8000
    
    def process_buffered_audio(self, audio_chunk: bytes) -> tuple[bytes, bool]:
        """
        Process incoming audio with buffering and VAD-driven segmentation
        
        Args:
            audio_chunk: Incoming audio chunk
            
        Returns:
            Tuple of (buffered_audio, should_transcribe)
        """
        # Add chunk to buffer
        self.speech_buffer.write(audio_chunk)
        
        # Check if current chunk contains speech
        has_speech = self.has_speech_content(audio_chunk)
        
        if has_speech and not self.speech_started:
            # Speech started
            self.speech_started = True
            logger.info("Speech segment started")
            return b'', False
            
        elif not has_speech and self.speech_started:
            # Speech ended - return buffered audio for transcription
            self.speech_started = False
            buffered_audio = self.speech_buffer.getvalue()
            self.speech_buffer = io.BytesIO()  # Reset buffer
            logger.info(f"Speech segment ended, buffered {len(buffered_audio)} bytes for transcription")
            return buffered_audio, True
            
        elif self.speech_started and len(self.speech_buffer.getvalue()) > 160000:  # ~10 seconds at 16kHz
            # Buffer too large, force transcription
            buffered_audio = self.speech_buffer.getvalue()
            self.speech_buffer = io.BytesIO()  # Reset buffer
            logger.info(f"Buffer size limit reached, forcing transcription of {len(buffered_audio)} bytes")
            return buffered_audio, True
        
        # Continue buffering
        return b'', False

    def has_speech_content_wav(self, wav_path: str, energy_threshold: float = 300) -> bool:
        """
        Enhanced speech detection using audio energy analysis
        
        Args:
            wav_path: Path to WAV file
            energy_threshold: Energy threshold for speech detection
            
        Returns:
            True if speech is detected, False otherwise
        """
        try:
            with wave.open(wav_path, 'rb') as wav:
                frames = wav.readframes(wav.getnframes())
                samples = np.frombuffer(frames, dtype=np.int16)
                energy = np.sqrt(np.mean(samples**2))
                has_speech = energy > energy_threshold
                logger.debug(f"Audio energy analysis: {energy:.2f} (threshold: {energy_threshold}) - Speech detected: {has_speech}")
                return has_speech
        except Exception as e:
            logger.error(f"Error in WAV speech detection: {e}")
            return False

    def buffer_chunk(self, chunk_data: bytes) -> None:
        """Buffer small chunks for later combination"""
        self.chunk_buffer.append(chunk_data)
        logger.debug(f"Buffered chunk: {len(chunk_data)} bytes. Total buffered chunks: {len(self.chunk_buffer)}")

    def flush_buffered_chunks(self) -> bytes:
        """Combine and return all buffered chunks"""
        if not self.chunk_buffer:
            return b''
        
        combined = b''.join(self.chunk_buffer)
        chunk_count = len(self.chunk_buffer)
        self.chunk_buffer.clear()
        logger.info(f"Flushed {chunk_count} buffered chunks into {len(combined)} bytes")
        return combined

    def should_buffer_chunk(self, chunk_data: bytes, min_size: int = 32768) -> bool:
        """Check if chunk should be buffered (too small for reliable transcription)"""
        current_buffer_size = sum(len(chunk) for chunk in self.chunk_buffer)
        total_size = len(chunk_data) + current_buffer_size
        
        if len(chunk_data) < min_size and total_size < min_size:
            return True
        return False
    
    def convert_webm_to_wav(self, audio_data: bytes) -> str:
        """Convert WebM bytes to mono 16kHz WAV using ffmpeg with comprehensive validation"""
        return self.convert_webm_to_wav_robust(audio_data)
    
    def validate_webm_chunk(self, audio_data: bytes) -> tuple[bool, str]:
        """
        Validate WebM chunk before processing
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if len(audio_data) < 1024:  # Minimum viable WebM size
            return False, f"Chunk too small: {len(audio_data)} bytes"
        
        # Check for WebM EBML header
        if not audio_data.startswith(b'\x1a\x45\xdf\xa3'):
            # Try to find EBML header in first 512 bytes
            ebml_found = False
            for i in range(min(512, len(audio_data) - 4)):
                if audio_data[i:i+4] == b'\x1a\x45\xdf\xa3':
                    ebml_found = True
                    break
            
            if not ebml_found:
                return False, "No valid EBML header found"
        
        return True, "Valid WebM chunk"

    def convert_webm_to_wav_robust(self, audio_data: bytes) -> str:
        """Convert WebM bytes to mono 16kHz WAV using ffmpeg with comprehensive validation"""
        import tempfile
        import subprocess
        import os
        
        # Validate chunk first
        is_valid, error_msg = self.validate_webm_chunk(audio_data)
        if not is_valid:
            raise Exception(f"Invalid WebM chunk: {error_msg}")
        
        logger.info(f"[WEBM→WAV] Processing {len(audio_data)} bytes (validated)")
        
        # Create temporary files with proper cleanup
        webm_fd, webm_path = tempfile.mkstemp(suffix='.webm')
        wav_fd, wav_path = tempfile.mkstemp(suffix='.wav')
        
        try:
            # Write WebM data with forced sync
            with os.fdopen(webm_fd, 'wb') as f:
                f.write(audio_data)
                f.flush()
                os.fsync(f.fileno())  # Force write to disk
            
            os.close(wav_fd)  # Close WAV file descriptor
            
            # Enhanced FFmpeg command with better error handling and minimum duration padding
            cmd = [
                'ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
                '-f', 'webm',         # Force input format
                '-i', webm_path,      # Input file
                '-vn',                # No video
                '-af', 'volume=1.0',  # Simple volume normalization for speech clarity
                '-ac', '1',           # Convert to mono
                '-ar', '16000',       # 16kHz sample rate
                '-c:a', 'pcm_s16le',  # PCM 16-bit little-endian
                '-f', 'wav',          # WAV format
                '-fflags', '+igndts', # Ignore DTS errors
                wav_path
            ]
            
            logger.debug(f"[FFMPEG-ENHANCED] {' '.join(cmd)}")
            
            # Execute conversion with timeout and detailed error capture
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=15,  # Shorter timeout
                text=True,
                check=False  # Don't raise on non-zero exit
            )
            
            # Check if conversion succeeded
            if result.returncode == 0 and os.path.exists(wav_path):
                wav_size = os.path.getsize(wav_path)
                if wav_size > 44:  # Valid WAV header size
                    logger.info(f"[WEBM→WAV] SUCCESS: {len(audio_data)} → {wav_size} bytes")
                    return wav_path
                else:
                    raise Exception(f"FFmpeg produced empty WAV file ({wav_size} bytes)")
            else:
                error_msg = result.stderr.strip() if result.stderr else f"Exit code: {result.returncode}"
                raise Exception(f"FFmpeg conversion failed: {error_msg}")
                
        except Exception as e:
            logger.error(f"[WEBM→WAV] Failed: {e}")
            raise
        finally:
            # Cleanup input WebM file only (keep WAV for caller to use)
            if os.path.exists(webm_path):
                try:
                    os.unlink(webm_path)
                except OSError:
                    pass
            # Note: WAV file cleanup is handled by the caller after Whisper processing
        
    def get_wav_duration(self, wav_path: str) -> float:
        """Get duration of WAV file in seconds"""
        try:
            with wave.open(wav_path, 'rb') as wf:
                frames = wf.getnframes()
                rate = wf.getframerate()
                duration_sec = frames / float(rate)
                logger.info(f"[DURATION] WAV file duration: {duration_sec:.3f}s")
                return duration_sec
        except Exception as e:
            logger.error(f"[WAV-DURATION] Failed to get duration: {e}")
            return 0.0
    
    def should_buffer_chunk_enhanced(self, wav_path: str, session_id: str) -> tuple[bool, float, str]:
        """
        Enhanced chunk buffering with better duration checking and VAD integration
        Returns (should_buffer, duration, reason)
        """
        duration = self.get_wav_duration(wav_path)
        
        # Check if chunk is too short for Whisper
        if duration < self.min_duration_seconds:
            return True, duration, f"too_short_{duration:.3f}s"
        
        # Check if chunk is borderline and should be buffered for quality
        if duration < self.buffer_threshold_seconds:
            return True, duration, f"quality_buffer_{duration:.3f}s"
        
        # Check if chunk has actual speech content
        if not self.has_speech_content_wav(wav_path):
            return True, duration, f"no_speech_{duration:.3f}s"
        
        return False, duration, f"ready_{duration:.3f}s"
    
    def should_buffer_audio(self, wav_path: str, session_id: str) -> tuple[bool, float]:
        """
        Check if audio should be buffered due to short duration
        Returns (should_buffer, duration_seconds)
        """
        if not self.pydub_available:
            return False, 0.0
            
        duration = self.get_wav_duration(wav_path)
        logger.info(f"[AUDIO-BUFFER] Chunk duration: {duration:.3f}s for session {session_id}")
        
        # If duration is below minimum, buffer it
        if duration < self.min_duration_seconds:
            logger.info(f"[AUDIO-BUFFER] Chunk too short ({duration:.3f}s < {self.min_duration_seconds}s), buffering...")
            return True, duration
            
        return False, duration
    
    def add_to_buffer(self, wav_path: str, session_id: str) -> tuple[bool, str]:
        """
        Add audio to buffer and check if ready for transcription
        Returns (ready_for_transcription, merged_wav_path_or_None)
        """
        if not self.pydub_available:
            return False, None
            
        try:
            # Load new audio chunk
            new_chunk = self.AudioSegment.from_wav(wav_path)
            
            # Use global buffer manager for persistent state
            current_buffer = global_buffer_manager.get_buffer(session_id)
            
            # Initialize or append to buffer
            chunk_duration = len(new_chunk) / 1000.0  # Convert ms to seconds
            if current_buffer is None:
                global_buffer_manager.set_buffer(session_id, new_chunk)
                total_buffer_duration = chunk_duration
                logger.info(f"[AUDIO-BUFFER] Initialized buffer with {chunk_duration:.3f}s of audio for session {session_id}")
            else:
                merged_buffer = current_buffer + new_chunk  # Concatenate audio
                global_buffer_manager.set_buffer(session_id, merged_buffer)
                total_buffer_duration = len(merged_buffer) / 1000.0
                # Enhanced logging as per Step 3
                logger.info(f"[AUDIO-BUFFER] Added chunk: {chunk_duration:.3f}s, total buffer: {total_buffer_duration:.3f}s")
            
            # Get current buffer state
            current_buffer = global_buffer_manager.get_buffer(session_id)
            total_buffer_duration = len(current_buffer) / 1000.0  # Convert ms to seconds
            
            # Step 4: Add buffer cap to avoid infinite memory growth
            if total_buffer_duration > self.max_buffer_duration_seconds:
                logger.warning(f"[AUDIO-BUFFER] Buffer exceeded max duration ({total_buffer_duration:.3f}s > {self.max_buffer_duration_seconds}s), forcing transcription!")
                # Force transcription and clear buffer
                fd, merged_wav_path = tempfile.mkstemp(suffix='.wav')
                os.close(fd)
                current_buffer.export(merged_wav_path, format="wav")
                global_buffer_manager.clear_session(session_id)
                logger.info(f"[AUDIO-BUFFER] Force exported oversized buffer to {merged_wav_path}")
                return True, merged_wav_path
            
            # Step 2: Apply logic to prevent premature transcription
            if total_buffer_duration < self.buffer_threshold_seconds:
                logger.info(f"[AUDIO-BUFFER] Buffer too short ({total_buffer_duration:.3f}s < {self.buffer_threshold_seconds:.1f}s), waiting for more...")
                return False, None  # Do NOT process transcription yet
            
            # Buffer meets minimum threshold - ready for transcription
            logger.info(f"[AUDIO-BUFFER] Minimum threshold met, sending to Whisper... ({total_buffer_duration:.3f}s >= {self.buffer_threshold_seconds:.1f}s)")
            
            # Export merged audio to temporary WAV file
            fd, merged_wav_path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            
            current_buffer.export(merged_wav_path, format="wav")
            
            # Clear buffer for next chunks
            global_buffer_manager.clear_session(session_id)
            
            logger.info(f"[AUDIO-BUFFER] Exported merged audio to {merged_wav_path}")
            return True, merged_wav_path
                
        except Exception as e:
            logger.error(f"[AUDIO-BUFFER] Error adding to buffer: {e}")
            return False, None
    
    def flush_buffer(self, session_id: str) -> str:
        """
        Flush remaining buffer on session end, padding if necessary
        Returns path to final WAV file or None
        """
        if not self.pydub_available:
            return None
            
        # Get current buffer from global manager
        current_buffer = global_buffer_manager.get_buffer(session_id)
        if current_buffer is None:
            logger.info(f"[AUDIO-BUFFER] No buffer to flush for session {session_id}")
            return None
            
        try:
            total_duration = len(current_buffer) / 1000.0
            logger.info(f"[AUDIO-BUFFER] Flushing buffer with {total_duration:.3f}s of audio")
            
            # If buffer is too short, pad with silence to meet minimum
            if total_duration < self.min_duration_seconds:
                silence_needed = self.min_duration_seconds - total_duration
                logger.info(f"[AUDIO-BUFFER] Padding with {silence_needed:.3f}s silence to meet minimum")
                
                silence = self.AudioSegment.silent(duration=int(silence_needed * 1000))
                current_buffer += silence
                
            # Export final buffered audio
            fd, final_wav_path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            
            current_buffer.export(final_wav_path, format="wav")
            
            # Clear buffer
            global_buffer_manager.clear_session(session_id)
            
            logger.info(f"[AUDIO-BUFFER] Flushed buffer to {final_wav_path}")
            return final_wav_path
            
        except Exception as e:
            logger.error(f"[AUDIO-BUFFER] Error flushing buffer: {e}")
            return None
    
    def add_to_session_buffer(self, wav_path: str, session_id: str) -> tuple[bool, str, str]:
        """
        Add chunk to session buffer for intelligent batching
        Returns (is_ready_for_transcription, batch_id, status_message)
        """
        if not self.pydub_available:
            return True, f"direct_{int(time.time())}", "PyDub not available, processing directly"
            
        try:
            # Initialize session buffer if needed
            if session_id not in self.session_buffers:
                self.session_buffers[session_id] = {
                    'audio_segments': [],
                    'total_duration': 0.0,
                    'batch_id': None
                }
                self.batch_counters[session_id] = 0
                
            # Load audio chunk
            new_chunk = self.AudioSegment.from_wav(wav_path)
            chunk_duration = len(new_chunk) / 1000.0  # Convert ms to seconds
            
            buffer_info = self.session_buffers[session_id]
            
            # Add chunk to buffer
            buffer_info['audio_segments'].append(new_chunk)
            buffer_info['total_duration'] += chunk_duration
            
            # Generate batch ID if not set
            if not buffer_info['batch_id']:
                self.batch_counters[session_id] += 1
                buffer_info['batch_id'] = f"buffer_batch_{self.batch_counters[session_id]}"
            
            current_duration = buffer_info['total_duration']
            batch_id = buffer_info['batch_id']
            
            logger.info(f"[BATCH-BUFFER] Added {chunk_duration:.3f}s to buffer, total: {current_duration:.3f}s (batch: {batch_id})")
            
            # Check if buffer is ready for transcription (>= 5 seconds)
            if current_duration >= self.batch_threshold_seconds:
                logger.info(f"[BATCH-BUFFER] Buffer ready for transcription: {current_duration:.3f}s >= {self.batch_threshold_seconds}s")
                return True, batch_id, f"Buffer ready: {current_duration:.3f}s"
            elif current_duration > self.max_buffer_duration_seconds:
                # Force transcription if buffer gets too large
                logger.warning(f"[BATCH-BUFFER] Buffer too large, forcing transcription: {current_duration:.3f}s")
                return True, batch_id, f"Buffer forced: {current_duration:.3f}s (max exceeded)"
            else:
                # Continue buffering
                return False, batch_id, f"Buffering: {current_duration:.3f}s of {self.batch_threshold_seconds:.1f}s needed"
                
        except Exception as e:
            logger.error(f"[BATCH-BUFFER] Error adding to session buffer: {e}")
            return True, f"error_{int(time.time())}", f"Buffer error: {str(e)}"
    
    def transcribe_buffer(self, session_id: str) -> tuple[str, str]:
        """
        Export accumulated buffer for transcription and clear session buffer
        Returns (wav_path, batch_id)
        """
        if session_id not in self.session_buffers or not self.pydub_available:
            return None, None
            
        try:
            buffer_info = self.session_buffers[session_id]
            segments = buffer_info['audio_segments']
            batch_id = buffer_info['batch_id']
            
            if not segments:
                logger.warning(f"[BATCH-BUFFER] No segments to transcribe for session {session_id}")
                return None, None
                
            # Combine all segments
            combined_audio = segments[0]
            for segment in segments[1:]:
                combined_audio += segment
                
            # Export to temporary file
            fd, merged_wav_path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            combined_audio.export(merged_wav_path, format="wav")
            
            total_duration = len(combined_audio) / 1000.0
            logger.info(f"[BATCH-BUFFER] Exported {total_duration:.3f}s buffer to {merged_wav_path} (batch: {batch_id})")
            
            # Clear session buffer for next batch
            self.clear_session_buffer(session_id)
            
            return merged_wav_path, batch_id
            
        except Exception as e:
            logger.error(f"[BATCH-BUFFER] Error transcribing buffer: {e}")
            return None, None
    
    def clear_session_buffer(self, session_id: str):
        """Clear session buffer to start fresh batch"""
        if session_id in self.session_buffers:
            self.session_buffers[session_id] = {
                'audio_segments': [],
                'total_duration': 0.0,
                'batch_id': None
            }
            logger.info(f"[BATCH-BUFFER] Cleared session buffer for {session_id}")
    
    def get_buffer_status(self, session_id: str) -> dict:
        """Get current buffer status for UI updates"""
        if session_id not in self.session_buffers:
            return {'duration': 0.0, 'batch_id': None, 'segments_count': 0}
            
        buffer_info = self.session_buffers[session_id]
        return {
            'duration': buffer_info['total_duration'],
            'batch_id': buffer_info['batch_id'],
            'segments_count': len(buffer_info['audio_segments']),
            'ready': buffer_info['total_duration'] >= self.batch_threshold_seconds
        }

    def process_audio_with_buffering(self, audio_data: bytes, session_id: str) -> tuple[str, str, bool]:
        """
        Process audio with intelligent buffering for short chunks
        Returns (status, wav_path_or_message, is_final_result)
        
        Status can be: 'ready', 'buffered', 'error'
        """
        if not audio_data:
            return 'error', 'No audio data provided', False
            
        try:
            # CRITICAL FIX: Check format first per documentation
            if audio_data[:4] == b'RIFF' and b'WAVE' in audio_data[:20]:
                logger.info(f"[AUDIO-BUFFER] WAV format detected - saving directly")
                # For WAV files, save directly without WebM conversion
                import tempfile
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_wav:
                    temp_wav.write(audio_data)
                    wav_path = temp_wav.name
            else:
                # Convert WebM to WAV for other formats
                wav_path = self.convert_webm_to_wav(audio_data)
            
            # Check if this chunk should be buffered
            should_buffer, duration = self.should_buffer_audio(wav_path, session_id)
            
            if should_buffer:
                # Add to buffer and check if ready
                ready, merged_path = self.add_to_buffer(wav_path, session_id)
                
                # Clean up original WAV since we've buffered it
                if os.path.exists(wav_path):
                    os.unlink(wav_path)
                    
                if ready:
                    logger.info(f"[AUDIO-BUFFER] Merged buffer ready for transcription")
                    return 'ready', merged_path, True
                else:
                    logger.info(f"[AUDIO-BUFFER] Chunk buffered, waiting for more audio...")
                    return 'buffered', f'Buffered {duration:.3f}s audio, waiting for more...', False
            else:
                # Chunk is long enough, proceed normally
                logger.info(f"[AUDIO-BUFFER] Chunk duration {duration:.3f}s is sufficient, proceeding...")
                return 'ready', wav_path, False
                
        except Exception as e:
            logger.error(f"[AUDIO-BUFFER] Error processing audio: {e}")
            return 'error', f'Audio processing failed: {str(e)}', False