#!/usr/bin/env python3
"""
Comprehensive End-to-End Tests for Real-Time Transcription Page
Tests all components: UI loading, audio processing, WebSocket streaming, error handling
"""

import os
import sys
import time
import json
import tempfile
import subprocess
import requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import queue

# Test configuration
BASE_URL = "http://127.0.0.1:5000"
REAL_TIME_URL = f"{BASE_URL}/real_time_transcription"
API_TRANSCRIBE_CHUNK = f"{BASE_URL}/api/transcribe_chunk_streaming"

class RealTimeTranscriptionE2ETest:
    """Comprehensive E2E test suite for real-time transcription functionality"""
    
    def __init__(self):
        self.test_results = []
        self.start_time = time.time()
        self.session_id = f"test_session_{int(time.time())}"
        
    def log_test(self, test_name, status, details="", duration=0):
        """Log individual test results"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "duration": f"{duration:.2f}s",
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        
        # Color-coded console output
        color = "\033[92m" if status == "PASS" else "\033[91m" if status == "FAIL" else "\033[93m"
        print(f"{color}[{status}]\033[0m {test_name} ({duration:.2f}s)")
        if details:
            print(f"    └── {details}")
    
    def test_1_page_accessibility(self):
        """Test 1: Page loads and returns proper HTML"""
        start = time.time()
        try:
            response = requests.get(REAL_TIME_URL, timeout=10)
            duration = time.time() - start
            
            if response.status_code == 200:
                html_content = response.text
                required_elements = [
                    "real_time_transcription.js",
                    "websocket_streaming.js", 
                    "vad_processor_advanced.js",
                    "recordBtn",
                    "transcriptContainer",
                    "liveTranscriptDisplay"
                ]
                
                missing_elements = []
                for element in required_elements:
                    if element not in html_content:
                        missing_elements.append(element)
                
                if not missing_elements:
                    self.log_test("Page Accessibility", "PASS", 
                                f"All required elements found in {len(html_content)} chars", duration)
                else:
                    self.log_test("Page Accessibility", "FAIL", 
                                f"Missing elements: {', '.join(missing_elements)}", duration)
            else:
                self.log_test("Page Accessibility", "FAIL", 
                            f"HTTP {response.status_code}", duration)
                
        except Exception as e:
            self.log_test("Page Accessibility", "FAIL", f"Request failed: {e}", time.time() - start)
    
    def test_2_static_assets_loading(self):
        """Test 2: All JavaScript assets load successfully"""
        start = time.time()
        assets = [
            "/static/js/real_time_transcription.js",
            "/static/js/websocket_streaming.js",
            "/static/js/vad_processor_advanced.js",
            "/static/css/real_time_ui.css"
        ]
        
        failed_assets = []
        for asset in assets:
            try:
                response = requests.get(f"{BASE_URL}{asset}", timeout=5)
                if response.status_code != 200:
                    failed_assets.append(f"{asset} (HTTP {response.status_code})")
            except Exception as e:
                failed_assets.append(f"{asset} (Error: {e})")
        
        duration = time.time() - start
        if not failed_assets:
            self.log_test("Static Assets Loading", "PASS", 
                        f"All {len(assets)} assets loaded successfully", duration)
        else:
            self.log_test("Static Assets Loading", "FAIL", 
                        f"Failed assets: {', '.join(failed_assets)}", duration)
    
    def test_3_api_endpoint_availability(self):
        """Test 3: API endpoints return appropriate responses"""
        start = time.time()
        
        # Test with empty request (should return 400)
        try:
            response = requests.post(API_TRANSCRIBE_CHUNK, timeout=10)
            
            if response.status_code == 400:
                self.log_test("API Endpoint Availability", "PASS", 
                            "Endpoint correctly rejects empty requests", time.time() - start)
            else:
                self.log_test("API Endpoint Availability", "FAIL", 
                            f"Unexpected status code: {response.status_code}", time.time() - start)
        except Exception as e:
            self.log_test("API Endpoint Availability", "FAIL", 
                        f"API endpoint not reachable: {e}", time.time() - start)
    
    def create_test_webm_chunk(self, duration_seconds=2):
        """Create a test WebM audio chunk - simplified version without FFmpeg"""
        try:
            # Create a minimal WebM header with EBML signature
            webm_header = bytes([
                0x1a, 0x45, 0xdf, 0xa3,  # EBML signature
                0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1f,  # EBML header size
                0x42, 0x86, 0x81, 0x01,  # EBML Version = 1
                0x42, 0xf7, 0x81, 0x01,  # EBML Read Version = 1
                0x42, 0xf2, 0x81, 0x04,  # EBML Max ID Length = 4
                0x42, 0xf3, 0x81, 0x08,  # EBML Max Size Length = 8
                0x42, 0x82, 0x84, 0x77, 0x65, 0x62, 0x6d,  # Doc Type = "webm"
                0x42, 0x87, 0x81, 0x02,  # Doc Type Version = 2
                0x42, 0x85, 0x81, 0x02,  # Doc Type Read Version = 2
            ])
            
            # Add minimal segment header
            segment_header = bytes([
                0x18, 0x53, 0x80, 0x67,  # Segment
                0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  # Unknown size
            ])
            
            # Create minimal audio data (empty for testing)
            audio_data = b'\x00' * (duration_seconds * 1000)  # Placeholder audio data
            
            return webm_header + segment_header + audio_data
            
        except Exception as e:
            print(f"Failed to create test WebM: {e}")
            return None
    
    def test_4_audio_chunk_processing(self):
        """Test 4: Audio chunk processing with real WebM data"""
        start = time.time()
        
        # Create test WebM audio
        webm_data = self.create_test_webm_chunk(2)
        if not webm_data:
            self.log_test("Audio Chunk Processing", "FAIL", 
                        "Could not create test WebM audio", time.time() - start)
            return
        
        try:
            # Prepare form data
            files = {'audio': ('test_chunk.webm', webm_data, 'audio/webm')}
            data = {
                'chunk_id': f'test_chunk_{int(time.time())}',
                'session_id': self.session_id
            }
            
            # Send to API
            response = requests.post(API_TRANSCRIBE_CHUNK, files=files, data=data, timeout=30)
            duration = time.time() - start
            
            if response.status_code == 200:
                try:
                    result = response.json()
                    if 'status' in result and 'text' in result:
                        self.log_test("Audio Chunk Processing", "PASS", 
                                    f"Response: {result.get('status')} - '{result.get('text', '')[:50]}...'", duration)
                    else:
                        self.log_test("Audio Chunk Processing", "FAIL", 
                                    f"Invalid response format: {result}", duration)
                except json.JSONDecodeError:
                    self.log_test("Audio Chunk Processing", "FAIL", 
                                f"Invalid JSON response: {response.text[:100]}...", duration)
            else:
                self.log_test("Audio Chunk Processing", "FAIL", 
                            f"HTTP {response.status_code}: {response.text[:100]}...", duration)
                
        except Exception as e:
            self.log_test("Audio Chunk Processing", "FAIL", 
                        f"Request failed: {e}", time.time() - start)
    
    def test_5_concurrent_chunk_processing(self):
        """Test 5: Concurrent chunk processing under load"""
        start = time.time()
        
        webm_data = self.create_test_webm_chunk(1)
        if not webm_data:
            self.log_test("Concurrent Chunk Processing", "FAIL", 
                        "Could not create test WebM audio", time.time() - start)
            return
        
        def send_chunk(chunk_index):
            """Send a single chunk to API"""
            try:
                files = {'audio': ('test_chunk.webm', webm_data, 'audio/webm')}
                data = {
                    'chunk_id': f'concurrent_chunk_{chunk_index}_{int(time.time())}',
                    'session_id': f'{self.session_id}_concurrent'
                }
                
                response = requests.post(API_TRANSCRIBE_CHUNK, files=files, data=data, timeout=15)
                return {
                    'chunk_index': chunk_index,
                    'status_code': response.status_code,
                    'success': response.status_code == 200
                }
            except Exception as e:
                return {
                    'chunk_index': chunk_index,
                    'status_code': 0,
                    'success': False,
                    'error': str(e)
                }
        
        # Send 5 concurrent chunks
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(send_chunk, i) for i in range(5)]
            results = [future.result() for future in as_completed(futures)]
        
        duration = time.time() - start
        successful_chunks = sum(1 for result in results if result['success'])
        
        if successful_chunks >= 3:  # At least 60% success rate
            self.log_test("Concurrent Chunk Processing", "PASS", 
                        f"{successful_chunks}/5 chunks processed successfully", duration)
        else:
            self.log_test("Concurrent Chunk Processing", "FAIL", 
                        f"Only {successful_chunks}/5 chunks processed successfully", duration)
    
    def test_6_error_handling(self):
        """Test 6: Error handling with invalid audio data"""
        start = time.time()
        
        test_cases = [
            ("Empty audio", b""),
            ("Invalid WebM", b"invalid_webm_data_12345"),
            ("Corrupted header", b"\x1a\x45\xdf\xa3invalid_rest_of_data"),
        ]
        
        error_handling_results = []
        
        for test_name, test_data in test_cases:
            try:
                files = {'audio': ('test_chunk.webm', test_data, 'audio/webm')}
                data = {
                    'chunk_id': f'error_test_{test_name.replace(" ", "_")}',
                    'session_id': self.session_id
                }
                
                response = requests.post(API_TRANSCRIBE_CHUNK, files=files, data=data, timeout=10)
                
                # We expect either 400 (bad request) or 200 with error status
                if response.status_code in [200, 400, 500]:
                    error_handling_results.append(f"{test_name}: HTTP {response.status_code}")
                else:
                    error_handling_results.append(f"{test_name}: Unexpected HTTP {response.status_code}")
                    
            except Exception as e:
                error_handling_results.append(f"{test_name}: Exception {e}")
        
        duration = time.time() - start
        self.log_test("Error Handling", "PASS", 
                    f"All error cases handled: {', '.join(error_handling_results)}", duration)
    
    def test_7_websocket_availability(self):
        """Test 7: WebSocket functionality (Socket.IO availability)"""
        start = time.time()
        
        try:
            # Test Socket.IO endpoint
            response = requests.get(f"{BASE_URL}/socket.io/?EIO=4&transport=polling", timeout=5)
            
            if response.status_code == 200:
                self.log_test("WebSocket Availability", "PASS", 
                            "Socket.IO endpoint accessible", time.time() - start)
            else:
                self.log_test("WebSocket Availability", "WARN", 
                            f"Socket.IO endpoint returned HTTP {response.status_code}", time.time() - start)
                
        except Exception as e:
            self.log_test("WebSocket Availability", "WARN", 
                        f"Socket.IO endpoint not accessible: {e}", time.time() - start)
    
    def test_8_database_connectivity(self):
        """Test 8: Database connectivity for session management"""
        start = time.time()
        
        try:
            # Test a simple endpoint that might use database
            response = requests.get(f"{BASE_URL}/health", timeout=5)
            
            if response.status_code == 200:
                self.log_test("Database Connectivity", "PASS", 
                            "Health endpoint accessible", time.time() - start)
            else:
                # Try dashboard as backup
                response = requests.get(f"{BASE_URL}/", timeout=5)
                if response.status_code == 200:
                    self.log_test("Database Connectivity", "PASS", 
                                "App responding normally", time.time() - start)
                else:
                    self.log_test("Database Connectivity", "FAIL", 
                                f"App not responding: HTTP {response.status_code}", time.time() - start)
                    
        except Exception as e:
            self.log_test("Database Connectivity", "FAIL", 
                        f"Database connectivity test failed: {e}", time.time() - start)
    
    def test_9_performance_metrics(self):
        """Test 9: Performance metrics for transcription speed"""
        start = time.time()
        
        # Create longer test audio (5 seconds)
        webm_data = self.create_test_webm_chunk(5)
        if not webm_data:
            self.log_test("Performance Metrics", "FAIL", 
                        "Could not create test WebM audio", time.time() - start)
            return
        
        try:
            files = {'audio': ('performance_test.webm', webm_data, 'audio/webm')}
            data = {
                'chunk_id': f'performance_test_{int(time.time())}',
                'session_id': self.session_id
            }
            
            api_start = time.time()
            response = requests.post(API_TRANSCRIBE_CHUNK, files=files, data=data, timeout=60)
            api_duration = time.time() - api_start
            
            if response.status_code == 200:
                # Performance thresholds
                if api_duration < 10:  # Under 10 seconds is good
                    self.log_test("Performance Metrics", "PASS", 
                                f"API responded in {api_duration:.2f}s (< 10s threshold)", time.time() - start)
                elif api_duration < 30:  # Under 30 seconds is acceptable
                    self.log_test("Performance Metrics", "WARN", 
                                f"API responded in {api_duration:.2f}s (slow but acceptable)", time.time() - start)
                else:
                    self.log_test("Performance Metrics", "FAIL", 
                                f"API too slow: {api_duration:.2f}s (> 30s threshold)", time.time() - start)
            else:
                self.log_test("Performance Metrics", "FAIL", 
                            f"Performance test failed: HTTP {response.status_code}", time.time() - start)
                
        except Exception as e:
            self.log_test("Performance Metrics", "FAIL", 
                        f"Performance test failed: {e}", time.time() - start)
    
    def test_10_integration_flow(self):
        """Test 10: Full integration flow simulation"""
        start = time.time()
        
        # Simulate a complete recording session
        webm_data = self.create_test_webm_chunk(3)
        if not webm_data:
            self.log_test("Integration Flow", "FAIL", 
                        "Could not create test WebM audio", time.time() - start)
            return
        
        integration_session = f"integration_test_{int(time.time())}"
        chunks_sent = 0
        chunks_successful = 0
        
        try:
            # Send 3 chunks to simulate a recording session
            for i in range(3):
                files = {'audio': ('integration_chunk.webm', webm_data, 'audio/webm')}
                data = {
                    'chunk_id': f'integration_chunk_{i}_{int(time.time())}',
                    'session_id': integration_session
                }
                
                response = requests.post(API_TRANSCRIBE_CHUNK, files=files, data=data, timeout=20)
                chunks_sent += 1
                
                if response.status_code == 200:
                    chunks_successful += 1
                
                # Small delay between chunks
                time.sleep(0.5)
            
            duration = time.time() - start
            success_rate = (chunks_successful / chunks_sent) * 100
            
            if success_rate >= 66:  # At least 66% success rate
                self.log_test("Integration Flow", "PASS", 
                            f"Integration flow completed: {chunks_successful}/{chunks_sent} chunks successful ({success_rate:.1f}%)", duration)
            else:
                self.log_test("Integration Flow", "FAIL", 
                            f"Integration flow failed: {chunks_successful}/{chunks_sent} chunks successful ({success_rate:.1f}%)", duration)
                
        except Exception as e:
            self.log_test("Integration Flow", "FAIL", 
                        f"Integration flow failed: {e}", time.time() - start)
    
    def run_all_tests(self):
        """Run all E2E tests and generate comprehensive report"""
        print("\n" + "="*60)
        print("🚀 REAL-TIME TRANSCRIPTION E2E TEST SUITE")
        print("="*60)
        
        # Run all tests
        test_methods = [
            self.test_1_page_accessibility,
            self.test_2_static_assets_loading,
            self.test_3_api_endpoint_availability,
            self.test_4_audio_chunk_processing,
            self.test_5_concurrent_chunk_processing,
            self.test_6_error_handling,
            self.test_7_websocket_availability,
            self.test_8_database_connectivity,
            self.test_9_performance_metrics,
            self.test_10_integration_flow
        ]
        
        for test_method in test_methods:
            test_method()
        
        # Generate summary report
        self.generate_summary_report()
    
    def generate_summary_report(self):
        """Generate comprehensive test summary report"""
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed_tests = len([r for r in self.test_results if r['status'] == 'FAIL'])
        warned_tests = len([r for r in self.test_results if r['status'] == 'WARN'])
        
        total_duration = time.time() - self.start_time
        
        print("\n" + "="*60)
        print("📊 TEST SUMMARY REPORT")
        print("="*60)
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"⚠️  Warnings: {warned_tests}")
        print(f"📈 Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        print(f"⏱️  Total Duration: {total_duration:.2f}s")
        print("="*60)
        
        # Detailed results
        print("\n🔍 DETAILED TEST RESULTS:")
        for result in self.test_results:
            status_emoji = "✅" if result['status'] == 'PASS' else "❌" if result['status'] == 'FAIL' else "⚠️"
            print(f"{status_emoji} {result['test']} ({result['duration']})")
            if result['details']:
                print(f"    └── {result['details']}")
        
        # Save results to file
        with open('e2e_real_time_transcription_results.json', 'w') as f:
            json.dump({
                'summary': {
                    'total_tests': total_tests,
                    'passed': passed_tests,
                    'failed': failed_tests,
                    'warnings': warned_tests,
                    'success_rate': f"{(passed_tests/total_tests)*100:.1f}%",
                    'total_duration': f"{total_duration:.2f}s"
                },
                'results': self.test_results,
                'timestamp': datetime.now().isoformat()
            }, f, indent=2)
        
        print(f"\n💾 Detailed results saved to: e2e_real_time_transcription_results.json")
        
        # Production readiness assessment
        if passed_tests >= 8:  # 80% pass rate
            print("\n🎉 PRODUCTION READINESS: ✅ READY")
            print("The real-time transcription system is ready for production deployment.")
        elif passed_tests >= 6:  # 60% pass rate
            print("\n🔧 PRODUCTION READINESS: ⚠️ NEEDS IMPROVEMENT")
            print("The system needs some improvements before production deployment.")
        else:
            print("\n⚠️ PRODUCTION READINESS: ❌ NOT READY")
            print("The system requires significant fixes before production deployment.")

if __name__ == "__main__":
    # Initialize and run tests
    test_suite = RealTimeTranscriptionE2ETest()
    test_suite.run_all_tests()