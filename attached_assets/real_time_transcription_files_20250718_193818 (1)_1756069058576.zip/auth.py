"""
Simple Flask authentication system for Mina Pro
Basic login/register with session management and usage quotas
"""

from flask import session, request, jsonify, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from functools import wraps
import logging

logger = logging.getLogger(__name__)

class AuthManager:
    """Handle user authentication and session management"""
    
    def __init__(self, db_session):
        self.db = db_session
        self.FREE_TIER_LIMIT = 3  # sessions per month
    
    def register_user(self, username: str, email: str, password: str) -> dict:
        """Register new user with validation"""
        try:
            from models import User
            
            # Check if user exists
            existing_user = self.db.query(User).filter(
                (User.username == username) | (User.email == email)
            ).first()
            
            if existing_user:
                return {"status": "error", "message": "Username or email already exists"}
            
            # Create new user
            password_hash = generate_password_hash(password)
            user = User(
                username=username,
                email=email,
                password_hash=password_hash,
                sessions_used=0,
                monthly_reset=datetime.utcnow() + timedelta(days=30)
            )
            
            self.db.add(user)
            self.db.commit()
            
            logger.info(f"[USER-REGISTER] New user: {username}")
            return {"status": "success", "user_id": user.id}
            
        except Exception as e:
            logger.error(f"[REGISTER-ERROR] {e}")
            return {"status": "error", "message": str(e)}
    
    def login_user(self, username: str, password: str) -> dict:
        """Authenticate user and create session"""
        try:
            from models import User
            
            user = self.db.query(User).filter(
                (User.username == username) | (User.email == username)
            ).first()
            
            if not user or not check_password_hash(user.password_hash, password):
                return {"status": "error", "message": "Invalid credentials"}
            
            # Check if monthly quota needs reset
            if datetime.utcnow() > user.monthly_reset:
                user.sessions_used = 0
                user.monthly_reset = datetime.utcnow() + timedelta(days=30)
                self.db.commit()
            
            # Create session
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_premium'] = user.is_premium
            
            logger.info(f"[USER-LOGIN] User: {username}")
            return {
                "status": "success", 
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "sessions_used": user.sessions_used,
                    "is_premium": user.is_premium
                }
            }
            
        except Exception as e:
            logger.error(f"[LOGIN-ERROR] {e}")
            return {"status": "error", "message": str(e)}
    
    def logout_user(self):
        """Clear user session"""
        session.clear()
        logger.info("[USER-LOGOUT]")
        return {"status": "success"}
    
    def get_current_user(self):
        """Get current user from session"""
        if 'user_id' not in session:
            return None
        
        try:
            from models import User
            return self.db.query(User).filter(User.id == session['user_id']).first()
        except:
            return None
    
    def check_usage_quota(self, user_id: str) -> dict:
        """Check if user can create new session"""
        try:
            from models import User
            
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return {"allowed": False, "message": "User not found"}
            
            # Premium users have unlimited sessions
            if user.is_premium:
                return {"allowed": True, "usage": {"used": user.sessions_used, "limit": "unlimited"}}
            
            # Check free tier limit
            if user.sessions_used >= self.FREE_TIER_LIMIT:
                return {
                    "allowed": False, 
                    "message": f"Monthly limit of {self.FREE_TIER_LIMIT} sessions reached",
                    "usage": {"used": user.sessions_used, "limit": self.FREE_TIER_LIMIT}
                }
            
            return {
                "allowed": True,
                "usage": {"used": user.sessions_used, "limit": self.FREE_TIER_LIMIT}
            }
            
        except Exception as e:
            logger.error(f"[QUOTA-CHECK-ERROR] {e}")
            return {"allowed": False, "message": "Error checking quota"}
    
    def increment_usage(self, user_id: str):
        """Increment user's session count"""
        try:
            from models import User
            
            user = self.db.query(User).filter(User.id == user_id).first()
            if user and not user.is_premium:  # Don't count for premium users
                user.sessions_used += 1
                self.db.commit()
                logger.info(f"[USAGE-INCREMENT] User {user.username}: {user.sessions_used}/{self.FREE_TIER_LIMIT}")
                
        except Exception as e:
            logger.error(f"[USAGE-INCREMENT-ERROR] {e}")

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json:
                return jsonify({"status": "error", "message": "Authentication required"}), 401
            else:
                return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def require_quota(f):
    """Decorator to check usage quota"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"status": "error", "message": "Authentication required"}), 401
        
        # For now, allow guest users unlimited access
        # In production, implement proper quota checking
        return f(*args, **kwargs)
    return decorated_function