#!/usr/bin/env python3
"""
Comprehensive Patch Validation Test for Mina Real-Time Transcription
Tests all 5 critical fixes implemented in the patch:
1. Prevent duplicate rendering of chunk results using processedChunks Set
2. Stop appending previous transcript strings recursively in final transcript
3. Update renderFinalTranscript() to include deduplication and chunk ID handling
4. Update real_time_transcription.js to calculate and display live metrics
5. Ensure backend emits only current chunk's transcript, not cumulative history
"""

import os
import sys
import json
import time
import logging
import requests
import subprocess
import tempfile
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PatchValidationTest:
    def __init__(self, base_url="http://localhost:5000"):
        self.base_url = base_url
        self.test_results = {}
        self.validation_passed = True
        
    def log_test_result(self, test_name, passed, details=""):
        self.test_results[test_name] = {
            "passed": passed,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        if not passed:
            self.validation_passed = False
        
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info(f"{status} - {test_name}: {details}")
    
    def test_fix_1_duplicate_prevention(self):
        """Test Fix 1: Prevent duplicate rendering with processedChunks Set"""
        logger.info("Testing Fix 1: Duplicate rendering prevention...")
        
        # Check if processedChunks Set is initialized in JavaScript
        with open('static/js/real_time_transcription.js', 'r') as f:
            js_content = f.read()
            
        has_processed_chunks = 'this.processedChunks = new Set()' in js_content
        has_duplicate_check = 'this.processedChunks.has(chunk_id)' in js_content
        has_add_to_set = 'this.processedChunks.add(chunk_id)' in js_content
        
        passed = has_processed_chunks and has_duplicate_check and has_add_to_set
        self.log_test_result(
            "Fix 1 - Duplicate Prevention", 
            passed,
            f"processedChunks Set: {has_processed_chunks}, duplicate check: {has_duplicate_check}, add to set: {has_add_to_set}"
        )
        
    def test_fix_2_recursive_transcript_prevention(self):
        """Test Fix 2: Stop appending previous transcript strings recursively"""
        logger.info("Testing Fix 2: Recursive transcript prevention...")
        
        # Check backend flush session endpoint
        with open('app_standalone.py', 'r') as f:
            backend_content = f.read()
            
        # Look for the fix where we emit individual chunks instead of cumulative final_transcript
        has_individual_emission = 'socketio.emit(\'transcript_final\', {' in backend_content
        has_chunk_id_emission = 'chunk.get(\'chunk_id\'' in backend_content
        avoids_cumulative = 'final_transcript' not in backend_content or 'PATCH FIX 5' in backend_content
        
        passed = has_individual_emission and has_chunk_id_emission
        self.log_test_result(
            "Fix 2 - Recursive Transcript Prevention",
            passed,
            f"Individual emission: {has_individual_emission}, chunk ID emission: {has_chunk_id_emission}"
        )
        
    def test_fix_3_render_final_transcript(self):
        """Test Fix 3: renderFinalTranscript() with deduplication and chunk ID handling"""
        logger.info("Testing Fix 3: renderFinalTranscript() function...")
        
        with open('static/js/real_time_transcription.js', 'r') as f:
            js_content = f.read()
            
        has_render_function = 'renderFinalTranscript = function(chunk_id, text, confidence)' in js_content
        has_deduplication = 'if (!chunk_id || this.processedChunks.has(chunk_id))' in js_content
        has_chunk_id_handling = 'chunk-${chunk_id}' in js_content
        
        passed = has_render_function and has_deduplication and has_chunk_id_handling
        self.log_test_result(
            "Fix 3 - renderFinalTranscript() Function",
            passed,
            f"Function exists: {has_render_function}, deduplication: {has_deduplication}, chunk ID handling: {has_chunk_id_handling}"
        )
        
    def test_fix_4_live_metrics(self):
        """Test Fix 4: Live word count, total word count, and confidence metrics"""
        logger.info("Testing Fix 4: Live metrics calculation...")
        
        with open('static/js/real_time_transcription.js', 'r') as f:
            js_content = f.read()
            
        has_live_word_count = 'this.liveWordCount' in js_content
        has_live_confidence = 'this.liveConfidence' in js_content
        has_update_metrics = 'updateLiveMetrics = function(text, confidence)' in js_content
        has_total_words_update = 'this.totalWords +=' in js_content
        
        # Check HTML template for metric display elements
        with open('templates/real_time_transcription.html', 'r') as f:
            html_content = f.read()
            
        has_live_word_display = 'id="liveWordCount"' in html_content
        has_live_confidence_display = 'id="liveConfidence"' in html_content
        has_total_words_display = 'id="totalWords"' in html_content
        
        passed = (has_live_word_count and has_live_confidence and has_update_metrics and 
                 has_total_words_update and has_live_word_display and has_live_confidence_display)
        self.log_test_result(
            "Fix 4 - Live Metrics",
            passed,
            f"JS metrics: {has_live_word_count and has_live_confidence and has_update_metrics}, HTML display: {has_live_word_display and has_live_confidence_display}"
        )
        
    def test_fix_5_backend_individual_emission(self):
        """Test Fix 5: Backend emits only current chunk's transcript, not cumulative history"""
        logger.info("Testing Fix 5: Backend individual chunk emission...")
        
        with open('app_standalone.py', 'r') as f:
            backend_content = f.read()
            
        # Look for the PATCH FIX 5 implementation
        has_patch_fix_5 = 'PATCH FIX 5' in backend_content
        has_individual_chunks = 'for i, chunk in enumerate(interim_chunks)' in backend_content
        has_transcript_final = 'socketio.emit(\'transcript_final\'' in backend_content
        avoids_cumulative_final = 'final_transcript' not in backend_content.split('PATCH FIX 5')[1] if 'PATCH FIX 5' in backend_content else False
        
        passed = has_patch_fix_5 and has_individual_chunks and has_transcript_final
        self.log_test_result(
            "Fix 5 - Backend Individual Emission",
            passed,
            f"Patch fix 5: {has_patch_fix_5}, individual chunks: {has_individual_chunks}, transcript_final: {has_transcript_final}"
        )
        
    def test_websocket_handlers(self):
        """Test WebSocket event handlers for new patch functions"""
        logger.info("Testing WebSocket event handlers...")
        
        with open('static/js/real_time_transcription.js', 'r') as f:
            js_content = f.read()
            
        has_patched_handlers = 'setupPatchedWebSocketHandlers' in js_content
        has_transcript_final_handler = 'socket.on(\'transcript_final\'' in js_content
        has_render_final_call = 'window.realTimeEngine.renderFinalTranscript(chunk_id,' in js_content
        
        passed = has_patched_handlers and has_transcript_final_handler and has_render_final_call
        self.log_test_result(
            "WebSocket Handlers",
            passed,
            f"Patched handlers: {has_patched_handlers}, transcript_final handler: {has_transcript_final_handler}, render call: {has_render_final_call}"
        )
        
    def test_data_structure_cleanup(self):
        """Test that processedChunks is properly cleared between sessions"""
        logger.info("Testing data structure cleanup...")
        
        with open('static/js/real_time_transcription.js', 'r') as f:
            js_content = f.read()
            
        has_clear_processed_chunks = 'this.processedChunks' in js_content and '.clear()' in js_content
        has_clear_in_data_structures = 'clearDataStructures' in js_content
        
        passed = has_clear_processed_chunks and has_clear_in_data_structures
        self.log_test_result(
            "Data Structure Cleanup",
            passed,
            f"Clear processed chunks: {has_clear_processed_chunks}, clear in data structures: {has_clear_in_data_structures}"
        )
        
    def run_all_tests(self):
        """Run all validation tests"""
        logger.info("🚀 Starting comprehensive patch validation tests...")
        
        self.test_fix_1_duplicate_prevention()
        self.test_fix_2_recursive_transcript_prevention()
        self.test_fix_3_render_final_transcript()
        self.test_fix_4_live_metrics()
        self.test_fix_5_backend_individual_emission()
        self.test_websocket_handlers()
        self.test_data_structure_cleanup()
        
        # Generate final report
        passed_tests = sum(1 for result in self.test_results.values() if result["passed"])
        total_tests = len(self.test_results)
        
        logger.info(f"\n{'='*60}")
        logger.info(f"COMPREHENSIVE PATCH VALIDATION RESULTS")
        logger.info(f"{'='*60}")
        logger.info(f"Total Tests: {total_tests}")
        logger.info(f"Passed: {passed_tests}")
        logger.info(f"Failed: {total_tests - passed_tests}")
        logger.info(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if self.validation_passed:
            logger.info("✅ ALL PATCH FIXES VALIDATED SUCCESSFULLY!")
            logger.info("System is ready for 2-3 minute podcast testing.")
        else:
            logger.error("❌ Some patch fixes need attention.")
            logger.info("Review failed tests above before proceeding.")
            
        # Save results to JSON file
        with open('patch_validation_results.json', 'w') as f:
            json.dump({
                "validation_passed": self.validation_passed,
                "success_rate": f"{(passed_tests/total_tests)*100:.1f}%",
                "test_results": self.test_results,
                "timestamp": datetime.now().isoformat()
            }, f, indent=2)
            
        return self.validation_passed

def main():
    """Main function to run patch validation"""
    print("🔍 Mina Real-Time Transcription Patch Validation")
    print("Testing all 5 critical fixes implemented in the comprehensive patch\n")
    
    validator = PatchValidationTest()
    success = validator.run_all_tests()
    
    if success:
        print("\n🎉 Patch validation completed successfully!")
        print("Ready for 2-3 minute podcast testing to validate:")
        print("• Incrementally building transcript (no duplicates)")
        print("• Non-repeating final transcript")
        print("• Responsive live metrics (word count, confidence)")
        return 0
    else:
        print("\n⚠️  Patch validation found issues that need attention.")
        print("Please review the failed tests and fix before proceeding.")
        return 1

if __name__ == "__main__":
    sys.exit(main())