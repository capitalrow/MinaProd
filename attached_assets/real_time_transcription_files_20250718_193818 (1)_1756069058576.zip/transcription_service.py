"""
Production Transcription Service for Mina Pro
Whisper-first with GPT-4o fallback and intelligent post-processing
"""

import logging
import openai
import os
import tempfile
import time
import re
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)

class TranscriptionService:
    """Production-grade transcription with intelligence layer"""
    
    def __init__(self):
        self.client = openai.OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
        self.primary_model = "whisper-1"
        self.fallback_model = "gpt-4o-transcribe"
        
        # Meeting type prompts for context
        self.meeting_prompts = {
            "general": "Please transcribe this audio accurately with proper punctuation.",
            "meeting": "Transcribe this meeting, focusing on decisions, action items, and key discussion points.",
            "sales": "Transcribe this sales conversation, highlighting customer needs and next steps.",
            "interview": "Transcribe this interview with attention to questions and responses.",
            "lecture": "Transcribe this lecture, emphasizing key concepts and explanations.",
            "brainstorm": "Transcribe this brainstorming session, capturing all ideas and discussions."
        }
    
    def transcribe_audio(self, audio_data: bytes, meeting_type: str = "general") -> Dict[str, Any]:
        """
        Main transcription endpoint with Whisper-first, GPT-4o fallback
        
        Returns comprehensive result with intelligence features
        """
        start_time = time.time()
        session_data = {
            "status": "processing",
            "meeting_type": meeting_type,
            "processing_start": start_time
        }
        
        try:
            # Primary: Whisper-1 with context prompt
            logger.info(f"[BATCH-UPLOAD] Starting Whisper-1 transcription, type: {meeting_type}")
            
            result = self._transcribe_with_whisper(audio_data, meeting_type)
            
            if result["status"] == "success":
                logger.info(f"[WHISPER-SUCCESS] Confidence: {result['confidence']:.1%}, Words: {result['word_count']}")
                session_data.update(result)
                session_data["model_used"] = self.primary_model
                session_data["fallback_used"] = False
            else:
                # Fallback: GPT-4o (single retry)
                logger.warning(f"[G4O-FALLBACK] Whisper failed: {result.get('error', 'Unknown')}")
                result = self._transcribe_with_gpt4o(audio_data, meeting_type)
                
                if result["status"] == "success":
                    session_data.update(result)
                    session_data["model_used"] = self.fallback_model
                    session_data["fallback_used"] = True
                    logger.info(f"[G4O-SUCCESS] Fallback completed successfully")
                else:
                    logger.error(f"[TRANSCRIBE-FAILED] Both models failed")
                    return {"status": "error", "error": "All transcription methods failed"}
            
            # Add intelligence layer
            if session_data["status"] == "success":
                session_data.update(self._add_intelligence_layer(session_data["text"], meeting_type))
            
            # Final metadata
            processing_time = (time.time() - start_time) * 1000
            session_data["processing_time_ms"] = round(processing_time, 1)
            
            logger.info(f"[TRANSCRIBE-COMPLETE] Total time: {processing_time:.1f}ms")
            return session_data
            
        except Exception as e:
            logger.error(f"[TRANSCRIBE-ERROR] {e}")
            return {
                "status": "error",
                "error": str(e),
                "processing_time_ms": (time.time() - start_time) * 1000
            }
    
    def _transcribe_with_whisper(self, audio_data: bytes, meeting_type: str) -> Dict[str, Any]:
        """Primary transcription using Whisper-1 with verbose JSON"""
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                temp_file.write(audio_data)
                temp_file.flush()
                
                prompt = self.meeting_prompts.get(meeting_type, self.meeting_prompts["general"])
                
                with open(temp_file.name, 'rb') as audio_file:
                    response = self.client.audio.transcriptions.create(
                        model=self.primary_model,
                        file=audio_file,
                        response_format="verbose_json",
                        timestamp_granularities=["word"],
                        prompt=prompt
                    )
                
                # Extract comprehensive data
                transcript = response.text
                confidence = getattr(response, 'confidence', 0.85)
                
                # Process word-level timestamps if available
                words_data = []
                if hasattr(response, 'words') and response.words:
                    words_data = [
                        {
                            "word": word.word,
                            "start": word.start,
                            "end": word.end,
                            "confidence": getattr(word, 'confidence', 0.85)
                        }
                        for word in response.words
                    ]
                    
                    # Calculate average confidence
                    confidences = [w["confidence"] for w in words_data]
                    if confidences:
                        confidence = sum(confidences) / len(confidences)
                
                return {
                    "status": "success",
                    "text": transcript,
                    "confidence": confidence,
                    "word_count": len(transcript.split()),
                    "words_data": words_data,
                    "has_timestamps": len(words_data) > 0
                }
                
        except Exception as e:
            logger.error(f"[WHISPER-ERROR] {e}")
            return {"status": "error", "error": str(e)}
    
    def _transcribe_with_gpt4o(self, audio_data: bytes, meeting_type: str) -> Dict[str, Any]:
        """Fallback transcription using GPT-4o"""
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                temp_file.write(audio_data)
                temp_file.flush()
                
                prompt = self.meeting_prompts.get(meeting_type, self.meeting_prompts["general"])
                
                with open(temp_file.name, 'rb') as audio_file:
                    response = self.client.audio.transcriptions.create(
                        model=self.fallback_model,
                        file=audio_file,
                        response_format="text",
                        prompt=prompt
                    )
                
                transcript = response if isinstance(response, str) else response.text
                
                return {
                    "status": "success",
                    "text": transcript,
                    "confidence": 0.90,  # GPT-4o typically high confidence
                    "word_count": len(transcript.split()),
                    "words_data": [],
                    "has_timestamps": False
                }
                
        except Exception as e:
            logger.error(f"[GPT4O-ERROR] {e}")
            return {"status": "error", "error": str(e)}
    
    def _add_intelligence_layer(self, transcript: str, meeting_type: str) -> Dict[str, Any]:
        """Add smart title, tags, and action items"""
        intelligence = {
            "smart_title": self._generate_smart_title(transcript, meeting_type),
            "suggested_tags": self._extract_tags(transcript, meeting_type),
            "action_items": self._extract_action_items(transcript),
            "key_points": self._extract_key_points(transcript)
        }
        
        logger.info(f"[ACTION-TAGS] Generated {len(intelligence['action_items'])} action items")
        return intelligence
    
    def _generate_smart_title(self, transcript: str, meeting_type: str) -> str:
        """Generate intelligent session title"""
        # Simple rule-based title generation
        words = transcript.split()[:50]  # First 50 words
        text_sample = " ".join(words)
        
        # Extract potential meeting topics
        topics = re.findall(r'\b(?:about|regarding|discussing|meeting about|talk about)\s+([^.!?]+)', 
                           text_sample.lower())
        
        if topics:
            topic = topics[0].strip()[:30]
            return f"{meeting_type.title()}: {topic.title()}"
        
        # Fallback titles
        from datetime import datetime
        date_str = datetime.now().strftime("%B %d")
        return f"{meeting_type.title()} Session - {date_str}"
    
    def _extract_tags(self, transcript: str, meeting_type: str) -> List[str]:
        """Extract relevant tags from transcript"""
        tags = [f"#{meeting_type}"]
        
        # Common meeting tags
        tag_patterns = {
            "planning": r'\b(?:plan|planning|roadmap|strategy)\b',
            "review": r'\b(?:review|retrospective|feedback)\b',
            "decision": r'\b(?:decide|decision|agreed|consensus)\b',
            "action": r'\b(?:action|todo|task|assignment)\b',
            "followup": r'\b(?:follow.?up|next.?steps|next.?time)\b'
        }
        
        text_lower = transcript.lower()
        for tag, pattern in tag_patterns.items():
            if re.search(pattern, text_lower):
                tags.append(f"#{tag}")
        
        return tags[:5]  # Limit to 5 tags
    
    def _extract_action_items(self, transcript: str) -> List[str]:
        """Extract action items using pattern matching"""
        action_patterns = [
            r'(?:need to|should|must|will|going to|plan to)\s+([^.!?]+)',
            r'(?:action|todo|task):\s*([^.!?]+)',
            r'(?:assign|delegate|give)\s+\w+\s+to\s+([^.!?]+)',
            r'(?:follow.?up|next.?step):\s*([^.!?]+)'
        ]
        
        actions = []
        for pattern in action_patterns:
            matches = re.findall(pattern, transcript, re.IGNORECASE)
            for match in matches:
                action = match.strip()
                if len(action) > 10 and len(action) < 100:  # Reasonable length
                    actions.append(f"⬜ {action}")
        
        return actions[:5]  # Limit to 5 action items
    
    def _extract_key_points(self, transcript: str) -> List[str]:
        """Extract key discussion points"""
        # Simple sentence extraction based on length and keywords
        sentences = re.split(r'[.!?]+', transcript)
        key_points = []
        
        important_keywords = ['important', 'key', 'main', 'critical', 'essential', 
                             'decision', 'agreed', 'concluded', 'result']
        
        for sentence in sentences:
            sentence = sentence.strip()
            if 20 <= len(sentence) <= 150:  # Reasonable length
                if any(keyword in sentence.lower() for keyword in important_keywords):
                    key_points.append(sentence)
        
        return key_points[:3]  # Top 3 key points
    
    def generate_summary(self, transcript: str, meeting_type: str) -> Dict[str, Any]:
        """Generate intelligent summary using GPT-4"""
        try:
            prompt = f"""
            Analyze this {meeting_type} transcript and provide a structured summary:
            
            1. Main Summary (2-3 sentences)
            2. Key Points (3-5 bullet points)
            3. Action Items (specific tasks mentioned)
            4. Decisions Made (if any)
            
            Transcript:
            {transcript}
            
            Format as JSON with arrays for each section.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert meeting analyst. Provide clear, actionable summaries."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=800,
                temperature=0.3
            )
            
            summary_text = response.choices[0].message.content
            
            return {
                "status": "success",
                "summary": summary_text,
                "model": "gpt-4"
            }
            
        except Exception as e:
            logger.error(f"[SUMMARY-ERROR] {e}")
            return {"status": "error", "error": str(e)}