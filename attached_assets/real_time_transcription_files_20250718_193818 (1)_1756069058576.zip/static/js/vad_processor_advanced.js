/**
 * Advanced Voice Activity Detection Processor
 * Implements sophisticated VAD with overlapping buffer management
 */
class AdvancedVADProcessor {
    constructor() {
        this.audioContext = null;
        this.mediaStreamSource = null;
        this.processor = null;
        this.isInitialized = false;
        this.isProcessing = false;
        
        // VAD Configuration
        this.config = {
            sampleRate: 16000,
            frameSize: 512,
            energyThreshold: 0.01,
            silenceThreshold: 0.005,
            speechThreshold: 0.02,
            minSpeechDuration: 300,  // ms
            maxSilenceDuration: 1000, // ms
            overllapDuration: 1500,   // ms for sliding window
            chunkDuration: 2500       // ms for optimal chunks
        };
        
        // Buffer Management
        this.audioBuffer = [];
        this.overlappingBuffer = [];
        this.energyHistory = [];
        this.speechState = 'silence';
        this.speechStartTime = 0;
        this.silenceStartTime = 0;
        this.lastChunkTime = 0;
        
        // Callbacks
        this.onSpeechStart = null;
        this.onSpeechEnd = null;
        this.onAudioChunk = null;
        this.onEnergyLevel = null;
    }
    
    async initialize(stream) {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: this.config.sampleRate
            });
            
            this.mediaStreamSource = this.audioContext.createMediaStreamSource(stream);
            
            // Create script processor for real-time analysis
            this.processor = this.audioContext.createScriptProcessor(this.config.frameSize, 1, 1);
            
            this.processor.onaudioprocess = (event) => {
                this.processAudioFrame(event.inputBuffer);
            };
            
            // Connect audio pipeline
            this.mediaStreamSource.connect(this.processor);
            this.processor.connect(this.audioContext.destination);
            
            this.isInitialized = true;
            console.log('[VAD] Advanced VAD processor initialized');
            
        } catch (error) {
            console.error('[VAD] Initialization failed:', error);
            throw error;
        }
    }
    
    processAudioFrame(buffer) {
        if (!this.isProcessing) return;
        
        const channelData = buffer.getChannelData(0);
        const energy = this.calculateEnergy(channelData);
        const timestamp = Date.now();
        
        // Store energy for analysis
        this.energyHistory.push({ energy, timestamp });
        this.trimEnergyHistory();
        
        // Update energy level callback
        if (this.onEnergyLevel) {
            this.onEnergyLevel(energy);
        }
        
        // Store audio data
        this.audioBuffer.push(new Float32Array(channelData));
        
        // Analyze speech state
        this.analyzeSpeechState(energy, timestamp);
        
        // Check for chunk creation
        this.checkChunkCreation(timestamp);
    }
    
    calculateEnergy(samples) {
        let sum = 0;
        for (let i = 0; i < samples.length; i++) {
            sum += samples[i] * samples[i];
        }
        return Math.sqrt(sum / samples.length);
    }
    
    // Add isSilent function for chunk validation per document requirement
    isSilent(buffer) {
        const rms = this.calculateEnergy(buffer);
        return rms < 0.01; // Use RMS < 0.01 threshold as suggested
    }
    
    trimEnergyHistory() {
        const cutoff = Date.now() - 2000; // Keep 2 seconds
        this.energyHistory = this.energyHistory.filter(item => item.timestamp > cutoff);
    }
    
    analyzeSpeechState(energy, timestamp) {
        const isSpeech = energy > this.config.speechThreshold;
        const isSilence = energy < this.config.silenceThreshold;
        
        switch (this.speechState) {
            case 'silence':
                if (isSpeech) {
                    this.speechState = 'speech';
                    this.speechStartTime = timestamp;
                    console.log('[VAD] Speech detected');
                    if (this.onSpeechStart) this.onSpeechStart();
                }
                break;
                
            case 'speech':
                if (isSilence) {
                    this.speechState = 'potential_silence';
                    this.silenceStartTime = timestamp;
                } else if (isSpeech) {
                    // Continue speech, reset any silence detection
                    this.speechState = 'speech';
                }
                break;
                
            case 'potential_silence':
                if (isSpeech) {
                    // Return to speech
                    this.speechState = 'speech';
                } else if (timestamp - this.silenceStartTime > this.config.maxSilenceDuration) {
                    // Confirmed silence
                    this.speechState = 'silence';
                    console.log('[VAD] Speech ended');
                    if (this.onSpeechEnd) this.onSpeechEnd();
                    this.createChunkFromSpeech(timestamp);
                }
                break;
        }
    }
    
    checkChunkCreation(timestamp) {
        // Create chunks based on duration even during continuous speech
        if (timestamp - this.lastChunkTime > this.config.chunkDuration) {
            if (this.speechState === 'speech') {
                this.createChunkFromSpeech(timestamp);
            }
        }
    }
    
    createChunkFromSpeech(endTime) {
        if (this.audioBuffer.length === 0) return;
        
        // Calculate overlap with previous chunk
        const overlapSamples = Math.floor(
            (this.config.overllapDuration / 1000) * this.config.sampleRate / this.config.frameSize
        );
        
        // Create chunk with overlap
        const chunkData = this.createOverlappingChunk(overlapSamples);
        
        if (chunkData && chunkData.length > 0) {
            const audioBlob = this.convertToBlob(chunkData);
            const chunkDuration = (chunkData.length / this.config.sampleRate) * 1000;
            
            // CRITICAL: Ensure VAD chunks are >1.5s and non-silent per document requirement
            if (chunkDuration < 1500 || this.isSilent(chunkData)) {
                console.warn('[VAD] Skipping too-short or silent chunk:', chunkDuration, 'ms');
                return; // skip this chunk
            }
            
            console.log(`[VAD] Created chunk: ${audioBlob.size} bytes, ${chunkDuration.toFixed(1)}ms, ${this.speechState} state`);
            
            if (this.onAudioChunk) {
                this.onAudioChunk(audioBlob, {
                    chunkId: `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    hasOverlap: overlapSamples > 0,
                    speechState: this.speechState,
                    energy: this.getAverageEnergy(),
                    duration: this.audioBuffer.length * this.config.frameSize / this.config.sampleRate * 1000
                });
            }
            
            // Update overlapping buffer
            this.updateOverlappingBuffer(overlapSamples);
            this.lastChunkTime = endTime;
        }
        
        // Clear main buffer but keep overlap
        this.audioBuffer = [];
    }
    
    createOverlappingChunk(overlapSamples) {
        let chunkData = [];
        
        // Add overlap from previous chunk
        if (this.overlappingBuffer.length > 0) {
            chunkData = [...this.overlappingBuffer];
        }
        
        // Add current buffer
        chunkData = chunkData.concat(this.audioBuffer);
        
        return chunkData;
    }
    
    updateOverlappingBuffer(overlapSamples) {
        // Keep last N samples for next chunk overlap
        if (this.audioBuffer.length >= overlapSamples) {
            this.overlappingBuffer = this.audioBuffer.slice(-overlapSamples);
        } else {
            // If buffer is smaller, keep all
            this.overlappingBuffer = [...this.audioBuffer];
        }
    }
    
    convertToBlob(audioData) {
        // Convert Float32Array frames to 16-bit PCM
        const totalSamples = audioData.length * this.config.frameSize;
        const int16Array = new Int16Array(totalSamples);
        
        let offset = 0;
        for (const frame of audioData) {
            for (let i = 0; i < frame.length; i++) {
                int16Array[offset++] = Math.max(-32768, Math.min(32767, frame[i] * 32768));
            }
        }
        
        // Create WAV header
        const buffer = new ArrayBuffer(44 + int16Array.length * 2);
        const view = new DataView(buffer);
        
        // WAV header
        const writeString = (offset, string) => {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        };
        
        writeString(0, 'RIFF');
        view.setUint32(4, 36 + int16Array.length * 2, true);
        writeString(8, 'WAVE');
        writeString(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, this.config.sampleRate, true);
        view.setUint32(28, this.config.sampleRate * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        writeString(36, 'data');
        view.setUint32(40, int16Array.length * 2, true);
        
        // Copy audio data
        const audioView = new Int16Array(buffer, 44);
        audioView.set(int16Array);
        
        return new Blob([buffer], { type: 'audio/wav' });
    }
    
    getAverageEnergy() {
        if (this.energyHistory.length === 0) return 0;
        const sum = this.energyHistory.reduce((acc, item) => acc + item.energy, 0);
        return sum / this.energyHistory.length;
    }
    
    start() {
        this.isProcessing = true;
        console.log('[VAD] Started processing');
    }
    
    stop() {
        this.isProcessing = false;
        
        // Process any remaining audio
        if (this.audioBuffer.length > 0) {
            this.createChunkFromSpeech(Date.now());
        }
        
        console.log('[VAD] Stopped processing');
    }
    
    destroy() {
        this.stop();
        
        if (this.processor) {
            this.processor.disconnect();
            this.processor = null;
        }
        
        if (this.mediaStreamSource) {
            this.mediaStreamSource.disconnect();
            this.mediaStreamSource = null;
        }
        
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        
        this.isInitialized = false;
        console.log('[VAD] Destroyed');
    }
    
    // Configuration methods
    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        console.log('[VAD] Configuration updated:', this.config);
    }
    
    getConfig() {
        return { ...this.config };
    }
    
    // Audio level monitoring
    getCurrentEnergyLevel() {
        return this.energyHistory.length > 0 ? 
               this.energyHistory[this.energyHistory.length - 1].energy : 0;
    }
    
    getSpeechState() {
        return this.speechState;
    }
}

// Export for module usage
window.AdvancedVADProcessor = AdvancedVADProcessor;