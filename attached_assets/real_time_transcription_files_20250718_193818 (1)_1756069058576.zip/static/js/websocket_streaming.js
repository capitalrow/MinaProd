/**
 * WebSocket Streaming Manager for Real-Time Transcription
 * Handles bidirectional audio streaming with immediate transcript responses
 */
class WebSocketStreamingManager {
    constructor() {
        this.ws = null;
        this.isConnected = false;
        this.isStreaming = false;
        this.sessionId = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        
        // Message queue for offline buffering
        this.messageQueue = [];
        this.audioQueue = [];
        
        // Callbacks
        this.onConnected = null;
        this.onDisconnected = null;
        this.onTranscriptReceived = null;
        this.onError = null;
        this.onStatusUpdate = null;
        
        // Performance monitoring
        this.metrics = {
            messagesSent: 0,
            messagesReceived: 0,
            audioBytesSent: 0,
            latencyHistory: [],
            connectionTime: null
        };
    }
    
    async connect(sessionId) {
        try {
            this.sessionId = sessionId;
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws/transcribe/${sessionId}`;
            
            console.log('[WS] Connecting to:', wsUrl);
            
            this.ws = new WebSocket(wsUrl);
            this.setupEventHandlers();
            
            // Wait for connection
            await new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('WebSocket connection timeout'));
                }, 10000);
                
                this.ws.onopen = () => {
                    clearTimeout(timeout);
                    resolve();
                };
                
                this.ws.onerror = (error) => {
                    clearTimeout(timeout);
                    reject(error);
                };
            });
            
        } catch (error) {
            console.error('[WS] Connection failed:', error);
            throw error;
        }
    }
    
    setupEventHandlers() {
        this.ws.onopen = () => {
            console.log('[WS] Connected successfully');
            this.isConnected = true;
            this.reconnectAttempts = 0;
            this.metrics.connectionTime = Date.now();
            
            // Send queued messages
            this.flushMessageQueue();
            
            if (this.onConnected) {
                this.onConnected();
            }
            
            // Send initial configuration
            this.sendMessage({
                type: 'config',
                config: {
                    language: 'en',
                    model: 'whisper-1',
                    response_format: 'verbose_json',
                    enable_vad: true,
                    chunk_overlap: true
                }
            });
        };
        
        this.ws.onmessage = (event) => {
            this.handleMessage(event.data);
        };
        
        this.ws.onclose = (event) => {
            console.log('[WS] Connection closed:', event.code, event.reason);
            this.isConnected = false;
            this.isStreaming = false;
            
            if (this.onDisconnected) {
                this.onDisconnected(event);
            }
            
            // Attempt reconnection if not intentional
            if (event.code !== 1000 && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.attemptReconnection();
            }
        };
        
        this.ws.onerror = (error) => {
            console.error('[WS] Error:', error);
            if (this.onError) {
                this.onError(error);
            }
        };
    }
    
    async handleMessage(data) {
        try {
            const message = JSON.parse(data);
            this.metrics.messagesReceived++;
            
            // ACTION #1: CRITICAL - Ensure chunk_id is explicitly preserved and validated
            if (!message.chunk_id || message.chunk_id === 'undefined' || message.chunk_id === 'null') {
                console.warn(`[WS] ⚠️ Missing or invalid chunk_id in WebSocket message: ${message.chunk_id}`);
                message.chunk_id = `ws_fallback_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
            }
            
            // Calculate latency if message has timestamp
            if (message.timestamp) {
                const latency = Date.now() - message.timestamp;
                this.metrics.latencyHistory.push(latency);
                
                // Keep only last 50 latency measurements
                if (this.metrics.latencyHistory.length > 50) {
                    this.metrics.latencyHistory = this.metrics.latencyHistory.slice(-50);
                }
            }
            
            // ACTION #5: Improve latency + retries - Add throttling for backpressure prevention
            const currentTime = Date.now();
            if (this.lastMessageTime && (currentTime - this.lastMessageTime) < 100) {
                // Throttle messages if coming too fast (< 100ms apart)
                setTimeout(() => this.processMessage(message), 100);
                return;
            }
            this.lastMessageTime = currentTime;
            
            this.processMessage(message);
            
        } catch (error) {
            console.error('[WS] Message parsing error:', error);
            if (this.onError) {
                this.onError({ error: 'Message parsing failed', details: error.message });
            }
        }
    }
    
    processMessage(message) {
        switch (message.type) {
            case 'transcript_partial':
                this.handlePartialTranscript(message);
                break;
                
            case 'transcript_final':
                this.handleFinalTranscript(message);
                break;
                
            case 'status':
                this.handleStatusUpdate(message);
                break;
                
            case 'error':
                this.handleError(message);
                break;
                
            default:
                console.warn(`[WS] Unknown message type: ${message.type}`);
        }
    }
    
    handlePartialTranscript(message) {
        // ACTION 1: Ensure chunk_id is explicitly preserved
        const chunkId = message.chunk_id || `partial_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
        
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                chunk_id: chunkId,
                text: message.text,
                type: 'partial',
                confidence: message.confidence || 0,
                timestamp: message.timestamp || Date.now()
            });
        }
    }
    
    handleFinalTranscript(message) {
        // ACTION 1: Ensure chunk_id is explicitly preserved
        const chunkId = message.chunk_id || `final_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
        
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                chunk_id: chunkId,
                text: message.text,
                type: 'final',
                confidence: message.confidence || 0,
                timestamp: message.timestamp || Date.now()
            });
        }
    }
    
    handleStatusUpdate(message) {
        if (this.onStatusUpdate) {
            this.onStatusUpdate(message);
        }
    }
    
    handleError(message) {
        if (this.onError) {
            this.onError(message);
        }
    }
    
    // ACTION 5: Add retry logic for WebSocket operations
    async sendWithRetry(data, maxRetries = 2) {
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                    this.ws.send(JSON.stringify(data));
                    return;
                }
                throw new Error('WebSocket not open');
            } catch (error) {
                if (attempt === maxRetries) {
                    console.error(`[WS] Send failed after ${maxRetries} retries:`, error);
                    throw error;
                }
                
                const delay = 1000 * Math.pow(2, attempt);
                console.log(`[WS] Send retry ${attempt + 1}/${maxRetries} in ${delay}ms`);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    
    handlePartialTranscript(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                text: message.text,
                chunkId: message.chunkId || message.chunk_id,
                type: 'partial',
                confidence: message.confidence || 0,
                timestamp: message.timestamp || Date.now()
            });
        }
    }
    
    handleFinalTranscript(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                text: message.text,
                chunkId: message.chunkId || message.chunk_id,
                type: 'final',
                confidence: message.confidence || 0,
                timestamp: message.timestamp || Date.now()
            });
        }
    }
    
    handleTranscriptCorrection(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                text: message.text,
                chunkId: message.chunkId || message.chunk_id,
                type: 'correction',
                confidence: message.confidence || 0,
                timestamp: message.timestamp || Date.now()
            });
        }
    }
    
    handleStatusUpdate(message) {
        if (this.onStatusUpdate) {
            this.onStatusUpdate(message);
        }
    }
    
    handleError(message) {
        if (this.onError) {
            this.onError(message);
        }
    }
    
    // Continue with original handlePartialTranscript method
    handlePartialTranscriptOriginal(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                type: 'partial',
                text: message.text,
                confidence: message.confidence,
                chunkId: message.chunk_id,
                timestamp: message.timestamp,
                isStable: message.is_stable || false
            });
        }
    }
    
    handleFinalTranscript(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                type: 'final',
                text: message.text,
                confidence: message.confidence,
                chunkId: message.chunk_id,
                timestamp: message.timestamp,
                segments: message.segments || []
            });
        }
    }
    
    handleTranscriptCorrection(message) {
        if (this.onTranscriptReceived) {
            this.onTranscriptReceived({
                type: 'correction',
                text: message.text,
                confidence: message.confidence,
                replaceChunkId: message.replace_chunk_id,
                timestamp: message.timestamp
            });
        }
    }
    
    handleStatusUpdate(message) {
        if (this.onStatusUpdate) {
            this.onStatusUpdate({
                status: message.status,
                message: message.message,
                details: message.details
            });
        }
    }
    
    handleError(message) {
        console.error('[WS] Server error:', message.error);
        if (this.onError) {
            this.onError(new Error(message.error));
        }
    }
    
    sendAudioChunk(audioBlob, metadata = {}) {
        if (!this.isConnected) {
            console.warn('[WS] Not connected, queuing audio');
            this.audioQueue.push({ audioBlob, metadata });
            return;
        }
        
        // Convert blob to base64
        const reader = new FileReader();
        reader.onload = () => {
            const base64Audio = reader.result.split(',')[1];
            
            const message = {
                type: 'audio_chunk',
                audio_data: base64Audio,
                metadata: {
                    chunk_id: this.generateChunkId(),
                    timestamp: Date.now(),
                    has_overlap: metadata.hasOverlap || false,
                    speech_state: metadata.speechState || 'unknown',
                    energy_level: metadata.energy || 0,
                    duration_ms: metadata.duration || 0,
                    ...metadata
                }
            };
            
            this.sendMessage(message);
            this.metrics.audioBytesSent += audioBlob.size;
        };
        
        reader.readAsDataURL(audioBlob);
    }
    
    sendMessage(message) {
        if (!this.isConnected) {
            this.messageQueue.push(message);
            return;
        }
        
        try {
            this.ws.send(JSON.stringify(message));
            this.metrics.messagesSent++;
        } catch (error) {
            console.error('[WS] Error sending message:', error);
            this.messageQueue.push(message);
        }
    }
    
    flushMessageQueue() {
        while (this.messageQueue.length > 0 && this.isConnected) {
            const message = this.messageQueue.shift();
            this.sendMessage(message);
        }
        
        while (this.audioQueue.length > 0 && this.isConnected) {
            const { audioBlob, metadata } = this.audioQueue.shift();
            this.sendAudioChunk(audioBlob, metadata);
        }
    }
    
    startStreaming() {
        if (!this.isConnected) {
            throw new Error('WebSocket not connected');
        }
        
        this.isStreaming = true;
        this.sendMessage({
            type: 'start_streaming',
            timestamp: Date.now()
        });
        
        console.log('[WS] Started streaming');
    }
    
    stopStreaming() {
        this.isStreaming = false;
        
        if (this.isConnected) {
            this.sendMessage({
                type: 'stop_streaming',
                timestamp: Date.now()
            });
        }
        
        console.log('[WS] Stopped streaming');
    }
    
    requestFlush() {
        if (this.isConnected) {
            this.sendMessage({
                type: 'flush_request',
                timestamp: Date.now()
            });
        }
    }
    
    async attemptReconnection() {
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`[WS] Attempting reconnection ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
        
        setTimeout(async () => {
            try {
                await this.connect(this.sessionId);
                
                if (this.isStreaming) {
                    this.startStreaming();
                }
                
            } catch (error) {
                console.error('[WS] Reconnection failed:', error);
                
                if (this.reconnectAttempts >= this.maxReconnectAttempts) {
                    console.error('[WS] Max reconnection attempts reached');
                    if (this.onError) {
                        this.onError(new Error('WebSocket reconnection failed'));
                    }
                }
            }
        }, delay);
    }
    
    disconnect() {
        this.isStreaming = false;
        
        if (this.ws) {
            this.ws.close(1000, 'Client disconnect');
            this.ws = null;
        }
        
        this.isConnected = false;
        console.log('[WS] Disconnected');
    }
    
    generateChunkId() {
        return `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    getMetrics() {
        const avgLatency = this.metrics.latencyHistory.length > 0 ?
            this.metrics.latencyHistory.reduce((a, b) => a + b, 0) / this.metrics.latencyHistory.length : 0;
        
        return {
            ...this.metrics,
            averageLatency: avgLatency,
            connectionDuration: this.metrics.connectionTime ? Date.now() - this.metrics.connectionTime : 0,
            isConnected: this.isConnected,
            isStreaming: this.isStreaming,
            queuedMessages: this.messageQueue.length,
            queuedAudio: this.audioQueue.length
        };
    }
    
    // Configuration methods
    updateConfig(config) {
        if (this.isConnected) {
            this.sendMessage({
                type: 'update_config',
                config: config
            });
        }
    }
    
    // Network status handling
    handleNetworkChange() {
        if (!navigator.onLine && this.isConnected) {
            console.log('[WS] Network offline detected');
            this.isConnected = false;
        } else if (navigator.onLine && !this.isConnected && this.ws) {
            console.log('[WS] Network online detected, attempting reconnection');
            this.attemptReconnection();
        }
    }
}

// Global network status monitoring
window.addEventListener('online', () => {
    console.log('[WS] Network online');
});

window.addEventListener('offline', () => {
    console.log('[WS] Network offline');
});

// Export for module usage
window.WebSocketStreamingManager = WebSocketStreamingManager;