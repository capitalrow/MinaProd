/**
 * Real-Time Transcription Engine
 * Processes audio chunks every 2-3 seconds with immediate backend transcription
 */

class RealTimeTranscriptionEngine {
    constructor() {
        this.isRecording = false;
        this.mediaRecorder = null;
        this.audioStream = null;
        this.socket = null;
        this.sessionId = null;
        this.chunkCounter = 0;
        this.vadProcessor = null;
        this.audioMeter = null;
        this.isWebSocketEnabled = false;
        this.config = {};
        
        // ACTION 1: Map-based transcript registry per document requirements
        this.transcriptRegistry = new Map(); // chunk_id -> {text, confidence, timestamp, type, is_stable}
        this.chunkMap = new Map(); // ACTION 1: chunkMap[chunkId] = result keyed structure
        this.partialTranscripts = new Map(); // Separate tracking for partials that might be overwritten
        this.transcriptItems = [];
        this.wordCount = 0;
        this.recordingStartTime = null;
        this.recordingTimer = null;
        this.cachedEBMLHeader = null; // Fix for WebM EBML header corruption
        
        // 🔍 METRICS VALIDATION: Track all required metrics per document
        this.sessionMetrics = {
            sessionId: null,
            duration: 0,
            totalChunks: 0,
            finalWordCount: 0,
            avgConfidence: 0,
            driftRatio: 0,              // Final transcript drift vs interim
            retryCount: 0,              // Number of retry attempts
            duplicatesBlocked: 0,       // Suppressed duplicate chunks
            finalisationRate: 0,        // Percentage of chunks finalised
            avgLatency: 0,              // Average processing latency
            startTime: Date.now(),
            lastChunkTime: Date.now(),
            errorCount: 0,
            websocketDisconnects: 0,
            flushDuration: 0
        };
        
        // Document requirement: Final overwrites partial using same chunkId
        this.chunkStates = new Map(); // chunk_id -> 'partial' | 'final'
        
        // 🧠 FIX #1: Initialize all state holders in the engine class
        this.interimUtterances = new Map(); // For interim transcripts
        this.finalUtterances = new Map(); // For final transcripts
        this.liveTranscript = ""; // Unified live transcript feed
        this.chunkHashSet = new Set(); // For deduplication
        
        // 🔧 FIX: Central Transcript Registry to prevent duplicates
        // Note: transcriptRegistry already initialized as Map on line 20 - do not overwrite
        this.processedChunks = new Set(); // Track processed chunk IDs
        this.chunkCounter = 0; // Counter for chunks without IDs
        
        // BULLETPROOF: Early duplicate detection Set for all processing pathways
        this.processedTranscriptEvents = new Set(); // Track processed events across all pathways
        
        // ACTION A: Implement chunkTranscriptStore (Map) to track chunk_id -> text and avoid duplicates
        this.chunkTranscriptStore = new Map(); // chunk_id -> { text, timestamp, type, confidence }
        this.liveTranscriptStore = new Map(); // For live transcript tracking
        this.activeChunks = new Map(); // For active chunk tracking
        
        // Additional state for metrics
        this.totalWords = 0;
        this.totalChunks = 0;
        this.totalConfidence = 0;
        
        // CRITICAL FIX: Final transcript appending fix per document requirement
        this.finalChunks = {}; // Track final chunks to prevent duplication
        
        // PATCH FIX 1: Prevent duplicate rendering with processedChunks Set
        this.processedChunks = new Set(); // Track processed chunk IDs to prevent duplicates
        
        // PATCH FIX 4: Live metrics tracking
        this.liveWordCount = 0;
        this.liveConfidence = 0;
        
        // PATCH FIX 2: Enhanced clearDataStructures for processedChunks Set cleanup
        this.clearDataStructures = () => {
            this.processedChunks.clear();
            this.totalWords = 0;
            this.totalChunks = 0;
            this.totalConfidence = 0;
            this.liveWordCount = 0;
            this.liveConfidence = 0;
            console.log('[RT-ENGINE] 🧹 PATCH FIX 2: Data structures cleared between sessions');
        };
        
        console.log('[RT-ENGINE] Initialized with all state holders, performance metrics, and duplicate prevention');
    }
    
    // ACTION 2: Ensure proper finalization logic - flushChunks implementation
    async flushChunks() {
        const flushStartTime = Date.now();
        console.log('[RT-ENGINE] 🔄 Starting chunk flush process...');
        
        try {
            // Collect all interim chunks for final processing
            const interimChunks = [];
            for (const [chunkId, chunk] of this.chunkMap) {
                if (chunk.type === 'partial') {
                    interimChunks.push({ chunkId, ...chunk });
                }
            }
            
            // Send flush request to enhanced backend
            const response = await fetch('/api/flush_session_enhanced', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    session_id: this.sessionId,
                    interim_chunks: interimChunks
                })
            });
            
            if (response.ok) {
                const result = await response.json();
                
                // ACTION 3: Emit final_transcript event with merged results
                this.handleFinalTranscript(result);
                
                // Update session metrics
                this.sessionMetrics.flushDuration = Date.now() - flushStartTime;
                this.sessionMetrics.finalTranscriptWordCount = result.final_transcript ? result.final_transcript.split(' ').length : 0;
                
                // ACTION 7: Calculate drift ratio
                this.calculateDriftRatio(result.final_transcript);
                
                console.log('[RT-ENGINE] ✅ Flush completed successfully');
                return result;
            } else {
                throw new Error(`Flush failed: ${response.status}`);
            }
        } catch (error) {
            console.error('[RT-ENGINE] ❌ Flush failed:', error);
            this.sessionMetrics.errorCount++;
            this.sessionMetrics.flushDuration = Date.now() - flushStartTime;
            throw error;
        }
    }
    
    // ACTION 7: Final transcript drift protection
    calculateDriftRatio(finalTranscript) {
        if (!finalTranscript) return;
        
        let totalInterimWords = 0;
        let matchedWords = 0;
        
        // Combine all interim transcripts
        const interimText = Array.from(this.chunkMap.values())
            .filter(chunk => chunk.type === 'partial')
            .map(chunk => chunk.text)
            .join(' ');
        
        const interimWords = interimText.split(' ').filter(word => word.length > 0);
        const finalWords = finalTranscript.split(' ').filter(word => word.length > 0);
        
        totalInterimWords = interimWords.length;
        
        // Calculate similarity
        for (const interimWord of interimWords) {
            if (finalWords.includes(interimWord)) {
                matchedWords++;
            }
        }
        
        const driftRatio = totalInterimWords > 0 ? ((totalInterimWords - matchedWords) / totalInterimWords) * 100 : 0;
        this.sessionMetrics.driftRatio = Math.round(driftRatio * 10) / 10;
        
        // ACTION 7: Log warning if drift > 10%
        if (driftRatio > 10) {
            console.warn(`[RT-ENGINE] ⚠️ HIGH DRIFT DETECTED: ${driftRatio.toFixed(1)}% - Consider chunk boundary optimization`);
        }
        
        console.log(`[RT-ENGINE] 📊 Drift ratio: ${this.sessionMetrics.driftRatio}%`);
    }
    
    // ACTION 8: Post-session summary logging
    logSessionSummary() {
        console.log('[RT-ENGINE] 📋 === SESSION SUMMARY ===');
        console.log(`Session ID: ${this.sessionMetrics.sessionId}`);
        console.log(`Total Chunks: ${this.sessionMetrics.totalChunks}`);
        console.log(`Final Transcript Word Count: ${this.sessionMetrics.finalTranscriptWordCount}`);
        console.log(`Drift Ratio: ${this.sessionMetrics.driftRatio}%`);
        console.log(`Duplicates Blocked: ${this.sessionMetrics.duplicatesBlocked}`);
        console.log(`Avg Chunk Confidence: ${this.sessionMetrics.avgChunkConfidence}%`);
        console.log(`Flush Duration: ${this.sessionMetrics.flushDuration}ms`);
        console.log(`Error Count: ${this.sessionMetrics.errorCount}`);
        console.log(`Retries: ${this.sessionMetrics.retryCount}`);
        console.log(`WebSocket Disconnects: ${this.sessionMetrics.websocketDisconnects}`);
        console.log('[RT-ENGINE] 📋 === END SUMMARY ===');
    }
    
    // ACTION 3: Frontend final display - render from stored chunkMap
    renderFinalTranscriptFromChunkMap() {
        console.log('[RT-ENGINE] 📄 Rendering final transcript from chunk map...');
        
        // Get all final chunks in order
        const finalChunks = Array.from(this.chunkMap.values())
            .filter(chunk => chunk.type === 'final')
            .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
        
        if (finalChunks.length === 0) {
            console.log('[RT-ENGINE] No final chunks to render');
            return;
        }
        
        // Combine all final transcript text
        const finalTranscriptText = finalChunks
            .map(chunk => chunk.text)
            .join(' ')
            .trim();
        
        // Update session metrics
        this.sessionMetrics.finalTranscriptWordCount = finalTranscriptText.split(' ').length;
        
        // Display final transcript
        this.displayFinalTranscript({ final_transcript: finalTranscriptText });
        
        console.log(`[RT-ENGINE] ✅ Final transcript rendered: ${finalTranscriptText.length} characters`);
    }
    
    // ACTION 4: Tighten deduplication logic with sliding window
    checkDuplicationWithSlidingWindow(text, timestamp) {
        const now = Date.now();
        const windowSize = 5000; // 5 seconds
        
        // Clean old entries from sliding window
        const recentEntries = Array.from(this.chunkMap.values())
            .filter(chunk => (now - (chunk.timestamp || 0)) <= windowSize);
        
        // Count identical text occurrences in recent window
        const identicalCount = recentEntries.filter(chunk => 
            chunk.text === text
        ).length;
        
        // ACTION 4: Prevent >3 identical chunks within <5s
        if (identicalCount >= 3) {
            console.log(`[RT-ENGINE] 🚫 SLIDING WINDOW DEDUPLICATION: "${text}" appeared ${identicalCount} times in 5s`);
            this.sessionMetrics.duplicatesBlocked++;
            return true; // Block this chunk
        }
        
        return false; // Allow this chunk
    }
    
    // ACTION 5: Retry logic with exponential backoff
    async retryWithBackoff(operation, maxRetries = 2, baseDelay = 1000) {
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                const result = await operation();
                if (attempt > 0) {
                    console.log(`[RT-ENGINE] ✅ Retry successful on attempt ${attempt + 1}`);
                }
                return result;
            } catch (error) {
                this.sessionMetrics.retryCount++;
                
                if (attempt === maxRetries) {
                    console.error(`[RT-ENGINE] ❌ Max retries (${maxRetries}) exceeded:`, error);
                    throw error;
                }
                
                const delay = baseDelay * Math.pow(2, attempt); // Exponential backoff
                console.log(`[RT-ENGINE] 🔄 Retry ${attempt + 1}/${maxRetries} in ${delay}ms:`, error.message);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    
    // 🧠 WHISPER: String similarity comparison (Levenshtein distance) to suppress duplicates
    calculateLevenshteinDistance(text1, text2) {
        const matrix = [];
        const n = text1.length;
        const m = text2.length;
        
        if (n === 0) return m;
        if (m === 0) return n;
        
        // Create matrix
        for (let i = 0; i <= n; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= m; j++) {
            matrix[0][j] = j;
        }
        
        // Fill matrix
        for (let i = 1; i <= n; i++) {
            for (let j = 1; j <= m; j++) {
                if (text1.charAt(i - 1) === text2.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j] + 1,      // deletion
                        matrix[i][j - 1] + 1,      // insertion
                        matrix[i - 1][j - 1] + 1   // substitution
                    );
                }
            }
        }
        
        return matrix[n][m];
    }
    
    // 🧠 WHISPER: Enhanced duplicate suppression with string similarity
    isDuplicateByLevenshtein(currentText, threshold = 0.8) {
        if (!this.lastChunkText || !currentText) return false;
        
        const distance = this.calculateLevenshteinDistance(currentText, this.lastChunkText);
        const maxLength = Math.max(currentText.length, this.lastChunkText.length);
        const similarity = 1 - (distance / maxLength);
        
        if (similarity >= threshold) {
            console.log(`[RT-ENGINE] 🚫 DUPLICATE DETECTED: Similarity ${(similarity * 100).toFixed(1)}%`);
            this.sessionMetrics.duplicatesBlocked++;
            return true;
        }
        
        this.lastChunkText = currentText;
        return false;
    }
    
    // ACTION 6: Zero hallucinations check with enhanced patterns
    validateContentForHallucinations(text) {
        // Check for emojis or non-verbal content
        const emojiPattern = /[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu;
        const nonVerbalPattern = /[🎵✨🎶🎼🎤🎧🎬🎭🎪🎨🎯🎲🎳🎴🎮🎯]/g;
        
        if (emojiPattern.test(text) || nonVerbalPattern.test(text)) {
            console.log(`[RT-ENGINE] 🚫 HALLUCINATION DETECTED: Non-verbal content "${text}"`);
            return false;
        }
        
        // Enhanced repetition detection per document requirements
        const repetitivePatterns = ['You', 'or', 'um', 'uh', 'so', 'like', 'yeah', 'okay'];
        const words = text.split(' ').filter(w => w.length > 0);
        
        if (words.length === 1 && repetitivePatterns.includes(words[0])) {
            console.log(`[RT-ENGINE] 🚫 HALLUCINATION DETECTED: Repetitive filler "${text}"`);
            return false;
        }
        
        // Check for Korean patterns (additional to backend filtering)
        const koreanPatterns = ['MBC', '뉴스', '날씨', '이덕영', '기상캐스터', '배혜지'];
        if (koreanPatterns.some(pattern => text.includes(pattern))) {
            console.log(`[RT-ENGINE] 🚫 HALLUCINATION DETECTED: Korean pattern "${text}"`);
            return false;
        }
        
        return true;
    }
    
    // ACTION 3: Enhanced final transcript display
    displayFinalTranscript(data = {}) {
        const finalTranscript = data.final_transcript || 'No meaningful speech detected.';
        
        // Find or create final transcript container
        let finalContainer = document.getElementById('finalTranscriptContainer');
        if (!finalContainer) {
            finalContainer = document.createElement('div');
            finalContainer.id = 'finalTranscriptContainer';
            finalContainer.className = 'final-transcript-container';
            
            // Insert after live transcript
            const liveContainer = document.getElementById('liveTranscript') || document.querySelector('.live-transcript');
            if (liveContainer) {
                liveContainer.after(finalContainer);
            } else {
                document.body.appendChild(finalContainer);
            }
        }
        
        // ACTION 3: Clear all interim chunks and display clean final transcript
        finalContainer.innerHTML = `
            <div class="final-transcript-header">
                <h3>📋 Final Transcript</h3>
                <div class="transcript-stats">
                    <span>Words: ${this.sessionMetrics.finalTranscriptWordCount}</span>
                    <span>Confidence: ${Math.round(this.sessionMetrics.avgChunkConfidence)}%</span>
                    <span>Drift: ${this.sessionMetrics.driftRatio}%</span>
                </div>
            </div>
            <div class="final-transcript-content">
                ${finalTranscript}
            </div>
            <div class="final-transcript-actions">
                <button onclick="this.downloadTranscript('${data.session_id}', '${finalTranscript}')" class="btn-download">
                    📥 Download TXT
                </button>
                <button onclick="this.copyTranscript('${finalTranscript}')" class="btn-copy">
                    📋 Copy
                </button>
            </div>
        `;
        
        // Add CSS for final transcript styling
        const finalTranscriptCSS = `
            .final-transcript-container {
                margin: 20px 0;
                padding: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 12px;
                color: white;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            }
            .final-transcript-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 15px;
            }
            .transcript-stats {
                display: flex;
                gap: 15px;
                font-size: 0.9em;
                opacity: 0.9;
            }
            .final-transcript-content {
                background: rgba(255,255,255,0.1);
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 15px;
                line-height: 1.6;
            }
            .final-transcript-actions {
                display: flex;
                gap: 10px;
            }
            .btn-download, .btn-copy {
                padding: 8px 16px;
                border: none;
                border-radius: 6px;
                background: rgba(255,255,255,0.2);
                color: white;
                cursor: pointer;
                font-size: 0.9em;
                transition: all 0.3s ease;
            }
            .btn-download:hover, .btn-copy:hover {
                background: rgba(255,255,255,0.3);
                transform: translateY(-2px);
            }
        `;
        
        // Add CSS if not already present
        if (!document.getElementById('finalTranscriptStyles')) {
            const style = document.createElement('style');
            style.id = 'finalTranscriptStyles';
            style.textContent = finalTranscriptCSS;
            document.head.appendChild(style);
        }
        
        console.log('[RT-ENGINE] ✅ Final transcript displayed with enhanced styling');
    }

    async initialize(config = {}) {
        this.config = {
            chunkInterval: 4000, // 4 seconds - balance between completeness and silence
            useWebSocket: true,
            fallbackToHTTP: true,
            enableVAD: true,
            enableConfidenceScoring: true,
            enableAudioMeter: true,
            overlappingChunks: false, // Start simple, add later
            realTimeCorrection: false, // Start simple, add later
            mobileOptimizations: true,
            ...config
        };

        console.log('[RT-ENGINE] Initializing with config:', this.config);

        // Initialize WebSocket if enabled
        if (this.config.useWebSocket) {
            await this.initializeWebSocket();
        }
        
        // Setup WebSocket callbacks
        if (this.wsManager) {
            this.wsManager.onTranscriptReceived = (data) => {
                this.displayTranscriptUpdate(data);
            };
        } else if (this.socket) {
            // Setup Socket.IO listeners for transcript updates
            // CRITICAL: CTO-specified events (EXACT requirement)
            this.socket.on('transcript_partial', (data) => {
                // CRITICAL FIX: Validate data before processing
                if (!data || !data.chunk_id || !data.text || data.text === '' || data.text === 'undefined') {
                    console.log('[RT-ENGINE] Invalid partial data, skipping:', data);
                    return;
                }
                
                // BULLETPROOF: Early duplicate detection AFTER validation
                const chunkId = data.chunk_id;
                const processingKey = `partial_${chunkId}`;
                
                // Check if we've already processed this exact event
                if (this.processedTranscriptEvents.has(processingKey)) {
                    console.log('[RT-ENGINE] 🚫 EARLY DUPLICATE DETECTION: Skipping partial', chunkId);
                    return; // Exit immediately - no processing
                }
                
                // Mark as processed FIRST
                this.processedTranscriptEvents.add(processingKey);
                
                console.log('[RT-ENGINE] ✅ CTO-SPEC transcript_partial received:', data);
                console.log('[RT-ENGINE] 🔍 CONFIDENCE DEBUG: Raw confidence =', data.confidence, 'Type:', typeof data.confidence);
                
                // Store in central registry
                this.transcriptRegistry.set(chunkId, {
                    text: data.text,
                    chunkId: chunkId,
                    type: 'partial',
                    confidence: data.confidence || 0.6,
                    timestamp: data.timestamp
                });
                
                // Process the chunk
                this.handleTranscription({
                    text: data.text,
                    chunkId: chunkId,
                    type: 'partial',
                    confidence: data.confidence || 0.6,
                    timestamp: data.timestamp
                });
                
                // Display update
                this.displayTranscriptUpdate({
                    text: data.text,
                    chunkId: chunkId,
                    type: 'partial',
                    confidence: data.confidence || 0.6,
                    timestamp: data.timestamp
                });
            });
            
            this.socket.on('transcript_final', (data) => {
                // CRITICAL FIX: Validate data before processing
                if (!data || !data.chunk_id) {
                    console.log('[RT-ENGINE] Invalid final data, skipping:', data);
                    return;
                }
                
                // Allow empty final text for cleanup but validate chunk_id
                const chunkId = data.chunk_id;
                const processingKey = `final_${chunkId}`;
                
                // Check if we've already processed this exact event
                if (this.processedTranscriptEvents.has(processingKey)) {
                    console.log('[RT-ENGINE] 🚫 EARLY DUPLICATE DETECTION: Skipping final', chunkId);
                    return; // Exit immediately - no processing
                }
                
                // Mark as processed FIRST
                this.processedTranscriptEvents.add(processingKey);
                
                console.log('[RT-ENGINE] ✅ CTO-SPEC transcript_final received:', data);
                console.log('[RT-ENGINE] 🔍 CONFIDENCE DEBUG: Raw confidence =', data.confidence, 'Type:', typeof data.confidence);
                
                // 🔧 FIX #3: Update existing chunk in registry or create new one
                if (this.transcriptRegistry.has(chunkId)) {
                    console.log('[RT-ENGINE] 🔄 Updating existing chunk to final:', chunkId);
                    const existing = this.transcriptRegistry.get(chunkId);
                    existing.type = 'final';
                    existing.confidence = data.confidence || 0.8;
                    existing.text = data.text;
                    this.transcriptRegistry.set(chunkId, existing);
                } else {
                    console.log('[RT-ENGINE] 🆕 Creating new final chunk:', chunkId);
                    this.transcriptRegistry.set(chunkId, {
                        text: data.text,
                        chunkId: chunkId,
                        type: 'final',
                        confidence: data.confidence || 0.8,
                        timestamp: data.timestamp
                    });
                }
                
                // Process the chunk
                this.handleTranscription({
                    text: data.text,
                    chunkId: chunkId,
                    type: 'final',
                    confidence: data.confidence || 0.8,
                    timestamp: data.timestamp
                });
                
                // Display update
                this.displayTranscriptUpdate({
                    text: data.text,
                    chunkId: chunkId,
                    type: 'final',
                    confidence: data.confidence || 0.8,
                    timestamp: data.timestamp
                });
            });
            
            // Legacy events for backward compatibility
            this.socket.on('transcription', (data) => {
                this.displayTranscriptUpdate({
                    text: data.text,
                    chunkId: data.chunk_id,
                    type: 'final',
                    confidence: data.confidence || 0.8,
                    timestamp: data.timestamp
                });
            });
            
            this.socket.on('interim_transcript', (data) => {
                // ACTION 1: Store in chunkMap with proper chunk_id validation
                const chunkId = data.chunk_id || `fallback_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
                
                this.chunkMap.set(chunkId, {
                    text: data.text,
                    type: 'partial',
                    confidence: data.confidence || 0.6,
                    timestamp: data.timestamp || Date.now(),
                    chunkId: chunkId
                });
                
                this.displayTranscriptUpdate({
                    text: data.text,
                    chunkId: chunkId,
                    type: 'partial',
                    confidence: data.confidence || 0.6,
                    timestamp: data.timestamp
                });
                
                // Update session metrics
                this.sessionMetrics.totalChunks++;
                this.sessionMetrics.avgChunkConfidence = 
                    (this.sessionMetrics.avgChunkConfidence + (data.confidence || 0.6)) / 2;
            });
            
            // ACTION 2: Listen for final_transcript events
            this.socket.on('final_transcript', (data) => {
                this.handleFinalTranscript(data);
            });
            
            // ACTION 3: Frontend final display - listen for transcript_final to handle final display
            this.socket.on('transcript_final', (data) => {
                const chunkId = data.chunk_id || `final_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
                
                // Store in chunkMap as final
                this.chunkMap.set(chunkId, {
                    text: data.text,
                    type: 'final',
                    confidence: data.confidence || 0.8,
                    timestamp: data.timestamp || Date.now(),
                    chunkId: chunkId
                });
                
                // ACTION 3: Loop over stored chunkMap entries and render final display
                this.renderFinalTranscriptFromChunkMap();
            });
        }
        
        // DISABLED: Remove duplicate placeholder creation to prevent dual display
        this.createTranscriptPlaceholder = function(chunkId) {
            // CRITICAL FIX: Disabled to prevent duplicate display systems
            // WebSocket events will handle all transcript display
            console.log(`[RT-ENGINE] Skipping placeholder creation for ${chunkId} - using WebSocket display only`);
        };

        // FIXED: Initialize data structures BEFORE use to prevent "undefined" errors
        this.initializeDataStructures();
        
        // Initialize VAD processor with proper error handling
        if (this.config.enableVAD) {
            try {
                // FIXED: Check if VADProcessor exists before attempting to use it
                if (typeof VADProcessor !== 'undefined') {
                    this.vadProcessor = new VADProcessor();
                    
                    // 🧠 FIX #6: Fix VAD processor fallback with proper guards
                    if (this.vadProcessor && typeof this.vadProcessor.initialize === 'function') {
                        await this.vadProcessor.initialize();
                        console.log('[RT-ENGINE] ✅ VAD processor initialized successfully');
                    } else {
                        console.warn('[RT-ENGINE] VADProcessor.initialize is not a function, using fallback');
                        this.vadProcessor = this.createFallbackVADProcessor();
                    }
                    
                    // Wire up VAD processor WITHOUT creating duplicate placeholders
                    if (this.vadProcessor) {
                        this.vadProcessor.onAudioChunk = (audioBlob, metadata) => {
                            // CRITICAL FIX: Don't create placeholders - let WebSocket events handle display
                            // Send chunk for transcription directly
                            this.sendChunkForTranscription(audioBlob, metadata);
                        };
                    }
                } else {
                    console.warn('[RT-ENGINE] VADProcessor not available, using fallback');
                    this.vadProcessor = this.createFallbackVADProcessor();
                }
            } catch (error) {
                console.warn('[RT-ENGINE] VAD initialization failed:', error);
                this.vadProcessor = this.createFallbackVADProcessor();
            }
        } else {
            console.log('[RT-ENGINE] VAD disabled in configuration');
            this.vadProcessor = null;
        }

        // Initialize audio meter
        if (this.config.enableAudioMeter) {
            this.audioMeter = new AudioMeter();
        }
        
        // Add sendChunkForTranscription method
        this.sendChunkForTranscription = async function(audioBlob, metadata) {
            try {
                const chunkId = metadata.chunkId || `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                
                // Send via WebSocket if available
                if (this.wsManager && this.wsManager.isConnected) {
                    await this.wsManager.sendAudioChunk(audioBlob, chunkId);
                } else {
                    // Fallback to HTTP API
                    const formData = new FormData();
                    formData.append('audio', audioBlob);
                    formData.append('session_id', this.sessionId);
                    formData.append('chunk_id', chunkId);
                    
                    const response = await fetch('/api/transcribe_chunk_streaming', {
                        method: 'POST',
                        body: formData
                    });
                    
                    if (response.ok) {
                        const result = await response.json();
                        this.displayTranscriptUpdate({
                            text: result.transcript || result.text,
                            chunkId: chunkId,
                            type: 'final',
                            confidence: result.confidence || 0.8,
                            timestamp: new Date().toISOString()
                        });
                    }
                }
            } catch (error) {
                console.error('[RT-ENGINE] Failed to send chunk:', error);
            }
        };

        // Setup UI event listeners
        this.setupUIEventListeners();

        console.log('[RT-ENGINE] Initialization complete');
    }
    
    // FIXED: Add essential helper methods to prevent undefined errors
    initializeDataStructures() {
        console.log('[RT-ENGINE] Initializing data structures...');
        
        // FIXED: Initialize all Maps and Arrays to prevent undefined errors
        this.transcriptRegistry = this.transcriptRegistry || new Map();
        this.activeChunks = this.activeChunks || new Map();
        this.interimUtterances = this.interimUtterances || new Map();
        this.finalUtterances = this.finalUtterances || new Map();
        this.transcriptItems = this.transcriptItems || [];
        this.chunkTranscripts = this.chunkTranscripts || new Map();
        
        // CRITICAL FIX: Initialize metrics variables to prevent undefined errors
        this.totalWords = 0;
        this.totalChunks = 0;
        this.totalConfidence = 0;
        this.hallucinationCount = 0;
        this.confidenceSum = 0;
        
        console.log('[RT-ENGINE] ✅ Data structures and metrics initialized');
    }
    
    clearDataStructures() {
        console.log('[RT-ENGINE] Clearing data structures safely...');
        
        // FIXED: Safe clearing with existence checks
        if (this.transcriptRegistry) this.transcriptRegistry.clear();
        if (this.activeChunks) this.activeChunks.clear();
        if (this.interimUtterances) this.interimUtterances.clear();
        if (this.finalUtterances) this.finalUtterances.clear();
        if (this.chunkTranscripts) this.chunkTranscripts.clear();
        if (this.transcriptItems) this.transcriptItems.length = 0;
        
        // CRITICAL FIX: Reset metrics variables
        this.totalWords = 0;
        this.totalChunks = 0;
        this.totalConfidence = 0;
        this.hallucinationCount = 0;
        this.confidenceSum = 0;
        
        // PATCH FIX: Clear processedChunks set
        if (this.processedChunks) this.processedChunks.clear();
        
        console.log('[RT-ENGINE] ✅ Data structures, metrics, and processed chunks cleared safely');
    }
    
    async getMicrophoneStream() {
        console.log('[RT-ENGINE] Requesting microphone access...');
        
        try {
            // FIXED: Explicit microphone stream acquisition per document requirement
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: 16000
                }
            });
            
            console.log('[RT-ENGINE] ✅ Microphone stream obtained successfully');
            return stream;
            
        } catch (error) {
            console.error('[RT-ENGINE] ❌ Microphone access failed:', error);
            throw new Error(`Microphone access failed: ${error.message}`);
        }
    }
    
    createFallbackVADProcessor() {
        console.log('[RT-ENGINE] Creating fallback VAD processor...');
        
        // FIXED: Fallback VAD processor with ALL required methods
        return {
            initialize: function() {
                console.log('[RT-ENGINE] Fallback VAD initialized');
                return Promise.resolve();
            },
            analyzeChunk: function(audioBlob) {
                // Simple fallback - assume speech is present if chunk has reasonable size
                const hasSpeech = audioBlob && audioBlob.size > 1000;
                console.log('[RT-ENGINE] Fallback VAD analysis:', { 
                    size: audioBlob?.size, 
                    hasSpeech 
                });
                return Promise.resolve({ hasSpeech, confidence: 0.7 });
            },
            onAudioChunk: null,
            isInitialized: true
        };
    }

    async initializeWebSocket() {
        try {
            // Check if Socket.IO is available
            if (typeof io !== 'undefined') {
                this.socket = io();
                this.isWebSocketEnabled = true;

                this.socket.on('connect', () => {
                    console.log('[RT-ENGINE] WebSocket connected');
                    this.updateNetworkStatus(true);
                    
                    // Join the session room if sessionId exists
                    if (this.sessionId) {
                        this.socket.emit('join_session', { session_id: this.sessionId });
                        console.log(`[RT-ENGINE] Joined WebSocket room: ${this.sessionId}`);
                    }
                });

                this.socket.on('disconnect', () => {
                    console.log('[RT-ENGINE] WebSocket disconnected');
                    this.updateNetworkStatus(false);
                });

                // CRITICAL: CTO-specified events (EXACT requirement)  
                this.socket.on('transcript_partial', (data) => {
                    console.log('[RT-ENGINE] ✅ CTO-SPEC transcript_partial received:', data);
                    console.log('[CONFIDENCE-DEBUG] Received confidence from WebSocket:', data.confidence, typeof data.confidence);
                    
                    // CRITICAL: Prevent duplicate processing
                    const eventId = `partial_${data.chunk_id}`;
                    if (window.processedTranscriptEvents.has(eventId)) {
                        console.log('[RT-ENGINE] 🚫 Duplicate partial event blocked:', eventId);
                        return;
                    }
                    window.processedTranscriptEvents.add(eventId);
                    
                    this.displayTranscriptUpdate({
                        text: data.text,
                        chunkId: data.chunk_id,
                        type: 'partial',
                        confidence: data.confidence || 0.6,
                        timestamp: data.timestamp
                    });
                });
                
                this.socket.on('transcript_final', (data) => {
                    console.log('[RT-ENGINE] ✅ CTO-SPEC transcript_final received:', data);
                    console.log('[CONFIDENCE-DEBUG] Received confidence from WebSocket FINAL:', data.confidence, typeof data.confidence);
                    
                    // CRITICAL: Prevent duplicate processing
                    const eventId = `final_${data.chunk_id}`;
                    if (window.processedTranscriptEvents.has(eventId)) {
                        console.log('[RT-ENGINE] 🚫 Duplicate final event blocked:', eventId);
                        return;
                    }
                    window.processedTranscriptEvents.add(eventId);
                    
                    this.displayTranscriptUpdate({
                        text: data.text,
                        chunkId: data.chunk_id,
                        type: 'final',
                        confidence: data.confidence || 0.8,
                        timestamp: data.timestamp
                    });
                });
                
                // Legacy events for backward compatibility
                this.socket.on('transcription', (data) => {
                    this.displayTranscriptUpdate({
                        text: data.text,
                        chunkId: data.chunk_id,
                        type: 'final',
                        confidence: data.confidence || 0.8,
                        timestamp: data.timestamp
                    });
                });

                this.socket.on('interim_transcript', (data) => {
                    this.displayTranscriptUpdate({
                        text: data.text,
                        chunkId: data.chunk_id,
                        type: 'partial',
                        confidence: data.confidence || 0.6,
                        timestamp: data.timestamp
                    });
                });

                this.socket.on('transcription_complete', (data) => {
                    console.log('[RT-ENGINE] Transcription complete:', data);
                    this.updateStatus('completed', 'Transcription completed');
                });

                this.socket.on('transcription_error', (data) => {
                    console.error('[RT-ENGINE] Transcription error:', data);
                    this.showError('Transcription error: ' + data.message);
                });

                console.log('[RT-ENGINE] WebSocket initialized');
            } else {
                console.warn('[RT-ENGINE] Socket.IO not available, using HTTP fallback');
                this.isWebSocketEnabled = false;
            }
        } catch (error) {
            console.warn('[RT-ENGINE] WebSocket initialization failed:', error);
            this.isWebSocketEnabled = false;
        }
    }

    setupUIEventListeners() {
        const recordBtn = document.getElementById('recordBtn');
        if (recordBtn) {
            recordBtn.addEventListener('click', () => this.toggleRecording());
        }
    }

    async toggleRecording() {
        if (this.isRecording) {
            await this.stopRecording();
        } else {
            await this.startRecording();
        }
    }

    async startRecording() {
        try {
            console.log('[RT-ENGINE] Starting real-time recording...');
            
            // BULLETPROOF: Multiple layers of duplicate prevention with immediate lock
            if (this.isRecording || this.recordingInProgress || window.MINA_RECORDING_IN_PROGRESS) {
                console.log('[RT-ENGINE] ⚠️ Already recording, BLOCKING duplicate start');
                return;
            }
            
            // IMMEDIATE LOCK: Set all flags immediately to prevent any race conditions
            this.recordingInProgress = true;
            this.isRecording = true;
            window.MINA_RECORDING_IN_PROGRESS = true;
            
            // ADDITIONAL PROTECTION: Record start time for timeout detection
            this.recordingStartTime = Date.now();
            window.MINA_RECORDING_START_TIME = this.recordingStartTime;

            // FIXED: Initialize data structures FIRST to prevent undefined errors
            this.initializeDataStructures();

            // CRITICAL: Use shared session ID for WebSocket room consistency
            this.sessionId = window.sharedSessionId || `session_${Date.now()}`;
            this.chunkCounter = 0;
            
            // FIXED: Safe clearing with existence checks
            this.clearDataStructures();
            
            console.log(`[RT-ENGINE] Using session ID: ${this.sessionId}`);

            // FIXED: Obtain microphone stream BEFORE creating MediaRecorder
            console.log('[RT-ENGINE] Requesting microphone access...');
            this.audioStream = await this.getMicrophoneStream();
            
            // Join WebSocket room for this session
            if (this.socket && this.socket.connected) {
                this.socket.emit('join_session', { session_id: this.sessionId });
                console.log(`[RT-ENGINE] Joined WebSocket room: ${this.sessionId}`);
            }

            console.log('[RT-ENGINE] ✅ Microphone stream obtained successfully');

            // Determine best codec with enhanced stability
            const mimeTypes = [
                'audio/webm;codecs=opus',
                'audio/webm;codecs=pcm', // PCM for better stability
                'audio/webm',
                'audio/mp4;codecs=mp4a.40.2',
                'audio/mp4',
                'audio/wav',
                'audio/ogg;codecs=opus'
            ];

            let options = { 
                audioBitsPerSecond: 128000, // Stable bitrate
                mimeType: null
            };
            
            for (const mimeType of mimeTypes) {
                if (MediaRecorder.isTypeSupported(mimeType)) {
                    options.mimeType = mimeType;
                    console.log('[RT-ENGINE] Using codec:', mimeType);
                    break;
                }
            }
            
            // Fallback to no mimeType if none are supported
            if (!options.mimeType) {
                console.warn('[RT-ENGINE] No supported MIME types found, using default');
                options = { audioBitsPerSecond: 128000 };
            }

            // FIXED: Create MediaRecorder with validated audio stream
            if (!this.audioStream) {
                throw new Error('Audio stream not available - microphone access failed');
            }
            
            this.mediaRecorder = new MediaRecorder(this.audioStream, options);
            console.log(`[RT-ENGINE] ✅ Created MediaRecorder with MIME type: ${options.mimeType}`);

            // Setup real-time chunk processing
            this.mediaRecorder.ondataavailable = async (event) => {
                await this.processAudioChunk(event.data);
            };

            this.mediaRecorder.onstop = () => {
                console.log('[RT-ENGINE] Recording stopped');
                this.handleRecordingStop();
            };

            this.mediaRecorder.onerror = (event) => {
                console.error('[RT-ENGINE] Recording error:', event);
                this.showError('Recording error: ' + event.error);
            };

            // TASK 2: Document requirement - change chunk interval for 6-10s buffering
            // Document: "buffer at least **6–10s of audio** before sending to Whisper"
            // Document: "Expect live chunks every ~6s showing interim lines"
            const DOCUMENT_CHUNK_INTERVAL = 6000; // 6 seconds per document requirement
            this.mediaRecorder.start(DOCUMENT_CHUNK_INTERVAL);
            this.isRecording = true;
            
            // TASK 3: Setup document-required event listeners for onTranscriptReceived
            this.setupDocumentRequiredEventListeners();
            
            // FIXED: Remove connectSocket() call - WebSocket already initialized in constructor

            // Initialize audio meter if available
            if (this.audioMeter) {
                this.audioMeter.start(this.audioStream);
            }
            
            // Start recording timer
            this.recordingStartTime = Date.now();
            this.startRecordingTimer();

            // Join WebSocket session
            if (this.socket && this.socket.connected) {
                console.log(`[RT-ENGINE] ✅ JOINING session room: ${this.sessionId}`);
                this.socket.emit('join_session', { session_id: this.sessionId });
                
                // Listen for session join confirmation
                this.socket.on('session_joined', (data) => {
                    console.log('[RT-ENGINE] ✅ SESSION JOINED confirmed:', data);
                });
                
                // Removed test connection listener to prevent spam messages
            }

            // Start streaming session on backend
            await this.startBackendSession();

            // Update UI
            this.updateRecordingUI(true);
            this.updateStatus('recording', 'Recording in progress...');

            console.log('[RT-ENGINE] Recording started successfully');

        } catch (error) {
            console.error('[RT-ENGINE] Failed to start recording:', error);
            this.showError('Failed to start recording: ' + error.message);
            await this.stopRecording();
        }
    }

    async stopRecording() {
        console.log('[RT-ENGINE] Stopping recording...');

        // BULLETPROOF: Clear all recording flags AND processing state
        this.isRecording = false;
        this.recordingInProgress = false;
        window.MINA_RECORDING_IN_PROGRESS = false;
        
        // Clear all initialization flags for fresh restart
        window.MINA_INITIALIZATION_IN_PROGRESS = false;
        
        // Clear processed events to prevent state corruption between sessions
        if (this.processedTranscriptEvents) {
            this.processedTranscriptEvents.clear();
            console.log('[RT-ENGINE] ✅ Cleared processed events registry');
        }
        
        // Clear render timestamps for fresh duplicate detection
        if (this.lastRenderTimestamp) {
            this.lastRenderTimestamp.clear();
            console.log('[RT-ENGINE] ✅ Cleared render timestamps');
        }
        
        // Clear processing timestamps for fresh duplicate detection
        if (this.lastProcessedTimestamp) {
            this.lastProcessedTimestamp.clear();
            console.log('[RT-ENGINE] ✅ Cleared processing timestamps');
        }
        
        console.log('[RT-ENGINE] ✅ All recording flags and processing state cleared');

        // Stop MediaRecorder
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
        }

        // Stop audio stream
        if (this.audioStream) {
            this.audioStream.getTracks().forEach(track => track.stop());
            this.audioStream = null;
        }

        // Stop audio meter
        if (this.audioMeter) {
            this.audioMeter.stop();
        }
        
        // Stop recording timer
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }

        // ACTION 2: Trigger flushChunks on recording stop with performance metrics
        setTimeout(async () => {
            try {
                console.log('[RT-ENGINE] 🔄 Triggering enhanced flush process...');
                await this.flushChunks();
                this.logSessionSummary();
                this.displayFinalTranscript();
            } catch (error) {
                console.error('[RT-ENGINE] Enhanced flush failed:', error);
                this.sessionMetrics.errorCount++;
                // Fallback to original method
                await this.flushSessionAndGetFinalTranscript();
            }
        }, 500); // Small delay to ensure last chunks are processed

        // Stop backend session
        await this.stopBackendSession();

        // Update UI
        this.updateRecordingUI(false);
        this.updateStatus('completed', 'Recording completed');

        // PATCH FIX 2: Clear data structures between sessions
        this.clearDataStructures();

        console.log('[RT-ENGINE] Recording stopped');
    }
    
    // BULLETPROOF: Function to clear all processed events and reset state
    clearProcessedEvents() {
        if (this.processedTranscriptEvents) {
            this.processedTranscriptEvents.clear();
            console.log('[RT-ENGINE] ✅ Cleared all processed events registry');
        }
        
        // Reset initialization flag if needed
        if (typeof window.MINA_RT_ENGINE_SINGLETON_INITIALIZED !== 'undefined') {
            window.MINA_RT_ENGINE_SINGLETON_INITIALIZED = false;
            console.log('[RT-ENGINE] ✅ Reset singleton initialization flag');
        }
        
        console.log('[RT-ENGINE] ✅ Complete state cleanup performed');
    }
    
    // PATCH FIX 5: Setup patched WebSocket handlers connecting new renderFinalTranscript
    setupPatchedWebSocketHandlers() {
        if (!this.socketManager) {
            console.warn('[RT-ENGINE] ⚠️ SocketManager not initialized for patched handlers');
            return;
        }
        
        // Connect renderFinalTranscript to transcript_final events
        this.socketManager.on('transcript_final', (data) => {
            console.log('[RT-ENGINE] 🔄 PATCH FIX 5: transcript_final event received:', data);
            
            // Use new renderFinalTranscript function
            this.renderFinalTranscript(data.chunk_id, data.text, data.confidence);
        });
        
        // Also handle transcript_partial events for interim display
        this.socketManager.on('transcript_partial', (data) => {
            console.log('[RT-ENGINE] 🔄 PATCH FIX 5: transcript_partial event received:', data);
            
            // Display interim transcripts using existing logic
            this.displayTranscriptUpdate(data);
        });
        
        console.log('[RT-ENGINE] ✅ PATCH FIX 5: setupPatchedWebSocketHandlers configured');
    }
    
    // ADVANCED QUALITY FILTERING METHODS for enterprise-grade transcription
    shouldDisplayTranscript(text, confidence) {
        // Comprehensive quality filtering system
        
        // 1. Length and content validation
        if (!text || text.trim().length <= 2) return false;
        
        // 2. Enhanced repetitive pattern detection
        const repetitivePatterns = [
            'we need', 'we have', 'when', 'processing...', 'loading...', 'buffering...',
            'you know', 'like', 'so', 'um', 'uh', 'ah', 'er', 'hmm', 'okay',
            '날씨였습니다', 'MBC 뉴스', '이덕영입니다', '이학수입니다'  // Korean hallucination patterns
        ];
        
        const isRepetitive = repetitivePatterns.some(pattern => 
            text.toLowerCase().includes(pattern.toLowerCase())
        );
        
        if (isRepetitive && confidence < 0.6) return false;
        
        // 3. Technical term preservation (even if short)
        const technicalTerms = ['API', 'UI', 'DB', 'SQL', 'CSS', 'HTML', 'JS', 'URL'];
        const hasTechnicalTerm = technicalTerms.some(term => 
            text.toUpperCase().includes(term)
        );
        
        if (hasTechnicalTerm) return true;
        
        // 4. Meaningful content detection
        const meaningfulWords = text.split(' ').filter(word => 
            word.length > 2 && !['the', 'and', 'but', 'for', 'are', 'you', 'was', 'were'].includes(word.toLowerCase())
        );
        
        if (meaningfulWords.length === 0) return false;
        
        // 5. Confidence-based filtering with context
        if (confidence < 0.2 && text.length < 10) return false;
        
        // 6. Short phrase enhancement - allow important short phrases
        const importantShortPhrases = ['yes', 'no', 'okay', 'right', 'sure', 'done', 'next', 'stop', 'start'];
        if (text.length <= 8) {
            return importantShortPhrases.some(phrase => 
                text.toLowerCase().includes(phrase)
            ) || confidence > 0.7;
        }
        
        // 7. Duplicate content prevention
        const existingChunks = document.querySelectorAll('.transcript-chunk .transcript-text');
        const isDuplicate = Array.from(existingChunks).some(element => {
            const existingText = element.textContent || '';
            return this.calculateSimilarity(text, existingText) > 0.85;
        });
        
        if (isDuplicate) return false;
        
        return true;
    }
    
    enhanceTranscriptData(data) {
        let text = data.text || '';
        let confidence = data.confidence || 0;
        let enhanced = false;
        
        // 1. Technical term correction
        const technicalCorrections = {
            'a p i': 'API',
            'u i': 'UI', 
            'data base': 'database',
            'web app': 'web application',
            'back end': 'backend',
            'front end': 'frontend',
            'java script': 'JavaScript',
            'css': 'CSS'
        };
        
        for (const [incorrect, correct] of Object.entries(technicalCorrections)) {
            const regex = new RegExp(incorrect, 'gi');
            if (regex.test(text)) {
                text = text.replace(regex, correct);
                confidence = Math.min(0.95, confidence + 0.1); // Boost confidence for technical corrections
                enhanced = true;
            }
        }
        
        // 2. Grammar improvements
        text = text.replace(/\bi\b/g, 'I'); // Fix capitalization
        text = text.replace(/\s+/g, ' ').trim(); // Clean whitespace
        
        // 3. Context-based confidence adjustment
        const wordCount = text.split(' ').length;
        if (wordCount >= 5) {
            confidence = Math.min(0.95, confidence + 0.05); // Boost for complete phrases
            enhanced = true;
        }
        
        // 4. Professional formatting
        if (text.length > 0) {
            text = text.charAt(0).toUpperCase() + text.slice(1); // Capitalize first letter
            if (!text.endsWith('.') && !text.endsWith('?') && !text.endsWith('!') && text.length > 10) {
                text += '.'; // Add period for complete sentences
            }
        }
        
        return {
            ...data,
            text: text,
            confidence: confidence,
            enhanced: enhanced
        };
    }
    
    calculateSimilarity(text1, text2) {
        const normalize = (str) => str.toLowerCase().trim().replace(/[^\w\s]/g, '');
        const norm1 = normalize(text1);
        const norm2 = normalize(text2);
        
        if (norm1 === norm2) return 1.0;
        if (norm1.length === 0 || norm2.length === 0) return 0.0;
        
        // Simple Jaccard similarity for word overlap
        const words1 = new Set(norm1.split(' '));
        const words2 = new Set(norm2.split(' '));
        const intersection = new Set([...words1].filter(x => words2.has(x)));
        const union = new Set([...words1, ...words2]);
        
        return intersection.size / union.size;
    }
    
    // 🧠 FIX #2: Deduplication and hallucination suppression
    hashTranscriptText(text) {
        // Simple hash function for deduplication
        let hash = 0;
        const str = JSON.stringify(text.toLowerCase().trim());
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash;
    }
    
    handleTranscription(chunk) {
        // Add deduplication logic before processing
        const hash = this.hashTranscriptText(chunk.text);
        if (this.chunkHashSet.has(hash)) {
            console.log('[RT-ENGINE] 🚫 Duplicate chunk filtered:', chunk.text);
            return; // Skip duplicate
        }
        this.chunkHashSet.add(hash);
        
        // 🧠 FIX #3: Append to unified live feed
        this.liveTranscript += chunk.text + " ";
        this.updateLiveTranscriptDisplay(this.liveTranscript, chunk.timestamp, chunk.confidence);
        
        // 🧠 FIX #4: Update metrics live
        const wordCount = this.wordCount(chunk.text);
        this.totalWords += wordCount;
        this.totalChunks++;
        this.totalConfidence += chunk.confidence || 0;
        
        // Store in appropriate map
        if (chunk.type === 'final') {
            this.finalUtterances.set(chunk.chunkId, chunk);
        } else {
            this.interimUtterances.set(chunk.chunkId, chunk);
        }
        
        console.log('[RT-ENGINE] 📊 Metrics updated:', {
            totalWords: this.totalWords,
            totalChunks: this.totalChunks,
            avgConfidence: this.totalConfidence / this.totalChunks
        });
    }
    
    wordCount(text) {
        return text.trim().split(/\s+/).filter(word => word.length > 0).length;
    }
    
    updateLiveTranscriptDisplay(liveTranscript, timestamp, confidence) {
        const liveTranscriptElement = document.getElementById('liveTranscriptOutput');
        if (liveTranscriptElement) {
            liveTranscriptElement.textContent = liveTranscript;
            liveTranscriptElement.setAttribute('data-timestamp', timestamp || Date.now());
            liveTranscriptElement.setAttribute('data-confidence', confidence || 0);
        } else {
            console.warn('[RT-ENGINE] liveTranscriptOutput element not found');
        }
    }

    // TASK 3: Document requirement - onTranscriptReceived() with specific DOM manipulation
    onTranscriptReceived(data) {
        console.log('[RT-ENGINE] TASK 3: onTranscriptReceived called with:', data);
        
        const { chunk_id, text, confidence, timestamp, type } = data;
        
        if (!chunk_id) {
            console.warn('[RT-ENGINE] TASK 3: Missing chunk_id in transcript data');
            return;
        }
        
        // ADVANCED QUALITY FILTERING SYSTEM for enterprise-grade transcription
        const processedText = text || 'Processing...';
        const actualConfidence = confidence || 0;
        
        // 🚨 EMERGENCY FIX: Disable quality filter that blocks legitimate speech
        // The quality filter was incorrectly blocking real speech like "Cause I got out bro..."
        // Korean hallucinations should be blocked at backend level, not frontend
        console.log(`[RT-ENGINE] 🚨 EMERGENCY FIX: Allowing all speech through (quality filter disabled)`);
        
        // Only block obvious empty or very short content
        if (!processedText || processedText.trim().length <= 1) {
            console.log(`[RT-ENGINE] 🚫 BLOCKING empty/short text: "${processedText}"`);
            return;
        }
        
        // Apply contextual enhancement to improve accuracy
        const enhancedData = this.enhanceTranscriptData({
            text: processedText,
            confidence: actualConfidence,
            chunk_id: chunk_id,
            timestamp: timestamp,
            type: type
        });
        
        // Document requirement: Create a new DOM element per chunk_id if not already present
        let chunkElement = document.getElementById(`chunk-${chunk_id}`);
        
        if (!chunkElement) {
            console.log('[RT-ENGINE] TASK 3: Creating new DOM element for chunk_id:', chunk_id);
            
            chunkElement = document.createElement('div');
            chunkElement.id = `chunk-${chunk_id}`;
            chunkElement.className = 'transcript-chunk interim';
            
            // Document requirement: Apply aria-live="polite" to make screenreader-friendly
            chunkElement.setAttribute('aria-live', 'polite');
            
            const transcriptContainer = document.getElementById('transcriptContainer');
            if (transcriptContainer) {
                transcriptContainer.appendChild(chunkElement);
                console.log('[RT-ENGINE] TASK 3: Added chunk element to transcriptContainer');
            } else {
                console.warn('[RT-ENGINE] TASK 3: transcriptContainer not found');
                return;
            }
        }
        
        // Document requirement: Update the same DOM element when a final result comes in for that chunk
        if (type === 'final') {
            chunkElement.className = 'transcript-chunk final';
            console.log('[RT-ENGINE] TASK 3: Updated chunk to final type:', chunk_id);
        }
        
        // Document requirement: Confidence scores render and are >0%
        const confidenceText = (confidence && confidence > 0) ? `${Math.round(confidence * 100)}%` : '0%';
        
        // Document requirement: Timestamps show HH:mm:ss format
        const timeFormatted = timestamp || new Date().toLocaleTimeString('en-US', { 
            hour12: false, 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });
        
        // 🚨 EMERGENCY FIX: Fix "Chunk undefined" display issue by using proper chunk ID
        const displayChunkId = chunk_id || `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // Update DOM element content
        chunkElement.innerHTML = `
            <div class="transcript-header">
                <span class="chunk-id">Chunk ${displayChunkId}</span>
                <span class="timestamp">${timeFormatted}</span>
                <span class="confidence">Confidence: ${confidenceText}</span>
                <span class="type">${type === 'final' ? '🟢 Final' : '🟡 Live'}</span>
            </div>
            <div class="transcript-text">${processedText}</div>
        `;
        
        // Auto-scroll to latest chunk
        chunkElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
        console.log('[RT-ENGINE] ✅ STORED meaningful content:', chunk_id, '→', `"${processedText}"`);
    }

    // 🚨 EMERGENCY FIX: Disable duplicate event listeners causing 4x+ processing
    setupDocumentRequiredEventListeners() {
        console.log('[RT-ENGINE] 🚨 EMERGENCY FIX: Disabling duplicate event listeners');
        
        if (this.socket) {
            // 🚨 DISABLE DUPLICATE LISTENERS: Only use CTO-spec events in main WebSocket setup
            // These events are already handled in the main WebSocket initialization
            console.log('[RT-ENGINE] 🚨 Skipping duplicate event listener setup to prevent 4x processing');
            
            // TASK 4: Document requirement - listen for session_complete event ONLY
            this.socket.on('session_complete', (data) => {
                console.log('[RT-ENGINE] TASK 4: Received session_complete:', data);
                this.renderFinalTranscript(data);
            });
        }
    }

    // TASK 4: Document requirement - Render final full transcript in separate div
    renderFinalTranscript(data) {
        console.log('[RT-ENGINE] TASK 4: Rendering final transcript');
        
        const finalTranscriptDiv = document.getElementById('finalTranscript');
        if (!finalTranscriptDiv) {
            console.warn('[RT-ENGINE] TASK 4: #finalTranscript div not found');
            return;
        }
        
        // Clear interim chunks per document requirement
        this.clearInterimChunks();
        
        // Show final transcript container
        finalTranscriptDiv.style.display = 'block';
        
        // Document requirement: "Replace any remaining interim lines with cleaned, deduplicated full transcript"
        finalTranscriptDiv.innerHTML = `
            <div class="final-transcript-header">
                <h3>📝 Final Transcript</h3>
                <p>Session completed at ${new Date().toLocaleTimeString()}</p>
            </div>
            <div class="final-transcript-content">
                ${data.final_transcript || 'No meaningful speech detected.'}
            </div>
            <div class="final-transcript-actions">
                <button onclick="this.downloadTranscript('${data.session_id}', '${data.final_transcript}')" class="btn-download">
                    📄 Download TXT
                </button>
                <button onclick="this.copyTranscript('${data.final_transcript}')" class="btn-copy">
                    📋 Copy
                </button>
            </div>
        `;
        
        console.log('[RT-ENGINE] TASK 4: Final transcript rendered successfully');
    }
    
    // TASK 4: Clear interim chunks as per document requirement
    clearInterimChunks() {
        console.log('[RT-ENGINE] TASK 4: Clearing interim chunks');
        
        const transcriptContainer = document.getElementById('transcriptContainer');
        if (transcriptContainer) {
            // Remove all interim chunk elements
            const chunkElements = transcriptContainer.querySelectorAll('.transcript-chunk');
            chunkElements.forEach(element => {
                element.remove();
            });
            console.log('[RT-ENGINE] TASK 4: Cleared ' + chunkElements.length + ' interim chunks');
        }
    }

    async processAudioChunk(audioBlob) {
        if (!audioBlob || audioBlob.size === 0) {
            console.warn('[RT-ENGINE] Empty audio chunk received');
            return;
        }

        // CRITICAL FIX: WebM EBML Header Reconstruction
        // Cache the EBML header from the first substantial chunk
        if (!this.cachedEBMLHeader && audioBlob.size > 1024) {
            try {
                const arrayBuffer = await audioBlob.arrayBuffer();
                const uint8Array = new Uint8Array(arrayBuffer);
                
                // Check for valid EBML signature (0x1a45dfa3)
                if (uint8Array[0] === 0x1a && uint8Array[1] === 0x45 && 
                    uint8Array[2] === 0xdf && uint8Array[3] === 0xa3) {
                    
                    // Cache the complete EBML header (first 4KB should be enough)
                    this.cachedEBMLHeader = uint8Array.slice(0, Math.min(4096, uint8Array.length));
                    console.log('[RT-ENGINE] Cached EBML header from first chunk (' + this.cachedEBMLHeader.length + ' bytes)');
                }
            } catch (error) {
                console.warn('[RT-ENGINE] Failed to cache EBML header:', error);
            }
        }

        // Reconstruct corrupted chunks with cached header
        if (this.cachedEBMLHeader && audioBlob.size > 100) {
            try {
                const arrayBuffer = await audioBlob.arrayBuffer();
                const uint8Array = new Uint8Array(arrayBuffer);
                
                // Check if current chunk has invalid EBML header
                if (!(uint8Array[0] === 0x1a && uint8Array[1] === 0x45 && 
                      uint8Array[2] === 0xdf && uint8Array[3] === 0xa3)) {
                    
                    // Reconstruct with cached header + current chunk data
                    const reconstructed = new Uint8Array(this.cachedEBMLHeader.length + uint8Array.length);
                    reconstructed.set(this.cachedEBMLHeader);
                    reconstructed.set(uint8Array, this.cachedEBMLHeader.length);
                    
                    // Create new blob with reconstructed data
                    audioBlob = new Blob([reconstructed], { type: audioBlob.type });
                    console.log('[RT-ENGINE] Reconstructed WebM chunk with cached EBML header');
                }
            } catch (error) {
                console.warn('[RT-ENGINE] Failed to reconstruct chunk:', error);
            }
        }

        const chunkId = `chunk_${this.sessionId}_${this.chunkCounter++}`;
        const timestamp = Date.now();

        // CRITICAL FIX: Audio chunk size logging per document requirement
        console.log(`[RT-ENGINE] 🔊 AUDIO CHUNK SIZE: ${audioBlob.size} bytes for chunk ${chunkId}`);
        console.log(`[RT-ENGINE] Processing chunk ${chunkId} (${audioBlob.size} bytes)`);

        // Create transcript placeholder immediately
        this.createTranscriptPlaceholder(chunkId);

        // VAD analysis if available
        let vadResult = null;
        if (this.vadProcessor && typeof this.vadProcessor.analyzeChunk === 'function') {
            try {
                vadResult = await this.vadProcessor.analyzeChunk(audioBlob);
                console.log(`[RT-ENGINE] VAD result for ${chunkId}:`, vadResult);
            } catch (error) {
                console.warn('[RT-ENGINE] VAD analysis failed:', error);
            }
        } else {
            console.log('[RT-ENGINE] VAD processor not available, proceeding without analysis');
        }

        // Skip if no speech detected and VAD is enabled
        if (vadResult && !vadResult.hasSpeech) {
            console.log(`[RT-ENGINE] Skipping chunk ${chunkId} - no speech detected`);
            this.updateTranscriptPlaceholder(chunkId, 'No speech detected', 'silent');
            return;
        }
        
        // REPETITIVE TRANSCRIPTION PREVENTION: Check for repeated short phrases
        if (this.lastProcessedText && audioBlob.size < 200000) { // Less than 200KB (likely short audio)
            const timeSinceLastChunk = Date.now() - (this.lastChunkTime || 0);
            if (timeSinceLastChunk < 8000) { // Less than 8 seconds since last chunk
                console.log(`[RT-ENGINE] 🚫 REPETITIVE PREVENTION: Skipping potential repeated chunk ${chunkId}`);
                return;
            }
        }

        // Create metadata
        const metadata = {
            speech_state: vadResult ? (vadResult.hasSpeech ? 'speech' : 'silence') : 'unknown',
            audio_level: vadResult ? vadResult.audioLevel : 0,
            chunk_size: audioBlob.size,
            timestamp: timestamp
        };

        // Send to backend immediately
        try {
            const result = await this.sendChunkToBackend(chunkId, audioBlob, metadata);
            
            if (result) {
                // Track last processed text for repetitive prevention
                this.lastProcessedText = result.text;
                this.lastChunkTime = Date.now();
                
                // Store in active chunks
                this.activeChunks.set(chunkId, {
                    ...result,
                    timestamp: timestamp,
                    metadata: metadata
                });

                // Update UI immediately
                this.displayInterimTranscript(chunkId, result);
            }

        } catch (error) {
            console.error(`[RT-ENGINE] Failed to process chunk ${chunkId}:`, error);
            this.showChunkError(chunkId, error.message);
        }
    }

    async sendChunkToBackend(chunkId, audioBlob, metadata) {
        // Try WebSocket first, then HTTP fallback
        if (this.isWebSocketEnabled && this.socket && this.socket.connected) {
            return await this.sendChunkViaWebSocket(chunkId, audioBlob, metadata);
        } else {
            return await this.sendChunkViaHTTP(chunkId, audioBlob, metadata);
        }
    }

    async sendChunkViaWebSocket(chunkId, audioBlob, metadata) {
        // Convert blob to base64 for WebSocket transmission
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const base64Data = reader.result.split(',')[1];
                
                this.socket.emit('process_audio_chunk', {
                    chunk_id: chunkId,
                    session_id: this.sessionId,
                    audio_data: base64Data,
                    metadata: metadata
                });

                // WebSocket responses are handled by event listeners
                resolve(null);
            };
            reader.onerror = reject;
            reader.readAsDataURL(audioBlob);
        });
    }

    async sendChunkViaHTTP(chunkId, audioBlob, metadata) {
        const formData = new FormData();
        formData.append('audio', audioBlob, `${chunkId}.webm`);
        formData.append('session_id', this.sessionId);
        formData.append('chunk_id', chunkId);
        formData.append('metadata', JSON.stringify(metadata));

        const response = await fetch('/api/transcribe_chunk_streaming', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const result = await response.json();
        
        if (result.error) {
            throw new Error(result.error);
        }

        return result;
    }

    async startBackendSession() {
        try {
            const response = await fetch('/api/start_streaming_session', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    session_id: this.sessionId,
                    config: this.config
                })
            });

            if (!response.ok) {
                throw new Error(`Failed to start backend session: ${response.statusText}`);
            }

            const result = await response.json();
            console.log('[RT-ENGINE] Backend session started:', result);

        } catch (error) {
            console.warn('[RT-ENGINE] Failed to start backend session:', error);
        }
    }

    async stopBackendSession() {
        try {
            const response = await fetch('/api/stop_streaming_session', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    session_id: this.sessionId
                })
            });

            if (!response.ok) {
                throw new Error(`Failed to stop backend session: ${response.statusText}`);
            }

            const result = await response.json();
            console.log('[RT-ENGINE] Backend session stopped:', result);

        } catch (error) {
            console.warn('[RT-ENGINE] Failed to stop backend session:', error);
        }
    }

    handleTranscription(data) {
        // CRITICAL FIX: Validate data and extract values safely
        if (!data || typeof data !== 'object') {
            console.warn('[RT-ENGINE] Invalid data passed to handleTranscription:', data);
            return;
        }
        
        const { chunk_index, chunk_id, text, confidence, session_id } = data;
        
        // CRITICAL FIX: Enhanced chunk_id validation with proper fallback per document requirement
        let validChunkId = chunk_id;
        // Only use fallback ID if chunkId is truly missing (EXACT match per document)
        if (!chunk_id || chunk_id === 'undefined') {
            validChunkId = `fallback_chunk_${Date.now()}`;
            console.log('[RT-ENGINE] Generated fallback chunk_id:', validChunkId);
        }
        
        // CRITICAL FIX: Enhanced text validation
        if (!text || text === '' || text === 'undefined' || text === 'null' || text.trim() === '') {
            console.log('[RT-ENGINE] Empty or invalid text, skipping processing for chunk:', validChunkId);
            return;
        }
        
        // BULLETPROOF: Early duplicate detection AFTER validation - but less aggressive
        const processingKey = `handle_${validChunkId}`;
        
        // Check if we've already processed this exact transcription recently (within 1 second)
        const now = Date.now();
        if (this.processedTranscriptEvents.has(processingKey)) {
            // Check if this is a very recent duplicate (within 500ms)
            const lastProcessed = this.lastProcessedTimestamp?.get(processingKey) || 0;
            if (now - lastProcessed < 500) {
                console.log('[RT-ENGINE] 🚫 RAPID DUPLICATE DETECTION: Skipping handleTranscription for', validChunkId);
                return; // Exit immediately - no processing
            }
        }
        
        // Mark as processed with timestamp
        this.processedTranscriptEvents.add(processingKey);
        if (!this.lastProcessedTimestamp) {
            this.lastProcessedTimestamp = new Map();
        }
        this.lastProcessedTimestamp.set(processingKey, now);
        
        // CRITICAL: Update metrics tracking for each processed chunk
        console.log('[RT-ENGINE] 📊 METRICS UPDATE: Processing chunk', validChunkId, 'with confidence:', confidence);
        
        // Update session metrics
        this.sessionMetrics.chunksProcessed++;
        this.sessionMetrics.totalWords += (text.split(' ').length || 0);
        
        // Update confidence tracking
        if (confidence && confidence > 0) {
            this.sessionMetrics.confidenceSum += confidence;
            this.sessionMetrics.confidenceCount++;
        }
        
        // Calculate WPM
        const elapsedMinutes = (now - this.recordingStartTime) / 60000;
        if (elapsedMinutes > 0) {
            this.sessionMetrics.wordsPerMinute = Math.round(this.sessionMetrics.totalWords / elapsedMinutes);
        }
        
        // Update UI metrics immediately
        this.updateMetrics();
        
        console.log('[RT-ENGINE] Processing transcription for chunk:', validChunkId, 'text:', text.substring(0, 50) + '...');
        
        // Update active chunks with valid chunk_id
        this.activeChunks.set(validChunkId, {
            text: text,
            confidence: confidence,
            timestamp: data.timestamp,
            isFinal: false,
            chunk_index: chunk_index
        });

        // Display transcript immediately (remove buffering state)
        this.displayChunkTranscript(chunk_index, text, confidence);
        
        // Update metrics
        this.updateMetrics();
    }

    handleInterimTranscript(data) {
        console.log('[RT-ENGINE] Received interim transcript:', data);
        
        // Update active chunks
        this.activeChunks.set(data.chunk_id, {
            text: data.text,
            confidence: data.confidence,
            timestamp: data.timestamp,
            isFinal: false
        });

        // Update UI
        this.displayInterimTranscript(data.chunk_id, data);
    }

    handleTranscriptionComplete(data) {
        console.log('[RT-ENGINE] Transcription complete:', data);
        this.updateStatus('completed', 'Transcription completed');
    }

    handleTranscriptionError(data) {
        console.error('[RT-ENGINE] Transcription error:', data);
        this.showError('Transcription error: ' + data.message);
    }

    displayChunkTranscript(chunkIndex, text, confidence) {
        const transcriptContainer = document.getElementById('transcriptContainer');
        if (!transcriptContainer) {
            console.warn('[RT-ENGINE] Transcript container not found');
            return;
        }

        // Remove empty state if present
        const emptyState = transcriptContainer.querySelector('.empty-state');
        if (emptyState) {
            emptyState.remove();
        }

        // Remove any buffering placeholder for this chunk
        const bufferingItem = document.getElementById(`buffering-${chunkIndex}`);
        if (bufferingItem) {
            bufferingItem.remove();
        }

        // Create new transcript item (no buffering, only completed transcripts)
        const transcriptItem = document.createElement('div');
        transcriptItem.id = `transcript-${chunkIndex}`;
        transcriptItem.className = 'transcript-item live fade-in';
        
        const confidencePercent = Math.round((confidence || 0) * 100);
        const confidenceClass = confidencePercent >= 80 ? 'high' : confidencePercent >= 60 ? 'medium' : 'low';
        const timestamp = new Date().toLocaleTimeString();

        transcriptItem.innerHTML = `
            <div class="transcript-header-info">
                <span class="transcript-type live">Chunk ${chunkIndex}</span>
                <span class="transcript-confidence ${confidenceClass}">${confidencePercent}% confidence</span>
                <span class="transcript-time">${timestamp}</span>
            </div>
            <p class="transcript-text">${text}</p>
        `;

        transcriptContainer.appendChild(transcriptItem);

        // Auto-scroll to bottom
        transcriptContainer.scrollTop = transcriptContainer.scrollHeight;

        console.log(`[RT-ENGINE] Displayed chunk ${chunkIndex || 'generated'}: "${text.substring(0, 30)}..."`);
    }

    displayInterimTranscript(chunkId, result) {
        const transcriptContainer = document.getElementById('transcriptContainer');
        if (!transcriptContainer) {
            console.warn('[RT-ENGINE] Transcript container not found');
            return;
        }

        // Remove empty state
        const emptyState = transcriptContainer.querySelector('.empty-state');
        if (emptyState) {
            emptyState.remove();
        }

        // Check if this chunk already exists
        let transcriptItem = document.getElementById(`transcript-${chunkId}`);
        
        if (!transcriptItem) {
            // Create new transcript item
            transcriptItem = document.createElement('div');
            transcriptItem.id = `transcript-${chunkId}`;
            transcriptItem.className = 'transcript-item partial fade-in';
            
            transcriptContainer.appendChild(transcriptItem);
        }

        // Update content with debug logging
        console.log('[RT-ENGINE] 🔍 displayInterimTranscript confidence debug:', result.confidence, 'Type:', typeof result.confidence);
        
        // CRITICAL FIX: Check if confidence is passed as decimal or percentage
        let confidence;
        if (result.confidence && result.confidence > 1) {
            // Already a percentage (e.g., 45.2)
            confidence = Math.round(result.confidence);
        } else {
            // Decimal format (e.g., 0.452)
            confidence = Math.round((result.confidence || 0) * 100);
        }
        
        console.log('[RT-ENGINE] 🔍 Calculated confidence percentage:', confidence);
        const confidenceClass = confidence >= 80 ? 'high' : confidence >= 60 ? 'medium' : 'low';
        const timestamp = new Date().toLocaleTimeString();

        transcriptItem.innerHTML = `
            <div class="transcript-header-info">
                <span class="transcript-type partial">Live</span>
                <span class="transcript-confidence">${confidence}% confidence</span>
                <span class="transcript-time">${timestamp}</span>
            </div>
            <p class="transcript-text">${result.text || 'Processing...'}</p>
            <div class="transcript-chunk-info">
                <span class="chunk-id">Chunk ${validChunkId}</span>
                <span class="chunk-confidence">${confidence}% confidence</span>
            </div>
        `;

        // Update confidence styling
        transcriptItem.className = `transcript-item partial ${confidenceClass} fade-in`;

        // Auto-scroll to bottom
        transcriptContainer.scrollTop = transcriptContainer.scrollHeight;

        // Update metrics
        this.updateMetrics();
    }

    updateMetrics() {
        console.log('[RT-ENGINE] 📊 METRICS UPDATE: Starting metrics update...');
        
        // Calculate metrics from ACTUAL instance variables, not sessionMetrics
        const chunksProcessed = this.totalChunks || 0;
        const totalWords = this.totalWords || 0;
        const avgConfidence = this.totalChunks > 0 ? 
            Math.round((this.totalConfidence / this.totalChunks) * 100) : 0;
        
        // Calculate WPM based on elapsed time
        const elapsedMinutes = this.recordingStartTime ? 
            (Date.now() - this.recordingStartTime) / 60000 : 0.1;
        const wordsPerMinute = elapsedMinutes > 0 ? Math.round(totalWords / elapsedMinutes) : 0;
        
        // Calculate success rate (non-empty chunks vs total)
        const successfulChunks = Array.from(this.chunkTranscriptStore.values())
            .filter(chunk => chunk.text && chunk.text.trim().length > 0).length;
        const successRate = chunksProcessed > 0 ? Math.round((successfulChunks / chunksProcessed) * 100) : 100;
        
        // Update all metrics elements with multiple fallback IDs
        this.updateMetricElement('chunksProcessed', chunksProcessed);
        this.updateMetricElement('totalWords', totalWords);
        this.updateMetricElement('avgConfidence', `${avgConfidence}%`);
        this.updateMetricElement('averageConfidence', `${avgConfidence}%`);
        this.updateMetricElement('wordsPerMinute', wordsPerMinute);
        this.updateMetricElement('qualityScore', `${avgConfidence}%`);
        this.updateMetricElement('successRate', `${successRate}%`);
        
        // Update accuracy text
        const accuracyText = avgConfidence >= 80 ? 'Excellent' : 
                            avgConfidence >= 60 ? 'Good' : 
                            avgConfidence >= 40 ? 'Fair' : 'Improving';
        this.updateMetricElement('accuracyText', accuracyText);
        
        // Update confidence indicator
        this.updateConfidenceIndicator(avgConfidence / 100);
        
        console.log('[RT-ENGINE] 📊 METRICS UPDATE: Updated metrics -', {
            chunksProcessed,
            totalWords,
            avgConfidence,
            wordsPerMinute,
            successRate,
            elapsedMinutes: elapsedMinutes.toFixed(2)
        });
    }

    calculateAverageConfidence() {
        const chunks = Array.from(this.activeChunks.values()).filter(chunk => chunk.confidence !== undefined);
        if (chunks.length === 0) return 0;
        
        // Convert confidence to decimal if needed (backend sends as percentage)
        const confidenceSum = chunks.reduce((acc, chunk) => {
            const confidence = chunk.confidence > 1 ? chunk.confidence / 100 : chunk.confidence;
            return acc + confidence;
        }, 0);
        
        return confidenceSum / chunks.length;
    }

    // CRITICAL FIX: Add missing calculateMetrics function
    calculateMetrics() {
        const chunksProcessed = this.totalChunks || 0;
        const totalWords = this.totalWords || 0;
        const avgConfidence = this.totalChunks > 0 ? 
            Math.round((this.totalConfidence / this.totalChunks) * 100) : 0;
        
        // Calculate WPM based on elapsed time
        const elapsedMinutes = this.recordingStartTime ? 
            (Date.now() - this.recordingStartTime) / 60000 : 0.1;
        const wordsPerMinute = elapsedMinutes > 0 ? Math.round(totalWords / elapsedMinutes) : 0;
        
        // Calculate success rate
        const successfulChunks = Array.from(this.chunkTranscriptStore.values())
            .filter(chunk => chunk.text && chunk.text.trim().length > 0).length;
        const successRate = chunksProcessed > 0 ? Math.round((successfulChunks / chunksProcessed) * 100) : 100;
        
        // Accuracy text based on confidence
        const accuracy = avgConfidence >= 80 ? 'Excellent' : 
                        avgConfidence >= 60 ? 'Good' : 
                        avgConfidence >= 40 ? 'Fair' : 'Improving';
        
        return {
            chunksProcessed,
            totalWords,
            avgConfidence,
            wordsPerMinute,
            successRate,
            accuracy,
            elapsedMinutes: elapsedMinutes.toFixed(2)
        };
    }

    updateMetricElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
            console.log(`[RT-ENGINE] 📊 Updated metric ${id}: ${value}`);
        } else {
            console.warn(`[RT-ENGINE] ⚠️ Metric element not found: ${id}`);
        }
        
        // TEMP HOTFIX: add missing metrics per document requirement
        const accuracyText = document.getElementById('accuracyText');
        if (accuracyText) {
            const metrics = this.calculateMetrics();
            accuracyText.textContent = `Accuracy: ${metrics.accuracy || 'Improving...'}`;
        } else {
            console.warn('⚠️ Metric element not found: accuracyText');
        }
    }

    updateConfidenceIndicator(confidence) {
        const confidenceFill = document.querySelector('.confidence-fill');
        const confidenceValue = document.querySelector('.confidence-value');
        
        if (confidenceFill && confidenceValue) {
            const percentage = Math.round(confidence * 100);
            confidenceFill.style.width = percentage + '%';
            confidenceValue.textContent = percentage + '%';
            
            // Update color class
            confidenceFill.className = 'confidence-fill ' + 
                (percentage >= 80 ? 'high' : percentage >= 60 ? 'medium' : 'low');
        }
    }

    updateRecordingUI(isRecording) {
        const recordBtn = document.getElementById('recordBtn');
        const buttonLabel = document.getElementById('buttonLabel');
        
        if (recordBtn) {
            recordBtn.className = `record-button ${isRecording ? 'recording' : ''}`;
            recordBtn.innerHTML = `<i class="fas fa-${isRecording ? 'stop' : 'microphone'}"></i>`;
        }
        
        if (buttonLabel) {
            buttonLabel.textContent = isRecording ? 'Stop Recording' : 'Start Recording';
        }
    }

    updateStatus(status, message) {
        const statusIndicator = document.getElementById('statusIndicator');
        if (statusIndicator) {
            const dot = statusIndicator.querySelector('.status-dot');
            const text = statusIndicator.querySelector('.status-text');
            
            if (dot) dot.className = `status-dot ${status}`;
            if (text) text.textContent = message;
        }
    }

    updateNetworkStatus(isOnline) {
        const networkStatus = document.getElementById('networkStatus');
        if (networkStatus) {
            networkStatus.className = `network-status ${isOnline ? 'online' : 'offline'}`;
            networkStatus.innerHTML = `<i class="fas fa-${isOnline ? 'wifi' : 'wifi-slash'}"></i> ${isOnline ? 'Online' : 'Offline'}`;
        }
    }

    showError(message) {
        console.error('[RT-ENGINE] Error:', message);
        
        const errorContainer = document.getElementById('errorContainer');
        if (errorContainer) {
            const errorAlert = document.createElement('div');
            errorAlert.className = 'alert alert-danger alert-dismissible fade show';
            errorAlert.innerHTML = `
                <strong>Error:</strong> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            errorContainer.appendChild(errorAlert);
            
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                if (errorAlert.parentNode) {
                    errorAlert.remove();
                }
            }, 5000);
        }
    }

    showChunkError(chunkId, message) {
        console.error(`[RT-ENGINE] Chunk ${chunkId} error:`, message);
        
        // Show error in transcript
        const transcriptContainer = document.getElementById('transcriptContainer');
        if (transcriptContainer) {
            const errorItem = document.createElement('div');
            errorItem.className = 'transcript-item error fade-in';
            errorItem.innerHTML = `
                <div class="transcript-header-info">
                    <span class="transcript-type error">Error</span>
                    <span class="transcript-time">${new Date().toLocaleTimeString()}</span>
                </div>
                <p class="transcript-text">Failed to process chunk: ${message}</p>
            `;
            
            transcriptContainer.appendChild(errorItem);
            transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
        }
    }

    handleRecordingStop() {
        // Process any final chunks
        console.log('[RT-ENGINE] Processing final chunks...');
        
        // Update UI to show completion
        this.updateStatus('completed', `Recording completed - ${this.activeChunks.size} chunks processed`);
        
        // Generate summary if we have transcripts
        if (this.activeChunks.size > 0) {
            this.generateSessionSummary();
        }
    }

    generateSessionSummary() {
        // Combine all transcript chunks
        const transcripts = Array.from(this.activeChunks.values())
            .filter(chunk => chunk.text)
            .map(chunk => chunk.text)
            .join(' ');

        if (transcripts.trim()) {
            console.log('[RT-ENGINE] Generated session summary:', transcripts.length, 'characters');
            
            // Could send to /api/transcribe_full for final processing and AI analysis
            this.processFinalTranscript(transcripts);
        }
    }

    async processFinalTranscript(transcript) {
        try {
            const response = await fetch('/api/transcribe_full', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    transcript: transcript,
                    session_id: this.sessionId,
                    meeting_type: 'general'
                })
            });

            if (response.ok) {
                const result = await response.json();
                console.log('[RT-ENGINE] Final transcript processed:', result);
                
                // Could display final summary/analysis
                this.displayFinalSummary(result);
            }

        } catch (error) {
            console.warn('[RT-ENGINE] Failed to process final transcript:', error);
        }
    }

    displayFinalSummary(result) {
        // Add final summary to UI
        const transcriptContainer = document.getElementById('transcriptContainer');
        if (transcriptContainer && result.summary) {
            const summaryItem = document.createElement('div');
            summaryItem.className = 'transcript-item final fade-in';
            summaryItem.innerHTML = `
                <div class="transcript-header-info">
                    <span class="transcript-type final">Summary</span>
                    <span class="transcript-confidence">AI Generated</span>
                    <span class="transcript-time">${new Date().toLocaleTimeString()}</span>
                </div>
                <p class="transcript-text"><strong>Summary:</strong> ${result.summary}</p>
            `;
            
            transcriptContainer.appendChild(summaryItem);
            transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
        }
    }
} // FIXED: Properly close the RealTimeTranscriptionEngine class

// Audio Meter utility class
class AudioMeter {
    constructor() {
        this.audioContext = null;
        this.analyser = null;
        this.dataArray = null;
        this.animationId = null;
    }

    async start(stream) {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const source = this.audioContext.createMediaStreamSource(stream);
            
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            
            source.connect(this.analyser);
            
            this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
            
            this.updateMeter();
            
        } catch (error) {
            console.warn('[AUDIO-METER] Failed to start:', error);
        }
    }

    updateMeter() {
        if (!this.analyser) return;
        
        this.analyser.getByteFrequencyData(this.dataArray);
        
        // Calculate volume (RMS)
        let sum = 0;
        for (let i = 0; i < this.dataArray.length; i++) {
            sum += this.dataArray[i] * this.dataArray[i];
        }
        const volume = Math.sqrt(sum / this.dataArray.length) / 255;
        
        // Update UI
        this.updateMeterUI(volume);
        
        this.animationId = requestAnimationFrame(() => this.updateMeter());
    }

    updateMeterUI(volume) {
        const meterFill = document.querySelector('.meter-fill');
        const meterValue = document.querySelector('.meter-value');
        
        if (meterFill && meterValue) {
            const percentage = Math.round(volume * 100);
            meterFill.style.width = percentage + '%';
            meterValue.textContent = percentage + '%';
        }
    }

    stop() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
    }
}

// Global functions for template compatibility
window.clearTranscript = function() {
    const transcriptContainer = document.getElementById('transcriptContainer');
    if (transcriptContainer) {
        transcriptContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-microphone-slash"></i>
                <p>No transcript available</p>
                <small>Start recording to see live transcription</small>
            </div>
        `;
    }
};

// SPEC REQUIREMENT: Download functionality for .txt and .vtt formats
window.exportFinalTranscript = function(format) {
    const container = document.querySelector('.final-transcript-content p');
    if (!container) return;
    
    const transcript = container.textContent.trim();
    if (!transcript) return;
    
    let content, mimeType, extension;
    
    if (format === 'vtt') {
        // SPEC REQUIREMENT: VTT format with timestamps
        content = `WEBVTT

00:00:00.000 --> 00:00:30.000
${transcript}`;
        mimeType = 'text/vtt';
        extension = 'vtt';
    } else {
        // Default to TXT
        content = transcript;
        mimeType = 'text/plain';
        extension = 'txt';
    }
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${new Date().toISOString().slice(0, 10)}.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
};

window.copyFinalTranscript = function() {
    const container = document.querySelector('.final-transcript-content p');
    if (!container) return;
    
    const transcript = container.textContent.trim();
    if (navigator.clipboard) {
        navigator.clipboard.writeText(transcript).then(() => {
            console.log('[FINAL-PHASE] Transcript copied to clipboard');
        });
    }
};

window.exportTranscript = function() {
    if (window.transcriptionEngine && window.transcriptionEngine.activeChunks.size > 0) {
        const transcripts = Array.from(window.transcriptionEngine.activeChunks.values())
            .filter(chunk => chunk.text)
            .map((chunk, index) => `[${index + 1}] ${chunk.text}`)
            .join('\n\n');
            
        const blob = new Blob([transcripts], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `transcript_${new Date().toISOString().slice(0, 10)}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }
};

// ACTION A: Complete Transcript Rendering Logic Implementation
RealTimeTranscriptionEngine.prototype.displayTranscriptUpdate = function(data) {
    const { text, chunkId, chunk_id, timestamp, is_final, confidence } = data;
    const actualChunkId = chunkId || chunk_id || `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const actualText = text || data.transcript;
    const transcriptType = is_final ? 'final' : 'partial';
    
    // BULLETPROOF: Early duplicate detection using global processing key - but more permissive
    const renderKey = `render_${transcriptType}_${actualChunkId}`;
    
    // PATCH REQUIREMENT: Disable duplicate blocking as per document - allow ALL chunks through
    // Original blocking logic commented out per document fix requirement
    const now = Date.now();
    // DISABLED: Duplicate blocking per document requirement
    // if (this.processedTranscriptEvents.has(renderKey)) {
    //     const lastProcessed = this.lastRenderTimestamp?.get(renderKey) || 0;
    //     if (now - lastProcessed < 100) {
    //         console.log(`[TRANSCRIPT-RENDER] 🚫 RAPID DUPLICATE DETECTION: Skipping ${transcriptType} render for`, actualChunkId);
    //         return; // Exit immediately - no rendering
    //     }
    // }
    
    // Mark as processed with timestamp
    this.processedTranscriptEvents.add(renderKey);
    if (!this.lastRenderTimestamp) {
        this.lastRenderTimestamp = new Map();
    }
    this.lastRenderTimestamp.set(renderKey, now);
    
    console.log(`[TRANSCRIPT-RENDER] Processing ${transcriptType} chunk ${actualChunkId}: "${actualText?.substring(0, 30)}..."`);
    
    // SPEC REQUIREMENT: Only update UI when text.length > 1
    if (!actualText || actualText.length <= 1) {
        console.log(`[TRANSCRIPT-RENDER] Skipping short text: "${actualText}"`);
        return;
    }
    
    // ACTION A: Store in chunkTranscriptStore to track and avoid duplicates
    const chunkData = {
        text: actualText,
        timestamp: timestamp || Date.now(),
        type: transcriptType,
        confidence: confidence || 0,
        processed: false
    };
    
    // Additional check for exact same chunk data (secondary protection)
    if (this.chunkTranscriptStore.has(actualChunkId)) {
        const existing = this.chunkTranscriptStore.get(actualChunkId);
        if (existing.text === actualText && existing.type === transcriptType) {
            console.log(`[TRANSCRIPT-RENDER] Skipping duplicate chunk: ${actualChunkId}`);
            return;
        }
    }
    
    // Store the chunk data
    this.chunkTranscriptStore.set(actualChunkId, chunkData);
    
    // ACTION A: Render DOM elements based on type (partial vs final)
    this.renderTranscriptChunk(actualChunkId, chunkData);
    
    // ACTION C: Update metrics for final transcripts
    if (transcriptType === 'final') {
        this.updateMetricsFromFinalChunk(actualText, confidence || 0);
    }
};

// ACTION A: Render transcript chunk with proper DOM management
RealTimeTranscriptionEngine.prototype.renderTranscriptChunk = function(chunkId, chunkData) {
    const transcriptContainer = document.getElementById('transcriptContainer');
    if (!transcriptContainer) {
        console.warn('[TRANSCRIPT-RENDER] Container not found');
        return;
    }
    
    const { text, timestamp, type, confidence } = chunkData;
    const timestampFormatted = new Date(timestamp).toLocaleTimeString();
    
    // Check if chunk already exists in DOM
    let chunkElement = document.getElementById(`chunk-${chunkId}`);
    
    if (type === 'partial') {
        // For partial: update existing or create new with 🟡 indicator
        if (!chunkElement) {
            chunkElement = document.createElement('div');
            chunkElement.id = `chunk-${chunkId}`;
            chunkElement.className = 'transcript-chunk partial';
            transcriptContainer.appendChild(chunkElement);
        }
        
        chunkElement.innerHTML = `
            <div class="chunk-header">
                <span class="chunk-indicator">🟡 Live</span>
                <span class="chunk-timestamp">${timestampFormatted}</span>
                <span class="chunk-confidence">${Math.round(confidence * 100)}%</span>
            </div>
            <div class="chunk-text">${text}</div>
        `;
        
        console.log(`[TRANSCRIPT-RENDER] Rendered partial chunk ${chunkId}: "${text.substring(0, 30)}..."`);
        
    } else if (type === 'final') {
        // For final: replace existing partial or create new with ✅ indicator
        if (chunkElement) {
            // Replace existing partial with final
            chunkElement.className = 'transcript-chunk final';
            chunkElement.innerHTML = `
                <div class="chunk-header">
                    <span class="chunk-indicator">✅ Final</span>
                    <span class="chunk-timestamp">${timestampFormatted}</span>
                    <span class="chunk-confidence">${Math.round(confidence * 100)}%</span>
                </div>
                <div class="chunk-text">${text}</div>
            `;
            console.log(`[TRANSCRIPT-RENDER] Replaced partial with final chunk ${chunkId}`);
        } else {
            // Create new final chunk
            chunkElement = document.createElement('div');
            chunkElement.id = `chunk-${chunkId}`;
            chunkElement.className = 'transcript-chunk final';
            chunkElement.innerHTML = `
                <div class="chunk-header">
                    <span class="chunk-indicator">✅ Final</span>
                    <span class="chunk-timestamp">${timestampFormatted}</span>
                    <span class="chunk-confidence">${Math.round(confidence * 100)}%</span>
                </div>
                <div class="chunk-text">${text}</div>
            `;
            transcriptContainer.appendChild(chunkElement);
            console.log(`[TRANSCRIPT-RENDER] Created new final chunk ${chunkId}`);
        }
    }
    
    // Auto-scroll to bottom
    transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
};

// ACTION C: Metrics Update Hook - Update metrics when final transcripts are received
RealTimeTranscriptionEngine.prototype.updateMetricsFromFinalChunk = function(text, confidence) {
    const words = text.split(' ').filter(word => word.length > 0);
    const wordCount = words.length;
    
    // Update session metrics
    this.sessionMetrics.finalTranscriptWordCount += wordCount;
    this.sessionMetrics.totalChunks++;
    this.sessionMetrics.totalConfidence += confidence;
    this.sessionMetrics.avgConfidence = this.sessionMetrics.totalConfidence / this.sessionMetrics.totalChunks;
    
    // Calculate session duration
    const sessionDuration = (Date.now() - this.sessionMetrics.startTime) / 1000;
    this.sessionMetrics.sessionDuration = sessionDuration;
    
    // Calculate WPM
    const wpm = sessionDuration > 0 ? (this.sessionMetrics.finalTranscriptWordCount / sessionDuration) * 60 : 0;
    
    // Update DOM elements
    this.updateMetricsDOM({
        wordsTranscribed: this.sessionMetrics.finalTranscriptWordCount,
        liveWords: wordCount,
        sessionDuration: Math.round(sessionDuration),
        avgConfidence: Math.round(this.sessionMetrics.avgConfidence * 100),
        wpm: Math.round(wpm)
    });
    
    console.log(`[METRICS-UPDATE] Final chunk processed: ${wordCount} words, ${Math.round(confidence * 100)}% confidence`);
};

// ACTION C: Update metrics DOM elements
RealTimeTranscriptionEngine.prototype.updateMetricsDOM = function(metrics) {
    const elements = {
        wordsTranscribed: document.getElementById('wordsTranscribed'),
        liveWords: document.getElementById('liveWords'), 
        sessionDuration: document.getElementById('sessionDuration'),
        avgConfidence: document.getElementById('avgConfidence'),
        wpm: document.getElementById('wpmDisplay')
    };
    
    if (elements.wordsTranscribed) elements.wordsTranscribed.textContent = metrics.wordsTranscribed;
    if (elements.liveWords) elements.liveWords.textContent = metrics.liveWords;
    if (elements.sessionDuration) elements.sessionDuration.textContent = `${metrics.sessionDuration}s`;
    if (elements.avgConfidence) elements.avgConfidence.textContent = `${metrics.avgConfidence}%`;
    if (elements.wpm) elements.wpm.textContent = `${metrics.wpm} WPM`;
    
    console.log(`[METRICS-DOM] Updated: ${metrics.wordsTranscribed} words, ${metrics.avgConfidence}% confidence, ${metrics.wpm} WPM`);
};

// ACTION D: Enhanced Final Transcript Rendering Function
RealTimeTranscriptionEngine.prototype.displayFinalTranscript = function() {
    console.log('[FINAL-TRANSCRIPT] Displaying final transcript...');
    
    // Get containers
    const finalContainer = document.getElementById('finalTranscriptContainer');
    const liveContainer = document.getElementById('liveTranscriptDisplay');
    const finalContent = document.getElementById('finalTranscriptContent');
    
    if (!finalContainer || !finalContent) {
        console.error('[FINAL-TRANSCRIPT] Required containers not found');
        return;
    }
    
    // Sort chunks by timestamp
    const sortedChunks = Array.from(this.chunkTranscriptStore.entries())
        .sort(([, a], [, b]) => a.timestamp - b.timestamp);
    
    // Compile final transcript
    const finalTranscriptLines = [];
    let totalWords = 0;
    let totalConfidence = 0;
    let finalChunks = 0;
    
    for (const [chunkId, chunkData] of sortedChunks) {
        // Only include final chunks or chunks without corresponding final versions
        if (chunkData.type === 'final' || !sortedChunks.some(([, data]) => data.type === 'final' && data.timestamp > chunkData.timestamp)) {
            finalTranscriptLines.push(chunkData.text);
            totalWords += chunkData.text.split(' ').length;
            totalConfidence += chunkData.confidence;
            finalChunks++;
        }
    }
    
    const finalTranscriptText = finalTranscriptLines.join(' ');
    const avgConfidence = finalChunks > 0 ? totalConfidence / finalChunks : 0;
    
    // Render final transcript
    finalContent.innerHTML = `
        <div class="final-transcript-header">
            <h3>✅ Final Transcript</h3>
            <div class="final-transcript-stats">
                <span>Words: ${totalWords}</span>
                <span>Confidence: ${Math.round(avgConfidence * 100)}%</span>
                <span>Chunks: ${finalChunks}</span>
            </div>
        </div>
        <div class="final-transcript-content">
            ${finalTranscriptText}
        </div>
    `;
    
    // Hide live transcript, show final transcript
    if (liveContainer) {
        liveContainer.style.display = 'none';
    }
    finalContainer.style.display = 'block';
    
    console.log(`[FINAL-TRANSCRIPT] ✅ Final transcript displayed: ${totalWords} words, ${Math.round(avgConfidence * 100)}% confidence`);
};

// ACTION D: Final Transcript Action Functions
function copyFinalTranscript() {
    const finalContent = document.getElementById('finalTranscriptContent');
    if (finalContent) {
        const text = finalContent.textContent || finalContent.innerText;
        navigator.clipboard.writeText(text).then(() => {
            console.log('[FINAL-TRANSCRIPT] Copied to clipboard');
            // Show notification
            showNotification('Final transcript copied to clipboard!', 'success');
        }).catch(err => {
            console.error('[FINAL-TRANSCRIPT] Failed to copy:', err);
            showNotification('Failed to copy transcript', 'error');
        });
    }
}

function exportFinalTranscript() {
    const finalContent = document.getElementById('finalTranscriptContent');
    if (finalContent) {
        const text = finalContent.textContent || finalContent.innerText;
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `final_transcript_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        console.log('[FINAL-TRANSCRIPT] Exported successfully');
        showNotification('Final transcript exported!', 'success');
    }
}

function clearFinalTranscript() {
    const finalContainer = document.getElementById('finalTranscriptContainer');
    const liveContainer = document.getElementById('liveTranscriptDisplay');
    
    if (finalContainer) {
        finalContainer.style.display = 'none';
    }
    if (liveContainer) {
        liveContainer.style.display = 'block';
    }
    
    console.log('[FINAL-TRANSCRIPT] Cleared, returning to live view');
    showNotification('Final transcript cleared', 'info');
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1000;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
    `;
    
    switch (type) {
        case 'success':
            notification.style.background = 'rgba(72, 187, 120, 0.9)';
            break;
        case 'error':
            notification.style.background = 'rgba(239, 68, 68, 0.9)';
            break;
        case 'info':
        default:
            notification.style.background = 'rgba(59, 130, 246, 0.9)';
            break;
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
};

// FINAL PHASE: Implement flush session and final transcript replacement
RealTimeTranscriptionEngine.prototype.flushSessionAndGenerateFinalTranscript = async function() {
    console.log('[FINAL-PHASE] Flushing session and generating final transcript...');
    
    try {
        const sessionId = localStorage.getItem('currentSessionId') || this.sessionId;
        
        // SPEC REQUIREMENT: Call POST /api/flush_session
        const response = await fetch('/api/flush_session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                session_id: sessionId
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('[FINAL-PHASE] Flush session response:', result);
            
            // SPEC REQUIREMENT: Replace all chunk rows with single clean final transcript
            this.replaceChunksWithFinalTranscript();
        } else {
            console.error('[FINAL-PHASE] Failed to flush session:', response.status);
        }
    } catch (error) {
        console.error('[FINAL-PHASE] Error flushing session:', error);
    }
};

// SPEC REQUIREMENT: Replace all chunk rows with single clean final transcript
RealTimeTranscriptionEngine.prototype.replaceChunksWithFinalTranscript = function() {
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    
    console.log('[FINAL-PHASE] Replacing chunks with final transcript...');
    
    // Collect all meaningful text from chunks
    const chunks = container.querySelectorAll('.transcript-chunk');
    const finalTranscriptParts = [];
    
    chunks.forEach(chunk => {
        const textElement = chunk.querySelector('.text');
        if (textElement && textElement.textContent.trim().length > 1) {
            finalTranscriptParts.push(textElement.textContent.trim());
        }
    });
    
    // Generate clean final transcript
    const finalTranscript = finalTranscriptParts.join(' ').replace(/\s+/g, ' ').trim();
    
    if (finalTranscript) {
        // Clear all interim chunks
        container.innerHTML = '';
        
        // Create final transcript display
        const finalContainer = document.createElement('div');
        finalContainer.className = 'final-transcript-container';
        finalContainer.innerHTML = `
            <div class="final-transcript-header">
                <h3>Final Transcript</h3>
                <div class="final-transcript-metadata">
                    <span class="final-timestamp">${new Date().toLocaleString()}</span>
                    <span class="final-word-count">${finalTranscript.split(/\s+/).length} words</span>
                </div>
            </div>
            <div class="final-transcript-content">
                <p>${finalTranscript}</p>
            </div>
            <div class="final-transcript-actions">
                <button onclick="window.exportFinalTranscript('txt')" class="export-btn">Download TXT</button>
                <button onclick="window.exportFinalTranscript('vtt')" class="export-btn">Download VTT</button>
                <button onclick="window.copyFinalTranscript()" class="export-btn">Copy Text</button>
            </div>
        `;
        
        container.appendChild(finalContainer);
        console.log('[FINAL-PHASE] Final transcript displayed successfully');
    } else {
        console.log('[FINAL-PHASE] No meaningful transcript content found');
        container.innerHTML = '<div class="no-transcript">No transcript available</div>';
    }
};

RealTimeTranscriptionEngine.prototype.createTranscriptPlaceholder = function(chunkId) {
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    
    const chunkNumber = chunkId.split('_').pop();
    const placeholder = document.createElement('div');
    placeholder.id = `chunk-${chunkId}`;
    placeholder.className = 'transcript-chunk placeholder';
    placeholder.innerHTML = `
        <div class="transcript-header">
            <span class="chunk-id">Chunk ${chunkNumber}</span>
            <span class="transcript-status buffering">Buffering...</span>
            <span class="confidence">--</span>
        </div>
        <div class="transcript-text placeholder">Chunk ${chunkNumber}: Buffering...</div>
    `;
    
    container.appendChild(placeholder);
    container.scrollTop = container.scrollHeight;
};

RealTimeTranscriptionEngine.prototype.updateTranscriptPlaceholder = function(chunkId, text, status) {
    const element = document.getElementById(`chunk-${chunkId}`);
    if (element) {
        element.className = `transcript-chunk ${status}`;
        element.querySelector('.transcript-status').textContent = status;
        element.querySelector('.transcript-text').textContent = text;
    }
};

RealTimeTranscriptionEngine.prototype.startRecordingTimer = function() {
    const timerElement = document.getElementById('recordingTimer');
    if (!timerElement) return;
    
    this.recordingTimer = setInterval(() => {
        if (this.recordingStartTime) {
            const elapsed = Date.now() - this.recordingStartTime;
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
    }, 1000);
};

RealTimeTranscriptionEngine.prototype.updateWordCount = function() {
    const wordCountElement = document.getElementById('wordCount');
    if (wordCountElement) {
        wordCountElement.textContent = this.wordCount;
    }
};

// 🧠 FIX #5: Fix final transcript replacement
RealTimeTranscriptionEngine.prototype.flushSessionAndGetFinalTranscript = function() {
        console.log('[RT-ENGINE] 🧠 FIX #5: Flushing session and generating final transcript...');
        
        // Ensure finalUtterances is initialized
        if (!this.finalUtterances) {
            this.finalUtterances = new Map();
        }
        
        // Generate final transcript from all final utterances
        const allText = Array.from(this.finalUtterances.values())
            .map(utterance => utterance.text || '')
            .join(' ')
            .trim();
        
        // Display the final transcript
        this.displayFinalTranscript(allText || this.liveTranscript);
        
        // 🧠 FIX #7: Fix undefined `.clear()` and `.values()` errors with proper guards
        if (this.interimUtterances && typeof this.interimUtterances.clear === 'function') {
            this.interimUtterances.clear();
        }
        if (this.finalUtterances && typeof this.finalUtterances.clear === 'function') {
            this.finalUtterances.clear();
        }
        
        // Reset live transcript display
        this.resetLiveTranscriptDisplay();
        
        console.log('[RT-ENGINE] ✅ Final transcript replacement completed');
        
        return allText;
};

RealTimeTranscriptionEngine.prototype.displayFinalTranscript = function(finalText) {
        console.log('[RT-ENGINE] Displaying final transcript:', finalText);
        
        // Find or create final transcript container
        let finalTranscriptContainer = document.getElementById('finalTranscriptContainer');
        if (!finalTranscriptContainer) {
            finalTranscriptContainer = document.createElement('div');
            finalTranscriptContainer.id = 'finalTranscriptContainer';
            finalTranscriptContainer.className = 'final-transcript-container';
            
            // Insert into main container
            const mainContainer = document.getElementById('transcriptContainer') || document.body;
            mainContainer.appendChild(finalTranscriptContainer);
        }
        
        // Display final transcript with professional styling
        finalTranscriptContainer.innerHTML = `
            <div class="final-transcript-header">
                <h3>📝 Final Transcript</h3>
                <div class="transcript-actions">
                    <button onclick="copyFinalTranscript()" class="btn btn-sm btn-outline-primary">
                        Copy
                    </button>
                    <button onclick="downloadFinalTranscript()" class="btn btn-sm btn-outline-success">
                        Download
                    </button>
                </div>
            </div>
            <div class="final-transcript-content">
                ${finalText || 'No transcript available'}
            </div>
        `;
        
        // Add fade-in animation
        finalTranscriptContainer.style.opacity = '0';
        finalTranscriptContainer.style.transform = 'translateY(20px)';
        
        requestAnimationFrame(() => {
            finalTranscriptContainer.style.transition = 'all 0.5s ease-in-out';
            finalTranscriptContainer.style.opacity = '1';
            finalTranscriptContainer.style.transform = 'translateY(0)';
        });
};

RealTimeTranscriptionEngine.prototype.resetLiveTranscriptDisplay = function() {
        // Clear live transcript display
        const liveTranscriptElement = document.getElementById('liveTranscriptOutput');
        if (liveTranscriptElement) {
            liveTranscriptElement.textContent = '';
        }
        
        // Clear interim transcript chunks
        const interimChunks = document.querySelectorAll('.transcript-chunk.interim');
        interimChunks.forEach(chunk => chunk.remove());
        
        // Reset live transcript state
        this.liveTranscript = '';
        
        console.log('[RT-ENGINE] ✅ Live transcript display reset');
};

RealTimeTranscriptionEngine.prototype.flushSessionAndGetFinalTranscript_Legacy = async function() {
    try {
        console.log('[RT-ENGINE] Flushing session and preparing final transcript...');
        
        // Wait a moment for final chunks to complete
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // CRITICAL: Replace interim chunks with final clean transcript per CTO document
        this.replaceInterimWithFinalTranscript();
        
        // Call backend flush for any remaining audio
        const response = await fetch('/api/flush_session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                session_id: this.sessionId
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('[RT-ENGINE] Session flushed:', result);
        }
    } catch (error) {
        console.warn('[RT-ENGINE] Failed to flush session:', error);
    }
};

RealTimeTranscriptionEngine.prototype.appendFinalTranscript = function(text) {
    const container = document.getElementById('transcriptContainer');
    if (!container) return;
    
    const finalElement = document.createElement('div');
    finalElement.className = 'transcript-chunk final-session';
    finalElement.innerHTML = `
        <div class="transcript-header">
            <span class="chunk-id">Final Transcript</span>
            <span class="transcript-status final">Complete</span>
            <span class="confidence">100%</span>
        </div>
        <div class="transcript-text final">${text || '[No speech detected]'}</div>
    `;
    
    container.appendChild(finalElement);
    container.scrollTop = container.scrollHeight;
};

RealTimeTranscriptionEngine.prototype.handleFinalTranscript = function(text) {
    // Fallback handling for empty or null text
    if (!text || text.trim() === '') {
        text = '[No speech detected]';
    }
    
    this.appendFinalTranscript(text);
};

// CRITICAL: Final transcript replacement methods per CTO document requirements
RealTimeTranscriptionEngine.prototype.replaceInterimWithFinalTranscript = function() {
    console.log('[RT-ENGINE] ✅ Replacing interim transcripts with final clean version...');
    
    // Generate complete final transcript from all chunks
    const finalTranscript = this.generateCleanFinalTranscript();
    
    if (finalTranscript.trim()) {
        // Clear all interim chunks from UI
        this.clearInterimChunks();
        
        // Display single clean final transcript
        this.displayFinalTranscript(finalTranscript);
        
        console.log('[RT-ENGINE] ✅ Final transcript replacement completed');
    }
};

RealTimeTranscriptionEngine.prototype.generateCleanFinalTranscript = function() {
    // FIXED: Comprehensive safety checks per attached document
    if (!this.transcriptRegistry) {
        console.warn('[RT-ENGINE] transcriptRegistry is undefined, initializing...');
        this.transcriptRegistry = new Map();
    } else if (!(this.transcriptRegistry instanceof Map)) {
        console.warn('[RT-ENGINE] transcriptRegistry is not a Map, converting...');
        const oldData = this.transcriptRegistry;
        this.transcriptRegistry = new Map();
        // Convert object entries to Map if needed
        if (typeof oldData === 'object') {
            Object.entries(oldData).forEach(([key, value]) => {
                this.transcriptRegistry.set(key, value);
            });
        }
    }
    
    if (!this.activeChunks) {
        console.warn('[RT-ENGINE] activeChunks is undefined, initializing...');
        this.activeChunks = new Map();
    }
    
    // FIXED: Try both transcriptRegistry and activeChunks for maximum compatibility
    let chunks = [];
    
    if (this.transcriptRegistry && this.transcriptRegistry.size > 0) {
        chunks = Array.from(this.transcriptRegistry.values());
        console.log('[RT-ENGINE] Using transcriptRegistry with', chunks.length, 'items');
    } else if (this.activeChunks && this.activeChunks.size > 0) {
        chunks = Array.from(this.activeChunks.values());
        console.log('[RT-ENGINE] Using activeChunks with', chunks.length, 'items');
    } else {
        console.warn('[RT-ENGINE] No transcript data available in either registry');
        return '[No transcripts available]';
    }
    
    // Filter meaningful chunks
    const filteredChunks = chunks
        .filter(chunk => chunk && chunk.text && chunk.text.trim() && 
                !chunk.text.includes('No speech detected') &&
                !chunk.text.includes('[No speech]') &&
                (chunk.confidence || 0) > 0.1) // Filter low confidence
        .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0)); // Sort by timestamp
    
    const transcript = filteredChunks
        .map(chunk => chunk.text.trim())
        .join(' ')
        .replace(/\s+/g, ' ') // Clean up multiple spaces
        .trim();
        
    console.log('[RT-ENGINE] Generated final transcript:', transcript.length, 'characters from', filteredChunks.length, 'chunks');
    return transcript || '[No meaningful transcript content]';
};

RealTimeTranscriptionEngine.prototype.clearInterimChunks = function() {
    console.log('[RT-ENGINE] Clearing interim chunk elements from UI...');
    
    const transcriptContainer = document.getElementById('transcriptContainer');
    if (transcriptContainer) {
        // Remove all chunk elements
        const chunkElements = transcriptContainer.querySelectorAll('.transcript-chunk');
        console.log('[RT-ENGINE] Removing', chunkElements.length, 'interim chunk elements');
        chunkElements.forEach(element => element.remove());
    }
};

RealTimeTranscriptionEngine.prototype.displayFinalTranscript = function(transcript) {
    const transcriptContainer = document.getElementById('transcriptContainer');
    if (!transcriptContainer) return;
    
    // CRITICAL FIX: Type validation and conversion
    let finalTranscript = '';
    if (typeof transcript === 'string') {
        finalTranscript = transcript;
    } else if (transcript && typeof transcript === 'object') {
        // Handle cases where transcript is an object
        finalTranscript = transcript.text || transcript.transcript || JSON.stringify(transcript);
    } else {
        finalTranscript = String(transcript || '[No transcript content]');
    }
    
    console.log('[RT-ENGINE] Displaying final clean transcript...', typeof finalTranscript, finalTranscript.length);
    
    // BULLETPROOF: Ensure we have a string before calling split
    const wordCount = finalTranscript.split ? finalTranscript.split(/\s+/).filter(w => w.length > 0).length : 0;
    
    // Create clean final transcript display
    const finalElement = document.createElement('div');
    finalElement.className = 'transcript-item final-complete fade-in';
    finalElement.innerHTML = `
        <div class="transcript-header-info">
            <span class="transcript-type final-complete">✅ Final Transcript</span>
            <span class="transcript-time">${new Date().toLocaleTimeString()}</span>
            <span class="word-count">${wordCount} words</span>
        </div>
        <div class="transcript-text final-complete">${finalTranscript}</div>
        <div class="transcript-actions">
            <button onclick="window.downloadTranscript()" class="btn btn-sm btn-outline-primary">
                📄 Download
            </button>
            <button onclick="window.copyTranscript()" class="btn btn-sm btn-outline-secondary">
                📋 Copy
            </button>
        </div>
    `;
    
    transcriptContainer.appendChild(finalElement);
    transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
    
    console.log('[RT-ENGINE] ✅ Final transcript displayed:', finalTranscript.length, 'characters');
};

// STATS UPDATE: Live statistics calculation
RealTimeTranscriptionEngine.prototype.updateLiveStatistics = function(text, confidence, isHallucination = false) {
        const wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
        
        // Update totals (including hallucinations for chunk counting)
        this.totalChunks = (this.totalChunks || 0) + 1;
        this.confidenceSum = (this.confidenceSum || 0) + confidence;
        
        // Only count meaningful words for WPM (exclude hallucinations)
        if (!isHallucination) {
            this.totalWords = (this.totalWords || 0) + wordCount;
            this.hallucinationCount = (this.hallucinationCount || 0);
        } else {
            this.hallucinationCount = (this.hallucinationCount || 0) + 1;
        }
        
        // Calculate averages
        const avgConfidence = Math.round((this.confidenceSum / this.totalChunks) * 100);
        const elapsedTime = (Date.now() - (this.recordingStartTime || Date.now())) / 1000 / 60; // minutes
        const wpm = Math.round((this.totalWords || 0) / Math.max(elapsedTime, 0.1));
        const successRate = Math.round(((this.totalChunks - (this.hallucinationCount || 0)) / this.totalChunks) * 100);
        
        // Update UI elements safely with multiple fallback IDs
        this.safeUpdateElement('chunksProcessed', this.totalChunks);
        this.safeUpdateElement('avgConfidence', `${avgConfidence}%`);
        this.safeUpdateElement('averageConfidence', `${avgConfidence}%`);
        this.safeUpdateElement('confidenceScore', `${avgConfidence}%`); // Additional fallback
        this.safeUpdateElement('wordsPerMinute', wpm);
        this.safeUpdateElement('totalWords', this.totalWords || 0);
        this.safeUpdateElement('qualityScore', `${avgConfidence}%`);
        this.safeUpdateElement('successRate', `${successRate}%`);
        this.safeUpdateElement('hallucinations', this.hallucinationCount || 0);
        
        // Force update accuracy display with jQuery fallback
        try {
            const accuracyElements = document.querySelectorAll('[class*="accuracy"], [id*="confidence"], [id*="Confidence"]');
            accuracyElements.forEach(el => {
                if (el && el.textContent !== undefined) {
                    el.textContent = `${avgConfidence}%`;
                }
            });
        } catch (e) {
            console.log('[STATS] Error updating accuracy elements:', e);
        }
        
        // Update accuracy indicator
        const accuracyElement = document.querySelector('.accuracy-indicator');
        if (accuracyElement) {
            let accuracyText = 'Improving...';
            if (avgConfidence >= 80) accuracyText = 'Excellent!';
            else if (avgConfidence >= 60) accuracyText = 'Good';
            else if (avgConfidence >= 40) accuracyText = 'Fair';
            
            accuracyElement.textContent = `Accuracy: ${accuracyText} (${avgConfidence}%)`;
        }
        
        console.log(`[STATS] Updated: ${this.totalWords || 0} words, ${avgConfidence}% confidence, ${wpm} WPM, ${this.hallucinationCount || 0} hallucinations`);
};

// PATCH FIX 3: New renderFinalTranscript function with deduplication and chunk ID handling
RealTimeTranscriptionEngine.prototype.renderFinalTranscript = function(chunk_id, text, confidence) {
    // PATCH FIX 1: Prevent duplicate rendering
    if (!chunk_id || this.processedChunks.has(chunk_id)) {
        console.log(`[RT-ENGINE] Skipping duplicate chunk: ${chunk_id}`);
        return;
    }
    
    // Add to processed chunks
    this.processedChunks.add(chunk_id);
    
    // Check if element already exists
    const existing = document.getElementById(`chunk-${chunk_id}`);
    if (existing) {
        console.log(`[RT-ENGINE] Chunk ${chunk_id} already rendered, updating...`);
        existing.querySelector('.transcript-text').textContent = text;
        existing.querySelector('.confidence').textContent = `${Math.round(confidence * 100)}%`;
        return;
    }
    
    // Create new transcript line
    const transcriptContainer = document.getElementById('transcriptContainer') || 
                               document.getElementById('transcriptContent') ||
                               document.getElementById('liveTranscript');
    
    if (!transcriptContainer) {
        console.warn('[RT-ENGINE] No transcript container found for renderFinalTranscript');
        return;
    }
    
    const line = document.createElement("div");
    line.id = `chunk-${chunk_id}`;
    line.classList.add("final-chunk", "transcript-chunk");
    line.innerHTML = `
        <div class="transcript-header">
            <span class="chunk-id">Chunk ${chunk_id}</span>
            <span class="timestamp">${new Date().toLocaleTimeString()}</span>
            <span class="confidence">${Math.round(confidence * 100)}%</span>
            <span class="transcript-status final">✅ Final</span>
        </div>
        <div class="transcript-text">${text}</div>
    `;
    
    transcriptContainer.appendChild(line);
    transcriptContainer.scrollTop = transcriptContainer.scrollHeight;
    
    // PATCH FIX 4: Update live metrics
    this.updateLiveMetrics(text, confidence);
    
    console.log(`[RT-ENGINE] Rendered final transcript for chunk ${chunk_id}: ${text.substring(0, 50)}...`);
};

// PATCH FIX 4: Update live metrics calculation and display
RealTimeTranscriptionEngine.prototype.updateLiveMetrics = function(text, confidence) {
    const words = text.trim().split(/\s+/).filter(w => w.length > 0).length;
    
    // Update totals
    this.totalWords += words;
    this.totalChunks++;
    this.totalConfidence += confidence;
    this.liveWordCount = words; // Current chunk word count
    this.liveConfidence = Math.round(confidence * 100);
    
    // Calculate averages
    const avgConfidence = Math.round((this.totalConfidence / this.totalChunks) * 100);
    const elapsedTime = (Date.now() - (this.recordingStartTime || Date.now())) / 1000 / 60; // minutes
    const wpm = Math.round(this.totalWords / Math.max(elapsedTime, 0.1));
    
    // Update UI elements with multiple fallback IDs
    const updateElements = [
        { ids: ['totalWords', 'wordCount', 'totalWordCount'], value: this.totalWords },
        { ids: ['liveWordCount', 'liveWords', 'currentWords'], value: this.liveWordCount },
        { ids: ['avgConfidence', 'confidenceScore', 'averageConfidence'], value: `${avgConfidence}%` },
        { ids: ['wordsPerMinute', 'wpm', 'currentWPM'], value: wpm },
        { ids: ['chunksProcessed', 'totalChunks', 'chunkCount'], value: this.totalChunks },
        { ids: ['liveConfidence', 'currentConfidence'], value: `${this.liveConfidence}%` }
    ];
    
    updateElements.forEach(({ ids, value }) => {
        ids.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
    });
    
    console.log(`[RT-ENGINE] Live metrics updated: ${this.totalWords} total words, ${this.liveWordCount} live words, ${avgConfidence}% confidence`);
};

// SAFE DOM UPDATE: Prevent null reference errors
RealTimeTranscriptionEngine.prototype.safeUpdateElement = function(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = value;
        } else {
            console.warn(`[STATS] Element not found: ${elementId}`);
        }
};

console.log('[RT-ENGINE] Real-time transcription engine loaded');

// CRITICAL: Expose RealTimeTranscriptionEngine to global scope
window.RealTimeTranscriptionEngine = RealTimeTranscriptionEngine;

// Global registry to prevent duplicate processing
window.processedTranscriptEvents = new Set();
window.eventHandlerRegistry = {
    transcript_partial: [],
    transcript_final: []
};

// Initialize the global engine instance
window.realTimeEngine = null;
window.isEngineInitialized = false;

// BULLETPROOF SINGLETON PATTERN - COMPLETE DUPLICATE PREVENTION
if (!window.MINA_RT_ENGINE_SINGLETON_INITIALIZED) {
    window.MINA_RT_ENGINE_SINGLETON_INITIALIZED = true;
    
    // Initialize when DOM is ready - ONLY ONCE
    document.addEventListener('DOMContentLoaded', function() {
        // QUADRUPLE CHECK: Prevent any duplicate initialization
        if (window.realTimeEngine || window.isEngineInitialized || window.MINA_INITIALIZATION_IN_PROGRESS || window.MINA_INITIALIZATION_COMPLETE) {
            console.log('[APP] ⚠️ Engine already exists or initializing, BLOCKING duplicate initialization');
            return;
        }
        
        // Set initialization flag IMMEDIATELY
        window.MINA_INITIALIZATION_IN_PROGRESS = true;
        
        console.log('[APP] Initializing Real-Time Transcription [SINGLETON - DEFINITIVE]');
        
        try {
            // Create global engine instance - ONLY ONCE
            window.realTimeEngine = new RealTimeTranscriptionEngine();
            
            // Initialize with default config
            window.realTimeEngine.initialize({
                chunkInterval: 4000,
                useWebSocket: true,
                enableVAD: true,
                enableConfidenceScoring: true
            }).then(() => {
                console.log('[APP] ✅ Real-time transcription engine initialized successfully [SINGLETON - DEFINITIVE]');
                window.isEngineInitialized = true;
                window.MINA_INITIALIZATION_IN_PROGRESS = false;
                window.MINA_INITIALIZATION_COMPLETE = true;
            }).catch(error => {
                console.error('[APP] Failed to initialize engine:', error);
                window.MINA_INITIALIZATION_IN_PROGRESS = false;
            });
            
        } catch (error) {
            console.error('[APP] Initialization failed:', error);
            window.MINA_INITIALIZATION_IN_PROGRESS = false;
        }
    });
}

// PATCH FIX: Add WebSocket event handlers for the new renderFinalTranscript function
// This should be called after socket connection is established
function setupPatchedWebSocketHandlers(socket) {
    if (!socket || !window.realTimeEngine) return;
    
    // Handle final transcript events with new renderFinalTranscript
    socket.on('transcription_result', (data) => {
        const { chunk_id, transcript, confidence, is_final } = data;
        
        // PATCH FIX 1: Prevent duplicate rendering
        if (!chunk_id || window.realTimeEngine.processedChunks.has(chunk_id)) {
            console.log(`[PATCH] Skipping duplicate chunk: ${chunk_id}`);
            return;
        }
        
        if (is_final) {
            // PATCH FIX 3: Use new renderFinalTranscript with deduplication
            window.realTimeEngine.renderFinalTranscript(chunk_id, transcript, confidence);
        } else {
            // Handle interim transcripts (existing logic)
            window.realTimeEngine.renderInterimTranscript(chunk_id, transcript, confidence);
        }
    });
    
    // Handle transcript_final events specifically
    socket.on('transcript_final', (data) => {
        const { chunk_id, text, confidence } = data;
        
        if (chunk_id && text && !window.realTimeEngine.processedChunks.has(chunk_id)) {
            console.log(`[PATCH] Rendering final transcript for chunk: ${chunk_id}`);
            window.realTimeEngine.renderFinalTranscript(chunk_id, text, confidence || 0.5);
        }
    });
    
    console.log('[PATCH] WebSocket handlers set up with new renderFinalTranscript function');
}

// Auto-setup when socket becomes available
if (typeof window.setupWebSocketHandlers === 'function') {
    const originalSetup = window.setupWebSocketHandlers;
    window.setupWebSocketHandlers = function(socket) {
        originalSetup(socket);
        setupPatchedWebSocketHandlers(socket);
    };
}