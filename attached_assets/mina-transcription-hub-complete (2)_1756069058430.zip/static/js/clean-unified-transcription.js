class CleanUnifiedTranscriptionSystem {
    constructor() {
        console.log('[CLEAN-UNIFIED] Initializing enhanced system for 80%+ confidence...');
        this.isRecording = false;
        this.socket = null;
        this.processedTranscripts = new Set();
        this.audioContext = null;
        this.processor = null;
        this.source = null;
        this.recordingBuffer = [];
        this.chunkTimer = null;
        this.audioProcessor = new EnhancedAudioProcessor();
        this.qualityMetrics = [];
        this.setupUI();
        this.initializeWebSocket();
    }
    
    setupUI() {
        this.startBtn = document.getElementById('startRecording');
        this.stopBtn = document.getElementById('stopRecording');
        this.statusDiv = document.getElementById('connectionStatus');
        this.transcriptContainer = document.getElementById('transcriptContainer');
        
        if (this.startBtn && this.stopBtn) {
            this.startBtn.onclick = null;
            this.stopBtn.onclick = null;
            
            this.startBtn.addEventListener('click', () => this.startRecording());
            this.stopBtn.addEventListener('click', () => this.stopRecording());
            
            console.log('[CLEAN-UNIFIED] UI setup complete');
        }
    }
    
    initializeWebSocket() {
        if (typeof io !== 'undefined') {
            this.socket = io();
            
            this.socket.on('connect', () => {
                console.log('[CLEAN-UNIFIED] WebSocket connected');
                this.updateStatus('Ready to transcribe', 'ready');
            });
            
            this.socket.on('transcription_result', (data) => {
                this.handleTranscriptionResult(data);
            });
            
            this.socket.on('disconnect', () => {
                console.log('[CLEAN-UNIFIED] WebSocket disconnected');
                this.updateStatus('Connection lost', 'error');
            });
        }
    }
    
    async startRecording() {
        if (this.isRecording) return;
        
        console.log('[CLEAN-UNIFIED] Starting recording...');
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    sampleRate: 48000, // Higher initial sample rate for better quality
                    channelCount: 1,
                    echoCancellation: true,
                    noiseSuppression: false, // Let our processor handle this
                    autoGainControl: false,  // Manual gain control for consistency
                    googEchoCancellation: true,
                    googAutoGainControl: false,
                    googNoiseSuppression: false,
                    googHighpassFilter: false
                }
            });
            
            // Initialize enhanced audio processing chain
            const processedOutput = await this.audioProcessor.initializeAudioProcessing(stream);
            this.audioContext = this.audioProcessor.audioContext;
            
            // Create script processor for audio capture
            this.processor = this.audioContext.createScriptProcessor(2048, 1, 1); // Smaller buffer for lower latency
            
            this.recordingBuffer = [];
            this.sampleRate = this.audioContext.sampleRate;
            
            this.processor.onaudioprocess = (event) => {
                if (this.isRecording) {
                    const inputBuffer = event.inputBuffer.getChannelData(0);
                    
                    // Analyze audio quality in real-time
                    const quality = this.audioProcessor.analyzeAudioQuality(inputBuffer);
                    this.qualityMetrics.push(quality);
                    
                    // Only record if we have good quality audio with voice
                    if (quality.hasVoice && quality.quality > 0.3) {
                        this.recordingBuffer.push(new Float32Array(inputBuffer));
                        this.updateQualityDisplay(quality);
                    }
                }
            };
            
            processedOutput.connect(this.processor);
            this.processor.connect(this.audioContext.destination);
            
            // Process audio in 3-second chunks for better context
            this.chunkTimer = setInterval(() => {
                if (this.recordingBuffer.length > 0 && this.isRecording) {
                    this.processBufferedAudio();
                }
            }, 3000);
            
            this.stream = stream;
            this.isRecording = true;
            
            // Update UI
            this.startBtn.style.display = 'none';
            this.stopBtn.style.display = 'inline-block';
            this.updateStatus('Recording...', 'recording');
            this.clearTranscripts();
            
            console.log('[CLEAN-UNIFIED] Recording started successfully');
            
        } catch (error) {
            console.error('[CLEAN-UNIFIED] Start recording failed:', error);
            this.updateStatus('Microphone access denied', 'error');
        }
    }
    
    stopRecording() {
        if (!this.isRecording) return;
        
        console.log('[CLEAN-UNIFIED] Stopping recording...');
        
        try {
            this.isRecording = false;
            
            // Clear timer
            if (this.chunkTimer) {
                clearInterval(this.chunkTimer);
                this.chunkTimer = null;
            }
            
            // Process any remaining buffer
            if (this.recordingBuffer.length > 0) {
                this.processBufferedAudio();
            }
            
            // Clean up Web Audio API
            if (this.processor) {
                this.processor.disconnect();
                this.processor = null;
            }
            if (this.source) {
                this.source.disconnect();
                this.source = null;
            }
            
            // Clean up enhanced audio processor
            this.audioProcessor.cleanup();
            this.audioContext = null;
            
            // Stop media stream
            if (this.stream) {
                this.stream.getTracks().forEach(track => track.stop());
                this.stream = null;
            }
            
            // Update UI
            this.startBtn.style.display = 'inline-block';
            this.stopBtn.style.display = 'none';
            this.updateStatus('Recording stopped', 'ready');
            
            console.log('[CLEAN-UNIFIED] Recording stopped successfully');
            
        } catch (error) {
            console.error('[CLEAN-UNIFIED] Stop recording failed:', error);
            this.isRecording = false;
            this.startBtn.style.display = 'inline-block';
            this.stopBtn.style.display = 'none';
            this.updateStatus('Recording stopped (forced)', 'ready');
        }
    }
    
    processBufferedAudio() {
        if (this.recordingBuffer.length === 0) return;
        
        console.log('[CLEAN-UNIFIED] Processing enhanced audio chunks:', this.recordingBuffer.length);
        
        // Calculate average quality for this chunk
        const avgQuality = this.qualityMetrics.length > 0 
            ? this.qualityMetrics.reduce((sum, q) => sum + q.quality, 0) / this.qualityMetrics.length
            : 0;
        
        console.log(`[CLEAN-UNIFIED] Chunk quality score: ${(avgQuality * 100).toFixed(1)}%`);
        
        // Only process high-quality chunks
        if (avgQuality < 0.4) {
            console.log('[CLEAN-UNIFIED] Skipping low-quality chunk');
            this.recordingBuffer = [];
            this.qualityMetrics = [];
            return;
        }
        
        // Create optimized WAV using enhanced processor
        const wavBlob = this.createEnhancedWAVBlob(this.recordingBuffer);
        this.recordingBuffer = []; // Clear buffer
        this.qualityMetrics = []; // Clear quality metrics
        
        // Process WAV blob
        this.processAudioChunk(wavBlob, avgQuality);
    }
    
    createEnhancedWAVBlob(buffers) {
        // Use enhanced audio processor for optimal WAV creation
        const wavBuffer = this.audioProcessor.createOptimizedWAV(buffers, this.sampleRate);
        return new Blob([wavBuffer], { type: 'audio/wav' });
    }
    
    async processAudioChunk(audioBlob, expectedQuality) {
        console.log('[CLEAN-UNIFIED] Processing enhanced WAV chunk, size:', audioBlob.size);
        
        // Skip tiny chunks (likely silence)
        if (audioBlob.size < 10000) { // Increased threshold for 3-second chunks
            console.log('[CLEAN-UNIFIED] Skipping small chunk (silence)');
            return;
        }
        
        const predictedConfidence = this.audioProcessor.calculateConfidencePrediction({ 
            quality: expectedQuality, 
            hasVoice: true 
        });
        console.log(`[CLEAN-UNIFIED] Predicted confidence: ${(predictedConfidence * 100).toFixed(1)}%`);
        
        const formData = new FormData();
        formData.append('audio', audioBlob, 'enhanced_chunk.wav');
        formData.append('chunk_id', Date.now().toString());
        formData.append('quality_score', expectedQuality.toFixed(3));
        formData.append('predicted_confidence', predictedConfidence.toFixed(3));
        
        try {
            const response = await fetch('/api/transcribe_clean', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Audio-Format': 'wav-enhanced'
                }
            });
            
            if (!response.ok) {
                console.error('[CLEAN-UNIFIED] API error:', response.status);
                const errorText = await response.text();
                console.error('[CLEAN-UNIFIED] Error details:', errorText);
                this.updateStatus(`API Error: ${response.status}`, 'error');
                return;
            }
            
            const result = await response.json();
            
            if (result.text && result.text.trim()) {
                // Add quality metadata to result
                result.quality_score = expectedQuality;
                result.predicted_confidence = predictedConfidence;
                this.displayTranscription(result);
            } else if (result.error) {
                console.error('[CLEAN-UNIFIED] Transcription error:', result.error);
                this.updateStatus(result.error, 'error');
            }
            
        } catch (error) {
            console.error('[CLEAN-UNIFIED] Processing error:', error);
            this.updateStatus('Processing failed', 'error');
        }
    }
    
    handleTranscriptionResult(data) {
        const uniqueKey = `${data.chunk_id}_${data.timestamp}_${data.text}`;
        
        if (this.processedTranscripts.has(uniqueKey)) {
            console.log('[CLEAN-UNIFIED] Duplicate transcript blocked:', data.text);
            return;
        }
        
        this.processedTranscripts.add(uniqueKey);
        this.displayTranscription(data);
    }
    

    
    updateStatus(message, type) {
        if (this.statusDiv) {
            this.statusDiv.textContent = message;
            this.statusDiv.className = `status ${type}`;
        }
        console.log(`[CLEAN-UNIFIED] Status: ${message} (${type})`);
    }
    
    clearTranscripts() {
        if (this.transcriptContainer) {
            this.transcriptContainer.innerHTML = '';
        }
        this.processedTranscripts.clear();
        console.log('[CLEAN-UNIFIED] Transcripts cleared');
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('[CLEAN-UNIFIED] Page loaded, initializing...');
    window.cleanTranscriptionSystem = new CleanUnifiedTranscriptionSystem();
    console.log('[CLEAN-UNIFIED] ✅ Clean system initialized');
});