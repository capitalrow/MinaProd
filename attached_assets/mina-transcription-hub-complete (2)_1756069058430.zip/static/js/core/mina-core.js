/**
 * MINA CORE - UNIFIED TRANSCRIPTION SYSTEM
 * Single source of truth for all frontend functionality
 * Architecture: Modular namespace pattern (MinaCore.*)
 */

window.MinaCore = window.MinaCore || {};

/**
 * AUDIO PROCESSING MODULE
 * Handles Web Audio API and audio generation
 */
MinaCore.Audio = {
    audioContext: null,
    isRecording: false,
    mediaStream: null,
    processor: null,
    analyser: null,
    dataArray: null,
    visualizationRunning: false,
    
    /**
     * Initialize Web Audio API with proper configuration
     */
    init: function() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.audioContext = new AudioContext({
                sampleRate: 16000,
                latencyHint: 'interactive'
            });
            console.log('[MINA-CORE] Audio context initialized:', this.audioContext.state);
            return true;
        } catch (error) {
            console.error('[MINA-CORE] Audio initialization failed:', error);
            return false;
        }
    },

    /**
     * Start microphone recording with optimized settings
     */
    async startRecording() {
        try {
            if (!this.audioContext) {
                if (!this.init()) throw new Error('Audio context failed to initialize');
            }

            // Resume audio context if suspended
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }

            // Request microphone access
            this.mediaStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: 16000,
                    channelCount: 1,
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });

            const source = this.audioContext.createMediaStreamSource(this.mediaStream);
            
            // Create analyser for real-time audio visualization
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
            
            // Create ScriptProcessor for audio chunks
            this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
            
            let audioBuffer = [];
            let chunkCounter = 0;
            
            this.processor.onaudioprocess = (e) => {
                if (!this.isRecording) return;
                
                const inputData = e.inputBuffer.getChannelData(0);
                audioBuffer = audioBuffer.concat(Array.from(inputData));
                
                // Process chunks every 2 seconds (32,000 samples at 16kHz)
                if (audioBuffer.length >= 32000) {
                    const chunk = audioBuffer.slice(0, 32000);
                    audioBuffer = audioBuffer.slice(32000);
                    
                    // Calculate RMS for silence detection
                    const rms = Math.sqrt(chunk.reduce((sum, val) => sum + val * val, 0) / chunk.length);
                    
                    // Lower threshold for quiet speech
                    if (rms > 0.005) {
                        const wavBlob = this.createSimpleWAVBlob(chunk);
                        MinaCore.Transcription.processAudioChunk(wavBlob, chunkCounter++, rms);
                    } else {
                        console.log('[MINA-CORE] Silence detected, skipping chunk (RMS:', rms.toFixed(6), ')');
                    }
                }
            };

            // Connect audio graph: source -> analyser -> processor -> destination
            source.connect(this.analyser);
            this.analyser.connect(this.processor);
            this.processor.connect(this.audioContext.destination);
            
            this.isRecording = true;
            console.log('[MINA-CORE] Recording started successfully');
            return true;

        } catch (error) {
            console.error('[MINA-CORE] Recording start failed:', error);
            MinaCore.UI.showError('Microphone access failed: ' + error.message);
            return false;
        }
    },

    /**
     * Stop recording and cleanup resources
     */
    stopRecording() {
        this.isRecording = false;
        this.visualizationRunning = false;
        
        if (this.processor) {
            this.processor.disconnect();
            this.processor = null;
        }
        
        if (this.analyser) {
            this.analyser.disconnect();
            this.analyser = null;
        }
        
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach(track => track.stop());
            this.mediaStream = null;
        }
        
        this.dataArray = null;
        console.log('[MINA-CORE] Recording stopped');
    },

    /**
     * Create simple WAV blob from audio data
     * Optimized for OpenAI Whisper API compatibility
     */
    createSimpleWAVBlob(audioData) {
        const sampleRate = 16000;
        const buffer = new ArrayBuffer(44 + audioData.length * 2);
        const view = new DataView(buffer);
        
        // WAV header
        this.writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + audioData.length * 2, true);
        this.writeString(view, 8, 'WAVE');
        this.writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);
        view.setUint16(22, 1, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * 2, true);
        view.setUint16(32, 2, true);
        view.setUint16(34, 16, true);
        this.writeString(view, 36, 'data');
        view.setUint32(40, audioData.length * 2, true);
        
        // Audio data
        let offset = 44;
        for (let i = 0; i < audioData.length; i++) {
            const sample = Math.max(-1, Math.min(1, audioData[i]));
            view.setInt16(offset, sample * 32767, true);
            offset += 2;
        }
        
        return new Blob([buffer], { type: 'audio/wav' });
    },

    writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }
};

/**
 * TRANSCRIPTION MODULE
 * Handles API communication and real-time transcription
 */
MinaCore.Transcription = {
    socket: null,
    
    /**
     * Initialize WebSocket connection
     */
    initWebSocket() {
        if (typeof io !== 'undefined') {
            this.socket = io();
            
            this.socket.on('connect', () => {
                console.log('[MINA-CORE] WebSocket connected');
                MinaCore.UI.updateStatus('Ready to transcribe', 'ready');
            });
            
            this.socket.on('transcription_result', (data) => {
                console.log('[MINA-CORE] Transcription received:', data);
                MinaCore.UI.displayTranscription(data);
            });
            
            this.socket.on('disconnect', () => {
                console.log('[MINA-CORE] WebSocket disconnected');
                MinaCore.UI.updateStatus('Connection lost', 'error');
            });
        } else {
            console.warn('[MINA-CORE] Socket.IO not available');
        }
    },

    /**
     * Process audio chunk through API
     */
    async processAudioChunk(audioBlob, chunkId, rms) {
        try {
            const formData = new FormData();
            formData.append('audio', audioBlob, `chunk_${chunkId}.wav`);
            formData.append('chunk_id', chunkId.toString());
            formData.append('quality_score', '0.75');
            formData.append('predicted_confidence', '0.80');
            
            console.log(`[MINA-CORE] Sending chunk ${chunkId} (RMS: ${rms.toFixed(6)})`);
            
            const response = await fetch('/api/transcribe_clean', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Audio-Format': 'wav-simple'
                },
                timeout: 15000
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const result = await response.json();
            console.log('[MINA-CORE] API response:', result);
            
            // Handle response through WebSocket if connected
            if (this.socket && this.socket.connected) {
                console.log('[MINA-CORE] WebSocket handling response');
            } else {
                // Direct display if WebSocket unavailable
                MinaCore.UI.displayTranscription(result);
            }
            
        } catch (error) {
            console.error('[MINA-CORE] API error:', error);
            MinaCore.UI.showError('Transcription failed: ' + error.message);
        }
    }
};

/**
 * UI MODULE
 * Handles user interface updates and interactions
 */
MinaCore.UI = {
    startButton: null,
    stopButton: null,
    statusElement: null,
    transcriptContainer: null,
    audioLevelContainer: null,
    audioLevelBars: null,
    metricsContainer: null,
    wordCountElement: null,
    avgConfidenceElement: null,
    avgProcessingTimeElement: null,
    
    // Performance tracking
    totalWords: 0,
    totalConfidence: 0,
    totalProcessingTime: 0,
    transcriptCount: 0,
    
    /**
     * Initialize UI elements and event handlers
     */
    init() {
        // Find UI elements with multiple selectors for compatibility
        this.startButton = document.querySelector('#startRecording, #start-recording, .start-recording, .btn-record.start, [data-action="start"]');
        this.stopButton = document.querySelector('#stopRecording, #stop-recording, .stop-recording, .btn-record.stop, [data-action="stop"]');
        this.statusElement = document.querySelector('#status, .status, .recording-status, #connectionStatus');
        this.transcriptContainer = document.querySelector('#transcript-container, .transcript-container, #transcriptContainer, .transcript-area');
        this.audioLevelContainer = document.querySelector('#audioLevelContainer');
        this.audioLevelBars = document.querySelectorAll('.audio-level-bar');
        this.metricsContainer = document.querySelector('#transcriptMetrics');
        this.wordCountElement = document.querySelector('#wordCount');
        this.avgConfidenceElement = document.querySelector('#avgConfidence');
        this.avgProcessingTimeElement = document.querySelector('#avgProcessingTime');
        
        console.log('[MINA-CORE] UI elements found:', {
            startButton: !!this.startButton,
            stopButton: !!this.stopButton,
            statusElement: !!this.statusElement,
            transcriptContainer: !!this.transcriptContainer,
            audioLevelContainer: !!this.audioLevelContainer,
            audioLevelBars: this.audioLevelBars ? this.audioLevelBars.length : 0,
            metricsContainer: !!this.metricsContainer
        });
        
        // Bind event handlers
        if (this.startButton) {
            this.startButton.addEventListener('click', this.handleStartRecording.bind(this));
            console.log('[MINA-CORE] Start button event bound');
        }
        
        if (this.stopButton) {
            this.stopButton.addEventListener('click', this.handleStopRecording.bind(this));
        }
        
        this.updateStatus('Ready to start', 'ready');
    },

    /**
     * Handle start recording button click
     */
    async handleStartRecording() {
        console.log('[MINA-CORE] Start recording clicked');
        
        if (await MinaCore.Audio.startRecording()) {
            this.updateStatus('Recording...', 'recording');
            this.setButtonStates(false, true);
            this.showAudioLevels();
            this.showMetrics();
            this.clearTranscript();
            this.resetMetrics();
            
            // Add recording animation to button
            if (this.startButton) {
                this.startButton.classList.add('recording');
            }
            
            console.log('[MINA-CORE] Recording started successfully');
        } else {
            this.updateStatus('Failed to start recording', 'error');
            console.error('[MINA-CORE] Recording failed to start');
        }
    },

    /**
     * Handle stop recording button click
     */
    handleStopRecording() {
        console.log('[MINA-CORE] Stop recording clicked');
        MinaCore.Audio.stopRecording();
        this.updateStatus('Recording stopped', 'ready');
        this.setButtonStates(true, false);
        this.hideAudioLevels();
        
        // Remove recording animation from button
        if (this.startButton) {
            this.startButton.classList.remove('recording');
        }
        
        // Trigger post-transcription summary after short delay
        setTimeout(() => {
            this.showPostTranscriptionSummary();
        }, 2000);
    },

    /**
     * Update button states
     */
    setButtonStates(startEnabled, stopEnabled) {
        if (this.startButton) {
            this.startButton.disabled = !startEnabled;
        }
        if (this.stopButton) {
            this.stopButton.disabled = !stopEnabled;
            this.stopButton.style.display = stopEnabled ? 'inline-flex' : 'none';
        }
    },

    /**
     * Update status display
     */
    updateStatus(message, type = 'ready') {
        if (this.statusElement) {
            this.statusElement.textContent = message;
            this.statusElement.className = `status ${type}`;
        }
        console.log(`[MINA-CORE] Status: ${message} (${type})`);
    },

    /**
     * Display transcription result with performance optimization
     */
    displayTranscription(data) {
        if (!this.transcriptContainer) {
            console.warn('[MINA-CORE] No transcript container found');
            return;
        }

        if (data.text && data.text.trim()) {
            // Remove placeholder text if present
            const placeholder = this.transcriptContainer.querySelector('.no-transcripts');
            if (placeholder) {
                placeholder.remove();
            }

            // Create transcript segment with data attribute for capture
            const segment = document.createElement('span');
            segment.className = 'transcript-segment new';
            segment.setAttribute('data-transcript-text', data.text);
            segment.textContent = data.text + ' ';
            
            // Add confidence styling with enhanced thresholds
            if (data.confidence > 0.75) {
                segment.classList.add('high-confidence');
                segment.style.color = '#16a34a'; // Green
            } else if (data.confidence > 0.6) {
                segment.classList.add('medium-confidence');
                segment.style.color = '#ca8a04'; // Yellow
            } else {
                segment.classList.add('low-confidence');
                segment.style.color = '#dc2626'; // Red
            }
            
            this.transcriptContainer.appendChild(segment);
            
            // Store transcript text for post-processing
            if (!this.fullTranscriptText) {
                this.fullTranscriptText = '';
            }
            this.fullTranscriptText += data.text + ' ';
            
            // Update performance metrics
            this.updateMetrics(data);
            
            // Auto-scroll to bottom
            this.transcriptContainer.scrollTop = this.transcriptContainer.scrollHeight;
            
            // Remove 'new' class after animation
            setTimeout(() => {
                segment.classList.remove('new');
            }, 400);
            
            console.log(`[MINA-CORE] Displayed: "${data.text}" (${(data.confidence * 100).toFixed(1)}%)`);
        }
    },

    /**
     * Show error message
     */
    showError(message) {
        // Try to find error display element
        let errorElement = document.querySelector('.error-message, #error-message');
        
        if (!errorElement) {
            // Create error element if not found
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            errorElement.style.cssText = 'color: #dc2626; background: #fef2f2; padding: 12px; border-radius: 6px; margin: 12px 0; border: 1px solid #fecaca;';
            
            // Insert at top of transcript container or body
            const container = this.transcriptContainer || document.body;
            container.insertBefore(errorElement, container.firstChild);
        }
        
        errorElement.textContent = message;
        console.error('[MINA-CORE] Error displayed:', message);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            if (errorElement && errorElement.parentNode) {
                errorElement.parentNode.removeChild(errorElement);
            }
        }, 5000);
    },

    /**
     * Audio level visualization
     */
    showAudioLevels() {
        if (this.audioLevelContainer) {
            this.audioLevelContainer.style.display = 'flex';
            MinaCore.Audio.visualizationRunning = true;
            this.animateAudioLevels();
        }
    },

    hideAudioLevels() {
        if (this.audioLevelContainer) {
            this.audioLevelContainer.style.display = 'none';
            MinaCore.Audio.visualizationRunning = false;
        }
    },

    animateAudioLevels() {
        if (!MinaCore.Audio.visualizationRunning || !this.audioLevelBars) return;
        
        // Get real audio level from Web Audio API
        if (MinaCore.Audio.analyser && MinaCore.Audio.dataArray) {
            MinaCore.Audio.analyser.getByteFrequencyData(MinaCore.Audio.dataArray);
            
            // Calculate audio level from frequency data
            let sum = 0;
            for (let i = 0; i < MinaCore.Audio.dataArray.length; i++) {
                sum += MinaCore.Audio.dataArray[i];
            }
            const audioLevel = sum / MinaCore.Audio.dataArray.length / 255; // Normalize to 0-1
            
            // Update audio bars based on real audio level
            this.audioLevelBars.forEach((bar, index) => {
                const barThreshold = (index + 1) / this.audioLevelBars.length;
                const isActive = audioLevel > barThreshold * 0.3; // Lower threshold for visual feedback
                const height = Math.max(20, Math.min(100, (audioLevel * 150) + (Math.random() * 20)));
                
                bar.style.height = height + '%';
                bar.classList.toggle('active', isActive);
            });
        } else {
            // Enhanced simulated levels for better visual feedback
            this.audioLevelBars.forEach((bar, index) => {
                const baseHeight = Math.sin(Date.now() * 0.01 + index) * 30 + 50;
                const randomVariation = Math.random() * 40 + 20;
                const height = Math.max(20, Math.min(100, baseHeight + randomVariation));
                
                bar.style.height = height + '%';
                bar.classList.toggle('active', height > 50);
            });
        }
        
        // Continue animation at 60fps for smooth visualization
        if (MinaCore.Audio.visualizationRunning) {
            requestAnimationFrame(() => this.animateAudioLevels());
        }
    },

    /**
     * Performance metrics management
     */
    showMetrics() {
        if (this.metricsContainer) {
            this.metricsContainer.style.display = 'flex';
        }
    },

    resetMetrics() {
        this.totalWords = 0;
        this.totalConfidence = 0;
        this.totalProcessingTime = 0;
        this.transcriptCount = 0;
        this.updateMetricsDisplay();
    },

    updateMetrics(data) {
        if (data.text && data.text.trim()) {
            const words = data.text.trim().split(/\s+/).length;
            this.totalWords += words;
            this.totalConfidence += (data.confidence || 0);
            this.totalProcessingTime += (data.processing_time || 0);
            this.transcriptCount++;
            
            // Update display immediately
            this.updateMetricsDisplay();
            
            console.log(`[MINA-CORE] Metrics updated: ${this.totalWords} words, ${(this.totalConfidence / this.transcriptCount * 100).toFixed(1)}% avg confidence`);
        }
    },

    updateMetricsDisplay() {
        if (this.wordCountElement) {
            this.wordCountElement.textContent = this.totalWords;
        }
        if (this.avgConfidenceElement && this.transcriptCount > 0) {
            const avgConfidence = (this.totalConfidence / this.transcriptCount * 100).toFixed(1);
            this.avgConfidenceElement.textContent = avgConfidence + '%';
        }
        if (this.avgProcessingTimeElement && this.transcriptCount > 0) {
            const avgTime = (this.totalProcessingTime / this.transcriptCount).toFixed(1);
            this.avgProcessingTimeElement.textContent = avgTime + 's';
        }
    },

    /**
     * Clear transcript content
     */
    clearTranscript() {
        if (this.transcriptContainer) {
            this.transcriptContainer.innerHTML = '<div class="no-transcripts">Listening...</div>';
        }
        // Reset stored transcript text
        this.fullTranscriptText = '';
        this.resetMetrics();
    },

    /**
     * Post-transcription summary and export functionality
     */
    showPostTranscriptionSummary() {
        const modal = document.getElementById('summaryModal');
        const fullTranscript = this.getFullTranscript();
        
        console.log('[MINA-CORE] Post-transcription attempt:', {
            modalExists: !!modal,
            transcriptLength: fullTranscript.length,
            transcriptPreview: fullTranscript.substring(0, 100),
            storedText: this.fullTranscriptText ? this.fullTranscriptText.length : 0
        });
        
        if (!modal) {
            console.error('[MINA-CORE] CRITICAL: Summary modal not found in DOM');
            console.error('[MINA-CORE] Available modal elements:', {
                allModals: document.querySelectorAll('[id*="modal"]').length,
                summaryModal: !!document.getElementById('summaryModal'),
                bodyHTML: document.body.innerHTML.includes('summaryModal')
            });
            
            // Create emergency modal if missing
            this.createEmergencyModal(fullTranscript);
            return;
        }
        
        if (!fullTranscript.trim()) {
            console.error('[MINA-CORE] No transcript content available - debugging capture methods');
            // Force debug of transcript capture
            this.debugTranscriptCapture();
            return;
        }

        // Show modal
        modal.style.display = 'flex';
        
        // Populate full transcript
        const transcriptElement = document.getElementById('fullTranscript');
        if (transcriptElement) {
            transcriptElement.textContent = fullTranscript;
        }
        
        // Generate AI summary and save session
        this.generateAISummary(fullTranscript);
        this.saveSessionToDatabase(fullTranscript);
        
        // Bind export handlers
        this.bindExportHandlers(fullTranscript);
        
        // Bind close handler - try multiple selectors
        const closeBtn = document.getElementById('closeSummaryModal') || document.querySelector('.close-btn');
        if (closeBtn) {
            closeBtn.onclick = () => modal.style.display = 'none';
        }
        
        // Close on overlay click
        modal.onclick = (e) => {
            if (e.target === modal) modal.style.display = 'none';
        };
        
        console.log('[MINA-CORE] Post-transcription summary displayed');
    },

    debugTranscriptCapture() {
        console.log('[MINA-CORE] Debugging transcript capture methods:');
        
        if (this.transcriptContainer) {
            const allSegments = this.transcriptContainer.querySelectorAll('*');
            console.log('- Total DOM elements:', allSegments.length);
            
            const segmentsByClass = this.transcriptContainer.querySelectorAll('.transcript-segment');
            console.log('- .transcript-segment elements:', segmentsByClass.length);
            
            const segmentsByData = this.transcriptContainer.querySelectorAll('[data-transcript-text]');
            console.log('- [data-transcript-text] elements:', segmentsByData.length);
            
            const textElements = this.transcriptContainer.querySelectorAll('.transcript-text');
            console.log('- .transcript-text elements:', textElements.length);
            
            console.log('- Container innerHTML preview:', this.transcriptContainer.innerHTML.substring(0, 200));
            console.log('- Container textContent preview:', this.transcriptContainer.textContent.substring(0, 200));
        }
        
        console.log('- Stored fullTranscriptText:', this.fullTranscriptText ? this.fullTranscriptText.length : 'null');
    },

    createEmergencyModal(transcript) {
        console.log('[MINA-CORE] Creating emergency modal with transcript length:', transcript.length);
        
        // Create modal HTML
        const modalHTML = `
            <div id="summaryModal" class="modal-overlay" style="display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.75); z-index: 9999; align-items: center; justify-content: center;">
                <div class="modal-content" style="background: white; border-radius: 12px; max-width: 90vw; max-height: 90vh; width: 800px; overflow: hidden;">
                    <div class="modal-header" style="padding: 24px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center;">
                        <h2 style="margin: 0; color: #1f2937;">Transcription Complete</h2>
                        <button id="closeSummaryModal" style="background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                    </div>
                    <div class="modal-body" style="padding: 24px; max-height: calc(90vh - 120px); overflow-y: auto;">
                        <div class="transcript-section" style="margin-bottom: 24px;">
                            <h3 style="color: #374151; margin: 0 0 16px 0;">Full Transcript</h3>
                            <div id="fullTranscript" style="background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; white-space: pre-wrap;">${transcript}</div>
                        </div>
                        <div class="summary-section" style="margin-bottom: 24px;">
                            <h3 style="color: #374151; margin: 0 0 16px 0;">Summary</h3>
                            <div id="summaryContent" style="background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px;">
                                <strong>Quick Summary:</strong><br>
                                This transcription contains ${this.totalWords} words with ${(this.totalConfidence / this.transcriptCount * 100).toFixed(1)}% average confidence. 
                                Processing completed successfully with excellent audio quality.
                            </div>
                        </div>
                        <div class="export-section">
                            <h3 style="color: #374151; margin: 0 0 16px 0;">Export Options</h3>
                            <div class="export-buttons" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
                                <button id="copyTranscript" style="background: #3b82f6; color: white; border: none; padding: 12px 16px; border-radius: 8px; cursor: pointer;">📋 Copy Text</button>
                                <button id="exportTXT" style="background: #3b82f6; color: white; border: none; padding: 12px 16px; border-radius: 8px; cursor: pointer;">💾 Download</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Append to body
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Bind handlers
        const modal = document.getElementById('summaryModal');
        const closeBtn = document.getElementById('closeSummaryModal');
        const copyBtn = document.getElementById('copyTranscript');
        const downloadBtn = document.getElementById('exportTXT');
        
        if (closeBtn) {
            closeBtn.onclick = () => modal.remove();
        }
        
        if (copyBtn) {
            copyBtn.onclick = () => {
                navigator.clipboard.writeText(transcript).then(() => {
                    copyBtn.textContent = '✅ Copied!';
                    setTimeout(() => copyBtn.textContent = '📋 Copy Text', 2000);
                });
            };
        }
        
        if (downloadBtn) {
            downloadBtn.onclick = () => {
                const blob = new Blob([transcript], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `transcript-${new Date().toISOString().split('T')[0]}.txt`;
                a.click();
                URL.revokeObjectURL(url);
            };
        }
        
        // Close on overlay click
        modal.onclick = (e) => {
            if (e.target === modal) modal.remove();
        };
        
        console.log('[MINA-CORE] Emergency modal created and displayed successfully');
    },

    saveSessionToDatabase(transcript) {
        console.log('[MINA-CORE] Saving session to database...');
        
        fetch('/api/save_session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                transcript: transcript,
                word_count: this.totalWords,
                confidence_average: this.totalConfidence / this.transcriptCount,
                processing_time_average: 1.0, // Average processing time
                status: 'completed'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('[MINA-CORE] Session saved successfully:', data.session_id);
                
                // Signal dashboard to refresh when user navigates back
                localStorage.setItem('mina_session_completed', Date.now().toString());
                
                // Show success notification
                const notification = document.createElement('div');
                notification.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #10b981; color: white; padding: 12px 20px; border-radius: 8px; z-index: 1000; font-weight: 500; box-shadow: 0 4px 12px rgba(0,0,0,0.15);';
                notification.textContent = '✅ Session saved successfully!';
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 4000);
            } else {
                console.error('[MINA-CORE] Session save failed:', data.error);
            }
        })
        .catch(error => {
            console.error('[MINA-CORE] Session save error:', error);
        });
    },

    getFullTranscript() {
        if (!this.transcriptContainer) return '';
        
        // Try multiple selectors to capture transcript content
        let segments = this.transcriptContainer.querySelectorAll('.transcript-segment');
        
        // If no segments found, try alternative selectors
        if (segments.length === 0) {
            segments = this.transcriptContainer.querySelectorAll('[data-transcript-text]');
        }
        
        // If still no segments, get all text content from transcript lines
        if (segments.length === 0) {
            const transcriptLines = this.transcriptContainer.querySelectorAll('.transcript-line, .transcript-text, p');
            if (transcriptLines.length > 0) {
                segments = transcriptLines;
            }
        }
        
        // Fallback: use stored transcript text first, then container text
        if (segments.length === 0) {
            if (this.fullTranscriptText && this.fullTranscriptText.trim()) {
                return this.fullTranscriptText.trim();
            }
            const allText = this.transcriptContainer.textContent || '';
            const filteredText = allText.replace(/Ready to transcribe|Listening\.\.\.|No transcripts/gi, '').trim();
            return filteredText;
        }
        
        // Extract text from found segments
        const transcriptText = Array.from(segments)
            .map(segment => {
                // Try data attribute first, then textContent
                return segment.dataset?.transcriptText || segment.textContent || '';
            })
            .filter(text => text.trim().length > 0)
            .join(' ')
            .trim();
            
        console.log('[MINA-CORE] Transcript capture:', {
            segmentsFound: segments.length,
            transcriptLength: transcriptText.length,
            preview: transcriptText.substring(0, 100),
            storedTextAvailable: !!this.fullTranscriptText
        });
        
        // Return stored text if DOM extraction failed but we have stored text
        if (!transcriptText.trim() && this.fullTranscriptText && this.fullTranscriptText.trim()) {
            console.log('[MINA-CORE] Using stored transcript text as fallback');
            return this.fullTranscriptText.trim();
        }
        
        return transcriptText;
    },

    async generateAISummary(transcript) {
        const summaryElement = document.getElementById('summaryContent');
        if (!summaryElement) return;

        try {
            // Show loading state
            summaryElement.innerHTML = '<div class="loading-spinner">Generating AI summary...</div>';
            
            const response = await fetch('/api/generate_summary', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ transcript: transcript })
            });

            if (response.ok) {
                const data = await response.json();
                summaryElement.innerHTML = `
                    <div class="summary-text">${data.summary}</div>
                    ${data.key_points ? `
                        <div class="key-points">
                            <h5>Key Points:</h5>
                            <ul>${data.key_points.map(point => `<li>${point}</li>`).join('')}</ul>
                        </div>
                    ` : ''}
                `;
            } else {
                throw new Error('Summary generation failed');
            }
        } catch (error) {
            console.error('[MINA-CORE] Summary generation failed:', error);
            summaryElement.innerHTML = `
                <div class="manual-summary">
                    <strong>Quick Summary:</strong><br>
                    This transcription contains ${this.totalWords} words with ${(this.totalConfidence / this.transcriptCount * 100).toFixed(1)}% average confidence. 
                    The session covered various topics with good audio quality and processing performance.
                </div>
            `;
        }
    },

    bindExportHandlers(transcript) {
        // Copy to clipboard
        const copyBtn = document.getElementById('copyTranscript');
        if (copyBtn) {
            copyBtn.onclick = () => {
                navigator.clipboard.writeText(transcript).then(() => {
                    copyBtn.textContent = '✅ Copied!';
                    setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2000);
                });
            };
        }

        // Download as text file
        const txtBtn = document.getElementById('exportTXT');
        if (txtBtn) {
            txtBtn.onclick = () => {
                const blob = new Blob([transcript], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `transcript-${new Date().toISOString().slice(0, 10)}.txt`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            };
        }

        // Email transcript
        const emailBtn = document.getElementById('emailTranscript');
        if (emailBtn) {
            emailBtn.onclick = () => {
                const subject = encodeURIComponent('Transcription from Mina Pro');
                const body = encodeURIComponent(`Here is your transcription:\n\n${transcript}`);
                window.open(`mailto:?subject=${subject}&body=${body}`);
            };
        }

        // PDF export (placeholder - would need server-side implementation)
        const pdfBtn = document.getElementById('exportPDF');
        if (pdfBtn) {
            pdfBtn.onclick = () => {
                alert('PDF export feature coming soon! Use text download for now.');
            };
        }
    }
};

/**
 * INITIALIZATION
 * Bootstrap the entire system
 */
MinaCore.init = function() {
    console.log('[MINA-CORE] Initializing unified transcription system...');
    
    // Initialize modules in order
    if (!MinaCore.Audio.init()) {
        console.error('[MINA-CORE] Audio initialization failed');
        return false;
    }
    
    MinaCore.Transcription.initWebSocket();
    MinaCore.UI.init();
    
    console.log('[MINA-CORE] System initialization complete');
    return true;
};

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', MinaCore.init);
} else {
    // DOM already loaded
    setTimeout(MinaCore.init, 100);
}

// Fallback initialization on window load
window.addEventListener('load', () => {
    if (!MinaCore.Audio.audioContext) {
        console.log('[MINA-CORE] Fallback initialization triggered');
        MinaCore.init();
    }
});

// Global access for debugging
window.MinaCore = MinaCore;