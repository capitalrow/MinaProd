"""
Mina Pro - Refactored Architecture
Production-ready AI transcription platform with modern architecture
"""

import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from models import db
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.middleware.proxy_fix import ProxyFix

# Import new modular services
from services.auth_service import auth_service

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize extensions - db imported from models
socketio = SocketIO()

def create_app(config_name='production'):
    """Application factory"""
    app = Flask(__name__)
    
    # Configuration
    configure_app(app, config_name)
    
    # Initialize extensions
    db.init_app(app)
    socketio.init_app(
        app, 
        cors_allowed_origins="*", 
        async_mode='threading',
        ping_timeout=60,
        ping_interval=25,
        max_http_buffer_size=1000000,
        transports=['websocket', 'polling'],
        logger=False,
        engineio_logger=False
    )
    
    # Initialize Flask-Login
    from flask_login import LoginManager
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please sign in to access this page.'
    
    @login_manager.user_loader
    def load_user(user_id):
        from models import User
        return User.query.get(user_id)
    
    # Initialize auth service
    auth_service.init_app(app)
    app.extensions['auth_service'] = auth_service
    app.extensions['login_manager'] = login_manager
    
    # Register blueprints
    register_blueprints(app)
    
    # Setup error handlers  
    setup_error_handlers(app)
    
    # Setup security
    setup_security(app)
    
    # Setup template context
    setup_template_context(app)
    
    # Create database tables
    with app.app_context():
        db.create_all()
    
    logger.info(f"Mina Pro initialized in {config_name} mode")
    return app

def configure_app(app, config_name):
    """Configure application settings"""
    
    # Basic configuration
    app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key')
    app.config['DEBUG'] = config_name == 'development'
    
    # Database configuration
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
        'DATABASE_URL',
        'sqlite:///mina_pro.db'
    )
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
        'echo': app.config['DEBUG']
    }
    
    # Authentication configuration
    app.config['JWT_SECRET_KEY'] = os.environ.get(
        'JWT_SECRET_KEY',
        'jwt-secret-key'
    )
    app.config['PASSWORD_MIN_LENGTH'] = 8
    app.config['SESSION_PERMANENT'] = True
    app.config['SESSION_TIMEOUT'] = 7200  # 2 hours
    
    # File upload configuration
    app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
    app.config['UPLOAD_FOLDER'] = os.path.join(
        app.instance_path,
        'uploads'
    )
    
    # API configuration
    app.config['API_RATE_LIMIT'] = '100/hour'
    app.config['API_TIMEOUT'] = 30
    
    # Create necessary directories
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.instance_path, exist_ok=True)

def initialize_extensions(app):
    """Initialize Flask extensions"""
    
    # Database
    db.init_app(app)
    
    # Authentication service
    auth_service.init_app(app)
    app.extensions['auth_service'] = auth_service
    
    # Socket.IO for real-time features
    socketio.init_app(
        app,
        cors_allowed_origins="*",
        logger=app.config['DEBUG'],
        engineio_logger=app.config['DEBUG']
    )
    
    # Proxy fix for deployment
    app.wsgi_app = ProxyFix(
        app.wsgi_app,
        x_for=1,
        x_proto=1,
        x_host=1,
        x_prefix=1
    )
    
    # Create database tables
    with app.app_context():
        db.create_all()

def register_blueprints(app):
    """Register application blueprints"""
    
    # Authentication routes
    from routes.auth_routes import auth_bp
    app.register_blueprint(auth_bp)
    
    # Add direct routes for compatibility
    @app.route('/register', methods=['GET', 'POST'])
    def register_direct():
        try:
            from routes.auth_routes_complete import register
            return register()
        except:
            return redirect('/auth/register')
    
    @app.route('/login', methods=['GET', 'POST'])
    def login_direct():
        try:
            from routes.auth_routes_complete import login
            return login()
        except:
            return redirect('/auth/login')
    
    # Main application routes
    from routes.main_routes import main_bp
    app.register_blueprint(main_bp)
    
    # AI Chat routes
    try:
        from routes.ai_chat_routes import ai_chat_bp
        app.register_blueprint(ai_chat_bp)
        logger.info("✅ AI Chat routes registered successfully")
    except ImportError as e:
        logger.warning(f"AI Chat routes not available: {e}")
    
    # Transcription routes - use clean template
    from routes.transcription_routes import transcription_bp
    app.register_blueprint(transcription_bp)
    
    # Override real-time route to use clean template
    @app.route('/transcription/real-time')
    def real_time_transcription_clean():
        """Serve the clean real-time transcription page"""
        from flask_login import login_required
        @login_required
        def _inner():
            return render_template('real_time_transcription_clean.html')
        return _inner()
    
    # Support routes  
    from routes.support_routes import support_bp
    app.register_blueprint(support_bp)
    
    # Static asset routes
    from routes.static_routes import static_bp
    app.register_blueprint(static_bp)
    
    # API routes (if they exist)
    try:
        from routes.api_routes import api_bp
        app.register_blueprint(api_bp, url_prefix='/api')
    except ImportError:
        pass
    
    # CRITICAL: Register live transcription API for real-time functionality
    try:
        from routes.live_transcription_api import live_transcription_api
        app.register_blueprint(live_transcription_api)
        logger.info("Live transcription API registered successfully - /api/transcribe_chunk_streaming now available")
    except ImportError as e:
        logger.error(f"Failed to register live transcription API: {e}")
    
    # WORKING: Register the actual working transcription API
    try:
        from routes.live_transcription_api_working import live_transcription_bp
        app.register_blueprint(live_transcription_bp)
        logger.info("✅ WORKING live transcription API registered - /api/transcribe_chunk_streaming is now FUNCTIONAL")
    except ImportError as e:
        logger.error(f"❌ Failed to register WORKING transcription API: {e}")
    
    # CLEAN: Register the clean transcription API
    try:
        from routes.transcription_api_clean import clean_transcription_bp
        app.register_blueprint(clean_transcription_bp)
        logger.info("✅ CLEAN transcription API registered - /api/transcribe_clean is now FUNCTIONAL")
    except ImportError as e:
        logger.error(f"❌ Failed to register CLEAN transcription API: {e}")
    
    # INDUSTRY STANDARDS: Register health check endpoints
    try:
        from routes.health_routes import health_bp
        app.register_blueprint(health_bp)
        logger.info("✅ HEALTH endpoints registered - /health, /metrics, /readiness, /liveness now available")
    except ImportError as e:
        logger.error(f"❌ Failed to register health endpoints: {e}")
    
    # INDUSTRY STANDARDS: Register API v1 routes
    try:
        from api.v1.transcription_routes import transcription_v1
        app.register_blueprint(transcription_v1)
        logger.info("✅ API v1 registered - /api/v1/transcription/* endpoints now available")
    except ImportError as e:
        logger.error(f"❌ Failed to register API v1: {e}")
    
    # Register complete API routes
    try:
        from routes.api_routes_complete import api_blueprint
        app.register_blueprint(api_blueprint)
    except ImportError:
        logger.warning("API routes not found")
    
    # Task management routes
    try:
        from routes.task_routes import task_routes
        app.register_blueprint(task_routes)
    except ImportError:
        logger.warning("Task routes not found")
    
    # Session management routes
    try:
        from routes.session_routes import session_bp
        app.register_blueprint(session_bp)
        logger.info("Session routes registered successfully")
    except ImportError as e:
        logger.warning(f"Session routes not available: {e}")
    
    # Register session API (NEW - for saving sessions)
    try:
        from routes.session_api import session_api_bp
        app.register_blueprint(session_api_bp)
        logger.info("✅ Session API registered - session persistence endpoints available")
    except ImportError as e:
        logger.warning(f"Session API not available: {e}")
    
    # Post-transcription routes for AI summary and export features
    try:
        from routes.post_transcription_api_fixed import post_transcription_bp
        app.register_blueprint(post_transcription_bp)
        logger.info("✅ Post-transcription API registered - summary and insights endpoints available")
    except ImportError as e:
        logger.warning(f"⚠️ Post-transcription API not available: {e}")
    
    # Sharing and collaboration routes
    try:
        from routes.sharing_routes import sharing_bp
        app.register_blueprint(sharing_bp)
    except ImportError as e:
        logger.warning(f"Session routes not available: {e}")
    
    # Final transcript routes
    try:
        from routes.final_transcript_routes import final_transcript_routes
        app.register_blueprint(final_transcript_routes)
    except ImportError as e:
        logger.warning(f"Final transcript routes not available: {e}")
    
    # Admin routes (if they exist)
    try:
        from routes.admin_routes import admin_bp
        app.register_blueprint(admin_bp, url_prefix='/admin')
    except ImportError:
        pass

def setup_error_handlers(app):
    """Setup error handlers"""
    
    @app.errorhandler(400)
    def bad_request(error):
        return render_template('errors/400.html'), 400
    
    @app.errorhandler(401)
    def unauthorized(error):
        return render_template('errors/401.html'), 401
    
    @app.errorhandler(403)
    def forbidden(error):
        return render_template('errors/403.html'), 403
    
    @app.errorhandler(404)
    def not_found(error):
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(429)
    def rate_limit_exceeded(error):
        return render_template('errors/429.html'), 429
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('errors/500.html'), 500

def setup_security(app):
    """Setup security headers and policies"""
    # Initialize security middleware
    try:
        from middleware.security_middleware import SecurityMiddleware
        security_middleware = SecurityMiddleware(app)
        logger.info("✅ SECURITY middleware initialized - comprehensive headers and rate limiting active")
    except ImportError as e:
        logger.error(f"❌ Failed to initialize security middleware: {e}")
        
        # Fallback basic security headers
        @app.after_request
        def after_request(response):
            # Security headers
            response.headers['X-Content-Type-Options'] = 'nosniff'
            response.headers['X-Frame-Options'] = 'DENY'
            response.headers['X-XSS-Protection'] = '1; mode=block'
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            
            # Content Security Policy
            csp = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' https://cdn.socket.io https://cdnjs.cloudflare.com; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; "
                "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; "
                "img-src 'self' data: https:; "
                "connect-src 'self' wss: https:; "
                "media-src 'self'; "
                "object-src 'none'; "
                "frame-src 'none';"
        )
        response.headers['Content-Security-Policy'] = csp
        
        return response

# Template context processors
def setup_template_context(app):
    """Setup template context processors"""
    
    @app.context_processor
    def inject_globals():
        # Don't override Flask-Login's current_user
        from flask_login import current_user
        return {
            'current_year': datetime.now().year,
            'app_version': getattr(app, 'version', '1.0.0'),
            'csrf_token': auth_service.generate_csrf_token,
            'socketio_enabled': True,
            'analytics_enabled': not app.config['DEBUG']
        }

# Socket.IO event handlers
@socketio.on('connect')
def handle_connect(auth=None):
    """Handle client connection"""
    from flask import request
    client_id = request.sid if hasattr(request, 'sid') else 'unknown'
    logger.info(f"Client connected: {client_id}")
    emit('connected', {'status': 'success'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    from flask import request
    client_id = request.sid if hasattr(request, 'sid') else 'unknown'
    logger.info(f"Client disconnected: {client_id}")

@socketio.on('join_session')
def handle_join_session(data):
    """Handle joining transcription session"""
    session_id = data.get('session_id')
    if session_id:
        join_room(session_id)
        emit('session_joined', {'session_id': session_id})

@socketio.on('leave_session')
def handle_leave_session(data):
    """Handle leaving transcription session"""
    session_id = data.get('session_id')
    if session_id:
        leave_room(session_id)
        emit('session_left', {'session_id': session_id})

# Create application instance
app = create_app(
    config_name=os.environ.get('FLASK_ENV', 'production')
)

# Setup template context
setup_template_context(app)

if __name__ == '__main__':
    # Development server
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    socketio.run(
        app,
        host='0.0.0.0',
        port=port,
        debug=debug,
        use_reloader=debug
    )