# Mina Pro Architecture Standards & Development Guidelines

## Core Architectural Principles

### 1. **Unified File Structure - NO DUPLICATES**
- **SINGLE SOURCE OF TRUTH**: Each functionality must exist in ONE file only
- **NO LEGACY FILES**: Delete obsolete files immediately upon refactoring
- **CLEAN DIRECTORIES**: Maintain minimal, purposeful file count in each directory

### 2. **JavaScript Architecture Standards**
- **PRIMARY**: `static/js/core/mina-core.js` - The ONLY JavaScript file for frontend functionality
- **FORBIDDEN**: Multiple JavaScript files with overlapping functionality
- **RULE**: All new JavaScript features must be integrated into mina-core.js modular structure
- **PATTERN**: Use namespace modules (MinaCore.auth, MinaCore.transcription, etc.)

### 3. **Template System Standards**
- **BASE TEMPLATE**: `templates/base_modern.html` - Single base template
- **LANDING**: `templates/modern_landing.html` - Main landing page
- **RULE**: All new templates must extend base_modern.html
- **FORBIDDEN**: Creating duplicate dashboard, auth, or enhanced templates

### 4. **Python Backend Architecture**
- **MAIN APP**: `app_standalone.py` - Primary Flask application
- **ROUTE STRUCTURE**: Blueprint system in `routes/` directory
  - `auth_routes.py` - Authentication endpoints
  - `transcription_routes.py` - Core transcription functionality
  - `api_routes.py` - API endpoints
  - `admin_routes.py` - Administrative functions
- **SERVICES**: Modular services in `services/` directory
- **FORBIDDEN**: Creating comprehensive_*.py, emergency_*.py, fix_*.py files

### 5. **Authentication Standards**
- **PRIMARY**: `services/auth_service.py` with bcrypt and JWT
- **FORBIDDEN**: Multiple auth systems or legacy auth.py files
- **ROUTES**: Authentication handled through `routes/auth_routes.py`

## File Naming Conventions

### ALLOWED Patterns:
- `mina-core.js` (unified JavaScript)
- `base_modern.html` (template base)
- `auth_service.py` (service modules)
- `transcription_routes.py` (blueprint routes)

### FORBIDDEN Patterns:
- `comprehensive_*.js/py` (indicates architectural bloat)
- `emergency_*.js/py` (suggests poor planning)
- `fix_*.js/py` (temporary patches that become permanent)
- `enhanced_*.html` (duplicate templates)
- `critical_*.js/py` (emergency patches)
- `validation_*.py` (test files in main directory)

## Development Workflow Standards

### Before Making Changes:
1. **ANALYZE EXISTING**: Check if functionality already exists in core files
2. **EXTEND, DON'T DUPLICATE**: Add to existing files rather than creating new ones
3. **DELETE OBSOLETE**: Remove any files made redundant by changes

### When Adding Features:
1. **JavaScript**: Add to appropriate module in mina-core.js
2. **Templates**: Extend base_modern.html or modify existing templates
3. **Backend**: Use existing service pattern or blueprint routes
4. **NO STANDALONE FILES**: Avoid creating isolated feature files

### File Lifecycle Management:
1. **CREATE**: Only when no existing file can accommodate the functionality
2. **MODIFY**: Preferred approach - extend existing files
3. **DELETE**: Immediately remove files made obsolete by refactoring
4. **DOCUMENT**: Update replit.md with architectural changes

## Quality Assurance Rules

### Code Integration Standards:
- **SINGLE RESPONSIBILITY**: Each file has one clear purpose
- **NO OVERLAPPING FUNCTIONALITY**: Eliminate duplicate implementations
- **CLEAN IMPORTS**: Remove unused dependencies and imports
- **CONSISTENT PATTERNS**: Follow established naming and structure conventions

### Testing and Validation:
- **INTEGRATION TESTS**: Test complete user flows, not isolated components
- **NO TEST POLLUTION**: Keep test files in dedicated test directories
- **CLEAN TEARDOWN**: Remove temporary files after testing

### Performance Standards:
- **MINIMAL FILES**: Fewer files = faster loading and easier maintenance
- **UNIFIED SYSTEMS**: Single JavaScript file reduces HTTP requests
- **EFFICIENT ROUTING**: Blueprint pattern for organized Flask routes

## Deployment Readiness Checklist

### Before Deployment:
- [ ] All legacy files removed
- [ ] Only essential files remain in each directory
- [ ] No duplicate functionality across files
- [ ] All routes properly organized in blueprints
- [ ] Single JavaScript file (mina-core.js) contains all frontend logic
- [ ] Templates follow unified base_modern.html pattern
- [ ] Services properly modularized
- [ ] No emergency/fix/comprehensive files present

### Architecture Validation:
- [ ] File count in static/js/ is minimal (ideally just core/ directory)
- [ ] Template count follows single-purpose pattern
- [ ] Python files follow service/route separation
- [ ] No conflicting route definitions
- [ ] Clean import statements throughout

## Maintenance Philosophy

### "Less is More" Principle:
- **MINIMIZE FILES**: Fewer files = easier maintenance
- **MAXIMIZE REUSE**: Extend existing functionality rather than duplicating
- **ELIMINATE CRUFT**: Regular cleanup of obsolete files
- **UNIFIED APPROACH**: One clear way to do each task

### Future-Proofing:
- **MODULAR DESIGN**: Easy to extend without creating new files
- **CLEAR SEPARATION**: Distinct boundaries between frontend/backend/services
- **CONSISTENT PATTERNS**: New developers can quickly understand structure
- **DOCUMENTATION**: Keep replit.md updated with architectural decisions

## Emergency Response Protocol

### When Issues Arise:
1. **DIAGNOSE**: Identify root cause before creating fixes
2. **EXTEND**: Modify existing files rather than creating patches
3. **CLEANUP**: Remove any temporary files created during debugging
4. **DOCUMENT**: Update architecture notes with lessons learned

### NEVER Create:
- emergency_*.js files
- fix_*.py patches
- comprehensive_*.anything
- temporary_*.js solutions
- quick_*.py workarounds

## Success Metrics

### Architecture Health Indicators:
- **File Count**: JavaScript directory has minimal files
- **Template Count**: Small number of focused templates
- **Route Organization**: Clear blueprint separation
- **Import Clarity**: No circular dependencies or unused imports
- **Functionality**: Everything works from unified core systems

### Red Flags:
- Multiple files with similar names
- Duplicate functionality across files
- Emergency or fix files accumulating
- Template proliferation
- Route conflicts or overlapping endpoints

---

**REMEMBER**: This architecture was achieved through systematic cleanup of 60+ legacy files. Maintain this clean state by following these standards rigorously.