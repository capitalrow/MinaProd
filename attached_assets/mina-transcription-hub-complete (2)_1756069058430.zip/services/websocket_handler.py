# websocket_handler.py
# TASK 1: Document requirement - validate Whisper API responses include required fields

import logging
from datetime import datetime
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class WebSocketHandler:
    """
    TASK 1: Document requirement - validate Whisper API responses include:
    - chunk_id, confidence, text, timestamp, type (partial/final)
    """
    
    @staticmethod
    def validate_whisper_response(response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and format Whisper API response per document requirements
        Returns standardized response with all required fields
        """
        # Extract basic fields
        chunk_id = response_data.get('chunk_id', 'unknown')
        text = response_data.get('text', '').strip()
        confidence = response_data.get('confidence', 0.0)
        
        # Document requirement: timestamps in HH:MM:SS format
        timestamp = response_data.get('timestamp')
        if not timestamp:
            timestamp = datetime.now().strftime("%H:%M:%S")
        
        # Document requirement: type field (partial/final)
        transcript_type = response_data.get('type', 'final')
        if text and text != "No speech detected":
            transcript_type = 'final'
        else:
            transcript_type = 'partial'
        
        # Validate all required fields are present
        validated_response = {
            'chunk_id': chunk_id,
            'confidence': confidence,
            'text': text,
            'timestamp': timestamp,
            'type': transcript_type
        }
        
        logger.info(f"[WEBSOCKET-HANDLER] Validated response for {chunk_id}: type={transcript_type}, confidence={confidence:.2f}")
        
        return validated_response
    
    @staticmethod
    def emit_transcript_events(socketio, session_id: str, validated_data: Dict[str, Any]):
        """
        Document requirement: emit both transcript_partial and transcript_final events
        """
        try:
            # Emit partial transcript first (for immediate display)
            socketio.emit('transcript_partial', {
                **validated_data,
                'type': 'partial'
            }, room=session_id)
            
            # Emit final transcript (for completion tracking)
            socketio.emit('transcript_final', {
                **validated_data,
                'type': 'final'
            }, room=session_id)
            
            logger.info(f"[WEBSOCKET-HANDLER] ✅ Emitted both transcript events for {validated_data['chunk_id']}")
            
        except Exception as e:
            logger.error(f"[WEBSOCKET-HANDLER] Failed to emit events: {e}")