"""
Authentication Service
Comprehensive user authentication and session management
"""

import os
import jwt
import bcrypt
from datetime import datetime, timedelta
from flask import session, request, current_app, redirect, url_for, abort
from functools import wraps
import secrets
import re
from typing import Optional, Dict, Any

class AuthService:
    def __init__(self, app=None):
        self.app = app
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        app.config.setdefault('JWT_SECRET_KEY', os.environ.get('JWT_SECRET_KEY', secrets.token_urlsafe(32)))
        app.config.setdefault('JWT_ACCESS_TOKEN_EXPIRES', timedelta(hours=24))
        app.config.setdefault('JWT_REFRESH_TOKEN_EXPIRES', timedelta(days=30))
        app.config.setdefault('PASSWORD_MIN_LENGTH', 8)
        app.config.setdefault('SESSION_TIMEOUT', 7200)  # 2 hours in seconds

    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def validate_password(self, password: str) -> Dict[str, Any]:
        """Validate password strength"""
        errors = []
        
        if len(password) < current_app.config['PASSWORD_MIN_LENGTH']:
            errors.append(f"Password must be at least {current_app.config['PASSWORD_MIN_LENGTH']} characters")
        
        if not re.search(r'[A-Z]', password):
            errors.append("Password must contain at least one uppercase letter")
        
        if not re.search(r'[a-z]', password):
            errors.append("Password must contain at least one lowercase letter")
        
        if not re.search(r'\d', password):
            errors.append("Password must contain at least one number")
        
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            errors.append("Password must contain at least one special character")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'strength': self._calculate_password_strength(password)
        }
    
    def _calculate_password_strength(self, password: str) -> str:
        """Calculate password strength score"""
        score = 0
        
        # Length bonus
        score += min(password.__len__(), 25)
        
        # Character variety bonus
        if re.search(r'[a-z]', password):
            score += 5
        if re.search(r'[A-Z]', password):
            score += 5
        if re.search(r'\d', password):
            score += 5
        if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            score += 10
        
        # Determine strength
        if score < 20:
            return 'weak'
        elif score < 40:
            return 'medium'
        elif score < 60:
            return 'strong'
        else:
            return 'very_strong'
    
    def generate_tokens(self, user_id: str, user_data: Dict[str, Any]) -> Dict[str, str]:
        """Generate JWT access and refresh tokens"""
        now = datetime.utcnow()
        
        # Access token
        access_payload = {
            'user_id': user_id,
            'type': 'access',
            'iat': now,
            'exp': now + current_app.config['JWT_ACCESS_TOKEN_EXPIRES']
        }
        
        # Refresh token
        refresh_payload = {
            'user_id': user_id,
            'type': 'refresh',
            'iat': now,
            'exp': now + current_app.config['JWT_REFRESH_TOKEN_EXPIRES']
        }
        
        access_token = jwt.encode(
            access_payload,
            current_app.config['JWT_SECRET_KEY'],
            algorithm='HS256'
        )
        
        refresh_token = jwt.encode(
            refresh_payload,
            current_app.config['JWT_SECRET_KEY'],
            algorithm='HS256'
        )
        
        return {
            'access_token': access_token,
            'refresh_token': refresh_token,
            'expires_in': str(int(current_app.config['JWT_ACCESS_TOKEN_EXPIRES'].total_seconds()))
        }
    
    def verify_token(self, token: str, token_type: str = 'access') -> Optional[Dict[str, Any]]:
        """Verify and decode JWT token"""
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
            
            if payload.get('type') != token_type:
                return None
            
            return payload
        
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def refresh_access_token(self, refresh_token: str) -> Optional[Dict[str, str]]:
        """Generate new access token from refresh token"""
        payload = self.verify_token(refresh_token, 'refresh')
        if not payload:
            return None
        
        # Generate new access token
        user_id = payload['user_id']
        return self.generate_tokens(user_id, {})
    
    def create_session(self, user_id: str, user_data: Dict[str, Any]):
        """Create secure session"""
        session.permanent = True
        session['user_id'] = user_id
        session['user_data'] = user_data
        session['created_at'] = datetime.utcnow().isoformat()
        session['csrf_token'] = secrets.token_urlsafe(32)
    
    def destroy_session(self):
        """Destroy current session"""
        session.clear()
    
    def get_current_user(self) -> Optional[Dict[str, Any]]:
        """Get current authenticated user"""
        # Check session
        if 'user_id' in session:
            # Validate session timeout
            if self._is_session_valid():
                return session.get('user_data')
            else:
                self.destroy_session()
        
        # Check JWT token in Authorization header
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            token = auth_header[7:]
            payload = self.verify_token(token)
            if payload:
                return {'id': payload['user_id']}
        
        return None
    
    def _is_session_valid(self) -> bool:
        """Check if current session is still valid"""
        if 'created_at' not in session:
            return False
        
        created_at = datetime.fromisoformat(session['created_at'])
        timeout = current_app.config['SESSION_TIMEOUT']
        
        return datetime.utcnow() - created_at < timedelta(seconds=timeout)
    
    def generate_csrf_token(self) -> str:
        """Generate CSRF token"""
        if 'csrf_token' not in session:
            session['csrf_token'] = secrets.token_urlsafe(32)
        return session['csrf_token']
    
    def validate_csrf_token(self, token: str) -> bool:
        """Validate CSRF token"""
        return session.get('csrf_token') == token
    
    def rate_limit_check(self, identifier: str, limit: int = 5, window: int = 300) -> bool:
        """Simple rate limiting (in production, use Redis)"""
        # In production, implement with Redis for distributed rate limiting
        # For now, using session-based simple rate limiting
        key = f"rate_limit_{identifier}"
        now = datetime.utcnow()
        
        if key not in session:
            session[key] = []
        
        # Clean old attempts
        session[key] = [
            attempt for attempt in session[key]
            if (now - datetime.fromisoformat(attempt)).total_seconds() < window
        ]
        
        if len(session[key]) >= limit:
            return False
        
        session[key].append(now.isoformat())
        return True

# Decorators for route protection
def login_required(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_service = current_app.extensions.get('auth_service')
        if not auth_service:
            raise RuntimeError("AuthService not initialized")
        
        user = auth_service.get_current_user()
        if not user:
            if request.is_json:
                return {'error': 'Authentication required'}, 401
            else:
                return redirect(url_for('auth.login'))
        
        return f(*args, **kwargs)
    return decorated_function

def csrf_required(f):
    """Decorator to require CSRF token validation"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method in ['POST', 'PUT', 'DELETE', 'PATCH']:
            auth_service = current_app.extensions.get('auth_service')
            if not auth_service:
                raise RuntimeError("AuthService not initialized")
            
            token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
            if not token or not auth_service.validate_csrf_token(token):
                if request.is_json:
                    return {'error': 'CSRF token validation failed'}, 403
                else:
                    abort(403)
        
        return f(*args, **kwargs)
    return decorated_function

def rate_limit(limit: int = 5, window: int = 300, identifier_func=None):
    """Decorator for rate limiting"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            auth_service = current_app.extensions.get('auth_service')
            if not auth_service:
                raise RuntimeError("AuthService not initialized")
            
            if identifier_func:
                identifier = identifier_func()
            else:
                identifier = request.remote_addr
            
            if not auth_service.rate_limit_check(identifier, limit, window):
                if request.is_json:
                    return {'error': 'Rate limit exceeded'}, 429
                else:
                    abort(429)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Create global auth service instance
auth_service = AuthService()