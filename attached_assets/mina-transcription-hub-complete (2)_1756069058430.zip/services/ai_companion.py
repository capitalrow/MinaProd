"""
AI Companion Service for Context-Aware Meeting Intelligence
GPT-4 powered analysis and enhancement features
"""
import os
import logging
import requests
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class AICompanionService:
    """
    Context-aware companion for meeting intelligence using GPT-4
    """
    
    def __init__(self):
        self.api_key = os.environ.get('OPENAI_API_KEY')
        self.model = "gpt-4"
        
    def summarize_meeting(self, transcript: str, context: str = "") -> Dict[str, Any]:
        """Generate intelligent meeting summary"""
        if not self.api_key:
            return {"error": "OpenAI API key required for AI features"}
        
        system_prompt = f"""You are a professional meeting summarizer. Create a concise, actionable summary of this meeting transcript.

Context: {context if context else "General meeting"}

Format your response as:
**Key Points:**
- Point 1
- Point 2

**Decisions Made:**
- Decision 1
- Decision 2

**Next Steps:**
- Step 1
- Step 2

Keep it professional and focused on actionable insights."""

        return self._call_gpt4(system_prompt, transcript)
    
    def extract_action_items(self, transcript: str) -> Dict[str, Any]:
        """Extract clear action items with responsibility assignment"""
        if not self.api_key:
            return {"error": "OpenAI API key required for AI features"}
        
        system_prompt = """Extract clear action items from this transcript. Format as bullet points and assign responsibility when possible.

Format each action item as:
• [Person/Role]: Specific action to take (by when if mentioned)

If no clear person is assigned, use "Team" or "Owner TBD". Focus on concrete, actionable tasks only."""

        return self._call_gpt4(system_prompt, transcript)
    
    def generate_follow_up_questions(self, transcript: str) -> Dict[str, Any]:
        """Generate intelligent follow-up questions"""
        if not self.api_key:
            return {"error": "OpenAI API key required for AI features"}
        
        system_prompt = """Based on this meeting transcript, generate 3-5 thoughtful follow-up questions that would help clarify next steps or uncover important details that weren't fully addressed.

Format as:
1. Question about [topic area]
2. Question about [topic area]
3. Question about [topic area]

Focus on strategic, operational, or clarifying questions that would add real value."""

        return self._call_gpt4(system_prompt, transcript)
    
    def analyze_sentiment(self, transcript: str) -> Dict[str, str]:
        """Analyze overall sentiment of the meeting"""
        if not self.api_key:
            return {"sentiment": "neutral", "confidence": "unknown"}
        
        system_prompt = """Analyze the overall sentiment and tone of this meeting transcript. 

Respond with just one word from: positive, neutral, negative, mixed

Consider factors like:
- Overall mood and energy
- Conflict vs collaboration
- Optimism vs concerns
- Progress vs frustration"""

        result = self._call_gpt4(system_prompt, transcript)
        if result.get("response"):
            sentiment = result["response"].strip().lower()
            if sentiment in ["positive", "negative", "neutral", "mixed"]:
                return {"sentiment": sentiment, "confidence": "high"}
        
        return {"sentiment": "neutral", "confidence": "low"}
    
    def extract_smart_tags(self, transcript: str) -> Dict[str, List[str]]:
        """Extract names, numbers, and action cues from transcript"""
        if not self.api_key:
            return {"names": [], "numbers": [], "action_cues": []}
        
        system_prompt = """Extract and categorize key information from this transcript:

1. Names: Any person names mentioned
2. Numbers: Important numbers (dates, amounts, metrics, percentages)
3. Action Cues: Phrases indicating tasks or next steps (like "let's do", "next step", "please check", "we need to")

Format as JSON:
{
  "names": ["Name1", "Name2"],
  "numbers": ["$5,000", "Q3", "15%"],
  "action_cues": ["Let's schedule follow-up", "Please review the proposal"]
}

Only include clearly stated information, don't infer or guess."""

        result = self._call_gpt4(system_prompt, transcript)
        try:
            import json
            if result.get("response"):
                return json.loads(result["response"])
        except:
            pass
        
        return {"names": [], "numbers": [], "action_cues": []}
    
    def generate_knowledge_base_entry(self, transcript: str, context: str = "") -> Dict[str, Any]:
        """Create structured knowledge base entry"""
        if not self.api_key:
            return {"error": "OpenAI API key required for AI features"}
        
        system_prompt = f"""Convert this meeting transcript into a structured knowledge base entry.

Context: {context}

Format as:
**Title:** [Meeting Topic/Purpose]
**Date:** [If mentioned, otherwise "Not specified"]
**Participants:** [Names if mentioned]
**Key Insights:** [Main learnings or insights]
**Decisions:** [What was decided]
**Actions:** [What needs to be done]
**Follow-up:** [Next meeting or check-in needed]

Keep it concise but comprehensive for future reference."""

        return self._call_gpt4(system_prompt, transcript)
    
    def _call_gpt4(self, system_prompt: str, user_content: str) -> Dict[str, Any]:
        """Make GPT-4 API call with error handling"""
        try:
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'model': self.model,
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': user_content}
                ],
                'max_tokens': 1000,
                'temperature': 0.3
            }
            
            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "status": "success",
                    "response": result['choices'][0]['message']['content'].strip(),
                    "model": self.model
                }
            else:
                logger.error(f"GPT-4 API error: {response.status_code}")
                return {"error": f"AI service unavailable (HTTP {response.status_code})"}
                
        except Exception as e:
            logger.error(f"GPT-4 call failed: {e}")
            return {"error": "AI processing failed"}

# Global companion service instance
ai_companion = AICompanionService()