"""
Action Tagging Service for Mina Pro
Real-time detection and classification of action items, decisions, issues, and next steps
"""

import logging
import re
import json
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class ActionTagger:
    def __init__(self):
        """Initialize the Action Tagger with rule-based patterns"""
        self.patterns = {
            "task": [
                r'\b(you will|we\'ll|I\'ll|need to|should|must|will)\b.*\b(do|complete|finish|implement|create|build|write|update|fix)\b',
                r'\b(assign|assigned|responsible for|take care of|handle)\b',
                r'\b(action item|todo|task|deliverable)\b',
                r'\b(by (monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d+))\b'
            ],
            "decision": [
                r'\b(decided|agreed|confirmed|approved|go with|chosen|selected)\b',
                r'\b(final decision|we\'re going|let\'s go with|agreed on)\b',
                r'\b(decision|conclusion|resolution)\b',
                r'\b(yes, let\'s|ok, we\'ll|alright, we)\b'
            ],
            "issue": [
                r'\b(blocker|blocked|problem|issue|concern|risk|challenge)\b',
                r'\b(can\'t|cannot|unable to|difficult|struggling)\b',
                r'\b(error|bug|broken|failing|not working)\b',
                r'\b(delay|delayed|behind schedule|running late)\b'
            ],
            "next_step": [
                r'\b(next|then|after|following|subsequent)\b.*\b(step|phase|stage|meeting)\b',
                r'\b(follow up|follow-up|check back|revisit|circle back)\b',
                r'\b(next week|next time|later|upcoming)\b',
                r'\b(schedule|plan|arrange|set up)\b.*\b(meeting|call|discussion)\b'
            ]
        }
        
        self.tag_config = {
            "task": {"icon": "🔨", "color": "#ffc107", "label": "Task"},
            "decision": {"icon": "✅", "color": "#28a745", "label": "Decision"},
            "issue": {"icon": "🚧", "color": "#dc3545", "label": "Issue"},
            "next_step": {"icon": "⏭️", "color": "#007bff", "label": "Next Step"}
        }
        
        logger.info("Action Tagger initialized with rule-based patterns")
    
    def tag_transcript_segment(self, text: str, confidence: float = 0.85, 
                              timestamp: str = None) -> Dict[str, Any]:
        """
        Tag a transcript segment for action items
        
        Args:
            text: Transcript text to analyze
            confidence: Transcription confidence score
            timestamp: Optional timestamp
            
        Returns:
            Dictionary with tag information
        """
        if not text or len(text.strip()) < 5:
            return {
                "has_tag": False,
                "tag_type": None,
                "confidence": 0.0,
                "highlight_text": "",
                "timestamp": timestamp or datetime.utcnow().isoformat()
            }
        
        # Normalize text for pattern matching
        text_lower = text.lower().strip()
        
        # Check patterns for each tag type
        for tag_type, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    return self._create_tag_result(text, tag_type, confidence, timestamp)
        
        # No tag found
        return {
            "has_tag": False,
            "tag_type": None,
            "confidence": confidence,
            "highlight_text": "",
            "timestamp": timestamp or datetime.utcnow().isoformat(),
            "original_text": text
        }
    
    def _create_tag_result(self, text: str, tag_type: str, confidence: float, 
                          timestamp: str = None) -> Dict[str, Any]:
        """Create a tagged result object"""
        config = self.tag_config.get(tag_type, {})
        
        return {
            "has_tag": True,
            "tag_type": tag_type,
            "tag_config": config,
            "confidence": confidence,
            "highlight_text": text,
            "timestamp": timestamp or datetime.utcnow().isoformat(),
            "original_text": text,
            "icon": config.get("icon", "📝"),
            "color": config.get("color", "#6c757d"),
            "label": config.get("label", tag_type.title())
        }
    
    def get_session_tags(self, session_id: str) -> List[Dict[str, Any]]:
        """Get all tags for a session (mock implementation)"""
        # In production, this would query a database
        # For now, return empty list as tags are stored client-side
        return []
    
    def save_session_tag(self, session_id: str, tag_data: Dict[str, Any]) -> bool:
        """Save a tag for a session (mock implementation)"""
        # In production, this would save to database
        logger.info(f"[ACTION_TAG] Session {session_id}: {tag_data['tag_type']} - {tag_data['highlight_text'][:50]}...")
        return True
    
    def get_tag_summary(self, tags: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary of tags by type"""
        summary = {
            "total_tags": len(tags),
            "by_type": {},
            "recent_tags": []
        }
        
        for tag in tags:
            tag_type = tag.get("tag_type")
            if tag_type:
                summary["by_type"][tag_type] = summary["by_type"].get(tag_type, 0) + 1
        
        # Get most recent 5 tags
        summary["recent_tags"] = sorted(tags, 
                                      key=lambda x: x.get("timestamp", ""), 
                                      reverse=True)[:5]
        
        return summary