"""
Export Service for Mina Pro
Handles transcript export in multiple formats with productivity insights
"""

import logging
from typing import Dict, Any, List
import json
import uuid
from datetime import datetime
import os

logger = logging.getLogger(__name__)

class ExportService:
    def __init__(self):
        self.export_cache = {}  # In-memory cache for shareable links
        logger.info("Export Service initialized")
    
    def generate_shareable_link(self, session_data: Dict[str, Any]) -> str:
        """
        Generate a shareable link for transcript session
        
        Args:
            session_data: Complete session data with transcripts and classifications
            
        Returns:
            Shareable URL ID
        """
        share_id = str(uuid.uuid4())
        
        # Cache the session data for public access
        self.export_cache[share_id] = {
            "session_data": session_data,
            "created_at": datetime.utcnow().isoformat(),
            "access_count": 0
        }
        
        logger.info(f"Generated shareable link: {share_id}")
        return share_id
    
    def get_shared_session(self, share_id: str) -> Dict[str, Any]:
        """
        Retrieve shared session data
        
        Args:
            share_id: Shareable URL ID
            
        Returns:
            Session data or None if not found
        """
        if share_id in self.export_cache:
            self.export_cache[share_id]["access_count"] += 1
            return self.export_cache[share_id]["session_data"]
        return None
    
    def export_as_markdown(self, session_data: Dict[str, Any]) -> str:
        """
        Export transcript as formatted Markdown
        
        Args:
            session_data: Session data with transcripts and classifications
            
        Returns:
            Markdown formatted transcript
        """
        transcript_chunks = session_data.get("transcript_chunks", [])
        classifications = session_data.get("classifications", [])
        meeting_mode = session_data.get("meeting_mode", "general")
        session_id = session_data.get("session_id", "unknown")
        
        # Header
        markdown = f"# Meeting Transcript\n\n"
        markdown += f"**Session ID:** {session_id}  \n"
        markdown += f"**Meeting Type:** {meeting_mode.title()}  \n"
        markdown += f"**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M')}  \n"
        markdown += f"**Total Chunks:** {len(transcript_chunks)}  \n\n"
        
        # Productivity Summary
        if classifications:
            actionable_count = sum(1 for c in classifications if c.get("actionable", False))
            markdown += f"## 📊 Productivity Summary\n\n"
            markdown += f"- **Total Segments:** {len(transcript_chunks)}\n"
            markdown += f"- **Actionable Items:** {actionable_count}\n"
            markdown += f"- **Productivity Score:** {round((actionable_count/max(len(transcript_chunks), 1))*100, 1)}%\n\n"
            
            # Category breakdown
            categories = {}
            for c in classifications:
                cat = c.get("classification", "neutral")
                categories[cat] = categories.get(cat, 0) + 1
            
            markdown += "### Category Breakdown\n"
            for category, count in categories.items():
                emoji = self._get_category_emoji(category)
                markdown += f"- {emoji} **{category.title()}:** {count}\n"
            markdown += "\n"
        
        # Transcript content
        markdown += "## 📝 Transcript\n\n"
        
        for i, chunk in enumerate(transcript_chunks):
            text = chunk.get("text", "")
            confidence = chunk.get("confidence", 0.0)
            duration = chunk.get("duration", 0.0)
            
            # Get classification if available
            classification = None
            if i < len(classifications):
                classification = classifications[i]
            
            # Format chunk
            markdown += f"### Chunk {i + 1}\n"
            if classification:
                category = classification.get("classification", "neutral")
                emoji = self._get_category_emoji(category)
                markdown += f"{emoji} **{category.title()}** | "
            
            markdown += f"Confidence: {confidence*100:.0f}% | Duration: {duration:.1f}s\n\n"
            markdown += f"> {text}\n\n"
            
            if classification and classification.get("reasoning"):
                markdown += f"*Classification reasoning: {classification['reasoning']}*\n\n"
        
        # Action Items Summary
        action_items = []
        for i, chunk in enumerate(transcript_chunks):
            if i < len(classifications):
                classification = classifications[i]
                if classification.get("classification") in ["task", "decision", "deadline", "follow-up"]:
                    action_items.append({
                        "text": chunk.get("text", ""),
                        "type": classification.get("classification"),
                        "chunk": i + 1
                    })
        
        if action_items:
            markdown += "## ✅ Action Items\n\n"
            for item in action_items:
                emoji = self._get_category_emoji(item["type"])
                markdown += f"- {emoji} **{item['type'].title()}** (Chunk {item['chunk']}): {item['text']}\n"
        
        markdown += f"\n---\n*Generated by Mina Pro on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*"
        
        return markdown
    
    def export_as_plain_text(self, session_data: Dict[str, Any]) -> str:
        """
        Export transcript as plain text
        
        Args:
            session_data: Session data with transcripts
            
        Returns:
            Plain text transcript
        """
        transcript_chunks = session_data.get("transcript_chunks", [])
        meeting_mode = session_data.get("meeting_mode", "general")
        session_id = session_data.get("session_id", "unknown")
        
        text = f"MEETING TRANSCRIPT\n"
        text += f"Session ID: {session_id}\n"
        text += f"Meeting Type: {meeting_mode.title()}\n"
        text += f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        text += f"Total Chunks: {len(transcript_chunks)}\n"
        text += "=" * 50 + "\n\n"
        
        for i, chunk in enumerate(transcript_chunks):
            chunk_text = chunk.get("text", "")
            confidence = chunk.get("confidence", 0.0)
            duration = chunk.get("duration", 0.0)
            
            text += f"[{i + 1:03d}] ({confidence*100:.0f}% | {duration:.1f}s) {chunk_text}\n"
        
        text += f"\n" + "=" * 50
        text += f"\nGenerated by Mina Pro on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return text
    
    def export_as_json(self, session_data: Dict[str, Any]) -> str:
        """
        Export complete session data as JSON
        
        Args:
            session_data: Complete session data
            
        Returns:
            JSON string
        """
        export_data = {
            "metadata": {
                "exported_at": datetime.utcnow().isoformat(),
                "session_id": session_data.get("session_id", "unknown"),
                "meeting_mode": session_data.get("meeting_mode", "general"),
                "total_chunks": len(session_data.get("transcript_chunks", []))
            },
            "transcript_chunks": session_data.get("transcript_chunks", []),
            "classifications": session_data.get("classifications", []),
            "productivity_metrics": self._calculate_productivity_metrics(session_data),
            "export_format": "mina_pro_v1"
        }
        
        return json.dumps(export_data, indent=2, ensure_ascii=False)
    
    def _get_category_emoji(self, category: str) -> str:
        """Get emoji for classification category"""
        emoji_map = {
            "task": "🟢",
            "decision": "🟣", 
            "deadline": "🔴",
            "follow-up": "🔵",
            "neutral": "⚪"
        }
        return emoji_map.get(category, "⚪")
    
    def _calculate_productivity_metrics(self, session_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate productivity metrics for session"""
        transcript_chunks = session_data.get("transcript_chunks", [])
        classifications = session_data.get("classifications", [])
        
        if not classifications:
            return {"productivity_score": 0, "total_actionable": 0, "category_distribution": {}}
        
        actionable_count = sum(1 for c in classifications if c.get("actionable", False))
        
        categories = {}
        for c in classifications:
            cat = c.get("classification", "neutral")
            categories[cat] = categories.get(cat, 0) + 1
        
        return {
            "productivity_score": round((actionable_count / max(len(transcript_chunks), 1)) * 100, 1),
            "total_actionable": actionable_count,
            "category_distribution": categories,
            "average_confidence": round(sum(chunk.get("confidence", 0) for chunk in transcript_chunks) / max(len(transcript_chunks), 1), 2)
        }

# Global export service instance
export_service = ExportService()