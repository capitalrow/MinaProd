"""
Whisper Streaming Service for Mina Pro
Implements sliding-window buffer with VAD-driven speech detection for real-time transcription
"""

import os
import time
import logging
import threading
from collections import deque
from typing import Dict, Any, List, Optional
import numpy as np

logger = logging.getLogger(__name__)

# Try to import whisper streaming
try:
    from whisper_streaming import WhisperStreamingTranscriber
    STREAMING_AVAILABLE = True
    logger.info("Whisper streaming available")
except ImportError:
    STREAMING_AVAILABLE = False
    logger.warning("Whisper streaming not available, using fallback")

# Fallback to regular whisper
try:
    import whisper
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

class SlidingWindowBuffer:
    """
    Manages sliding window buffer for continuous audio transcription
    """
    
    def __init__(self, window_size_seconds: float = 10.0, overlap_seconds: float = 2.0):
        self.window_size = window_size_seconds
        self.overlap = overlap_seconds
        self.audio_buffer = deque(maxlen=int(window_size_seconds * 16000))  # 16kHz samples
        self.timestamps = deque(maxlen=int(window_size_seconds * 16000))
        self.lock = threading.Lock()
        
    def add_audio(self, audio_data: np.ndarray, timestamp: float):
        """Add audio data to sliding window buffer"""
        with self.lock:
            # Add audio samples and their timestamps
            for i, sample in enumerate(audio_data):
                self.audio_buffer.append(sample)
                self.timestamps.append(timestamp + i / 16000.0)
    
    def get_window(self) -> tuple[np.ndarray, float, float]:
        """Get current window for transcription"""
        with self.lock:
            if len(self.audio_buffer) == 0:
                return np.array([]), 0.0, 0.0
            
            audio_array = np.array(list(self.audio_buffer))
            start_time = list(self.timestamps)[0] if self.timestamps else 0.0
            end_time = list(self.timestamps)[-1] if self.timestamps else 0.0
            
            return audio_array, start_time, end_time

class WhisperStreamingService:
    """
    Whisper streaming transcription service with sliding window buffer
    """
    
    def __init__(self, model_size: str = "base", chunk_length_s: int = 5, overlap_s: int = 2):
        self.chunk_length = chunk_length_s
        self.overlap = overlap_s
        self.buffer = SlidingWindowBuffer(window_size_seconds=chunk_length_s + overlap_s, overlap_seconds=overlap_s)
        
        # Initialize transcriber
        if STREAMING_AVAILABLE:
            try:
                self.transcriber = WhisperStreamingTranscriber(model_size)
                logger.info(f"Whisper streaming transcriber initialized with model: {model_size}")
            except Exception as e:
                logger.warning(f"Streaming transcriber failed to initialize: {e}")
                self.transcriber = None
                STREAMING_AVAILABLE = False
        else:
            self.transcriber = None
            
        # Fallback to regular whisper if streaming not available
        if not STREAMING_AVAILABLE and WHISPER_AVAILABLE:
            try:
                import whisper
                self.whisper_model = whisper.load_model(model_size)
                logger.info(f"Fallback Whisper model loaded: {model_size}")
            except Exception as e:
                logger.warning(f"Fallback Whisper model failed to load: {e}")
                self.whisper_model = None
        else:
            self.whisper_model = None
    
    def is_available(self) -> bool:
        """Check if any transcription method is available"""
        return (STREAMING_AVAILABLE and self.transcriber is not None) or \
               (WHISPER_AVAILABLE and self.whisper_model is not None)
    
    def transcribe_streaming(self, audio_data: np.ndarray, timestamp: float = None) -> Dict[str, Any]:
        """
        Transcribe audio data using streaming or fallback method
        """
        if timestamp is None:
            timestamp = time.time()
            
        # Add audio to buffer
        self.buffer.add_audio(audio_data, timestamp)
        
        # Get current window for transcription
        window_audio, start_time, end_time = self.buffer.get_window()
        
        if len(window_audio) == 0:
            return {"text": "", "confidence": 0.0, "timestamp": timestamp}
        
        try:
            if STREAMING_AVAILABLE and self.transcriber:
                # Use streaming transcriber
                result = self.transcriber.transcribe(window_audio)
                return {
                    "text": result.get("text", ""),
                    "confidence": result.get("confidence", 0.0),
                    "timestamp": timestamp,
                    "method": "streaming"
                }
            elif WHISPER_AVAILABLE and self.whisper_model:
                # Use fallback whisper
                result = self.whisper_model.transcribe(window_audio)
                return {
                    "text": result.get("text", ""),
                    "confidence": 0.5,  # Default confidence for regular whisper
                    "timestamp": timestamp,
                    "method": "whisper_fallback"
                }
            else:
                # No transcription available
                logger.warning("No transcription method available")
                return {"text": "", "confidence": 0.0, "timestamp": timestamp, "method": "none"}
                
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            return {"text": "", "confidence": 0.0, "timestamp": timestamp, "error": str(e)}

# Export streaming service instance
streaming_service = WhisperStreamingService()

# Convenience functions for external use
def transcribe_audio_stream(audio_data: np.ndarray, timestamp: float = None) -> Dict[str, Any]:
    """Main function for streaming audio transcription"""
    return streaming_service.transcribe_streaming(audio_data, timestamp)

def is_streaming_available() -> bool:
    """Check if streaming transcription is available"""
    return streaming_service.is_available()
                audio_window, start_time, end_time = self.buffer.get_window()
                
                if len(audio_window) < 16000:  # Less than 1 second
                    return {
                        "text": "",
                        "confidence": 0.0,
                        "start_time": start_time,
                        "end_time": end_time,
                        "processing_time": 0.0,
                        "mode": self.mode
                    }
                
                start_processing = time.time()
                
                if self.mode == "streaming" and self.transcriber:
                    # Use streaming transcriber
                    result = self.transcriber.transcribe(audio_window)
                    text = result.get("text", "").strip()
                    confidence = result.get("confidence", 0.8)
                    
                elif self.whisper_model:
                    # Use regular whisper as fallback
                    result = self.whisper_model.transcribe(audio_window, language="en", fp16=False)
                    text = result.get("text", "").strip()
                    
                    # Calculate confidence from segments
                    segments = result.get("segments", [])
                    if segments:
                        confidences = [seg.get("avg_logprob", 0.0) for seg in segments]
                        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
                        confidence = max(0.0, min(1.0, (avg_confidence + 5) / 5))
                    else:
                        confidence = 0.5
                        
                else:
                    # No transcription available
                    return {
                        "text": "",
                        "confidence": 0.0,
                        "start_time": start_time,
                        "end_time": end_time,
                        "processing_time": 0.0,
                        "mode": "none",
                        "error": "No transcription model available"
                    }
                
                processing_time = time.time() - start_processing
                
                # Remove duplicate content from previous transcript
                if text and self.last_transcript:
                    # Simple overlap detection and removal
                    if text.startswith(self.last_transcript[-50:]):  # Check last 50 chars
                        text = text[len(self.last_transcript[-50:]):].strip()
                
                if text:
                    self.last_transcript = text
                
                return {
                    "text": text,
                    "confidence": confidence,
                    "start_time": start_time,
                    "end_time": end_time,
                    "processing_time": processing_time,
                    "mode": self.mode,
                    "window_length": len(audio_window) / 16000.0
                }
                
            except Exception as e:
                logger.error(f"Window processing failed: {e}")
                return {
                    "text": "",
                    "confidence": 0.0,
                    "start_time": 0.0,
                    "end_time": 0.0,
                    "processing_time": 0.0,
                    "mode": self.mode,
                    "error": str(e)
                }

# Global streaming service instance
streaming_service = None

def get_streaming_service() -> WhisperStreamingService:
    """Get or create global streaming service instance"""
    global streaming_service
    if streaming_service is None:
        streaming_service = WhisperStreamingService()
    return streaming_service

def transcribe_with_streaming(audio_data: np.ndarray, timestamp: float = None) -> Dict[str, Any]:
    """
    Transcribe audio using streaming service
    
    Args:
        audio_data: Audio data as numpy array (16kHz)
        timestamp: Timestamp for the audio chunk
        
    Returns:
        Transcription result
    """
    if timestamp is None:
        timestamp = time.time()
    
    service = get_streaming_service()
    service.add_audio_chunk(audio_data, timestamp)
    return service.process_window()