"""
Task Extraction Service
AI-powered extraction of action items, tasks, and decisions from meeting transcripts
"""

import logging
import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import openai
import json

logger = logging.getLogger(__name__)

@dataclass
class TaskItem:
    """Represents an extracted task or action item"""
    id: str
    text: str
    assignee: Optional[str] = None
    deadline: Optional[datetime] = None
    priority: str = "medium"  # low, medium, high, critical
    impact_score: float = 0.5  # 0.0 to 1.0
    category: str = "action"  # action, decision, question, follow_up
    confidence: float = 0.0
    source_segment: str = ""
    tags: List[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []

class TaskExtractionService:
    """Advanced AI service for extracting actionable tasks from meeting transcripts"""
    
    def __init__(self):
        self.client = openai.OpenAI()
        self.task_indicators = [
            r"\b(?:need to|needs to|should|must|will|gonna|going to)\b",
            r"\b(?:action item|todo|task|follow up|follow-up)\b",
            r"\b(?:assign|assigned|responsible for|in charge of)\b",
            r"\b(?:deadline|due|by|before|schedule)\b",
            r"\b(?:decision|decide|resolved|agreed)\b"
        ]
        
        self.priority_keywords = {
            "critical": ["urgent", "asap", "immediately", "critical", "emergency"],
            "high": ["important", "priority", "soon", "quickly", "high"],
            "medium": ["should", "need", "plan", "schedule"],
            "low": ["consider", "think about", "eventually", "when possible"]
        }
        
        self.impact_keywords = {
            "high_impact": ["revenue", "customer", "launch", "deadline", "critical path", "blocker"],
            "medium_impact": ["improvement", "optimization", "feature", "update"],
            "low_impact": ["documentation", "cleanup", "minor", "nice to have"]
        }

    def extract_tasks_from_transcript(self, transcript: str, session_metadata: Dict = None) -> List[TaskItem]:
        """Main method to extract tasks from meeting transcript"""
        try:
            logger.info(f"[TASK-EXTRACTION] Processing transcript of {len(transcript)} characters")
            
            # Step 1: AI-powered task identification
            ai_tasks = self._extract_with_ai(transcript)
            
            # Step 2: Rule-based task detection (backup/enhancement)
            rule_tasks = self._extract_with_rules(transcript)
            
            # Step 3: Combine and deduplicate
            combined_tasks = self._combine_and_deduplicate(ai_tasks, rule_tasks)
            
            # Step 4: Enhance with context and scoring
            enhanced_tasks = self._enhance_tasks(combined_tasks, transcript, session_metadata)
            
            logger.info(f"[TASK-EXTRACTION] Extracted {len(enhanced_tasks)} tasks")
            return enhanced_tasks
            
        except Exception as e:
            logger.error(f"[TASK-EXTRACTION] Error extracting tasks: {e}")
            return []

    def _extract_with_ai(self, transcript: str) -> List[TaskItem]:
        """Use GPT-4 to identify tasks and action items"""
        try:
            system_prompt = """
            You are an AI meeting assistant specialized in extracting actionable tasks and decisions from meeting transcripts.
            
            Analyze the transcript and identify:
            1. Action items (tasks someone needs to complete)
            2. Decisions made during the meeting
            3. Follow-up items and next steps
            4. Questions that need answers
            
            For each item, extract:
            - The specific task/action/decision
            - Who is responsible (if mentioned)
            - Any deadlines or timeframes mentioned
            - Priority level based on context
            - Category (action, decision, question, follow_up)
            
            Respond with valid JSON array of objects with these fields:
            - text: The task description
            - assignee: Person responsible (or null)
            - deadline: Date string if mentioned (or null)  
            - priority: "low", "medium", "high", or "critical"
            - category: "action", "decision", "question", or "follow_up"
            - confidence: 0.0 to 1.0 confidence score
            - source_segment: The original text segment
            """
            
            user_prompt = f"""
            Meeting Transcript:
            {transcript[:4000]}  # Limit to avoid token limits
            
            Extract all actionable tasks, decisions, and follow-up items as JSON array.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                max_tokens=1500
            )
            
            ai_response = response.choices[0].message.content
            logger.debug(f"[TASK-EXTRACTION] AI response: {ai_response[:500]}...")
            
            # Parse JSON response
            try:
                tasks_data = json.loads(ai_response)
                tasks = []
                
                for i, task_data in enumerate(tasks_data):
                    task = TaskItem(
                        id=f"ai_{i}_{datetime.now().timestamp()}",
                        text=task_data.get("text", ""),
                        assignee=task_data.get("assignee"),
                        deadline=self._parse_deadline(task_data.get("deadline")),
                        priority=task_data.get("priority", "medium"),
                        impact_score=self._calculate_impact_score(task_data.get("text", "")),
                        category=task_data.get("category", "action"),
                        confidence=task_data.get("confidence", 0.8),
                        source_segment=task_data.get("source_segment", "")
                    )
                    tasks.append(task)
                
                return tasks
                
            except json.JSONDecodeError as e:
                logger.error(f"[TASK-EXTRACTION] Failed to parse AI JSON: {e}")
                return []
                
        except Exception as e:
            logger.error(f"[TASK-EXTRACTION] AI extraction failed: {e}")
            return []

    def _extract_with_rules(self, transcript: str) -> List[TaskItem]:
        """Rule-based task extraction as backup/enhancement"""
        tasks = []
        sentences = self._split_into_sentences(transcript)
        
        for i, sentence in enumerate(sentences):
            # Check for task indicators
            task_score = 0
            for pattern in self.task_indicators:
                if re.search(pattern, sentence, re.IGNORECASE):
                    task_score += 1
            
            if task_score > 0:
                task = TaskItem(
                    id=f"rule_{i}_{datetime.now().timestamp()}",
                    text=sentence.strip(),
                    priority=self._determine_priority(sentence),
                    impact_score=self._calculate_impact_score(sentence),
                    category=self._determine_category(sentence),
                    confidence=min(0.7, task_score * 0.3),
                    source_segment=sentence
                )
                
                # Try to extract assignee
                assignee = self._extract_assignee(sentence)
                if assignee:
                    task.assignee = assignee
                
                # Try to extract deadline
                deadline = self._extract_deadline(sentence)
                if deadline:
                    task.deadline = deadline
                    
                tasks.append(task)
        
        return tasks

    def _combine_and_deduplicate(self, ai_tasks: List[TaskItem], rule_tasks: List[TaskItem]) -> List[TaskItem]:
        """Combine AI and rule-based results, removing duplicates"""
        combined = []
        seen_texts = set()
        
        # Prioritize AI tasks (higher quality)
        for task in ai_tasks:
            text_key = task.text.lower().strip()[:50]  # First 50 chars for similarity
            if text_key not in seen_texts:
                combined.append(task)
                seen_texts.add(text_key)
        
        # Add unique rule-based tasks
        for task in rule_tasks:
            text_key = task.text.lower().strip()[:50]
            if text_key not in seen_texts:
                combined.append(task)
                seen_texts.add(text_key)
        
        return combined

    def _enhance_tasks(self, tasks: List[TaskItem], transcript: str, metadata: Dict = None) -> List[TaskItem]:
        """Enhance tasks with additional context and scoring"""
        enhanced = []
        
        for task in tasks:
            # Enhance impact scoring
            task.impact_score = max(task.impact_score, self._calculate_impact_score(task.text))
            
            # Add contextual tags
            task.tags = self._generate_tags(task.text)
            
            # Enhance priority based on keywords
            enhanced_priority = self._determine_priority(task.text)
            if enhanced_priority != "medium":  # Don't override if we have specific info
                task.priority = enhanced_priority
            
            # Validate and clean
            if len(task.text.strip()) > 10 and task.confidence > 0.3:
                enhanced.append(task)
        
        return sorted(enhanced, key=lambda t: t.impact_score, reverse=True)

    def _calculate_impact_score(self, text: str) -> float:
        """Calculate impact score based on keywords and context"""
        text_lower = text.lower()
        score = 0.5  # Base score
        
        # High impact indicators
        for keyword in self.impact_keywords["high_impact"]:
            if keyword in text_lower:
                score += 0.2
        
        # Medium impact indicators  
        for keyword in self.impact_keywords["medium_impact"]:
            if keyword in text_lower:
                score += 0.1
                
        # Low impact indicators
        for keyword in self.impact_keywords["low_impact"]:
            if keyword in text_lower:
                score -= 0.1
        
        return max(0.1, min(1.0, score))

    def _determine_priority(self, text: str) -> str:
        """Determine priority based on keywords"""
        text_lower = text.lower()
        
        for priority, keywords in self.priority_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    return priority
        
        return "medium"

    def _determine_category(self, text: str) -> str:
        """Determine task category based on content"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ["decided", "decision", "agreed", "resolved"]):
            return "decision"
        elif any(word in text_lower for word in ["question", "clarify", "confirm", "check"]):
            return "question"
        elif any(word in text_lower for word in ["follow up", "next", "continue", "review"]):
            return "follow_up"
        else:
            return "action"

    def _extract_assignee(self, text: str) -> Optional[str]:
        """Extract assignee from sentence"""
        # Simple patterns for now - can be enhanced with NER
        patterns = [
            r"(\w+)\s+(?:will|should|needs to|gonna)",
            r"assign(?:ed)?\s+to\s+(\w+)",
            r"(\w+)\s+is\s+responsible",
            r"(\w+)\s+take(?:s)?\s+care"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).title()
        
        return None

    def _extract_deadline(self, text: str) -> Optional[datetime]:
        """Extract deadline from sentence"""
        # Simple deadline extraction - can be enhanced
        now = datetime.now()
        
        if re.search(r"\btoday\b", text, re.IGNORECASE):
            return now
        elif re.search(r"\btomorrow\b", text, re.IGNORECASE):
            return now + timedelta(days=1)
        elif re.search(r"\bnext week\b", text, re.IGNORECASE):
            return now + timedelta(weeks=1)
        elif re.search(r"\bend of week\b", text, re.IGNORECASE):
            days_until_friday = (4 - now.weekday()) % 7
            return now + timedelta(days=days_until_friday)
        
        return None

    def _parse_deadline(self, deadline_str: str) -> Optional[datetime]:
        """Parse deadline string to datetime"""
        if not deadline_str:
            return None
        
        # Add parsing logic for various date formats
        # For now, simple implementation
        return None

    def _generate_tags(self, text: str) -> List[str]:
        """Generate relevant tags for the task"""
        tags = []
        text_lower = text.lower()
        
        # Category tags
        if any(word in text_lower for word in ["meeting", "call", "sync"]):
            tags.append("meeting")
        if any(word in text_lower for word in ["document", "doc", "write", "draft"]):
            tags.append("documentation")
        if any(word in text_lower for word in ["code", "develop", "implement", "build"]):
            tags.append("development")
        if any(word in text_lower for word in ["test", "verify", "validate", "check"]):
            tags.append("testing")
        if any(word in text_lower for word in ["review", "feedback", "approve"]):
            tags.append("review")
        
        return tags

    def _split_into_sentences(self, text: str) -> List[str]:
        """Split text into sentences"""
        # Simple sentence splitting - can be enhanced with NLTK
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if len(s.strip()) > 10]

# Global service instance
task_extraction_service = TaskExtractionService()