#!/usr/bin/env python3
"""
OpenAI API Optimization Service
High-performance OpenAI client with connection pooling and timeout handling
"""

import time
import logging
from openai import OpenAI
import httpx
from typing import Optional, Dict, Any
import os

logger = logging.getLogger(__name__)

class OptimizedOpenAIClient:
    """Optimized OpenAI client with connection pooling and timeout management"""
    
    def __init__(self):
        self.api_key = os.environ.get('OPENAI_API_KEY')
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")
        
        # Create optimized HTTP client with connection pooling
        self.http_client = httpx.Client(
            timeout=httpx.Timeout(30.0, read=25.0, write=10.0, connect=5.0),
            limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
            http2=True  # Use HTTP/2 for better performance
        )
        
        # Initialize OpenAI client with optimized HTTP client
        self.client = OpenAI(
            api_key=self.api_key,
            http_client=self.http_client
        )
        
        # Performance tracking
        self.request_count = 0
        self.total_processing_time = 0
        self.error_count = 0
        
        logger.info("🚀 Optimized OpenAI client initialized with connection pooling")
    
    def transcribe_audio(self, audio_file_path: str, **kwargs) -> Dict[str, Any]:
        """
        Optimized audio transcription with timeout and error handling
        
        Args:
            audio_file_path: Path to audio file
            **kwargs: Additional parameters for transcription
            
        Returns:
            Dict containing transcription results and metadata
        """
        
        start_time = time.time()
        self.request_count += 1
        
        try:
            with open(audio_file_path, 'rb') as audio_file:
                # Default parameters optimized for performance
                params = {
                    'model': 'whisper-1',
                    'file': audio_file,
                    'response_format': 'verbose_json',
                    'language': 'en',
                    **kwargs  # Allow override of defaults
                }
                
                logger.info(f"🎯 Starting OpenAI transcription (request #{self.request_count})")
                
                # Make the API call with optimized client
                transcription = self.client.audio.transcriptions.create(**params)
                
                processing_time = time.time() - start_time
                self.total_processing_time += processing_time
                
                logger.info(f"✅ OpenAI transcription completed in {processing_time:.2f}s")
                
                return {
                    'transcription': transcription,
                    'processing_time': processing_time,
                    'request_id': self.request_count,
                    'success': True
                }
                
        except Exception as e:
            self.error_count += 1
            processing_time = time.time() - start_time
            
            logger.error(f"❌ OpenAI transcription failed after {processing_time:.2f}s: {e}")
            
            return {
                'transcription': None,
                'processing_time': processing_time,
                'request_id': self.request_count,
                'success': False,
                'error': str(e),
                'error_type': type(e).__name__
            }
    
    def get_performance_stats(self) -> Dict[str, float]:
        """Get performance statistics for monitoring"""
        
        avg_processing_time = (
            self.total_processing_time / max(1, self.request_count - self.error_count)
        )
        error_rate = self.error_count / max(1, self.request_count)
        
        return {
            'total_requests': self.request_count,
            'successful_requests': self.request_count - self.error_count,
            'error_count': self.error_count,
            'error_rate': error_rate,
            'average_processing_time': avg_processing_time,
            'total_processing_time': self.total_processing_time
        }
    
    def close(self):
        """Close HTTP client connections"""
        if hasattr(self, 'http_client'):
            self.http_client.close()
            logger.info("🔌 OpenAI HTTP client connections closed")

# Global optimized client instance
_optimized_client: Optional[OptimizedOpenAIClient] = None

def get_optimized_client() -> OptimizedOpenAIClient:
    """Get or create the global optimized OpenAI client"""
    global _optimized_client
    
    if _optimized_client is None:
        _optimized_client = OptimizedOpenAIClient()
    
    return _optimized_client

def transcribe_with_optimization(audio_file_path: str, **kwargs) -> Dict[str, Any]:
    """
    Convenient function for optimized transcription
    
    Args:
        audio_file_path: Path to audio file
        **kwargs: Additional transcription parameters
        
    Returns:
        Dict with transcription results and performance data
    """
    
    client = get_optimized_client()
    return client.transcribe_audio(audio_file_path, **kwargs)

def get_performance_metrics() -> Dict[str, float]:
    """Get current performance metrics"""
    
    if _optimized_client:
        return _optimized_client.get_performance_stats()
    
    return {
        'total_requests': 0,
        'successful_requests': 0,
        'error_count': 0,
        'error_rate': 0.0,
        'average_processing_time': 0.0,
        'total_processing_time': 0.0
    }