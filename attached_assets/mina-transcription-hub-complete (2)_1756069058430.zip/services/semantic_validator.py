"""
Semantic Validator for Hallucination Prevention
Implements content analysis and conversational context validation
"""

import logging
import re
from typing import Dict, Any, List, Optional, Tuple
import time

logger = logging.getLogger(__name__)

class SemanticValidator:
    """
    ENTERPRISE ENHANCEMENT 2: Advanced hallucination prevention
    Validates transcript content against conversational patterns
    """
    
    def __init__(self):
        # Common hallucination patterns observed in live testing
        self.hallucination_patterns = {
            'philosophical': [
                r'\b(paradise|earth|spirit|soul|suffering|corruption)\b',
                r'\b(adversarial|personality|vulnerability|community)\b',
                r'\b(honest|human|continually|fail|managed)\b',
                r'\b(matrix|processing|times|consistently)\b'
            ],
            'religious': [
                r'\b(god|divine|prayer|blessing|sacred|holy)\b',
                r'\b(heaven|hell|angels|demons|salvation)\b'
            ],
            'abstract_concepts': [
                r'\b(existence|reality|consciousness|enlightenment)\b',
                r'\b(transcendence|meditation|spiritual|mystical)\b'
            ],
            'technical_jargon': [
                r'\b(algorithm|matrix|processing|optimization)\b',
                r'\b(variable|chunk|sizes|times|consistently)\b'
            ]
        }
        
        # Normal conversational patterns
        self.conversational_patterns = [
            r'\b(hello|hi|how|are|you|thanks|please|yes|no|okay|sure)\b',
            r'\b(can|could|would|should|will|going|want|need|like)\b',
            r'\b(what|when|where|why|how|who|which)\b',
            r'\b(today|tomorrow|yesterday|now|later|soon)\b',
            r'\b(good|bad|great|fine|nice|well|better|best)\b'
        ]
        
        # Language-specific validation
        self.language_validators = {
            'russian': self._validate_russian_content,
            'english': self._validate_english_content,
            'mixed': self._validate_mixed_content
        }
        
        # Context tracking
        self.recent_topics = []
        self.conversation_context = []
        self.hallucination_count = 0
        
        logger.info("[SEMANTIC-VALIDATOR] Advanced hallucination prevention initialized")
    
    def validate_transcript(self, text: str, confidence: float, language: str = 'english') -> Tuple[bool, str, float]:
        """
        CORE VALIDATION: Determine if transcript is likely authentic speech
        
        Args:
            text: Transcribed text to validate
            confidence: Original confidence score
            language: Detected language
            
        Returns:
            (is_valid, reason, adjusted_confidence)
        """
        if not text.strip():
            return False, "empty_text", 0.0
        
        text_lower = text.lower().strip()
        
        # Check for single word fragments (often hallucinations)
        if len(text.split()) == 1:
            if text_lower in ['you', 'the', 'and', 'or', 'also', 'but']:
                return False, "single_word_fragment", confidence * 0.3
        
        # Check for hallucination patterns
        hallucination_score = self._calculate_hallucination_score(text_lower)
        if hallucination_score > 0.6:
            self.hallucination_count += 1
            return False, f"hallucination_detected_score_{hallucination_score:.2f}", confidence * 0.2
        
        # Validate language-specific patterns
        validator = self.language_validators.get(language, self._validate_english_content)
        is_valid, reason = validator(text_lower)
        
        if not is_valid:
            return False, reason, confidence * 0.4
        
        # Context consistency check
        context_score = self._check_context_consistency(text_lower)
        adjusted_confidence = confidence * context_score
        
        # Update conversation context
        self._update_context(text_lower, language)
        
        return True, "valid_speech", adjusted_confidence
    
    def _calculate_hallucination_score(self, text: str) -> float:
        """Calculate likelihood of hallucination based on content patterns"""
        total_score = 0.0
        total_patterns = 0
        
        for category, patterns in self.hallucination_patterns.items():
            category_matches = 0
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    category_matches += 1
            
            if category_matches > 0:
                # Weight different categories
                if category == 'philosophical':
                    total_score += category_matches * 0.8
                elif category == 'technical_jargon':
                    total_score += category_matches * 0.6
                else:
                    total_score += category_matches * 0.7
                
                total_patterns += len(patterns)
        
        if total_patterns == 0:
            return 0.0
        
        # Normalize score
        return min(total_score / 5.0, 1.0)
    
    def _validate_english_content(self, text: str) -> Tuple[bool, str]:
        """Validate English conversational content"""
        # Check for natural conversational patterns
        conversational_matches = sum(1 for pattern in self.conversational_patterns 
                                   if re.search(pattern, text, re.IGNORECASE))
        
        word_count = len(text.split())
        
        # Natural speech indicators
        if conversational_matches > 0:
            return True, "conversational_english"
        
        # Short phrases are often fragments or hallucinations
        if word_count <= 2:
            return False, "too_short_english"
        
        # Check for proper sentence structure
        if word_count >= 3 and any(char in text for char in '.!?'):
            return True, "structured_english"
        
        # Medium-length phrases without obvious hallucination patterns
        if word_count <= 6 and self._calculate_hallucination_score(text) < 0.3:
            return True, "medium_phrase_english"
        
        return False, "suspicious_english_pattern"
    
    def _validate_russian_content(self, text: str) -> Tuple[bool, str]:
        """Validate Russian conversational content"""
        # Russian language patterns
        russian_chars = re.findall(r'[а-яё]', text, re.IGNORECASE)
        
        if len(russian_chars) < len(text.replace(' ', '')) * 0.7:
            return False, "insufficient_russian_chars"
        
        # Common Russian words/phrases
        russian_common = [r'\b(да|нет|как|что|где|когда|почему|хорошо|плохо|можно|нужно|идти|делать)\b']
        
        for pattern in russian_common:
            if re.search(pattern, text, re.IGNORECASE):
                return True, "conversational_russian"
        
        return True, "assumed_valid_russian"
    
    def _validate_mixed_content(self, text: str) -> Tuple[bool, str]:
        """Validate mixed-language content"""
        # For mixed content, apply more lenient validation
        english_valid, _ = self._validate_english_content(text)
        russian_valid, _ = self._validate_russian_content(text)
        
        if english_valid or russian_valid:
            return True, "valid_mixed_language"
        
        return False, "invalid_mixed_content"
    
    def _check_context_consistency(self, text: str) -> float:
        """Check if transcript fits conversation context"""
        if not self.conversation_context:
            return 1.0  # No context to compare against
        
        # Simple topic consistency check
        recent_words = set()
        for context_item in self.conversation_context[-3:]:  # Last 3 items
            recent_words.update(context_item.split())
        
        current_words = set(text.split())
        
        # Check for topic overlap
        overlap = len(current_words.intersection(recent_words))
        total_words = len(current_words)
        
        if total_words == 0:
            return 0.5
        
        # Higher overlap suggests context consistency
        consistency_score = min((overlap + 1) / (total_words + 1), 1.0)
        
        # Adjust based on recent hallucination frequency
        if self.hallucination_count > 3:  # Recent hallucination streak
            consistency_score *= 0.8
        
        return max(consistency_score, 0.3)  # Minimum score
    
    def _update_context(self, text: str, language: str):
        """Update conversation context tracking"""
        self.conversation_context.append(text)
        
        # Keep rolling window of recent context
        if len(self.conversation_context) > 10:
            self.conversation_context.pop(0)
        
        # Reset hallucination count periodically
        if len(self.conversation_context) % 5 == 0:
            self.hallucination_count = max(0, self.hallucination_count - 1)
    
    def get_validation_stats(self) -> Dict[str, Any]:
        """Get current validation statistics"""
        return {
            'conversation_length': len(self.conversation_context),
            'recent_hallucination_count': self.hallucination_count,
            'context_topics': len(self.recent_topics)
        }