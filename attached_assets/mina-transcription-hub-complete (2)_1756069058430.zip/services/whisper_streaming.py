"""
Whisper Streaming Service for Mina Pro
Implements sliding-window buffer with VAD-driven speech detection for real-time transcription
"""

import os
import time
import logging
import threading
from collections import deque
from typing import Dict, Any, List, Optional
import numpy as np

logger = logging.getLogger(__name__)

# Try to import whisper streaming
STREAMING_AVAILABLE = False
try:
    from whisper_streaming import WhisperStreamingTranscriber
    STREAMING_AVAILABLE = True
    logger.info("Whisper streaming available")
except ImportError:
    STREAMING_AVAILABLE = False
    logger.warning("Whisper streaming not available, using fallback")

# Fallback to regular whisper
WHISPER_AVAILABLE = False
try:
    import whisper
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

class SlidingWindowBuffer:
    """
    Manages sliding window buffer for continuous audio transcription
    """
    
    def __init__(self, window_size_seconds: float = 10.0, overlap_seconds: float = 2.0):
        self.window_size = window_size_seconds
        self.overlap = overlap_seconds
        self.audio_buffer = deque(maxlen=int(window_size_seconds * 16000))  # 16kHz samples
        self.timestamps = deque(maxlen=int(window_size_seconds * 16000))
        self.lock = threading.Lock()
        
    def add_audio(self, audio_data: np.ndarray, timestamp: float):
        """Add audio data to sliding window buffer"""
        with self.lock:
            # Add audio samples and their timestamps
            for i, sample in enumerate(audio_data):
                self.audio_buffer.append(sample)
                self.timestamps.append(timestamp + i / 16000.0)
    
    def get_window(self) -> tuple[np.ndarray, float, float]:
        """Get current window for transcription"""
        with self.lock:
            if len(self.audio_buffer) == 0:
                return np.array([]), 0.0, 0.0
            
            audio_array = np.array(list(self.audio_buffer))
            start_time = list(self.timestamps)[0] if self.timestamps else 0.0
            end_time = list(self.timestamps)[-1] if self.timestamps else 0.0
            
            return audio_array, start_time, end_time

class WhisperStreamingService:
    """
    Whisper streaming transcription service with sliding window buffer
    """
    
    def __init__(self, model_size: str = "base", chunk_length_s: int = 5, overlap_s: int = 2):
        self.chunk_length = chunk_length_s
        self.overlap = overlap_s
        self.buffer = SlidingWindowBuffer(window_size_seconds=chunk_length_s + overlap_s, overlap_seconds=overlap_s)
        
        # Initialize transcriber
        self.transcriber = None
        self.whisper_model = None
        
        if STREAMING_AVAILABLE:
            try:
                self.transcriber = WhisperStreamingTranscriber(model_size)
                logger.info(f"Whisper streaming transcriber initialized with model: {model_size}")
            except Exception as e:
                logger.warning(f"Streaming transcriber failed to initialize: {e}")
                self.transcriber = None
                
        # Fallback to regular whisper if streaming not available
        if not self.transcriber and WHISPER_AVAILABLE:
            try:
                import whisper
                self.whisper_model = whisper.load_model(model_size)
                logger.info(f"Fallback Whisper model loaded: {model_size}")
            except Exception as e:
                logger.warning(f"Fallback Whisper model failed to load: {e}")
                self.whisper_model = None
    
    def is_available(self) -> bool:
        """Check if any transcription method is available"""
        return (self.transcriber is not None) or (self.whisper_model is not None)
    
    def transcribe_streaming(self, audio_data: np.ndarray, timestamp: float = None) -> Dict[str, Any]:
        """
        Transcribe audio data using streaming or fallback method
        """
        if timestamp is None:
            timestamp = time.time()
            
        # Add audio to buffer
        self.buffer.add_audio(audio_data, timestamp)
        
        # Get current window for transcription
        window_audio, start_time, end_time = self.buffer.get_window()
        
        if len(window_audio) == 0:
            return {"text": "", "confidence": 0.0, "timestamp": timestamp}
        
        try:
            if self.transcriber:
                # Use streaming transcriber
                result = self.transcriber.transcribe(window_audio)
                return {
                    "text": result.get("text", ""),
                    "confidence": result.get("confidence", 0.0),
                    "timestamp": timestamp,
                    "method": "streaming"
                }
            elif self.whisper_model:
                # Use fallback whisper
                result = self.whisper_model.transcribe(window_audio)
                return {
                    "text": result.get("text", ""),
                    "confidence": 0.5,  # Default confidence for regular whisper
                    "timestamp": timestamp,
                    "method": "whisper_fallback"
                }
            else:
                # No transcription available
                logger.warning("No transcription method available")
                return {"text": "", "confidence": 0.0, "timestamp": timestamp, "method": "none"}
                
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            return {"text": "", "confidence": 0.0, "timestamp": timestamp, "error": str(e)}

# Export streaming service instance
streaming_service = WhisperStreamingService()

# Convenience functions for external use
def transcribe_audio_stream(audio_data: np.ndarray, timestamp: float = None) -> Dict[str, Any]:
    """Main function for streaming audio transcription"""
    return streaming_service.transcribe_streaming(audio_data, timestamp)

def is_streaming_available() -> bool:
    """Check if streaming transcription is available"""
    return streaming_service.is_available()

def get_streaming_service():
    """
    Get the streaming service instance for external use
    """
    return streaming_service

def transcribe_with_streaming(audio_data, session_id=None, chunk_id=None):
    """
    Legacy function for compatibility with buffered_transcription routes
    """
    try:
        if isinstance(audio_data, (str, bytes)):
            # Convert to numpy array if needed
            import numpy as np
            if isinstance(audio_data, str):
                # If it's a file path, read the file
                with open(audio_data, 'rb') as f:
                    audio_bytes = f.read()
            else:
                audio_bytes = audio_data
            
            # Convert bytes to numpy array (simplified for demo)
            audio_array = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        else:
            audio_array = audio_data
            
        result = streaming_service.transcribe_streaming(audio_array)
        
        return {
            "status": "success",
            "text": result.get("text", ""),
            "confidence": result.get("confidence", 0.0),
            "method": result.get("method", "fallback"),
            "chunk_id": chunk_id,
            "session_id": session_id
        }
        
    except Exception as e:
        logger.error(f"Streaming transcription failed: {e}")
        return {
            "status": "error", 
            "message": str(e),
            "text": "",
            "confidence": 0.0,
            "chunk_id": chunk_id,
            "session_id": session_id
        }