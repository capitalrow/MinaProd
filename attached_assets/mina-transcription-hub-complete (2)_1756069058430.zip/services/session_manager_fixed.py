"""
Fixed Session Management Service for comprehensive session persistence
"""
import json
import logging
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

class SessionManager:
    @staticmethod
    def create_session(user_id, title=None):
        """Create new transcription session"""
        try:
            from models import TranscriptSession
            from app import db
            
            if not title:
                title = f"Recording {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            
            session = TranscriptSession(
                user_id=user_id,
                title=title,
                created_at=datetime.utcnow(),
                word_count=0,
                confidence=0.0,
                transcript=""
            )
            
            db.session.add(session)
            db.session.commit()
            
            logger.info(f"✅ Session created: {session.id}")
            return session.id
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session creation failed: {e}")
            from app import db
            try:
                db.session.rollback()
            except:
                pass
            return None
        except Exception as e:
            logger.error(f"❌ Session creation error: {e}")
            return None
    
    @staticmethod
    def save_chunk(session_id, chunk_data):
        """Save transcription chunk to session"""
        try:
            from models import TranscriptSession
            from app import db
            
            # Just log chunk data for now
            logger.info(f"✅ Chunk data received for session {session_id}: {chunk_data.get('text', '')[:50]}...")
            
            # Update session with basic stats
            session = TranscriptSession.query.get(session_id)
            if session:
                new_text = chunk_data.get('text', '')
                if new_text:
                    # Append new text to existing transcript
                    current_transcript = session.transcript or ""
                    session.transcript = current_transcript + " " + new_text
                    session.word_count = len(session.transcript.split())
                    session.confidence = chunk_data.get('confidence', 0.0)
            
            db.session.commit()
            logger.info(f"✅ Chunk saved to session {session_id}")
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Chunk save failed: {e}")
            from app import db
            try:
                db.session.rollback()
            except:
                pass
        except Exception as e:
            logger.error(f"❌ Chunk save error: {e}")
    
    @staticmethod
    def complete_session(session_id, final_transcript, ai_summary=None):
        """Complete session with final transcript and analysis"""
        try:
            from models import TranscriptSession
            from app import db
            
            session = TranscriptSession.query.get(session_id)
            if not session:
                logger.error(f"❌ Session {session_id} not found")
                return False
                
            session.transcript = final_transcript
            session.transcript_text = final_transcript  # For compatibility
            session.word_count = len(final_transcript.split())
            
            if ai_summary:
                session.summary = ai_summary.get('summary', '')
            
            db.session.commit()
            logger.info(f"✅ Session completed: {session_id}")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session completion failed: {e}")
            from app import db
            try:
                db.session.rollback()
            except:
                pass
            return False
        except Exception as e:
            logger.error(f"❌ Session completion error: {e}")
            return False
    
    @staticmethod
    def get_user_sessions(user_id, limit=50, offset=0):
        """Get user's transcription sessions"""
        try:
            from models import TranscriptSession
            
            sessions = TranscriptSession.query.filter_by(user_id=user_id)\
                .order_by(TranscriptSession.created_at.desc())\
                .limit(limit).offset(offset).all()
                
            return [{
                'id': s.id,
                'title': s.title,
                'created_at': s.created_at.isoformat() if s.created_at else None,
                'duration': s.duration or 0.0,
                'word_count': s.word_count or 0,
                'confidence_average': s.confidence or 0.0,
                'status': 'completed',
                'full_transcript': s.transcript or s.transcript_text or '',
                'has_summary': bool(s.summary)
            } for s in sessions]
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session retrieval failed: {e}")
            return []
        except Exception as e:
            logger.error(f"❌ Session retrieval error: {e}")
            return []
    
    @staticmethod
    def get_session_detail(session_id, user_id):
        """Get detailed session information"""
        try:
            from models import TranscriptSession
            
            session = TranscriptSession.query.filter_by(
                id=session_id, user_id=user_id
            ).first()
            
            if not session:
                return None
                
            return {
                'id': session.id,
                'title': session.title,
                'created_at': session.created_at.isoformat() if session.created_at else None,
                'duration': session.duration or 0.0,
                'word_count': session.word_count or 0,
                'confidence': session.confidence or 0.0,
                'transcript': session.transcript or session.transcript_text or '',
                'summary': session.summary or '',
                'action_items': session.action_items or [],
                'status': 'completed'
            }
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session detail failed: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Session detail error: {e}")
            return None