# transcript_enhancer.py
# Advanced transcript post-processing with GPT-4 for industry-standard quality

import logging
import os
import re
from typing import Dict, Any, List, Optional
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

logger = logging.getLogger(__name__)

class TranscriptEnhancer:
    """
    Advanced transcript enhancement service for professional-grade output
    Features:
    - GPT-4 powered sentence reconstruction
    - Speaker diarization integration
    - Contextual coherence improvement
    - Professional formatting and punctuation
    """
    
    def __init__(self):
        if OpenAI:
            self.client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
        else:
            self.client = None
        self.enhancement_prompts = {
            'general': """
You are a professional transcript editor. Clean up this raw transcription while maintaining the original meaning and speaker intent.

Tasks:
1. Fix grammar, punctuation, and sentence structure
2. Remove filler words (um, uh, like) unless they're meaningful
3. Combine fragmented sentences logically
4. Maintain the conversational tone and natural flow
5. Preserve all meaningful content and context
6. Add proper paragraph breaks for topic changes

Raw transcript:
{transcript}

Return only the cleaned transcript without any commentary or metadata.
""",
            'meeting': """
You are transcribing a business meeting. Clean up this raw transcription with professional standards.

Tasks:
1. Structure into clear, professional sentences
2. Remove excessive filler words and false starts
3. Group related thoughts into coherent paragraphs
4. Preserve all business-critical information
5. Maintain professional tone while keeping conversational elements
6. Add topic breaks where discussions shift

Raw transcript:
{transcript}

Return only the professionally formatted transcript.
""",
            'interview': """
You are editing an interview transcript. Enhance readability while preserving authenticity.

Tasks:
1. Clean up grammar and punctuation
2. Preserve the natural conversational flow
3. Remove excessive filler words but keep some for authenticity
4. Structure into clear question-response format if applicable
5. Maintain speaker's voice and personality
6. Group related topics together

Raw transcript:
{transcript}

Return the enhanced transcript maintaining the interview's natural flow.
"""
        }
    
    def enhance_transcript(self, raw_transcript: str, context: str = "general", 
                          meeting_type: str = "general") -> Dict[str, Any]:
        """
        Enhance raw transcript using GPT-4 for professional quality
        
        Args:
            raw_transcript: Raw transcript text from Whisper
            context: Context for enhancement (general, meeting, interview)
            meeting_type: Type of meeting for specialized enhancement
            
        Returns:
            Enhanced transcript with quality metrics
        """
        try:
            if not raw_transcript or len(raw_transcript.strip()) < 10:
                return {
                    'enhanced_text': raw_transcript,
                    'original_text': raw_transcript,
                    'enhancement_applied': False,
                    'quality_score': 1.0,
                    'improvements': []
                }
            
            # Select appropriate enhancement prompt
            prompt_type = context if context in self.enhancement_prompts else 'general'
            prompt = self.enhancement_prompts[prompt_type].format(transcript=raw_transcript)
            
            # Call GPT for enhancement with fallback model
            # Try GPT-4o first, fallback to available models
            model_to_use = "gpt-3.5-turbo"  # Fallback to available model
            try:
                # Test if GPT-4o is available
                test_response = self.client.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "test"}],
                    max_tokens=5
                )
                model_to_use = "gpt-4o"
            except Exception:
                # GPT-4o not available, use GPT-3.5-turbo
                pass
            
            response = self.client.chat.completions.create(
                model=model_to_use,
                messages=[
                    {"role": "system", "content": "You are a professional transcript editor with expertise in creating clear, readable transcripts while preserving original meaning."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,  # Low temperature for consistent, conservative edits
                max_tokens=2000
            )
            
            enhanced_text = response.choices[0].message.content
            if enhanced_text:
                enhanced_text = enhanced_text.strip()
            
            # Quality analysis
            quality_metrics = self._analyze_enhancement_quality(raw_transcript, enhanced_text)
            
            return {
                'enhanced_text': enhanced_text,
                'original_text': raw_transcript,
                'enhancement_applied': True,
                'quality_score': quality_metrics['quality_score'],
                'improvements': quality_metrics['improvements'],
                'word_count_original': len(raw_transcript.split()),
                'word_count_enhanced': len(enhanced_text.split()),
                'processing_type': prompt_type
            }
            
        except Exception as e:
            logger.error(f"AI transcript enhancement failed: {e}")
            
            # Fallback to manual enhancement
            try:
                from services.manual_transcript_enhancer import ManualTranscriptEnhancer
                manual_enhancer = ManualTranscriptEnhancer()
                manual_result = manual_enhancer.enhance_transcript(raw_transcript, context)
                
                if manual_result.get('enhancement_applied'):
                    logger.info(f"Successfully applied manual enhancement fallback")
                    return manual_result
                else:
                    logger.warning(f"Manual enhancement also failed")
                    
            except Exception as manual_error:
                logger.error(f"Manual enhancement fallback failed: {manual_error}")
            
            return {
                'enhanced_text': raw_transcript,
                'original_text': raw_transcript,
                'enhancement_applied': False,
                'quality_score': 0.5,
                'improvements': [],
                'error': str(e),
                'fallback_attempted': True
            }
    
    def _analyze_enhancement_quality(self, original: str, enhanced: str) -> Dict[str, Any]:
        """Analyze the quality improvement from enhancement"""
        improvements = []
        
        # Count sentence improvements
        original_sentences = len([s for s in original.split('.') if s.strip()])
        enhanced_sentences = len([s for s in enhanced.split('.') if s.strip()])
        
        if enhanced_sentences > original_sentences:
            improvements.append("Better sentence structure")
        
        # Check for reduced fragments
        original_fragments = len([s for s in original.split() if len(s) < 3])
        enhanced_fragments = len([s for s in enhanced.split() if len(s) < 3])
        
        if enhanced_fragments < original_fragments:
            improvements.append("Reduced fragmentation")
        
        # Check for improved capitalization
        original_caps = sum(1 for c in original if c.isupper())
        enhanced_caps = sum(1 for c in enhanced if c.isupper())
        
        if enhanced_caps > original_caps:
            improvements.append("Improved capitalization")
        
        # Check for added punctuation
        original_punct = sum(1 for c in original if c in '.,!?;:')
        enhanced_punct = sum(1 for c in enhanced if c in '.,!?;:')
        
        if enhanced_punct > original_punct:
            improvements.append("Better punctuation")
        
        # Calculate quality score
        improvement_score = len(improvements) * 0.15
        length_retention = min(1.0, len(enhanced) / max(len(original), 1))
        quality_score = min(1.0, 0.5 + improvement_score + (length_retention * 0.3))
        
        return {
            'quality_score': quality_score,
            'improvements': improvements
        }
    
    def enhance_streaming_chunks(self, chunk_segments: List[Dict[str, Any]], 
                                session_context: str = "") -> Dict[str, Any]:
        """
        Enhance multiple streaming chunks together for better coherence
        
        Args:
            chunk_segments: List of transcription segments from streaming
            session_context: Context about the session/meeting
            
        Returns:
            Enhanced transcript with segment mapping
        """
        try:
            # Combine all chunks into continuous text
            combined_text = " ".join([
                segment.get('text', '') for segment in chunk_segments 
                if segment.get('text', '').strip()
            ])
            
            if not combined_text:
                combined_text = ""
            
            if not combined_text.strip():
                return {
                    'enhanced_text': '',
                    'segment_mapping': [],
                    'enhancement_applied': False
                }
            
            # Enhance the combined text
            enhancement_result = self.enhance_transcript(
                combined_text, 
                context="meeting" if "meeting" in session_context.lower() else "general"
            )
            
            # Create segment mapping for UI updates
            enhanced_sentences = [s.strip() + '.' for s in enhancement_result['enhanced_text'].split('.') if s.strip()]
            
            segment_mapping = []
            for i, sentence in enumerate(enhanced_sentences):
                segment_mapping.append({
                    'enhanced_text': sentence,
                    'original_chunks': chunk_segments[i:i+2] if i < len(chunk_segments) else [],
                    'confidence': enhancement_result['quality_score'],
                    'timestamp': chunk_segments[0].get('timestamp', 0) if chunk_segments else 0
                })
            
            return {
                'enhanced_text': enhancement_result['enhanced_text'],
                'segment_mapping': segment_mapping,
                'enhancement_applied': enhancement_result['enhancement_applied'],
                'quality_score': enhancement_result['quality_score'],
                'improvements': enhancement_result.get('improvements', [])
            }
            
        except Exception as e:
            logger.error(f"Streaming chunk enhancement failed: {e}")
            return {
                'enhanced_text': combined_text,
                'segment_mapping': [],
                'enhancement_applied': False,
                'error': str(e)
            }

def enhance_transcript_text(text: str, context: str = "general") -> str:
    """Utility function for simple transcript enhancement"""
    enhancer = TranscriptEnhancer()
    result = enhancer.enhance_transcript(text, context)
    return result.get('enhanced_text', text)
# Create global transcript enhancer instance
transcript_enhancer = TranscriptEnhancer()
