"""
Advanced Transcription Quality Enhancement Service
Implements multiple AI-powered techniques to improve live transcription accuracy
"""

import re
import time
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque, Counter

logger = logging.getLogger(__name__)

@dataclass
class TranscriptChunk:
    text: str
    confidence: float
    timestamp: float
    chunk_id: str
    audio_quality: float = 0.8
    speaker_clarity: float = 0.8
    background_noise: float = 0.2

class TranscriptionQualityEnhancer:
    def __init__(self):
        self.context_buffer = deque(maxlen=5)  # Rolling context for better accuracy
        self.word_frequency = Counter()
        self.speaking_patterns = {}
        self.noise_patterns = set()
        self.confidence_history = deque(maxlen=10)
        
        # Enhanced dictionaries for better word recognition
        self.common_words = {
            'technical': ['algorithm', 'implementation', 'architecture', 'database', 'API', 'framework'],
            'business': ['strategy', 'revenue', 'customer', 'market', 'stakeholder', 'deliverable'],
            'meeting': ['agenda', 'action', 'follow-up', 'deadline', 'priority', 'discussion']
        }
        
        # Pronunciation variants for better matching
        self.word_variants = {
            'api': ['API', 'a p i', 'ay pee eye'],
            'ui': ['UI', 'u i', 'you eye', 'user interface'],
            'database': ['db', 'data base'],
            'okay': ['ok', 'OK', 'alright', 'right']
        }
        
        logger.info("[QUALITY-ENHANCER] Initialized with advanced processing capabilities")

    def enhance_transcript(self, chunk: TranscriptChunk, context: Optional[List[str]] = None) -> TranscriptChunk:
        """Apply comprehensive quality enhancement to transcript chunk"""
        
        # Step 1: Contextual correction using previous chunks
        enhanced_text = self._apply_contextual_correction(chunk.text, context or [])
        
        # Step 2: Technical term recognition and correction
        enhanced_text = self._enhance_technical_terms(enhanced_text)
        
        # Step 3: Grammar and flow improvement
        enhanced_text = self._improve_grammar_flow(enhanced_text)
        
        # Step 4: Confidence adjustment based on multiple factors
        adjusted_confidence = self._calculate_enhanced_confidence(
            chunk.text, enhanced_text, chunk.confidence, chunk.audio_quality
        )
        
        # Step 5: Speaker pattern learning
        self._learn_speaking_patterns(enhanced_text, adjusted_confidence)
        
        # Update context buffer
        self.context_buffer.append(enhanced_text)
        self.confidence_history.append(adjusted_confidence)
        
        enhanced_chunk = TranscriptChunk(
            text=enhanced_text,
            confidence=adjusted_confidence,
            timestamp=chunk.timestamp,
            chunk_id=chunk.chunk_id,
            audio_quality=chunk.audio_quality,
            speaker_clarity=chunk.speaker_clarity,
            background_noise=chunk.background_noise
        )
        
        logger.debug(f"[QUALITY-ENHANCER] Enhanced '{chunk.text[:30]}...' → '{enhanced_text[:30]}...' "
                    f"(confidence: {chunk.confidence:.2f} → {adjusted_confidence:.2f})")
        
        return enhanced_chunk

    def _apply_contextual_correction(self, text: str, context: List[str]) -> str:
        """Use context from previous chunks to improve current transcription"""
        
        if not context:
            return text
        
        # Join recent context for pattern analysis
        context_text = ' '.join(context[-3:]).lower()
        current_text = text.lower()
        
        # Context-based corrections
        corrections = {
            # Common speech patterns
            'we need to': 'we need to',
            'we have to': 'we have to', 
            'let me': 'let me',
            'i think': 'I think',
            'that is': 'that is',
            
            # Technical context corrections
            'a p i': 'API' if 'api' in context_text or 'development' in context_text else 'a p i',
            'you i': 'UI' if 'interface' in context_text or 'design' in context_text else 'you i',
            'data base': 'database' if 'sql' in context_text or 'query' in context_text else 'data base',
        }
        
        enhanced_text = text
        for pattern, replacement in corrections.items():
            if pattern in current_text:
                enhanced_text = re.sub(re.escape(pattern), replacement, enhanced_text, flags=re.IGNORECASE)
        
        return enhanced_text

    def _enhance_technical_terms(self, text: str) -> str:
        """Improve recognition of technical and business terms"""
        
        enhanced_text = text
        
        # Technical term corrections
        technical_corrections = {
            r'\ba\s*p\s*i\b': 'API',
            r'\bu\s*i\b': 'UI',
            r'\bdata\s*base\b': 'database',
            r'\bweb\s*app\b': 'web app',
            r'\bback\s*end\b': 'backend',
            r'\bfront\s*end\b': 'frontend',
            r'\bmachine\s*learning\b': 'machine learning',
            r'\bartificial\s*intelligence\b': 'artificial intelligence',
        }
        
        for pattern, replacement in technical_corrections.items():
            enhanced_text = re.sub(pattern, replacement, enhanced_text, flags=re.IGNORECASE)
        
        return enhanced_text

    def _improve_grammar_flow(self, text: str) -> str:
        """Apply grammar and flow improvements"""
        
        enhanced_text = text
        
        # Capitalization fixes
        enhanced_text = re.sub(r'\bi\b', 'I', enhanced_text)  # Fix lowercase 'i'
        
        # Common phrase improvements
        phrase_corrections = {
            'gonna': 'going to',
            'wanna': 'want to',
            'shoulda': 'should have',
            'coulda': 'could have',
            'wouldve': 'would have',
            'cant': "can't",
            'wont': "won't",
            'dont': "don't",
        }
        
        for informal, formal in phrase_corrections.items():
            enhanced_text = re.sub(r'\b' + re.escape(informal) + r'\b', formal, enhanced_text, flags=re.IGNORECASE)
        
        # Remove excessive filler words when repeated
        enhanced_text = re.sub(r'\b(um|uh|er|ah)\s+\1+\b', r'\1', enhanced_text, flags=re.IGNORECASE)
        
        return enhanced_text.strip()

    def _calculate_enhanced_confidence(self, original: str, enhanced: str, base_confidence: float, audio_quality: float) -> float:
        """Calculate improved confidence score based on multiple factors"""
        
        confidence_adjustments = []
        
        # Factor 1: Length and completeness
        if len(enhanced.split()) >= 3:
            confidence_adjustments.append(0.1)  # Boost for complete phrases
        
        # Factor 2: Technical term recognition
        tech_terms_found = sum(1 for term_list in self.common_words.values() 
                              for term in term_list if term.lower() in enhanced.lower())
        if tech_terms_found > 0:
            confidence_adjustments.append(0.05 * tech_terms_found)
        
        # Factor 3: Context consistency
        if self.context_buffer:
            recent_context = ' '.join(list(self.context_buffer)[-2:])
            common_words = set(enhanced.lower().split()) & set(recent_context.lower().split())
            if len(common_words) > 1:
                confidence_adjustments.append(0.08)  # Context consistency boost
        
        # Factor 4: Audio quality impact
        audio_factor = (audio_quality - 0.5) * 0.2  # -0.1 to +0.1 based on audio quality
        confidence_adjustments.append(audio_factor)
        
        # Factor 5: Historical confidence trend
        if self.confidence_history:
            avg_recent_confidence = sum(self.confidence_history) / len(self.confidence_history)
            if base_confidence > avg_recent_confidence:
                confidence_adjustments.append(0.05)  # Trending upward
        
        # Apply adjustments
        total_adjustment = sum(confidence_adjustments)
        enhanced_confidence = min(0.95, max(0.1, base_confidence + total_adjustment))
        
        return enhanced_confidence

    def _learn_speaking_patterns(self, text: str, confidence: float):
        """Learn and adapt to speaker patterns for better future recognition"""
        
        # Track word frequency for this speaker
        words = text.lower().split()
        for word in words:
            if len(word) > 2:  # Ignore very short words
                self.word_frequency[word] += 1
        
        # Track high-confidence patterns
        if confidence > 0.8:
            phrases = self._extract_phrases(text)
            for phrase in phrases:
                if phrase not in self.speaking_patterns:
                    self.speaking_patterns[phrase] = 0
                self.speaking_patterns[phrase] += 1

    def _extract_phrases(self, text: str) -> List[str]:
        """Extract meaningful phrases for pattern learning"""
        
        # Extract 2-3 word phrases
        words = text.split()
        phrases = []
        
        for i in range(len(words) - 1):
            if i < len(words) - 2:
                three_word = ' '.join(words[i:i+3])
                if len(three_word) > 10:  # Meaningful length
                    phrases.append(three_word.lower())
            
            two_word = ' '.join(words[i:i+2])
            if len(two_word) > 6:  # Meaningful length
                phrases.append(two_word.lower())
        
        return phrases

    def get_context_prompt(self, meeting_type: str = "general") -> str:
        """Generate contextual prompt for Whisper based on recent transcription"""
        
        context_elements = []
        
        # Add recent high-confidence context
        if self.context_buffer:
            recent_text = ' '.join(list(self.context_buffer)[-2:])
            context_elements.append(f"Recent context: {recent_text}")
        
        # Add common words for this session
        if self.word_frequency:
            top_words = [word for word, count in self.word_frequency.most_common(5) if count > 2]
            if top_words:
                context_elements.append(f"Common words: {', '.join(top_words)}")
        
        # Add meeting-specific vocabulary
        if meeting_type in self.common_words:
            context_elements.append(f"Expected terms: {', '.join(self.common_words[meeting_type][:3])}")
        
        base_prompt = "This is a clear English speech recording with natural conversation."
        
        if context_elements:
            context_prompt = base_prompt + " " + " ".join(context_elements)
            return context_prompt[:200]  # Whisper prompt limit
        
        return base_prompt

    def should_process_chunk(self, text: str, confidence: float, audio_quality: float = 0.8) -> bool:
        """OPTIMIZED CHUNK PROCESSING: Dynamic confidence thresholding based on quality analysis"""
        
        # Skip very short or low-quality chunks
        if len(text.strip()) < 2:
            return False
        
        # ADAPTIVE CONFIDENCE THRESHOLD: Adjust based on recent performance
        adaptive_threshold = self.calculate_adaptive_threshold(confidence, audio_quality)
        if confidence < adaptive_threshold:
            return False
        
        # Skip obvious noise patterns
        noise_indicators = ['*', '[', ']', '(music)', '(background noise)', '(inaudible)']
        if any(indicator in text.lower() for indicator in noise_indicators):
            return False
        
        # Skip repetitive single words
        words = text.strip().split()
        if len(words) == 1 and words[0].lower() in ['um', 'uh', 'er', 'ah', 'hmm']:
            return False
        
        return True

    def get_quality_metrics(self) -> Dict:
        """Return current quality metrics for monitoring"""
        
        avg_confidence = sum(self.confidence_history) / len(self.confidence_history) if self.confidence_history else 0
        
        return {
            'average_confidence': round(avg_confidence, 3),
            'context_buffer_size': len(self.context_buffer),
            'learned_patterns': len(self.speaking_patterns),
            'vocabulary_size': len(self.word_frequency),
            'top_words': dict(self.word_frequency.most_common(5)),
            'adaptive_threshold': self.calculate_adaptive_threshold(avg_confidence, 0.8),
            'processing_rate': len(self.confidence_history) / max(1, len(self.confidence_history))
        }
    
    def calculate_adaptive_threshold(self, current_confidence: float, audio_quality: float) -> float:
        """Calculate dynamic confidence threshold based on recent performance"""
        
        if not self.confidence_history:
            return 0.35  # Default threshold
        
        # Calculate recent performance metrics
        recent_confidences = list(self.confidence_history)[-10:]  # Last 10 chunks
        avg_recent_confidence = sum(recent_confidences) / len(recent_confidences)
        
        # Base threshold starts at 0.35 and adjusts based on performance
        base_threshold = 0.35
        
        # If recent performance is good, lower threshold for better sensitivity
        if avg_recent_confidence > 0.5 and audio_quality > 0.7:
            adaptive_threshold = max(0.25, base_threshold - 0.05)
        # If recent performance is poor, raise threshold for better filtering
        elif avg_recent_confidence < 0.3 or audio_quality < 0.5:
            adaptive_threshold = min(0.5, base_threshold + 0.1)
        else:
            adaptive_threshold = base_threshold
        
        # Consider current confidence in the decision
        if current_confidence > 0.6:
            adaptive_threshold *= 0.9  # Be more permissive for high-confidence chunks
        
        return round(adaptive_threshold, 3)