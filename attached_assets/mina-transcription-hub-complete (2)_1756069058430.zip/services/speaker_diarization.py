"""
Speaker Diarization Service
Basic speaker separation for meeting transcripts
"""
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class SpeakerDiarization:
    """
    Basic speaker diarization using silence-based heuristics
    """
    
    def __init__(self):
        self.min_speaker_duration = 2.0  # Minimum seconds for speaker change
        self.silence_threshold = 1.5     # Silence duration that might indicate speaker change
    
    def analyze_speakers(self, transcript: str, audio_duration: float = None) -> Dict[str, Any]:
        """
        Analyze transcript for basic speaker patterns
        
        Args:
            transcript: Full transcript text
            audio_duration: Total audio duration in seconds
            
        Returns:
            Dictionary with speaker analysis
        """
        try:
            # Split transcript into sentences
            sentences = self._split_into_sentences(transcript)
            
            # Apply basic speaker detection heuristics
            speaker_segments = self._detect_speaker_changes(sentences)
            
            # Generate speaker statistics
            speaker_stats = self._generate_speaker_stats(speaker_segments, audio_duration)
            
            return {
                "status": "success",
                "speaker_count": len(speaker_stats),
                "segments": speaker_segments,
                "speaker_stats": speaker_stats,
                "methodology": "heuristic_silence_based"
            }
            
        except Exception as e:
            logger.error(f"Speaker diarization failed: {e}")
            return {
                "status": "error",
                "error": str(e),
                "speaker_count": 1,
                "segments": [{"speaker": "Speaker 1", "text": transcript, "start": 0}],
                "speaker_stats": {"Speaker 1": {"word_count": len(transcript.split()), "percentage": 100.0}}
            }
    
    def _split_into_sentences(self, transcript: str) -> List[str]:
        """Split transcript into sentences"""
        import re
        
        # Split on sentence boundaries
        sentences = re.split(r'[.!?]+', transcript)
        
        # Clean and filter empty sentences
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
    
    def _detect_speaker_changes(self, sentences: List[str]) -> List[Dict[str, Any]]:
        """
        Detect potential speaker changes using heuristics
        
        Basic rules:
        - Short responses might indicate speaker change
        - Questions often indicate speaker change
        - Certain phrases indicate turn-taking
        """
        segments = []
        current_speaker = "Speaker 1"
        speaker_count = 1
        
        turn_taking_phrases = [
            "yes", "no", "okay", "alright", "sure", "exactly", "right",
            "i think", "well", "so", "but", "however", "actually"
        ]
        
        for i, sentence in enumerate(sentences):
            sentence_lower = sentence.lower().strip()
            
            # Check for speaker change indicators
            should_change_speaker = False
            
            # Short responses (< 5 words) might be different speaker
            if len(sentence.split()) < 5 and i > 0:
                should_change_speaker = True
            
            # Questions might indicate speaker change
            if sentence.strip().endswith('?'):
                should_change_speaker = True
            
            # Turn-taking phrases
            if any(phrase in sentence_lower for phrase in turn_taking_phrases):
                if i > 0:  # Not first sentence
                    should_change_speaker = True
            
            # Change speaker if indicators suggest it
            if should_change_speaker and len(segments) > 0:
                # Switch speaker
                if current_speaker == "Speaker 1":
                    current_speaker = "Speaker 2"
                    if speaker_count == 1:
                        speaker_count = 2
                else:
                    current_speaker = "Speaker 1"
            
            # Add segment
            segments.append({
                "speaker": current_speaker,
                "text": sentence.strip(),
                "start": i * 3,  # Approximate timing (3 seconds per sentence)
                "end": (i + 1) * 3,
                "confidence": 0.6  # Low confidence for heuristic method
            })
        
        return segments
    
    def _generate_speaker_stats(self, segments: List[Dict[str, Any]], audio_duration: float = None) -> Dict[str, Dict[str, Any]]:
        """Generate speaking statistics per speaker"""
        stats = {}
        
        for segment in segments:
            speaker = segment["speaker"]
            
            if speaker not in stats:
                stats[speaker] = {
                    "word_count": 0,
                    "segment_count": 0,
                    "total_duration": 0.0
                }
            
            stats[speaker]["word_count"] += len(segment["text"].split())
            stats[speaker]["segment_count"] += 1
            stats[speaker]["total_duration"] += segment.get("end", 0) - segment.get("start", 0)
        
        # Calculate percentages
        total_words = sum(speaker_stats["word_count"] for speaker_stats in stats.values())
        
        for speaker in stats:
            if total_words > 0:
                stats[speaker]["percentage"] = (stats[speaker]["word_count"] / total_words) * 100
            else:
                stats[speaker]["percentage"] = 0.0
        
        return stats
    
    def format_transcript_with_speakers(self, segments: List[Dict[str, Any]]) -> str:
        """Format transcript with speaker labels"""
        formatted_lines = []
        
        current_speaker = None
        current_text = []
        
        for segment in segments:
            speaker = segment["speaker"]
            text = segment["text"]
            
            if speaker != current_speaker:
                # Finish previous speaker's text
                if current_speaker and current_text:
                    formatted_lines.append(f"{current_speaker}: {' '.join(current_text)}")
                
                # Start new speaker
                current_speaker = speaker
                current_text = [text]
            else:
                # Continue with same speaker
                current_text.append(text)
        
        # Add final speaker's text
        if current_speaker and current_text:
            formatted_lines.append(f"{current_speaker}: {' '.join(current_text)}")
        
        return '\n\n'.join(formatted_lines)

# Global diarization service instance
speaker_diarization = SpeakerDiarization()