"""
AI Intelligence Service
Post-meeting intelligence, summaries, and insights using OpenAI GPT-4
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

try:
    from openai import OpenAI
    openai_available = True
except ImportError:
    openai_available = False

logger = logging.getLogger(__name__)

class AIIntelligenceService:
    """Post-meeting AI intelligence and analysis"""
    
    def __init__(self):
        self.openai_api_key = os.environ.get('OPENAI_API_KEY')
        if self.openai_api_key and openai_available:
            self.client = OpenAI(api_key=self.openai_api_key)
            self.available = True
        else:
            self.client = None
            self.available = False
            logger.warning("OpenAI API key not available - AI intelligence disabled")
    
    def generate_meeting_summary(self, transcript: str, meeting_title: str = "Meeting") -> Dict[str, Any]:
        """Generate comprehensive meeting summary with AI"""
        if not self.available:
            return self._fallback_summary(transcript, meeting_title)
        
        try:
            system_prompt = """You are an expert meeting intelligence assistant. Generate a comprehensive, professional meeting summary that includes:

1. **Executive Summary**: 2-3 sentences capturing the main purpose and outcomes
2. **Key Decisions**: Bullet points of concrete decisions made
3. **Action Items**: Tasks assigned with owners (if mentioned)
4. **Key Topics**: Main discussion points
5. **Next Steps**: Follow-up actions needed

Be concise, professional, and focus on actionable insights. Use business-appropriate language."""

            user_prompt = f"""Meeting Title: {meeting_title}

Transcript:
{transcript}

Please generate a comprehensive meeting summary following the format above."""

            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            summary_text = response.choices[0].message.content
            
            return {
                'success': True,
                'summary': summary_text,
                'generated_at': datetime.utcnow().isoformat(),
                'model': 'gpt-4',
                'word_count': len(summary_text.split())
            }
            
        except Exception as e:
            logger.error(f"Summary generation failed: {e}")
            return self._fallback_summary(transcript, meeting_title)
    
    def generate_conversation_insights(self, transcript: str) -> Dict[str, Any]:
        """Generate AI-powered conversation insights and suggested questions"""
        if not self.available:
            return self._fallback_insights()
        
        try:
            system_prompt = """You are an AI assistant that analyzes meeting transcripts and generates helpful conversation insights. Based on the transcript, suggest 5-8 intelligent questions that participants might ask about the conversation. Focus on:

1. Decisions made
2. Action items assigned
3. Key participants mentioned
4. Important topics discussed
5. Follow-up questions
6. Clarification needs

Format as a JSON array of question objects with 'question' and 'category' fields."""

            user_prompt = f"""Analyze this transcript and suggest intelligent questions:

{transcript}

Return suggestions as JSON array."""

            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=800,
                temperature=0.4
            )
            
            suggestions_text = response.choices[0].message.content
            
            # Try to parse JSON, fallback to text parsing
            try:
                suggestions = json.loads(suggestions_text)
            except json.JSONDecodeError:
                # Fallback to basic suggestions
                suggestions = self._parse_suggestions_from_text(suggestions_text)
            
            return {
                'success': True,
                'suggestions': suggestions,
                'generated_at': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Insights generation failed: {e}")
            return self._fallback_insights()
    
    def extract_action_items(self, transcript: str) -> Dict[str, Any]:
        """Extract action items and takeaways from transcript"""
        if not self.available:
            return self._fallback_action_items()
        
        try:
            system_prompt = """You are an expert at extracting actionable tasks from meeting transcripts. Identify:

1. **Action Items**: Specific tasks that need to be completed
2. **Decisions Made**: Concrete decisions reached
3. **Key Deadlines**: Important dates mentioned
4. **Assigned Responsibilities**: Who is responsible for what
5. **Follow-up Meetings**: Scheduled or needed meetings

Format as structured data with clear categories."""

            user_prompt = f"""Extract action items and takeaways from this transcript:

{transcript}

Provide structured output with clear categories."""

            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=800,
                temperature=0.2
            )
            
            takeaways_text = response.choices[0].message.content
            
            return {
                'success': True,
                'takeaways': takeaways_text,
                'generated_at': datetime.utcnow().isoformat(),
                'extracted_at': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Action items extraction failed: {e}")
            return self._fallback_action_items()
    
    def answer_conversation_question(self, transcript: str, question: str) -> Dict[str, Any]:
        """Answer specific questions about the conversation"""
        if not self.available:
            return {
                'success': False,
                'answer': 'AI chat requires OpenAI API key configuration.',
                'confidence': 0.0
            }
        
        try:
            system_prompt = """You are a helpful AI assistant that answers questions about meeting transcripts. Provide accurate, specific answers based only on the information in the transcript. If information is not available in the transcript, clearly state that."""

            user_prompt = f"""Based on this meeting transcript, please answer the following question:

Question: {question}

Transcript:
{transcript}

Provide a helpful, accurate answer based on the transcript content."""

            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=500,
                temperature=0.3
            )
            
            answer = response.choices[0].message.content
            
            return {
                'success': True,
                'answer': answer,
                'question': question,
                'generated_at': datetime.utcnow().isoformat(),
                'confidence': 0.85  # Simulated confidence score
            }
            
        except Exception as e:
            logger.error(f"Question answering failed: {e}")
            return {
                'success': False,
                'answer': f'Unable to process question: {str(e)}',
                'confidence': 0.0
            }
    
    def _fallback_summary(self, transcript: str, meeting_title: str) -> Dict[str, Any]:
        """Fallback summary when AI is not available"""
        word_count = len(transcript.split())
        duration_estimate = max(1, word_count // 150)  # Rough estimate
        
        return {
            'success': True,
            'summary': f"""**{meeting_title}** - Meeting Summary

**Executive Summary**
Meeting transcript captured with {word_count} words (approximately {duration_estimate} minutes of discussion).

**Key Information**
- Transcript length: {word_count} words
- Processing completed: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}
- Auto-summary generation requires OpenAI API configuration

**Next Steps**
- Review transcript for action items
- Configure AI services for automated insights
- Schedule follow-up as needed""",
            'generated_at': datetime.utcnow().isoformat(),
            'model': 'fallback',
            'word_count': len(transcript.split())
        }
    
    def _fallback_insights(self) -> Dict[str, Any]:
        """Fallback conversation insights"""
        return {
            'success': True,
            'suggestions': [
                {'question': 'What were the main decisions made in this meeting?', 'category': 'decisions'},
                {'question': 'Who was assigned specific action items?', 'category': 'actions'},
                {'question': 'What topics require follow-up discussion?', 'category': 'follow-up'},
                {'question': 'Were any deadlines or timelines mentioned?', 'category': 'timeline'},
                {'question': 'What concerns or issues were raised?', 'category': 'issues'}
            ],
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _fallback_action_items(self) -> Dict[str, Any]:
        """Fallback action items extraction"""
        return {
            'success': True,
            'takeaways': """**Action Items & Takeaways**

**To extract detailed action items:**
1. Configure OpenAI API key for AI-powered analysis
2. Review transcript manually for specific tasks
3. Identify key decisions and assignments

**Manual Review Recommended**
- Review transcript for specific commitments
- Identify assigned responsibilities
- Note important deadlines mentioned
- Plan follow-up communications

*Automated extraction requires AI services configuration.*""",
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _parse_suggestions_from_text(self, text: str) -> List[Dict[str, str]]:
        """Parse suggestions from unstructured text"""
        suggestions = []
        lines = text.split('\n')
        
        for line in lines:
            line = line.strip()
            if line and ('?' in line or line.startswith('-') or line.startswith('*')):
                question = line.lstrip('- *').strip()
                if question:
                    suggestions.append({
                        'question': question,
                        'category': 'general'
                    })
        
        if not suggestions:
            return self._fallback_insights()['suggestions']
        
        return suggestions[:8]  # Limit to 8 suggestions

# Global instance
ai_intelligence = AIIntelligenceService()