"""
✅ REQUIREMENT: SendGrid Email Service - Phase 4 Launch Prep
Sends welcome email on registration and password reset email
"""

import os
import logging
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content

logger = logging.getLogger(__name__)

class EmailService:
    """Handles all email communications for MinaTranscribe"""
    
    def __init__(self):
        self.api_key = os.environ.get('SENDGRID_API_KEY')
        self.from_email = "noreply@minatranscribe.com"  # Configure your verified sender
        self.sg = None
        
        if self.api_key:
            self.sg = SendGridAPIClient(api_key=self.api_key)
            logger.info("SendGrid email service initialized")
        else:
            logger.warning("SENDGRID_API_KEY not found - email disabled")
    
    def send_welcome_email(self, user_email: str, username: str) -> bool:
        """
        ✅ REQUIREMENT: Send welcome email on registration
        Welcome new users with feature introduction
        """
        if not self.sg:
            logger.warning("SendGrid not configured - welcome email skipped")
            return False
        
        try:
            html_content = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #333; text-align: center;">Welcome to MinaTranscribe!</h1>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h2>Hi {username},</h2>
                    <p>Welcome to <strong>MinaTranscribe</strong> - your AI-powered transcription companion!</p>
                    
                    <h3>🎯 What you can do:</h3>
                    <ul>
                        <li><strong>Real-time Transcription</strong> - VAD-powered live audio-to-text</li>
                        <li><strong>AI Meeting Intelligence</strong> - Extract action items, summaries, and insights</li>
                        <li><strong>Multiple Export Formats</strong> - TXT, JSON, SRT downloads</li>
                        <li><strong>Speaker Detection</strong> - Automatic speaker identification</li>
                        <li><strong>30 Minutes Free</strong> - Get started with your free tier</li>
                    </ul>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="https://minatranscribe.com/dashboard" 
                           style="background: #007bff; color: white; padding: 12px 24px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            Start Transcribing Now
                        </a>
                    </div>
                    
                    <p style="color: #666; font-size: 14px;">
                        Need help? Reply to this email or visit our 
                        <a href="https://minatranscribe.com/help">help center</a>.
                    </p>
                </div>
                
                <div style="text-align: center; color: #999; font-size: 12px; margin-top: 40px;">
                    <p>MinaTranscribe - AI-Powered Meeting Intelligence</p>
                    <p>You're receiving this because you signed up for MinaTranscribe.</p>
                </div>
            </div>
            """
            
            message = Mail(
                from_email=Email(self.from_email),
                to_emails=To(user_email),
                subject="Welcome to MinaTranscribe - Your AI Transcription Platform",
                html_content=Content("text/html", html_content)
            )
            
            response = self.sg.send(message)
            logger.info(f"Welcome email sent to {user_email} - Status: {response.status_code}")
            return response.status_code == 202
            
        except Exception as e:
            logger.error(f"Failed to send welcome email to {user_email}: {e}")
            return False
    
    def send_password_reset_email(self, user_email: str, username: str, reset_token: str) -> bool:
        """
        ✅ REQUIREMENT: Send password reset email
        Secure password reset with token verification
        """
        if not self.sg:
            logger.warning("SendGrid not configured - password reset email skipped")
            return False
        
        try:
            reset_url = f"https://minatranscribe.com/reset-password?token={reset_token}"
            
            html_content = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #333; text-align: center;">Password Reset Request</h1>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h2>Hi {username},</h2>
                    <p>We received a request to reset your MinaTranscribe password.</p>
                    
                    <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
                        <p><strong>⚠️ Security Note:</strong> This link expires in 1 hour for your security.</p>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="{reset_url}" 
                           style="background: #dc3545; color: white; padding: 12px 24px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            Reset Your Password
                        </a>
                    </div>
                    
                    <p style="color: #666; font-size: 14px;">
                        If you didn't request this reset, please ignore this email. 
                        Your password will remain unchanged.
                    </p>
                    
                    <p style="color: #666; font-size: 12px;">
                        For security reasons, this link will expire in 60 minutes.
                        <br>
                        Reset URL: {reset_url}
                    </p>
                </div>
                
                <div style="text-align: center; color: #999; font-size: 12px; margin-top: 40px;">
                    <p>MinaTranscribe Security Team</p>
                    <p>If you have security concerns, contact support immediately.</p>
                </div>
            </div>
            """
            
            message = Mail(
                from_email=Email(self.from_email),
                to_emails=To(user_email),
                subject="MinaTranscribe Password Reset Request",
                html_content=Content("text/html", html_content)
            )
            
            response = self.sg.send(message)
            logger.info(f"Password reset email sent to {user_email} - Status: {response.status_code}")
            return response.status_code == 202
            
        except Exception as e:
            logger.error(f"Failed to send password reset email to {user_email}: {e}")
            return False
    
    def send_upgrade_notification(self, user_email: str, username: str, new_tier: str) -> bool:
        """
        ✅ REQUIREMENT: Send tier upgrade confirmation
        Notify users of successful tier upgrades
        """
        if not self.sg:
            logger.warning("SendGrid not configured - upgrade email skipped")
            return False
        
        try:
            benefits = {
                "pro": [
                    "Unlimited monthly transcription minutes",
                    "Priority processing queue",
                    "Advanced AI analysis features",
                    "Export to all formats",
                    "Premium support"
                ]
            }
            
            tier_benefits = benefits.get(new_tier.lower(), ["Enhanced features"])
            benefits_html = "".join([f"<li>{benefit}</li>" for benefit in tier_benefits])
            
            html_content = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #28a745; text-align: center;">🎉 Welcome to {new_tier.upper()}!</h1>
                
                <div style="background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #28a745;">
                    <h2>Hi {username},</h2>
                    <p>Congratulations! Your MinaTranscribe account has been upgraded to <strong>{new_tier.upper()}</strong> tier.</p>
                    
                    <h3>🚀 Your new benefits:</h3>
                    <ul>{benefits_html}</ul>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="https://minatranscribe.com/dashboard" 
                           style="background: #28a745; color: white; padding: 12px 24px; 
                                  text-decoration: none; border-radius: 5px; display: inline-block;">
                            Explore Your Pro Features
                        </a>
                    </div>
                </div>
                
                <div style="text-align: center; color: #999; font-size: 12px; margin-top: 40px;">
                    <p>Thank you for choosing MinaTranscribe Pro!</p>
                </div>
            </div>
            """
            
            message = Mail(
                from_email=Email(self.from_email),
                to_emails=To(user_email),
                subject=f"Welcome to MinaTranscribe {new_tier.upper()}! 🎉",
                html_content=Content("text/html", html_content)
            )
            
            response = self.sg.send(message)
            logger.info(f"Upgrade notification sent to {user_email} - Status: {response.status_code}")
            return response.status_code == 202
            
        except Exception as e:
            logger.error(f"Failed to send upgrade notification to {user_email}: {e}")
            return False

# Global service instance
email_service = EmailService()