"""
Session summarizer service with enhanced GPT-4o capabilities
"""

import os
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

class SessionSummarizer:
    def __init__(self):
        self.openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    
    def summarize(self, transcript):
        """Generate basic summary"""
        return {"summary": "Session completed", "transcript": transcript}

def summarize_session(transcript_text, meeting_type="general", user_preferences=None):
    """
    Enhanced session summarization function
    
    Args:
        transcript_text: Full transcript text to summarize
        meeting_type: Type of meeting (general, standup, 1:1, etc.)
        user_preferences: User customization options
        
    Returns:
        Dictionary with comprehensive summary data
    """
    try:
        if not transcript_text or len(transcript_text.strip()) < 10:
            return {
                "status": "error",
                "message": "Insufficient transcript content for summarization"
            }
        
        # Create OpenAI client
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        
        # Generate summary using GPT-4o
        summary_prompt = f"""
        Please analyze this {meeting_type} meeting transcript and provide a comprehensive summary:

        Transcript:
        {transcript_text}

        Provide a JSON response with:
        1. brief_summary: 2-3 sentence overview
        2. key_points: List of main discussion points
        3. action_items: Specific tasks or follow-ups mentioned
        4. decisions: Key decisions made
        5. next_steps: Planned follow-up actions
        6. sentiment: Overall tone (positive/neutral/negative)
        7. confidence: Summary confidence score (0-1)
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert meeting analyst. Respond with valid JSON only."},
                {"role": "user", "content": summary_prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=1000
        )
        
        import json
        summary_data = json.loads(response.choices[0].message.content)
        
        return {
            "status": "success",
            "summary": summary_data,
            "meeting_type": meeting_type,
            "transcript_length": len(transcript_text),
            "word_count": len(transcript_text.split())
        }
        
    except Exception as e:
        logger.error(f"Session summarization failed: {e}")
        return {
            "status": "error",
            "message": "Summarization failed",
            "fallback_summary": {
                "brief_summary": f"Meeting transcript processed with {len(transcript_text.split())} words",
                "key_points": ["Transcript content available for review"],
                "action_items": [],
                "decisions": [],
                "next_steps": [],
                "sentiment": "neutral",
                "confidence": 0.5
            }
        }
