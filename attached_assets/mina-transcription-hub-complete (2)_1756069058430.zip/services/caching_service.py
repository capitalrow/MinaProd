"""
Caching Service
Redis-based caching for improved performance
"""

import redis
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import os
import pickle

logger = logging.getLogger(__name__)

class CacheService:
    def __init__(self):
        self.redis_client = None
        self.fallback_cache = {}  # In-memory fallback
        self.connect_to_redis()
    
    def connect_to_redis(self):
        """Connect to Redis server"""
        try:
            redis_url = os.environ.get('REDIS_URL', 'redis://localhost:6379/0')
            self.redis_client = redis.from_url(
                redis_url,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5,
                retry_on_timeout=True,
                health_check_interval=30
            )
            
            # Test connection
            self.redis_client.ping()
            logger.info("Connected to Redis successfully")
            
        except Exception as e:
            logger.warning(f"Redis connection failed: {str(e)}. Using in-memory fallback.")
            self.redis_client = None
    
    def _get_key(self, prefix: str, identifier: str) -> str:
        """Generate cache key"""
        return f"mina:{prefix}:{identifier}"
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            if self.redis_client:
                value = self.redis_client.get(key)
                if value:
                    return json.loads(value)
            else:
                # Fallback to in-memory cache
                cache_entry = self.fallback_cache.get(key)
                if cache_entry and cache_entry['expires'] > datetime.utcnow():
                    return cache_entry['value']
                elif cache_entry:
                    # Expired entry
                    del self.fallback_cache[key]
                    
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {str(e)}")
        
        return None
    
    def set(self, key: str, value: Any, ttl: int = 3600) -> bool:
        """Set value in cache"""
        try:
            if self.redis_client:
                result = self.redis_client.setex(key, ttl, json.dumps(value, default=str))
                return bool(result)
            else:
                # Fallback to in-memory cache
                self.fallback_cache[key] = {
                    'value': value,
                    'expires': datetime.utcnow() + timedelta(seconds=ttl)
                }
                return True
                
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete key from cache"""
        try:
            if self.redis_client:
                return bool(self.redis_client.delete(key))
            else:
                if key in self.fallback_cache:
                    del self.fallback_cache[key]
                    return True
                return False
                    
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {str(e)}")
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        try:
            if self.redis_client:
                return bool(self.redis_client.exists(key))
            else:
                cache_entry = self.fallback_cache.get(key)
                return cache_entry and cache_entry['expires'] > datetime.utcnow()
                
        except Exception as e:
            logger.error(f"Cache exists error for key {key}: {str(e)}")
            return False
    
    def get_transcription(self, audio_hash: str) -> Optional[str]:
        """Get cached transcription result"""
        key = self._get_key('transcription', audio_hash)
        return self.get(key)
    
    def cache_transcription(self, audio_hash: str, transcription: str, ttl: int = 3600) -> bool:
        """Cache transcription result"""
        key = self._get_key('transcription', audio_hash)
        return self.set(key, transcription, ttl)
    
    def get_session_transcript(self, session_id: str) -> Optional[Dict]:
        """Get cached session transcript"""
        key = self._get_key('session_transcript', session_id)
        return self.get(key)
    
    def cache_session_transcript(self, session_id: str, transcript: Dict, ttl: int = 7200) -> bool:
        """Cache session transcript"""
        key = self._get_key('session_transcript', session_id)
        return self.set(key, transcript, ttl)
    
    def get_user_sessions(self, user_id: str) -> Optional[list]:
        """Get cached user sessions"""
        key = self._get_key('user_sessions', user_id)
        return self.get(key)
    
    def cache_user_sessions(self, user_id: str, sessions: list, ttl: int = 1800) -> bool:
        """Cache user sessions"""
        key = self._get_key('user_sessions', user_id)
        return self.set(key, sessions, ttl)
    
    def get_analytics(self, user_id: str, time_range: str) -> Optional[Dict]:
        """Get cached analytics"""
        key = self._get_key('analytics', f"{user_id}:{time_range}")
        return self.get(key)
    
    def cache_analytics(self, user_id: str, time_range: str, analytics: Dict, ttl: int = 1800) -> bool:
        """Cache analytics data"""
        key = self._get_key('analytics', f"{user_id}:{time_range}")
        return self.set(key, analytics, ttl)
    
    def invalidate_user_cache(self, user_id: str) -> bool:
        """Invalidate all cache entries for a user"""
        try:
            patterns = [
                self._get_key('user_sessions', user_id),
                self._get_key('analytics', f"{user_id}:*")
            ]
            
            if self.redis_client:
                # Use Redis pattern matching
                for pattern in patterns:
                    keys = self.redis_client.keys(pattern)
                    if keys:
                        self.redis_client.delete(*keys)
            else:
                # Fallback cache pattern matching
                keys_to_delete = []
                for key in self.fallback_cache.keys():
                    for pattern in patterns:
                        if pattern.replace('*', '') in key:
                            keys_to_delete.append(key)
                
                for key in keys_to_delete:
                    del self.fallback_cache[key]
            
            return True
            
        except Exception as e:
            logger.error(f"Cache invalidation error for user {user_id}: {str(e)}")
            return False
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache performance statistics"""
        try:
            if self.redis_client:
                info = self.redis_client.info()
                return {
                    'type': 'redis',
                    'connected': True,
                    'used_memory': info.get('used_memory_human', 'N/A'),
                    'connected_clients': info.get('connected_clients', 0),
                    'total_commands_processed': info.get('total_commands_processed', 0),
                    'keyspace_hits': info.get('keyspace_hits', 0),
                    'keyspace_misses': info.get('keyspace_misses', 0),
                    'hit_rate': self._calculate_hit_rate(
                        info.get('keyspace_hits', 0),
                        info.get('keyspace_misses', 0)
                    )
                }
            else:
                return {
                    'type': 'in_memory',
                    'connected': False,
                    'entries': len(self.fallback_cache),
                    'memory_usage': 'N/A'
                }
                
        except Exception as e:
            logger.error(f"Cache stats error: {str(e)}")
            return {'type': 'error', 'connected': False, 'error': str(e)}
    
    def _calculate_hit_rate(self, hits: int, misses: int) -> str:
        """Calculate cache hit rate percentage"""
        total = hits + misses
        if total == 0:
            return "0%"
        return f"{(hits / total * 100):.2f}%"
    
    def health_check(self) -> bool:
        """Health check for cache service"""
        try:
            if self.redis_client:
                self.redis_client.ping()
                return True
            else:
                # In-memory cache is always available
                return True
                
        except Exception as e:
            logger.error(f"Cache health check failed: {str(e)}")
            return False
    
    def cleanup_expired(self):
        """Clean up expired entries (for in-memory cache)"""
        if not self.redis_client:
            current_time = datetime.utcnow()
            expired_keys = [
                key for key, entry in self.fallback_cache.items()
                if entry['expires'] <= current_time
            ]
            
            for key in expired_keys:
                del self.fallback_cache[key]
            
            logger.info(f"Cleaned up {len(expired_keys)} expired cache entries")

# Global cache service instance
cache_service = CacheService()