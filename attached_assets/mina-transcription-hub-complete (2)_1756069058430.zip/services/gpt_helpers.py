"""
GPT Helper Functions for Mina Pro
Post-transcription GPT-4o analysis for summaries, action items, and sentiment
"""

import os
import json
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

# the newest OpenAI model is "gpt-4" which was released May 13, 2024.
# do not change this unless explicitly requested by the user
OPENAI_CLIENT = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def gpt_generate_summary(transcript: str) -> dict:
    """Generate a comprehensive summary using GPT-4o"""
    try:
        response = OPENAI_CLIENT.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert meeting summarizer. Create a concise, professional summary that captures the key points, decisions, and outcomes. Respond with JSON format."
                },
                {
                    "role": "user",
                    "content": f"Please summarize this transcript and provide a JSON response with 'summary' and 'key_points' fields:\n\n{transcript}"
                }
            ],
            response_format={"type": "json_object"},
            max_tokens=500,
            temperature=0.3
        )
        
        result = json.loads(response.choices[0].message.content)
        logger.info("GPT-4o summary generated successfully")
        return {
            "status": "success",
            "summary": result.get("summary", ""),
            "key_points": result.get("key_points", [])
        }
        
    except Exception as e:
        logger.error(f"GPT summary generation failed: {e}")
        return {
            "status": "error",
            "summary": "Summary generation failed",
            "key_points": []
        }

def gpt_extract_actions(transcript: str) -> dict:
    """Extract action items using GPT-4o"""
    try:
        response = OPENAI_CLIENT.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert at extracting action items from meeting transcripts. Identify specific tasks, assignments, and follow-ups. Respond with JSON format."
                },
                {
                    "role": "user",
                    "content": f"Extract action items from this transcript and provide a JSON response with 'actions' array (each with 'task', 'assignee', 'deadline' fields):\n\n{transcript}"
                }
            ],
            response_format={"type": "json_object"},
            max_tokens=400,
            temperature=0.2
        )
        
        result = json.loads(response.choices[0].message.content)
        logger.info("GPT-4o action items extracted successfully")
        return {
            "status": "success",
            "actions": result.get("actions", [])
        }
        
    except Exception as e:
        logger.error(f"GPT action extraction failed: {e}")
        return {
            "status": "error",
            "actions": []
        }

def gpt_analyse_sentiment(transcript: str) -> dict:
    """Analyze sentiment and tone using GPT-4o"""
    try:
        response = OPENAI_CLIENT.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert at analyzing meeting sentiment and tone. Evaluate the overall mood, engagement level, and emotional tone. Respond with JSON format."
                },
                {
                    "role": "user",
                    "content": f"Analyze the sentiment and tone of this transcript and provide a JSON response with 'sentiment' (positive/neutral/negative), 'confidence' (0-1), and 'insights' array:\n\n{transcript}"
                }
            ],
            response_format={"type": "json_object"},
            max_tokens=300,
            temperature=0.3
        )
        
        result = json.loads(response.choices[0].message.content)
        logger.info("GPT-4o sentiment analysis completed successfully")
        return {
            "status": "success",
            "sentiment": result.get("sentiment", "neutral"),
            "confidence": result.get("confidence", 0.5),
            "insights": result.get("insights", [])
        }
        
    except Exception as e:
        logger.error(f"GPT sentiment analysis failed: {e}")
        return {
            "status": "error",
            "sentiment": "neutral",
            "confidence": 0.0,
            "insights": []
        }