"""
Chunk Manager for Live Transcription
Handles chunk metadata, logging, and session replay functionality
"""
import json
import os
import logging
from datetime import datetime
from typing import Dict, List, Any
import uuid

logger = logging.getLogger(__name__)

class ChunkManager:
    """
    Manages transcription chunks with metadata tracking and replay capability
    """
    
    def __init__(self):
        self.sessions = {}
        self.data_dir = "instance/chunks"
        os.makedirs(self.data_dir, exist_ok=True)
    
    def create_chunk(self, session_id: str, chunk_data: bytes, chunk_number: int) -> Dict[str, Any]:
        """
        Create and track a new chunk
        
        Args:
            session_id: Session identifier
            chunk_data: Audio chunk data
            chunk_number: Sequential chunk number
            
        Returns:
            Chunk metadata dictionary
        """
        chunk_id = str(uuid.uuid4())
        
        chunk_metadata = {
            "chunk_id": chunk_id,
            "session_id": session_id,
            "chunk_number": chunk_number,
            "start_time": datetime.utcnow().isoformat(),
            "size_bytes": len(chunk_data),
            "status": "created",
            "model_used": None,
            "confidence": None,
            "fallback_used": False,
            "processing_time_ms": None,
            "transcript": None,
            "error": None
        }
        
        # Initialize session if needed
        if session_id not in self.sessions:
            self.sessions[session_id] = {
                "session_id": session_id,
                "created_at": datetime.utcnow().isoformat(),
                "chunks": [],
                "total_chunks": 0,
                "successful_chunks": 0,
                "failed_chunks": 0,
                "fallback_chunks": 0
            }
        
        # Add chunk to session
        self.sessions[session_id]["chunks"].append(chunk_metadata)
        self.sessions[session_id]["total_chunks"] += 1
        
        logger.info(f"[CHUNK_CREATED] Session: {session_id}, Chunk: {chunk_number}, ID: {chunk_id}")
        
        return chunk_metadata
    
    def update_chunk_result(self, session_id: str, chunk_id: str, result: Dict[str, Any], 
                           processing_time_ms: int) -> None:
        """
        Update chunk with transcription result
        
        Args:
            session_id: Session identifier
            chunk_id: Chunk identifier
            result: Transcription result
            processing_time_ms: Processing time in milliseconds
        """
        if session_id not in self.sessions:
            logger.error(f"Session {session_id} not found")
            return
        
        # Find and update chunk
        for chunk in self.sessions[session_id]["chunks"]:
            if chunk["chunk_id"] == chunk_id:
                chunk["end_time"] = datetime.utcnow().isoformat()
                chunk["processing_time_ms"] = processing_time_ms
                
                if result.get("status") == "success":
                    chunk["status"] = "success"
                    chunk["model_used"] = result.get("model", "unknown")
                    chunk["confidence"] = result.get("confidence", 0.0)
                    chunk["fallback_used"] = result.get("fallback_used", False)
                    chunk["transcript"] = result.get("text", "")
                    
                    # Update session stats
                    self.sessions[session_id]["successful_chunks"] += 1
                    if chunk["fallback_used"]:
                        self.sessions[session_id]["fallback_chunks"] += 1
                        
                    logger.info(f"[CHUNK_SUCCESS] ID: {chunk_id}, Model: {chunk['model_used']}, "
                               f"Fallback: {chunk['fallback_used']}, Confidence: {chunk['confidence']:.2f}")
                else:
                    chunk["status"] = "failed"
                    chunk["error"] = result.get("error", "Unknown error")
                    self.sessions[session_id]["failed_chunks"] += 1
                    
                    logger.error(f"[CHUNK_FAILED] ID: {chunk_id}, Error: {chunk['error']}")
                
                break
        
        # Save session to file
        self._save_session(session_id)
    
    def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        """Get comprehensive session statistics"""
        if session_id not in self.sessions:
            return {"error": "Session not found"}
        
        session = self.sessions[session_id]
        
        # Calculate advanced stats
        total_chunks = session["total_chunks"]
        successful_chunks = session["successful_chunks"]
        failed_chunks = session["failed_chunks"]
        fallback_chunks = session["fallback_chunks"]
        
        success_rate = (successful_chunks / total_chunks * 100) if total_chunks > 0 else 0
        fallback_rate = (fallback_chunks / total_chunks * 100) if total_chunks > 0 else 0
        
        # Average confidence
        confidences = [chunk["confidence"] for chunk in session["chunks"] 
                      if chunk["confidence"] is not None]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        
        # Processing times
        processing_times = [chunk["processing_time_ms"] for chunk in session["chunks"] 
                           if chunk["processing_time_ms"] is not None]
        avg_processing_time = sum(processing_times) / len(processing_times) if processing_times else 0
        
        return {
            "session_id": session_id,
            "total_chunks": total_chunks,
            "successful_chunks": successful_chunks,
            "failed_chunks": failed_chunks,
            "fallback_chunks": fallback_chunks,
            "success_rate": round(success_rate, 1),
            "fallback_rate": round(fallback_rate, 1),
            "avg_confidence": round(avg_confidence, 2),
            "avg_processing_time_ms": round(avg_processing_time, 1),
            "total_transcript_words": sum(len(chunk.get("transcript", "").split()) 
                                         for chunk in session["chunks"]),
            "session_duration": self._calculate_session_duration(session_id)
        }
    
    def get_chunk_replay_data(self, session_id: str) -> List[Dict[str, Any]]:
        """Get chunk data for session replay"""
        if session_id not in self.sessions:
            return []
        
        chunks = self.sessions[session_id]["chunks"]
        
        replay_data = []
        for chunk in chunks:
            replay_data.append({
                "chunk_number": chunk["chunk_number"],
                "timestamp": chunk["start_time"],
                "model_used": chunk["model_used"],
                "confidence": chunk["confidence"],
                "fallback_used": chunk["fallback_used"],
                "transcript": chunk["transcript"],
                "processing_time_ms": chunk["processing_time_ms"],
                "status": chunk["status"]
            })
        
        return replay_data
    
    def _save_session(self, session_id: str) -> None:
        """Save session data to file"""
        if session_id in self.sessions:
            file_path = os.path.join(self.data_dir, f"{session_id}.json")
            try:
                with open(file_path, 'w') as f:
                    json.dump(self.sessions[session_id], f, indent=2)
            except Exception as e:
                logger.error(f"Failed to save session {session_id}: {e}")
    
    def load_session(self, session_id: str) -> bool:
        """Load session from file"""
        file_path = os.path.join(self.data_dir, f"{session_id}.json")
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    self.sessions[session_id] = json.load(f)
                return True
        except Exception as e:
            logger.error(f"Failed to load session {session_id}: {e}")
        return False
    
    def _calculate_session_duration(self, session_id: str) -> str:
        """Calculate total session duration"""
        if session_id not in self.sessions:
            return "0:00"
        
        chunks = self.sessions[session_id]["chunks"]
        if not chunks:
            return "0:00"
        
        try:
            start_time = datetime.fromisoformat(chunks[0]["start_time"].replace('Z', '+00:00'))
            end_time = datetime.fromisoformat(chunks[-1].get("end_time", chunks[-1]["start_time"]).replace('Z', '+00:00'))
            
            duration = end_time - start_time
            total_seconds = int(duration.total_seconds())
            
            minutes = total_seconds // 60
            seconds = total_seconds % 60
            
            return f"{minutes}:{seconds:02d}"
        except:
            return "0:00"
    
    def clear_session(self, session_id: str) -> bool:
        """Clear session data"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            
            # Remove file
            file_path = os.path.join(self.data_dir, f"{session_id}.json")
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                logger.error(f"Failed to delete session file {session_id}: {e}")
            
            return True
        return False

# Global chunk manager instance
chunk_manager = ChunkManager()