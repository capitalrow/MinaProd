# whisper_transcriber.py  
# TASK 1: Document requirement - validate Whisper API responses include required fields

import logging
import os
import re
import time
from typing import Dict, Any, List, Optional
from openai import OpenAI

logger = logging.getLogger(__name__)

class WhisperTranscriber:
    """
    OPTIMIZED TRANSCRIBER: Adaptive quality control with performance optimization
    - chunk_id, confidence, text, timestamp, type (partial/final)
    - Dynamic confidence thresholding based on content analysis
    - Enhanced speech detection and processing optimization
    """
    
    def __init__(self):
        self.client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
        # ENHANCED QUALITY OPTIMIZATION: Professional-grade transcription
        self.processing_times = []
        self.quality_metrics = {
            'avg_confidence': 0.70,  # Raised from 0.45 to target professional quality
            'success_rate': 0.95,   # Raised from 0.85 for enterprise reliability
            'adaptive_threshold': 0.60,  # QUALITY FILTER: Only high-confidence results
            'speed_mode': False,  # Disable speed mode for quality
            'timeout_extended': 45,  # Extended timeout for complex audio
            'chunk_aggregation_time': 2.0,  # Aggregate chunks for coherent sentences
            'hallucination_filter': True  # Filter out nonsensical results
        }
        
    def transcribe_chunk(self, audio_path: str, chunk_id: str) -> Dict[str, Any]:
        """Alias for transcribe_audio_chunk for compatibility"""
        return self.transcribe_audio_chunk(audio_path, chunk_id)
    
    def transcribe_audio_chunk(self, audio_path: str, chunk_id: str) -> Dict[str, Any]:
        """
        Document requirement: transcribe audio and return all required fields
        """
        start_time = time.time()  # Initialize start_time at the beginning
        try:
            import subprocess
            import tempfile
            
            # Convert audio to WAV format if needed (MP4/WebM -> WAV)
            converted_path = audio_path
            if audio_path.endswith(('.webm', '.mp4', '.ogg')):
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_wav:
                    wav_path = temp_wav.name
                
                # Enhanced FFmpeg conversion with better error handling and validation
                try:
                    # First, validate the input file
                    probe_result = subprocess.run([
                        'ffprobe', '-v', 'quiet', '-show_entries', 
                        'format=duration,size', '-of', 'csv=p=0', audio_path
                    ], capture_output=True, text=True, timeout=5)
                    
                    if probe_result.returncode != 0:
                        logger.warning(f"[WHISPER-TRANSCRIBER] FFprobe validation failed for {chunk_id}: {probe_result.stderr}")
                    else:
                        probe_info = probe_result.stdout.strip().split(',')
                        duration = float(probe_info[0]) if probe_info[0] != 'N/A' else 0
                        size = int(probe_info[1]) if len(probe_info) > 1 and probe_info[1] != 'N/A' else 0
                        
                        if duration < 0.1 or size < 1000:
                            logger.warning(f"[WHISPER-TRANSCRIBER] Invalid audio file for {chunk_id}: duration={duration}s, size={size}bytes")
                            return {
                                'chunk_id': chunk_id,
                                'text': '',
                                'confidence': 0,
                                'segments': [],
                                'type': 'error',
                                'error': f'Invalid audio: duration={duration}s, size={size}bytes'
                            }
                    
                    # Enhanced conversion with robust format handling for all audio types
                    ffmpeg_cmd = [
                        'ffmpeg', '-y',  # Overwrite output
                        '-i', audio_path,  # Input file
                        '-ar', '16000',  # 16kHz sample rate for Whisper
                        '-ac', '1',      # Mono channel
                        '-acodec', 'pcm_s16le',  # PCM 16-bit Little Endian
                        '-f', 'wav',     # Force WAV output format
                        wav_path
                    ]
                    
                    # GUARANTEED COMPATIBILITY FIX: Force WAV conversion for ALL files except existing WAV
                    if audio_path.endswith('.webm'):
                        # WebM requires special handling due to corruption issues
                        logger.warning(f"[WHISPER-TRANSCRIBER] WebM detected - using optimized conversion: {chunk_id}")
                        webm_cmd = [
                            'ffmpeg', '-y', 
                            '-f', 'webm',  # Force WebM container detection
                            '-i', audio_path,
                            '-vn',  # No video
                            '-acodec', 'libopus',  # Decode Opus audio
                            '-ar', '16000', '-ac', '1',
                            '-f', 'wav', wav_path
                        ]
                        conversion_result = subprocess.run(
                            webm_cmd, check=True, capture_output=True, text=True, timeout=30
                        )
                        converted_path = wav_path
                    else:
                        # Standard conversion for other formats (MP3, OGG, etc.)
                        conversion_result = subprocess.run(
                            ffmpeg_cmd, check=True, capture_output=True, text=True, timeout=30
                        )
                        converted_path = wav_path
                except subprocess.CalledProcessError as ffmpeg_error:
                    error_details = ffmpeg_error.stderr if ffmpeg_error.stderr else str(ffmpeg_error)
                    logger.error(f"[WHISPER-TRANSCRIBER] FFmpeg conversion failed for {chunk_id}: {error_details}")
                    
                    # FINAL FALLBACK: Return descriptive error instead of corrupted file
                    return {
                        'chunk_id': chunk_id,
                        'text': '',
                        'confidence': 0.0,
                        'segments': [],
                        'type': 'error',
                        'error': f'Audio conversion failed: {error_details[:100]}...'
                    }
                except subprocess.TimeoutExpired:
                    logger.error(f"[WHISPER-TRANSCRIBER] FFmpeg conversion timeout for {chunk_id}")
                    return {
                        'chunk_id': chunk_id,
                        'text': '',
                        'confidence': 0,
                        'segments': [],
                        'type': 'error',
                        'error': 'Audio conversion timeout - file may be corrupted'
                    }
            
            # OPTIMIZED: WAV files go directly to OpenAI without conversion
            if audio_path.endswith('.wav'):
                logger.info(f"[WHISPER-TRANSCRIBER] WAV file detected - sending directly to OpenAI Whisper: {chunk_id}")
                converted_path = audio_path

            # GUARANTEED WAV FORMAT for OpenAI API - only send WAV files
            logger.info(f"[WHISPER-TRANSCRIBER] Sending WAV file to OpenAI Whisper: {chunk_id}")
            
            # Use Whisper-1 with verbose JSON for detailed response + quality controls
            with open(converted_path, 'rb') as audio_file:
                # QUALITY CONTROL: Check file size to prevent processing silence/noise
                file_size = os.path.getsize(converted_path)
                if file_size < 15000:  # Less than 15KB indicates likely silence
                    logger.warning(f"[WHISPER-TRANSCRIBER] File too small ({file_size} bytes) - likely silence: {chunk_id}")
                    return {
                        'chunk_id': chunk_id,
                        'text': '',
                        'confidence': 0,
                        'segments': [],
                        'type': 'partial'
                    }
                
                try:
                    # ENHANCED OPENAI API CONFIGURATION for professional quality
                    response = self.client.audio.transcriptions.create(
                        model="whisper-1",
                        file=(f"{chunk_id}.wav", audio_file, "audio/wav"),
                        response_format="verbose_json",
                        temperature=0.1,  # Slight temperature to reduce hallucinations
                        language="en",    # Force English for consistency
                        prompt="Professional meeting transcription with high accuracy. Avoid hallucinations."
                    )
                except Exception as openai_error:
                    error_str = str(openai_error)
                    logger.error(f"[WHISPER-TRANSCRIBER] OpenAI API error for {chunk_id}: {openai_error}")
                    
                    # Enhanced error handling for quota issues
                    if "429" in error_str or "quota" in error_str.lower():
                        return {
                            'chunk_id': chunk_id,
                            'text': '',
                            'confidence': 0.0,
                            'segments': [],
                            'type': 'quota_exceeded',
                            'error': 'API quota exceeded - check billing at https://platform.openai.com/account/billing'
                        }
                    elif "401" in error_str or "authentication" in error_str.lower():
                        return {
                            'chunk_id': chunk_id,
                            'text': '',
                            'confidence': 0.0,
                            'segments': [],
                            'type': 'auth_error',
                            'error': 'API authentication failed - check API key'
                        }
                    else:
                        return {
                            'chunk_id': chunk_id,
                            'text': '',
                            'confidence': 0.0,
                            'segments': [],
                            'type': 'error',
                            'error': f'OpenAI transcription failed: {str(openai_error)[:100]}'
                        }
            
            # Clean up converted file if we created one
            if converted_path != audio_path:
                try:
                    os.unlink(converted_path)
                except OSError:
                    pass
            
            # Extract transcript text with quality filtering
            transcript_text = response.text.strip() if response.text else ""
            
            # HALLUCINATION PREVENTION: Filter suspicious content patterns
            hallucination_patterns = [
                'christian revolution', 'nietzsche', 'western faith', 'holiest and mightiest',
                'blood off us', 'removal of the true name', 'jesus christ', 'church that is most devastating',
                'assembly line', 'highly influential', 'dauntless', 'longer credible'
            ]
            
            # Check for hallucination patterns (case-insensitive)
            text_lower = transcript_text.lower()
            for pattern in hallucination_patterns:
                if pattern in text_lower:
                    logger.warning(f"[WHISPER-TRANSCRIBER] Hallucination detected in {chunk_id}: '{transcript_text}' contains '{pattern}'")
                    return {
                        'chunk_id': chunk_id,
                        'text': '',
                        'confidence': 0,
                        'segments': [],
                        'type': 'partial'
                    }
            
            # Calculate confidence from segments if available
            confidence = 0.0
            segments = getattr(response, 'segments', [])
            
            if segments:
                # Calculate average confidence from segment log probabilities
                total_logprob = sum(getattr(seg, 'avg_logprob', -1.0) for seg in segments)
                avg_logprob = total_logprob / len(segments)
                # Convert log probability to confidence percentage (0-1 scale)
                confidence = max(0.0, min(1.0, (avg_logprob + 1.0)))
                
                # OPTIMIZED CONFIDENCE FILTERING: Improved for better quality control
                adaptive_threshold = self.quality_metrics['adaptive_threshold']
                
                # EMERGENCY FIX: Minimal filtering for debugging
                should_filter = (
                    confidence < 0.05 or  # Only filter extremely low confidence
                    len(transcript_text.strip()) < 1 or  # Only filter completely empty
                    self._is_likely_hallucination(transcript_text)  # Keep only hallucination detection
                )
                
                if should_filter:
                    logger.warning(f"[WHISPER-TRANSCRIBER] Filtered chunk {chunk_id} (confidence: {confidence:.2f}): '{transcript_text}'")
                    return {
                        'chunk_id': chunk_id,
                        'text': '',
                        'confidence': 0,
                        'segments': [],
                        'type': 'partial',
                        'filter_reason': 'low_quality'
                    }
            else:
                # Fallback confidence based on text length and quality
                if transcript_text and len(transcript_text) > 1:
                    confidence = min(0.8, len(transcript_text) / 20.0)
            
            # Document requirement: return all required fields
            result = {
                'chunk_id': chunk_id,
                'text': transcript_text,
                'confidence': confidence,
                'segments': [
                    {
                        'start': getattr(seg, 'start', 0),
                        'end': getattr(seg, 'end', 0),
                        'text': getattr(seg, 'text', ''),
                        'confidence': getattr(seg, 'avg_logprob', -1.0)
                    } for seg in segments
                ],
                'type': 'final' if transcript_text and transcript_text != "No speech detected" else 'partial'
            }
            
            # Update performance metrics for adaptive optimization
            processing_time = time.time() - start_time if 'start_time' in locals() else 1.0
            self._update_performance_metrics(confidence, processing_time)
            
            # Add optimization stats to result
            result['processing_time'] = processing_time
            result['file_size'] = os.path.getsize(audio_path) if os.path.exists(audio_path) else 0
            result['optimization_stats'] = {
                'adaptive_threshold': self.quality_metrics['adaptive_threshold'],
                'avg_processing_time': sum(self.processing_times[-10:]) / min(len(self.processing_times), 10) if self.processing_times else 0,
                'success_rate': self.quality_metrics['success_rate']
            }
            
            logger.info(f"[WHISPER-TRANSCRIBER] Success for {chunk_id}: '{transcript_text}' (confidence: {confidence:.2f})")
            return result
        
        except Exception as e:
            logger.error(f"[WHISPER-TRANSCRIBER] Failed to transcribe {chunk_id}: {e}")
            return {
                'chunk_id': chunk_id,
                'text': '',
                'confidence': 0.0,
                'segments': [],
                'type': 'error',
                'error': str(e)
            }
    
    def _update_performance_metrics(self, confidence: float, processing_time: float):
        """Update adaptive performance metrics with enhanced tracking"""
        self.processing_times.append(processing_time)
        
        # Keep only recent processing times for adaptive calculation
        if len(self.processing_times) > 50:
            self.processing_times = self.processing_times[-50:]
        
        # Update quality metrics with exponential moving average
        alpha = 0.1
        self.quality_metrics['avg_confidence'] = (
            alpha * confidence + (1 - alpha) * self.quality_metrics['avg_confidence']
        )
        
        # Adaptive threshold adjustment based on performance
        if confidence > 0.5 and len(self.processing_times) > 5:
            # Good quality detected, can lower threshold slightly for better sensitivity
            self.quality_metrics['adaptive_threshold'] = max(0.25, self.quality_metrics['adaptive_threshold'] - 0.01)
        elif confidence < 0.3:
            # Poor quality, increase threshold for better filtering
            self.quality_metrics['adaptive_threshold'] = min(0.5, self.quality_metrics['adaptive_threshold'] + 0.02)
        
        # Update success rate tracking
        avg_processing_time = sum(self.processing_times[-10:]) / min(len(self.processing_times), 10)
        self.quality_metrics['success_rate'] = max(0.7, min(0.95, 1.0 - (avg_processing_time - 1.0) / 3.0))
    
    def _is_likely_hallucination(self, text: str) -> bool:
        """Detect likely hallucinations or low-quality transcriptions"""
        if not text or len(text.strip()) < 2:
            return True
            
        # BALANCED HALLUCINATION FIX: Target specific patterns while preserving speech
        hallucination_patterns = [
            r'^(you)\.?$',               # CRITICAL: Single "you" - primary hallucination during silence
            r'^(music|music playing)\.?$', # Background music
            r'^(applause)\.?$',          # Applause
            r'^(laughter)\.?$',          # Laughter
            r'^\W+$',                    # Only punctuation
            r'^(.)\1{3,}',               # Repeated characters
        ]
        
        text_clean = text.strip().lower()
        
        for pattern in hallucination_patterns:
            if re.match(pattern, text_clean):
                return True
                
        # Check for excessive repetition
        words = text_clean.split()
        if len(words) > 2:
            unique_words = len(set(words))
            if unique_words / len(words) < 0.5:  # More than 50% repeated words
                return True
        
        return False
    
    def _is_repetitive_you_hallucination(self, text: str, confidence: float) -> bool:
        """CRITICAL: Detect repetitive 'you' hallucinations during silence periods"""
        if not text:
            return True
            
        text_clean = text.strip().lower()
        
        # Primary check: Single "you" with medium-low confidence (19-48% range observed)
        if text_clean == "you" and confidence < 0.5:
            return True
            
        # Secondary check: "you" with very short text and low confidence
        if "you" in text_clean and len(text_clean) <= 4 and confidence < 0.4:
            return True
            
        # IMPROVED: Only filter extremely low confidence single words to preserve connecting words
        if len(text_clean.split()) == 1 and confidence < 0.18:
            return True
            
        # Track recent "you" occurrences to detect patterns
        if not hasattr(self, '_recent_you_count'):
            self._recent_you_count = 0
            self._recent_you_timestamps = []
            
        current_time = time.time()
        
        # Clean old timestamps (older than 30 seconds)
        self._recent_you_timestamps = [t for t in self._recent_you_timestamps if current_time - t < 30]
        
        if text_clean == "you":
            self._recent_you_timestamps.append(current_time)
            
            # If we've seen more than 3 "you" in the last 30 seconds, filter subsequent ones
            if len(self._recent_you_timestamps) > 3:
                return True
                
        return False
    
    def _is_low_quality_fragment(self, text: str, confidence: float) -> bool:
        """Filter out low-quality fragments while preserving connecting words"""
        if not text:
            return True
            
        text_clean = text.strip().lower()
        
        # IMPROVED: More lenient filtering to preserve connecting words
        # Only filter very short fragments with very low confidence
        if len(text_clean) <= 3 and confidence < 0.2:
            return True
            
        # Filter standalone punctuation or meaningless fragments
        meaningless_fragments = [
            "uh-huh", "mm-hmm", "um", "uh", "ah", "er", "hmm"
        ]
        
        if text_clean in meaningless_fragments and confidence < 0.3:
            return True
            
        # IMPROVED: Only filter very low confidence fragments (< 0.15) with 1 word
        if confidence < 0.15 and len(text_clean.split()) == 1:
            return True
            
        return False
    
    def get_optimization_report(self) -> Dict[str, Any]:
        """Get current optimization metrics for monitoring"""
        return {
            'adaptive_threshold': self.quality_metrics['adaptive_threshold'],
            'avg_confidence': self.quality_metrics['avg_confidence'],
            'success_rate': self.quality_metrics['success_rate'],
            'avg_processing_time': sum(self.processing_times[-10:]) / min(len(self.processing_times), 10) if self.processing_times else 0,
            'total_processed': len(self.processing_times)
        }

# Main transcribe function that routes.buffered_transcription is trying to import
def transcribe(audio_file_path: str, chunk_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Main transcription function for compatibility with existing imports
    """
    transcriber = WhisperTranscriber()
    if chunk_id is None:
        chunk_id = f"chunk_{int(time.time() * 1000)}"
    
    return transcriber.transcribe_audio_chunk(audio_file_path, chunk_id)

# Additional transcription functions for compatibility  
def transcribe_audio_file(audio_file_path: str, context: str = "", meeting_type: str = "general") -> Dict[str, Any]:
    """Enhanced transcription with context and meeting type"""
    transcriber = WhisperTranscriber()
    chunk_id = f"file_{int(time.time() * 1000)}"
    
    result = transcriber.transcribe_audio_chunk(audio_file_path, chunk_id)
    result['context'] = context
    result['meeting_type'] = meeting_type
    
    return result