"""
Context Manager for Enhanced Transcription Quality
Implements sentence boundary detection, context buffering, and semantic validation
"""

import logging
import re
from typing import Dict, Any, List, Optional
from collections import deque
import time

logger = logging.getLogger(__name__)

class ContextManager:
    """
    ENTERPRISE ENHANCEMENT 1: Context-aware sentence assembly
    Buffers transcript fragments and delivers complete thoughts
    """
    
    def __init__(self):
        self.context_buffer = deque(maxlen=10)  # Rolling context window
        self.sentence_fragments = []
        self.last_complete_sentence_time = time.time()
        
        # Sentence boundary patterns
        self.sentence_endings = re.compile(r'[.!?]+\s*$')
        self.sentence_starters = re.compile(r'^[A-Z]')
        self.common_fragments = {
            'and', 'or', 'but', 'the', 'a', 'an', 'to', 'for', 'in', 'on', 'at',
            'with', 'by', 'from', 'about', 'into', 'through', 'during', 'before',
            'after', 'above', 'below', 'between', 'among'
        }
        
        # Language detection patterns
        self.language_patterns = {
            'russian': re.compile(r'[а-яё]', re.IGNORECASE),
            'english': re.compile(r'^[a-z\s.,!?-]+$', re.IGNORECASE)
        }
        
        logger.info("[CONTEXT-MANAGER] Enhanced context awareness initialized")
    
    def detect_language(self, text: str) -> str:
        """Detect primary language of text fragment"""
        if not text.strip():
            return 'unknown'
        
        if self.language_patterns['russian'].search(text):
            return 'russian'
        elif self.language_patterns['english'].match(text):
            return 'english'
        return 'mixed'
    
    def is_sentence_fragment(self, text: str) -> bool:
        """Determine if text is likely a sentence fragment"""
        if not text.strip():
            return True
        
        text = text.strip()
        
        # Check for sentence endings
        if self.sentence_endings.search(text):
            return False
        
        # Check for very short fragments
        if len(text.split()) < 2:
            return True
        
        # Check for common fragment starters
        first_word = text.split()[0].lower().strip('.,!?')
        if first_word in self.common_fragments:
            return True
        
        # Check for incomplete thoughts (no verb patterns)
        if len(text.split()) < 3 and not re.search(r'\b(is|are|was|were|have|has|do|does|did|will|would|can|could|should|may|might)\b', text.lower()):
            return True
        
        return False
    
    def buffer_fragment(self, transcript_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        CORE ENHANCEMENT: Buffer fragments and return complete sentences
        
        Args:
            transcript_data: Raw transcription with chunk_id, text, confidence
            
        Returns:
            Complete sentence data or None if still buffering
        """
        text = transcript_data.get('text', '').strip()
        confidence = transcript_data.get('confidence', 0)
        
        if not text:
            return None
        
        # Detect language context
        language = self.detect_language(text)
        
        # Add to context buffer
        self.context_buffer.append({
            'text': text,
            'confidence': confidence,
            'timestamp': time.time(),
            'language': language,
            'chunk_id': transcript_data.get('chunk_id', '')
        })
        
        # Check if this completes a sentence
        if not self.is_sentence_fragment(text):
            # We have a complete sentence, check if we should merge with previous fragments
            complete_sentence = self._assemble_complete_sentence()
            if complete_sentence:
                self.last_complete_sentence_time = time.time()
                return complete_sentence
        
        # Buffer fragments and check for timeout
        self.sentence_fragments.append(transcript_data)
        
        # Force output if buffer is getting full or too much time has passed
        current_time = time.time()
        if (len(self.sentence_fragments) >= 3 or 
            current_time - self.last_complete_sentence_time > 8.0):
            
            forced_sentence = self._force_sentence_assembly()
            if forced_sentence:
                self.last_complete_sentence_time = current_time
                return forced_sentence
        
        return None  # Still buffering
    
    def _assemble_complete_sentence(self) -> Optional[Dict[str, Any]]:
        """Assemble buffered fragments into a complete sentence"""
        if not self.context_buffer:
            return None
        
        # Get recent fragments (last 3-5 items)
        recent_fragments = list(self.context_buffer)[-5:]
        
        # Check language consistency
        languages = [f['language'] for f in recent_fragments]
        primary_language = max(set(languages), key=languages.count)
        
        # Filter fragments by primary language for context consistency
        consistent_fragments = [f for f in recent_fragments if f['language'] == primary_language or f['language'] == 'mixed']
        
        if not consistent_fragments:
            return None
        
        # Combine text
        combined_text = ' '.join(f['text'] for f in consistent_fragments).strip()
        combined_text = re.sub(r'\s+', ' ', combined_text)  # Clean up whitespace
        
        # Calculate weighted confidence
        total_confidence = sum(f['confidence'] for f in consistent_fragments)
        avg_confidence = total_confidence / len(consistent_fragments)
        
        # Clear fragment buffer
        self.sentence_fragments = []
        
        return {
            'text': combined_text,
            'confidence': avg_confidence,
            'timestamp': time.time(),
            'type': 'complete_sentence',
            'language': primary_language,
            'fragment_count': len(consistent_fragments)
        }
    
    def _force_sentence_assembly(self) -> Optional[Dict[str, Any]]:
        """Force assembly when buffer timeout occurs"""
        if not self.sentence_fragments:
            return None
        
        combined_text = ' '.join(f.get('text', '') for f in self.sentence_fragments).strip()
        if not combined_text:
            return None
        
        avg_confidence = sum(f.get('confidence', 0) for f in self.sentence_fragments) / len(self.sentence_fragments)
        
        # Clear buffer
        self.sentence_fragments = []
        
        return {
            'text': combined_text,
            'confidence': avg_confidence,
            'timestamp': time.time(),
            'type': 'assembled_fragments',
            'fragment_count': len(self.sentence_fragments)
        }
    
    def should_output_transcript(self, transcript_data: Dict[str, Any]) -> bool:
        """Determine if transcript should be output immediately or buffered"""
        text = transcript_data.get('text', '').strip()
        confidence = transcript_data.get('confidence', 0)
        
        # Always output high-confidence complete sentences
        if confidence > 0.6 and not self.is_sentence_fragment(text):
            return True
        
        # Buffer everything else for context assembly
        return False