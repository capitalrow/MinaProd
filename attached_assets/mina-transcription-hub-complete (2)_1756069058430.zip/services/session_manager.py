"""
Session Management Service for comprehensive session persistence
"""
import json
import logging
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

class SessionManager:
    @staticmethod
    def create_session(user_id, title=None):
        """Create new transcription session"""
        try:
            # Import here to avoid circular imports
            from models import TranscriptSession as TranscriptionSession
            
            if not title:
                title = f"Recording {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                
            session = TranscriptionSession(
                user_id=user_id,
                title=title,
                status='active'
            )
            
            from app import db
            db.session.add(session)
            db.session.commit()
            
            logger.info(f"✅ Session created: {session.id}")
            return session.id
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session creation failed: {e}")
            from app import db
            db.session.rollback()
            return None
        except Exception as e:
            logger.error(f"❌ Session creation error: {e}")
            return None
    
    @staticmethod
    def save_chunk(session_id, chunk_data):
        """Save transcription chunk to session"""
        try:
            from models import TranscriptSession as TranscriptionSession
            
            # For now, just log chunk data - will implement chunk storage later
            logger.info(f"✅ Chunk data received for session {session_id}: {chunk_data.get('text', '')[:50]}...")
            
            # Update session with basic stats
            from app import db
            session = TranscriptionSession.query.get(session_id)
            if session:
                # Update basic metrics without chunk storage for now
                session.word_count = session.word_count + len(chunk_data.get('text', '').split())
                session.confidence = chunk_data.get('confidence', 0.0)  # Update to latest confidence
                session.processing_time = chunk_data.get('processing_time', 0.0)
            
            db.session.commit()
            logger.info(f"✅ Chunk saved to session {session_id}")
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Chunk save failed: {e}")
            from app import db
            db.session.rollback()
        except Exception as e:
            logger.error(f"❌ Chunk save error: {e}")
    
    @staticmethod
    def complete_session(session_id, final_transcript, ai_summary=None):
        """Complete session with final transcript and analysis"""
        try:
            from models.session_models import TranscriptionSession
            
            session = TranscriptionSession.query.get(session_id)
            if not session:
                return False
                
            session.full_transcript = final_transcript
            session.status = 'completed'
            session.updated_at = datetime.utcnow()
            
            if ai_summary:
                session.ai_summary = ai_summary.get('summary')
                session.key_points = json.dumps(ai_summary.get('key_points', []))
                session.action_items = json.dumps(ai_summary.get('action_items', []))
            
            from app import db
            db.session.commit()
            logger.info(f"✅ Session completed: {session_id}")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session completion failed: {e}")
            from app import db
            db.session.rollback()
            return False
        except Exception as e:
            logger.error(f"❌ Session completion error: {e}")
            return False
    
    @staticmethod
    def get_user_sessions(user_id, limit=50, offset=0):
        """Get user's transcription sessions"""
        try:
            from models.session_models import TranscriptionSession
            
            sessions = TranscriptionSession.query.filter_by(user_id=user_id)\
                .order_by(TranscriptionSession.created_at.desc())\
                .limit(limit).offset(offset).all()
                
            return [{
                'id': s.id,
                'title': s.title,
                'created_at': s.created_at.isoformat(),
                'updated_at': s.updated_at.isoformat(),
                'duration_seconds': s.duration_seconds,
                'word_count': s.word_count,
                'confidence_average': s.confidence_average,
                'status': s.status,
                'has_summary': bool(s.ai_summary)
            } for s in sessions]
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session retrieval failed: {e}")
            return []
        except Exception as e:
            logger.error(f"❌ Session retrieval error: {e}")
            return []
    
    @staticmethod
    def get_session_detail(session_id, user_id):
        """Get detailed session information"""
        try:
            from models.session_models import TranscriptionSession
            
            session = TranscriptionSession.query.filter_by(
                id=session_id, user_id=user_id
            ).first()
            
            if not session:
                return None
                
            return {
                'id': session.id,
                'title': session.title,
                'created_at': session.created_at.isoformat(),
                'full_transcript': session.full_transcript,
                'word_count': session.word_count,
                'confidence_average': session.confidence_average,
                'processing_time_average': session.processing_time_average,
                'ai_summary': session.ai_summary,
                'key_points': json.loads(session.key_points) if session.key_points else [],
                'action_items': json.loads(session.action_items) if session.action_items else [],
                'status': session.status
            }
            
        except SQLAlchemyError as e:
            logger.error(f"❌ Session detail retrieval failed: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Session detail error: {e}")
            return None