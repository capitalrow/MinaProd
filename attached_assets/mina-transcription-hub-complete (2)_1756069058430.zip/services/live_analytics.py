"""
Live Analytics Service for Real-time Meeting Intelligence
Provides chunk-by-chunk analysis during live transcription
"""
import logging
import os
import json
from datetime import datetime
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class LiveAnalytics:
    """
    Provides real-time analytics during live transcription sessions
    """
    
    def __init__(self):
        self.session_data = {}  # Store analytics per session
        self.chunk_buffer = {}  # Buffer recent chunks for context
        
    def analyze_interim_content(self, transcript: str, session_id: str) -> Dict[str, Any]:
        """
        Analyze interim transcript content for live insights
        
        Args:
            transcript: Current transcript chunk
            session_id: Session identifier
            
        Returns:
            Live analytics data
        """
        try:
            # Initialize session if new
            if session_id not in self.session_data:
                self.session_data[session_id] = {
                    "action_items": [],
                    "follow_ups": [],
                    "questions": [],
                    "decisions": [],
                    "emotional_tone": {"calm": 0, "stressed": 0, "assertive": 0},
                    "speaker_stats": {"interruptions": 0, "speaking_time": 0},
                    "chunk_count": 0
                }
            
            session = self.session_data[session_id]
            session["chunk_count"] += 1
            
            # Add to chunk buffer
            if session_id not in self.chunk_buffer:
                self.chunk_buffer[session_id] = []
            
            self.chunk_buffer[session_id].append({
                "text": transcript,
                "timestamp": datetime.utcnow().isoformat(),
                "chunk_number": session["chunk_count"]
            })
            
            # Keep only last 5 chunks for context
            if len(self.chunk_buffer[session_id]) > 5:
                self.chunk_buffer[session_id] = self.chunk_buffer[session_id][-5:]
            
            # Analyze current chunk
            analysis = self._analyze_chunk(transcript, session_id)
            
            # Update session data
            self._update_session_analytics(session_id, analysis)
            
            return {
                "status": "success",
                "session_id": session_id,
                "current_analysis": analysis,
                "session_totals": session,
                "live_insights": self._generate_live_insights(session_id)
            }
            
        except Exception as e:
            logger.error(f"Live analytics error: {e}")
            return {"status": "error", "message": str(e)}
    
    def _analyze_chunk(self, transcript: str, session_id: str) -> Dict[str, Any]:
        """Analyze individual chunk for patterns"""
        analysis = {
            "action_items": [],
            "follow_ups": [],
            "questions": [],
            "decisions": [],
            "emotional_indicators": {},
            "speaker_changes": 0
        }
        
        text_lower = transcript.lower()
        
        # Quick pattern detection for live analysis
        # Action item indicators
        action_patterns = [
            "need to", "should", "must", "will do", "action item", 
            "deliverable", "deadline", "assign", "responsible"
        ]
        for pattern in action_patterns:
            if pattern in text_lower:
                analysis["action_items"].append({
                    "text": transcript,
                    "pattern": pattern,
                    "confidence": 0.7
                })
                break
        
        # Follow-up indicators
        followup_patterns = [
            "follow up", "check in", "next steps", "later", "schedule",
            "revisit", "circle back", "touch base"
        ]
        for pattern in followup_patterns:
            if pattern in text_lower:
                analysis["follow_ups"].append({
                    "text": transcript,
                    "pattern": pattern,
                    "confidence": 0.6
                })
                break
        
        # Question detection
        if "?" in transcript or any(q in text_lower for q in ["what", "how", "why", "when", "where", "who"]):
            analysis["questions"].append({
                "text": transcript,
                "type": "question",
                "confidence": 0.8
            })
        
        # Decision indicators
        decision_patterns = ["decided", "decision", "agreed", "concluded", "determined"]
        for pattern in decision_patterns:
            if pattern in text_lower:
                analysis["decisions"].append({
                    "text": transcript,
                    "pattern": pattern,
                    "confidence": 0.7
                })
                break
        
        # Emotional tone indicators (simple heuristics)
        emotional_words = {
            "calm": ["good", "great", "smooth", "easy", "comfortable", "relaxed"],
            "stressed": ["urgent", "deadline", "problem", "issue", "concern", "worried"],
            "assertive": ["definitely", "absolutely", "must", "important", "critical", "priority"]
        }
        
        for emotion, words in emotional_words.items():
            score = sum(1 for word in words if word in text_lower)
            if score > 0:
                analysis["emotional_indicators"][emotion] = score
        
        return analysis
    
    def _update_session_analytics(self, session_id: str, chunk_analysis: Dict[str, Any]) -> None:
        """Update cumulative session analytics"""
        session = self.session_data[session_id]
        
        # Add new findings
        session["action_items"].extend(chunk_analysis["action_items"])
        session["follow_ups"].extend(chunk_analysis["follow_ups"])
        session["questions"].extend(chunk_analysis["questions"])
        session["decisions"].extend(chunk_analysis["decisions"])
        
        # Update emotional tone
        for emotion, score in chunk_analysis["emotional_indicators"].items():
            session["emotional_tone"][emotion] += score
        
        # Keep lists manageable (last 10 items)
        for key in ["action_items", "follow_ups", "questions", "decisions"]:
            session[key] = session[key][-10:]
    
    def _generate_live_insights(self, session_id: str) -> Dict[str, Any]:
        """Generate live insights for UI display"""
        session = self.session_data[session_id]
        
        # Calculate percentages for emotional tone
        total_emotion = sum(session["emotional_tone"].values())
        emotion_percentages = {}
        if total_emotion > 0:
            for emotion, count in session["emotional_tone"].items():
                emotion_percentages[emotion] = round((count / total_emotion) * 100, 1)
        else:
            emotion_percentages = {"calm": 33.3, "stressed": 33.3, "assertive": 33.3}
        
        return {
            "recent_action_items": session["action_items"][-3:],
            "recent_follow_ups": session["follow_ups"][-3:],
            "recent_questions": session["questions"][-3:],
            "emotion_breakdown": emotion_percentages,
            "total_insights": {
                "action_items": len(session["action_items"]),
                "follow_ups": len(session["follow_ups"]),
                "questions": len(session["questions"]),
                "decisions": len(session["decisions"])
            },
            "session_health": self._calculate_session_health(session)
        }
    
    def _calculate_session_health(self, session: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate session health metrics"""
        chunk_count = session["chunk_count"]
        
        if chunk_count == 0:
            return {"score": 100, "status": "starting", "feedback": "Just getting started"}
        
        # Simple scoring based on activity
        action_rate = len(session["action_items"]) / chunk_count
        question_rate = len(session["questions"]) / chunk_count
        
        if action_rate > 0.3:
            status = "productive"
            feedback = "High action item generation"
        elif question_rate > 0.2:
            status = "exploratory"
            feedback = "Lots of questions being asked"
        else:
            status = "conversational"
            feedback = "General discussion"
        
        score = min(100, max(0, 50 + (action_rate * 100) + (question_rate * 50)))
        
        return {
            "score": round(score),
            "status": status,
            "feedback": feedback
        }
    
    def get_session_summary(self, session_id: str) -> Dict[str, Any]:
        """Get complete session analytics summary"""
        if session_id not in self.session_data:
            return {"error": "Session not found"}
        
        session = self.session_data[session_id]
        return {
            "session_id": session_id,
            "analytics": session,
            "insights": self._generate_live_insights(session_id),
            "chunk_history": self.chunk_buffer.get(session_id, [])
        }
    
    def clear_session(self, session_id: str) -> bool:
        """Clear session analytics data"""
        if session_id in self.session_data:
            del self.session_data[session_id]
        if session_id in self.chunk_buffer:
            del self.chunk_buffer[session_id]
        return True

# Global live analytics instance
live_analytics = LiveAnalytics()