"""
Custom Vocabulary Service for Domain-Specific Transcription
Manages user glossaries and terminology for improved accuracy
"""
import os
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)

class CustomVocabulary:
    """
    Manage custom vocabulary and glossaries for improved transcription accuracy
    """
    
    def __init__(self):
        self.default_vocabularies = {
            'tech': [
                'API', 'SDK', 'microservices', 'Kubernetes', 'Docker', 'DevOps',
                'frontend', 'backend', 'database', 'PostgreSQL', 'MongoDB',
                'React', 'Vue', 'Angular', 'JavaScript', 'TypeScript', 'Python'
            ],
            'finance': [
                'KPI', 'ROI', 'EBITDA', 'P&L', 'balance sheet', 'cash flow',
                'revenue', 'expenses', 'budget', 'forecast', 'quarterly',
                'fiscal year', 'CAGR', 'NPV', 'IRR'
            ],
            'healthcare': [
                'EHR', 'EMR', 'HIPAA', 'patient care', 'diagnosis', 'treatment',
                'medication', 'dosage', 'symptoms', 'follow-up', 'referral',
                'insurance', 'copay', 'deductible'
            ],
            'legal': [
                'contract', 'agreement', 'clause', 'liability', 'compliance',
                'regulation', 'statute', 'litigation', 'settlement', 'discovery',
                'deposition', 'plaintiff', 'defendant', 'jurisdiction'
            ],
            'sales': [
                'lead generation', 'pipeline', 'CRM', 'prospect', 'qualification',
                'demo', 'proposal', 'closing', 'upsell', 'cross-sell',
                'retention', 'churn', 'MRR', 'ARR', 'LTV'
            ]
        }
    
    def get_vocabulary_for_context(self, meeting_type: str, custom_terms: List[str] = None) -> List[str]:
        """
        Get vocabulary list for given meeting context
        
        Args:
            meeting_type: Type of meeting (tech, finance, etc.)
            custom_terms: Additional user-defined terms
            
        Returns:
            Combined vocabulary list
        """
        vocabulary = []
        
        # Add default vocabulary for meeting type
        if meeting_type.lower() in self.default_vocabularies:
            vocabulary.extend(self.default_vocabularies[meeting_type.lower()])
        
        # Add custom terms
        if custom_terms:
            vocabulary.extend(custom_terms)
        
        # Remove duplicates and return
        return list(set(vocabulary))
    
    def create_whisper_prompt(self, vocabulary: List[str], context: str = "") -> str:
        """
        Create optimized prompt for Whisper API including vocabulary
        
        Args:
            vocabulary: List of important terms
            context: Meeting context
            
        Returns:
            Formatted prompt string
        """
        if not vocabulary and not context:
            return ""
        
        prompt_parts = []
        
        if context:
            prompt_parts.append(f"Meeting context: {context}.")
        
        if vocabulary:
            # Limit to most important terms (Whisper has prompt limits)
            important_terms = vocabulary[:20]  # Limit to 20 terms
            prompt_parts.append(f"Key terms: {', '.join(important_terms)}.")
        
        return " ".join(prompt_parts)
    
    def enhance_transcript_with_vocabulary(self, transcript: str, vocabulary: List[str]) -> str:
        """
        Post-process transcript to highlight vocabulary terms
        
        Args:
            transcript: Original transcript
            vocabulary: Vocabulary terms to highlight
            
        Returns:
            Enhanced transcript with vocabulary highlighting
        """
        enhanced = transcript
        
        for term in vocabulary:
            # Case-insensitive replacement with highlighting
            import re
            pattern = re.compile(re.escape(term), re.IGNORECASE)
            enhanced = pattern.sub(f'<mark class="vocab-term" title="Domain term">{term}</mark>', enhanced)
        
        return enhanced
    
    def extract_domain_terms(self, transcript: str, domain: str = "general") -> List[str]:
        """
        Extract potential domain-specific terms from transcript
        
        Args:
            transcript: Transcript text
            domain: Domain context
            
        Returns:
            List of potential domain terms
        """
        terms = []
        
        # Extract capitalized words (potential acronyms/proper nouns)
        import re
        capitalized = re.findall(r'\b[A-Z]{2,}\b', transcript)
        terms.extend(capitalized)
        
        # Extract domain-specific patterns
        if domain == "tech":
            # Look for version numbers, URLs, etc.
            versions = re.findall(r'\b\w+\s*v?\d+\.\d+\b', transcript)
            terms.extend(versions)
        
        elif domain == "finance":
            # Look for monetary amounts, percentages
            money = re.findall(r'\$[\d,]+(?:\.\d{2})?', transcript)
            percentages = re.findall(r'\d+(?:\.\d+)?%', transcript)
            terms.extend(money + percentages)
        
        # Remove duplicates
        return list(set(terms))
    
    def save_user_vocabulary(self, user_id: str, vocabulary: List[str], domain: str = "custom") -> bool:
        """
        Save user's custom vocabulary (placeholder for database integration)
        
        Args:
            user_id: User identifier
            vocabulary: Custom vocabulary terms
            domain: Domain category
            
        Returns:
            Success status
        """
        try:
            # In production, this would save to database
            logger.info(f"Saving vocabulary for user {user_id}: {len(vocabulary)} terms in {domain}")
            return True
        except Exception as e:
            logger.error(f"Failed to save vocabulary: {e}")
            return False
    
    def load_user_vocabulary(self, user_id: str, domain: str = "custom") -> List[str]:
        """
        Load user's custom vocabulary (placeholder for database integration)
        
        Args:
            user_id: User identifier
            domain: Domain category
            
        Returns:
            User's vocabulary terms
        """
        try:
            # In production, this would load from database
            # For now, return empty list
            return []
        except Exception as e:
            logger.error(f"Failed to load vocabulary: {e}")
            return []

# Global vocabulary service instance
custom_vocabulary = CustomVocabulary()