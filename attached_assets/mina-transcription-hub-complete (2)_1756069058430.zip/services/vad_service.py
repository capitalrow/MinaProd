"""
Voice Activity Detection Service for Mina Pro
Implements smart chunking based on silence detection and speech boundaries
"""

import logging
import numpy as np
from typing import Tuple, Optional
import io

logger = logging.getLogger(__name__)

class VADService:
    def __init__(self):
        self.sample_rate = 16000
        self.frame_duration_ms = 30  # 30ms frames
        self.frame_size = int(self.sample_rate * self.frame_duration_ms / 1000)
        
        # OPTIMIZED THRESHOLDS: Enhanced speech detection sensitivity
        self.silence_threshold = 0.02  # Increased from 0.01 to reduce false positives
        self.speech_threshold = 0.05   # New: Higher threshold for confident speech detection
        self.silence_duration_ms = 600  # Reduced from 800ms for better responsiveness
        self.min_speech_duration_ms = 1200  # Reduced from 1500ms for faster processing
        self.max_chunk_duration_ms = 8000   # Reduced from 12s for lower latency
        self.forced_chunk_debounce_ms = 1500  # Reduced from 2s for better responsiveness
        
        # Adaptive sensitivity based on environment
        self.adaptive_mode = True
        self.noise_floor = 0.01
        self.recent_energy_levels = []
        
        # State tracking
        self.silence_frames = 0
        self.speech_frames = 0
        self.is_speaking = False
        
        logger.info("VAD Service initialized with smart chunking")
    
    def analyze_audio_energy(self, audio_data: bytes) -> float:
        """
        Analyze RMS energy of audio data
        
        Args:
            audio_data: Raw audio bytes
            
        Returns:
            RMS energy level (0.0 to 1.0)
        """
        try:
            # Convert bytes to numpy array (assuming 16-bit PCM)
            if len(audio_data) < 2:
                return 0.0
            
            # Simple energy calculation for WebM/raw data
            # This is a simplified approach - in production, you'd decode the audio first
            samples = np.frombuffer(audio_data, dtype=np.uint8).astype(np.float32) / 255.0
            
            if len(samples) == 0:
                return 0.0
            
            # Calculate RMS
            rms = np.sqrt(np.mean(samples ** 2))
            return min(rms, 1.0)
            
        except Exception as e:
            logger.warning(f"Energy analysis failed: {e}")
            return 0.5  # Default to medium energy
    
    def detect_speech_boundary(self, audio_chunk: bytes) -> Tuple[bool, str]:
        """
        OPTIMIZED SPEECH BOUNDARY DETECTION: Adaptive thresholding with enhanced sensitivity
        
        Args:
            audio_chunk: Audio data bytes
            
        Returns:
            Tuple of (should_chunk, reason)
        """
        energy = self.analyze_audio_energy(audio_chunk)
        
        # Adaptive threshold adjustment based on recent audio
        if self.adaptive_mode:
            self.recent_energy_levels.append(energy)
            if len(self.recent_energy_levels) > 20:  # Keep last 20 energy readings
                self.recent_energy_levels.pop(0)
                # Update noise floor based on minimum recent energy
                self.noise_floor = min(self.recent_energy_levels) * 1.5
                # Adjust silence threshold dynamically
                self.silence_threshold = max(0.015, self.noise_floor * 2.0)
        
        # Enhanced speech detection with dual thresholds
        has_confident_speech = energy > self.speech_threshold
        has_possible_speech = energy > self.silence_threshold
        has_speech = has_confident_speech or (has_possible_speech and self.is_speaking)
        
        if has_speech:
            self.speech_frames += 1
            self.silence_frames = 0
            if not self.is_speaking:
                self.is_speaking = True
                logger.debug("Speech started")
        else:
            self.silence_frames += 1
            if self.is_speaking and self.silence_frames > (self.silence_duration_ms / self.frame_duration_ms):
                # Long enough silence after speech - this is a boundary
                self.is_speaking = False
                speech_duration_ms = self.speech_frames * self.frame_duration_ms
                
                # Reset counters
                self.speech_frames = 0
                self.silence_frames = 0
                
                if speech_duration_ms >= self.min_speech_duration_ms:
                    return True, f"Speech boundary detected after {speech_duration_ms:.0f}ms speech"
                else:
                    return False, f"Speech too short ({speech_duration_ms:.0f}ms), continuing"
        
        return False, f"Continuing (energy: {energy:.3f}, speaking: {self.is_speaking})"
    
    def should_create_chunk(self, accumulated_chunks: list, total_duration_ms: float) -> Tuple[bool, str]:
        """
        Determine if accumulated chunks should be processed as a unit
        
        Args:
            accumulated_chunks: List of audio chunks
            total_duration_ms: Total duration of accumulated audio
            
        Returns:
            Tuple of (should_process, reason)
        """
        # Force chunking after maximum duration (10 seconds)
        max_duration_ms = 10000
        if total_duration_ms >= max_duration_ms:
            return True, f"Maximum duration reached ({total_duration_ms:.0f}ms)"
        
        # Force chunking after minimum chunks if we have speech
        min_chunks = 3
        if len(accumulated_chunks) >= min_chunks and total_duration_ms >= self.min_speech_duration_ms:
            # Check if latest chunks have speech energy
            recent_energy = sum(self.analyze_audio_energy(chunk) for chunk in accumulated_chunks[-2:]) / 2
            if recent_energy > self.silence_threshold:
                return True, f"Sufficient speech content ({len(accumulated_chunks)} chunks, {total_duration_ms:.0f}ms)"
        
        return False, f"Accumulating ({len(accumulated_chunks)} chunks, {total_duration_ms:.0f}ms)"
    
    def optimize_chunk_boundaries(self, audio_chunks: list) -> list:
        """
        Optimize chunk boundaries to align with speech patterns
        
        Args:
            audio_chunks: List of raw audio chunks
            
        Returns:
            List of optimized chunks grouped by speech boundaries
        """
        if not audio_chunks:
            return []
        
        optimized_chunks = []
        current_group = []
        
        for i, chunk in enumerate(audio_chunks):
            current_group.append(chunk)
            
            # Analyze if this is a good boundary point
            should_boundary, reason = self.detect_speech_boundary(chunk)
            
            if should_boundary or i == len(audio_chunks) - 1:  # Last chunk
                if current_group:
                    optimized_chunks.append(current_group)
                    logger.debug(f"Created chunk group with {len(current_group)} segments: {reason}")
                    current_group = []
        
        # Add any remaining chunks
        if current_group:
            optimized_chunks.append(current_group)
        
        return optimized_chunks
    
    def reset_state(self):
        """Reset VAD state for new recording session"""
        self.silence_frames = 0
        self.speech_frames = 0
        self.is_speaking = False
        logger.debug("VAD state reset for new session")