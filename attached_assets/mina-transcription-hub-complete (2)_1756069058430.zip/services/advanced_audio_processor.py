# advanced_audio_processor.py
# Voice Activity Detection and Smart Chunking for improved transcription quality

import logging
import numpy as np
import time
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger(__name__)

class AdvancedAudioProcessor:
    """
    Advanced audio processing for improved transcription quality
    Features:
    - Voice Activity Detection (VAD) with smart thresholds
    - Intelligent chunk boundary detection
    - Audio quality analysis and enhancement suggestions
    - Context-aware silence handling
    """
    
    def __init__(self):
        self.chunk_buffer = []
        self.silence_threshold = 0.01  # RMS threshold for silence
        self.voice_threshold = 0.02    # RMS threshold for voice activity
        self.min_speech_duration = 0.5  # Minimum speech duration in seconds
        self.max_silence_gap = 2.0      # Maximum silence gap to merge chunks
        
    def analyze_audio_quality(self, audio_data: bytes, sample_rate: int = 16000) -> Dict[str, Any]:
        """
        Analyze audio quality for transcription optimization
        
        Args:
            audio_data: Raw audio bytes
            sample_rate: Audio sample rate
            
        Returns:
            Quality analysis with recommendations
        """
        try:
            # Convert bytes to numpy array (assuming 16-bit PCM)
            audio_array = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            
            # Calculate audio metrics
            rms_energy = np.sqrt(np.mean(audio_array ** 2))
            peak_amplitude = np.max(np.abs(audio_array))
            zero_crossing_rate = self._calculate_zcr(audio_array)
            
            # Voice activity detection
            is_voice_detected = rms_energy > self.voice_threshold
            is_silence = rms_energy < self.silence_threshold
            
            # Quality score calculation
            quality_score = self._calculate_quality_score(rms_energy, peak_amplitude, zero_crossing_rate)
            
            # Generate recommendations
            recommendations = self._generate_audio_recommendations(
                rms_energy, peak_amplitude, zero_crossing_rate, is_voice_detected
            )
            
            return {
                'quality_score': quality_score,
                'rms_energy': float(rms_energy),
                'peak_amplitude': float(peak_amplitude),
                'zero_crossing_rate': float(zero_crossing_rate),
                'is_voice_detected': is_voice_detected,
                'is_silence': is_silence,
                'duration': len(audio_array) / sample_rate,
                'recommendations': recommendations,
                'optimal_for_transcription': quality_score > 0.3 and is_voice_detected
            }
            
        except Exception as e:
            logger.error(f"Audio quality analysis failed: {e}")
            return {
                'quality_score': 0.0,
                'error': str(e),
                'optimal_for_transcription': False
            }
    
    def detect_optimal_chunk_boundaries(self, audio_segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect optimal boundaries for audio chunking based on voice activity
        
        Args:
            audio_segments: List of audio segments with metadata
            
        Returns:
            Optimized segments with better boundaries
        """
        try:
            if not audio_segments:
                return []
            
            optimized_segments = []
            current_group = []
            last_voice_time = 0
            
            for segment in audio_segments:
                segment_time = segment.get('timestamp', 0)
                is_voice = segment.get('is_voice_detected', False)
                quality_score = segment.get('quality_score', 0.0)
                
                # Calculate time gap since last voice activity
                time_gap = segment_time - last_voice_time if last_voice_time > 0 else 0
                
                # Decision logic for grouping
                should_start_new_group = (
                    time_gap > self.max_silence_gap or  # Long silence gap
                    (not is_voice and quality_score < 0.2) or  # Poor quality silence
                    len(current_group) >= 5  # Maximum segments per group
                )
                
                if should_start_new_group and current_group:
                    # Finalize current group
                    merged_segment = self._merge_audio_group(current_group)
                    if merged_segment:
                        optimized_segments.append(merged_segment)
                    current_group = []
                
                # Add to current group
                current_group.append(segment)
                
                if is_voice:
                    last_voice_time = segment_time
            
            # Process final group
            if current_group:
                merged_segment = self._merge_audio_group(current_group)
                if merged_segment:
                    optimized_segments.append(merged_segment)
            
            logger.info(f"Optimized {len(audio_segments)} segments into {len(optimized_segments)} groups")
            return optimized_segments
            
        except Exception as e:
            logger.error(f"Chunk boundary detection failed: {e}")
            return audio_segments  # Return original if processing fails
    
    def enhance_transcription_context(self, transcript_segments: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Enhance transcription with contextual information and quality insights
        
        Args:
            transcript_segments: List of transcribed segments
            
        Returns:
            Enhanced context and quality analysis
        """
        try:
            total_duration = 0
            total_words = 0
            confidence_scores = []
            voice_segments = 0
            
            for segment in transcript_segments:
                duration = segment.get('duration', 0)
                text = segment.get('text', '')
                confidence = segment.get('confidence', 0.0)
                is_voice = segment.get('is_voice_detected', False)
                
                total_duration += duration
                total_words += len(text.split()) if text else 0
                confidence_scores.append(confidence)
                
                if is_voice and text.strip():
                    voice_segments += 1
            
            # Calculate metrics
            avg_confidence = np.mean(confidence_scores) if confidence_scores else 0.0
            words_per_minute = (total_words / total_duration * 60) if total_duration > 0 else 0
            voice_activity_ratio = voice_segments / len(transcript_segments) if transcript_segments else 0
            
            # Quality assessment
            quality_assessment = self._assess_transcription_quality(
                avg_confidence, words_per_minute, voice_activity_ratio
            )
            
            return {
                'total_duration': total_duration,
                'total_words': total_words,
                'average_confidence': avg_confidence,
                'words_per_minute': words_per_minute,
                'voice_activity_ratio': voice_activity_ratio,
                'quality_assessment': quality_assessment,
                'segment_count': len(transcript_segments),
                'voice_segments': voice_segments
            }
            
        except Exception as e:
            logger.error(f"Context enhancement failed: {e}")
            return {'error': str(e)}
    
    def _calculate_zcr(self, audio_array: np.ndarray) -> float:
        """Calculate zero crossing rate for voice detection"""
        zero_crossings = np.sum(np.abs(np.diff(np.sign(audio_array))))
        return zero_crossings / len(audio_array)
    
    def _calculate_quality_score(self, rms_energy: float, peak_amplitude: float, zcr: float) -> float:
        """Calculate overall audio quality score"""
        # Normalize components
        energy_score = min(1.0, rms_energy / 0.1)  # Scale to 0-1
        amplitude_score = min(1.0, peak_amplitude)
        zcr_score = min(1.0, zcr / 0.1)  # Typical range for speech
        
        # Weighted combination
        quality_score = (energy_score * 0.5 + amplitude_score * 0.3 + zcr_score * 0.2)
        return float(quality_score)
    
    def _generate_audio_recommendations(self, rms_energy: float, peak_amplitude: float, 
                                      zcr: float, is_voice: bool) -> List[str]:
        """Generate recommendations for audio quality improvement"""
        recommendations = []
        
        if rms_energy < 0.01:
            recommendations.append("Audio level too low - increase microphone gain")
        elif rms_energy > 0.3:
            recommendations.append("Audio level too high - reduce microphone gain")
        
        if peak_amplitude > 0.95:
            recommendations.append("Audio clipping detected - reduce input volume")
        
        if zcr > 0.15:
            recommendations.append("High noise detected - consider noise reduction")
        
        if not is_voice and rms_energy > 0.02:
            recommendations.append("Background noise present - use noise gate")
        
        if not recommendations:
            recommendations.append("Audio quality is optimal for transcription")
        
        return recommendations
    
    def _merge_audio_group(self, audio_group: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Merge a group of audio segments into a single optimized segment"""
        if not audio_group:
            return None
        
        # Combine metadata from all segments
        total_duration = sum(seg.get('duration', 0) for seg in audio_group)
        avg_quality = np.mean([seg.get('quality_score', 0) for seg in audio_group])
        has_voice = any(seg.get('is_voice_detected', False) for seg in audio_group)
        
        return {
            'timestamp': audio_group[0].get('timestamp', 0),
            'duration': total_duration,
            'quality_score': float(avg_quality),
            'is_voice_detected': has_voice,
            'segment_count': len(audio_group),
            'type': 'merged_group'
        }
    
    def _assess_transcription_quality(self, confidence: float, wpm: float, 
                                    voice_ratio: float) -> Dict[str, Any]:
        """Assess overall transcription quality and provide insights"""
        # Quality thresholds
        confidence_quality = "excellent" if confidence > 0.8 else "good" if confidence > 0.6 else "fair" if confidence > 0.4 else "poor"
        
        wpm_quality = "excellent" if 120 <= wpm <= 180 else "good" if 80 <= wpm <= 220 else "fair" if 40 <= wpm <= 280 else "poor"
        
        voice_quality = "excellent" if voice_ratio > 0.8 else "good" if voice_ratio > 0.6 else "fair" if voice_ratio > 0.4 else "poor"
        
        # Overall assessment
        scores = [confidence, min(1.0, wpm / 150), voice_ratio]
        overall_score = np.mean(scores)
        overall_quality = "excellent" if overall_score > 0.8 else "good" if overall_score > 0.6 else "fair" if overall_score > 0.4 else "poor"
        
        return {
            'overall_quality': overall_quality,
            'overall_score': float(overall_score),
            'confidence_quality': confidence_quality,
            'speech_rate_quality': wpm_quality,
            'voice_activity_quality': voice_quality,
            'recommendations': self._generate_quality_recommendations(confidence, wpm, voice_ratio)
        }
    
    def _generate_quality_recommendations(self, confidence: float, wpm: float, 
                                        voice_ratio: float) -> List[str]:
        """Generate recommendations for improving transcription quality"""
        recommendations = []
        
        if confidence < 0.5:
            recommendations.append("Consider using a better microphone or reducing background noise")
        
        if wpm < 60:
            recommendations.append("Speech rate is quite slow - ensure natural conversation pace")
        elif wpm > 250:
            recommendations.append("Speech rate is very fast - consider speaking more slowly")
        
        if voice_ratio < 0.4:
            recommendations.append("Low voice activity detected - minimize silence periods")
        
        if not recommendations:
            recommendations.append("Transcription quality is optimal")
        
        return recommendations

# Global audio processor instance
audio_processor = AdvancedAudioProcessor()