"""
Enhanced Transcription Service
Core transcription processing with caching and analytics
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import tempfile
import hashlib
from services.whisper_transcriber import WhisperTranscriber
from services.session_manager import SessionManager

logger = logging.getLogger(__name__)

class TranscriptionService:
    def __init__(self):
        self.whisper_transcriber = WhisperTranscriber()
        self.session_manager = SessionManager()
    
    def process_audio_file(self, audio_file, session_id: str) -> Dict[str, Any]:
        """Process uploaded audio file"""
        try:
            start_time = datetime.utcnow()
            
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                audio_file.save(temp_file.name)
                
                # Transcribe audio
                result = self.whisper_transcriber.transcribe_audio(temp_file.name)
                
                # Clean up temp file
                os.unlink(temp_file.name)
            
            processing_time = (datetime.utcnow() - start_time).total_seconds()
            
            # Save session data
            self.session_manager.update_session(session_id, {
                'transcription': result.get('text', ''),
                'confidence': result.get('confidence', 0),
                'processing_time': processing_time,
                'status': 'completed'
            })
            
            return {
                'success': True,
                'transcription': result.get('text', ''),
                'confidence': result.get('confidence', 0),
                'processing_time': processing_time
            }
            
        except Exception as e:
            logger.error(f"Audio file processing error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'transcription': '',
                'confidence': 0,
                'processing_time': 0
            }
    
    def process_audio_chunk(self, audio_chunk, session_id: str, chunk_index: int) -> Dict[str, Any]:
        """Process audio chunk for streaming transcription"""
        try:
            start_time = datetime.utcnow()
            
            # Save chunk temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                audio_chunk.save(temp_file.name)
                
                # Transcribe chunk
                result = self.whisper_transcriber.transcribe_audio(temp_file.name)
                
                # Clean up temp file
                os.unlink(temp_file.name)
            
            processing_time = (datetime.utcnow() - start_time).total_seconds()
            
            # Update session with chunk data
            self.session_manager.add_chunk_to_session(session_id, {
                'chunk_index': chunk_index,
                'transcription': result.get('text', ''),
                'confidence': result.get('confidence', 0),
                'processing_time': processing_time,
                'timestamp': datetime.utcnow().isoformat()
            })
            
            return {
                'success': True,
                'transcription': result.get('text', ''),
                'confidence': result.get('confidence', 0),
                'processing_time': processing_time,
                'is_final': False
            }
            
        except Exception as e:
            logger.error(f"Audio chunk processing error: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'transcription': '',
                'confidence': 0,
                'processing_time': 0,
                'is_final': False
            }
    
    def get_user_sessions(self, user_id: str, limit: int = 10, offset: int = 0) -> List[Dict]:
        """Get user's transcription sessions"""
        try:
            return self.session_manager.get_user_sessions(user_id, limit, offset)
        except Exception as e:
            logger.error(f"Get user sessions error: {str(e)}")
            return []
    
    def get_session_details(self, session_id: str) -> Optional[Dict]:
        """Get detailed session information"""
        try:
            return self.session_manager.get_session_details(session_id)
        except Exception as e:
            logger.error(f"Get session details error: {str(e)}")
            return None
    
    def get_session_transcript(self, session_id: str) -> Optional[Dict]:
        """Get full transcript for session"""
        try:
            return self.session_manager.get_session_transcript(session_id)
        except Exception as e:
            logger.error(f"Get session transcript error: {str(e)}")
            return None
    
    def get_transcription_analytics(self, user_id: str, time_range: str) -> Dict[str, Any]:
        """Get transcription analytics"""
        try:
            # Parse time range
            days = self._parse_time_range(time_range)
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Get analytics data
            analytics = self.session_manager.get_analytics(user_id, start_date)
            
            return {
                'total_sessions': analytics.get('total_sessions', 0),
                'total_duration': analytics.get('total_duration', 0),
                'average_confidence': analytics.get('average_confidence', 0),
                'successful_transcriptions': analytics.get('successful_transcriptions', 0),
                'failed_transcriptions': analytics.get('failed_transcriptions', 0),
                'most_active_day': analytics.get('most_active_day', ''),
                'average_processing_time': analytics.get('average_processing_time', 0),
                'time_range': time_range,
                'period_start': start_date.isoformat(),
                'period_end': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Get analytics error: {str(e)}")
            return {}
    
    def _parse_time_range(self, time_range: str) -> int:
        """Parse time range string to days"""
        time_range = time_range.lower()
        if time_range == '1d':
            return 1
        elif time_range == '7d':
            return 7
        elif time_range == '30d':
            return 30
        elif time_range == '90d':
            return 90
        else:
            return 30  # Default to 30 days
    
    def health_check(self) -> bool:
        """Health check for transcription service"""
        try:
            # Check OpenAI API availability
            if not os.environ.get('OPENAI_API_KEY'):
                logger.warning("OpenAI API key not configured")
                return False
            
            # Check whisper transcriber
            if not self.whisper_transcriber.health_check():
                return False
            
            # Check session manager
            if not self.session_manager.health_check():
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Transcription service health check failed: {str(e)}")
            return False