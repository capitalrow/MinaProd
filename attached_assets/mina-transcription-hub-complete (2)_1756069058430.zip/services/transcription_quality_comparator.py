"""
Transcription Quality Comparator Service
Compares live transcription output vs. complete authoritative transcription
for quality analysis and performance improvements
"""

import os
import json
import logging
import difflib
import tempfile
import time
from datetime import datetime
from typing import Dict, List, Tuple, Any
from dataclasses import dataclass, asdict
import openai

logger = logging.getLogger(__name__)

@dataclass
class TranscriptionComparison:
    """Data structure for transcription comparison results"""
    session_id: str
    recording_duration: float
    live_transcript: str
    complete_transcript: str
    word_error_rate: float
    missing_words: List[str]
    extra_words: List[str]
    timing_accuracy: Dict[str, Any]
    quality_score: float
    improvement_suggestions: List[str]
    timestamp: str

class TranscriptionQualityComparator:
    """Service for comparing live vs complete transcriptions"""
    
    def __init__(self):
        self.openai_client = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.comparisons = {}  # session_id -> comparison data
        self.live_transcript_buffer = {}  # session_id -> live chunks
        self.recordings_dir = "recordings"
        self.comparison_results_dir = "comparison_results"
        
        # Ensure directories exist
        os.makedirs(self.recordings_dir, exist_ok=True)
        os.makedirs(self.comparison_results_dir, exist_ok=True)
        
        logger.info("Transcription Quality Comparator initialized")
    
    def start_session(self, session_id: str):
        """Start tracking a comparison session"""
        return self.start_recording_session(session_id)
        
    def start_recording_session(self, session_id: str):
        """Initialize tracking for a new recording session"""
        self.live_transcript_buffer[session_id] = []
        self.comparisons[session_id] = {
            'start_time': time.time(),
            'chunks_received': 0,
            'live_chunks': []
        }
        logger.info(f"[COMPARATOR] Started tracking session: {session_id}")
        return {'status': 'success', 'session_id': session_id}
    
    def capture_live_transcript_chunk(self, session_id: str, chunk_data: Dict[str, Any]):
        """Capture live transcript chunks as they appear in UI"""
        if session_id not in self.live_transcript_buffer:
            self.start_recording_session(session_id)
        
        chunk_info = {
            'timestamp': time.time(),
            'chunk_id': chunk_data.get('chunk_id', ''),
            'text': chunk_data.get('text', ''),
            'confidence': chunk_data.get('confidence', 0.0),
            'type': chunk_data.get('type', 'partial')
        }
        
        self.live_transcript_buffer[session_id].append(chunk_info)
        self.comparisons[session_id]['chunks_received'] += 1
        self.comparisons[session_id]['live_chunks'].append(chunk_info)
        
        logger.debug(f"[COMPARATOR] Captured live chunk for {session_id}: {chunk_data.get('text', '')[:50]}...")
    
    def save_complete_audio(self, session_id: str, audio_path: str) -> str:
        """Save the complete recording for authoritative transcription"""
        if not os.path.exists(audio_path):
            logger.error(f"[COMPARATOR] Audio file not found: {audio_path}")
            return None
        
        # Copy to recordings directory with session ID
        recording_filename = f"session_{session_id}_{int(time.time())}.wav"
        saved_path = os.path.join(self.recordings_dir, recording_filename)
        
        import shutil
        shutil.copy2(audio_path, saved_path)
        
        logger.info(f"[COMPARATOR] Saved complete recording: {saved_path}")
        return saved_path
    
    def generate_authoritative_transcript(self, audio_path: str) -> Dict[str, Any]:
        """Generate high-quality authoritative transcript from complete audio"""
        try:
            with open(audio_path, 'rb') as audio_file:
                # Use highest quality Whisper settings for authoritative transcript
                response = self.openai_client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    language="en",
                    temperature=0.0,  # Most deterministic
                    response_format="verbose_json"  # Get detailed timing info
                )
                
            authoritative_data = {
                'text': response.text,
                'segments': response.segments if hasattr(response, 'segments') else [],
                'duration': getattr(response, 'duration', 0.0)
            }
            
            logger.info(f"[COMPARATOR] Generated authoritative transcript: {len(response.text)} characters")
            return authoritative_data
            
        except Exception as e:
            logger.error(f"[COMPARATOR] Failed to generate authoritative transcript: {e}")
            return {'text': '', 'segments': [], 'duration': 0.0}
    
    def calculate_word_error_rate(self, reference: str, hypothesis: str) -> Tuple[float, List[str], List[str]]:
        """Calculate WER and identify missing/extra words"""
        ref_words = reference.lower().split()
        hyp_words = hypothesis.lower().split()
        
        # Use difflib to find differences
        matcher = difflib.SequenceMatcher(None, ref_words, hyp_words)
        
        missing_words = []
        extra_words = []
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'delete':
                missing_words.extend(ref_words[i1:i2])
            elif tag == 'insert':
                extra_words.extend(hyp_words[j1:j2])
        
        # Calculate WER
        substitutions = sum(1 for tag, _, _, _, _ in matcher.get_opcodes() if tag == 'replace')
        deletions = len(missing_words)
        insertions = len(extra_words)
        
        total_errors = substitutions + deletions + insertions
        wer = total_errors / len(ref_words) if ref_words else 0.0
        
        return wer, missing_words, extra_words
    
    def analyze_timing_accuracy(self, live_chunks: List[Dict], authoritative_segments: List[Dict]) -> Dict[str, Any]:
        """Analyze timing accuracy of live transcript chunks"""
        timing_analysis = {
            'average_delay': 0.0,
            'chunk_timing_errors': [],
            'out_of_order_chunks': 0,
            'timing_drift': 0.0
        }
        
        if not live_chunks or not authoritative_segments:
            return timing_analysis
        
        # Simple timing analysis - can be enhanced based on available timing data
        first_chunk_time = live_chunks[0]['timestamp'] if live_chunks else 0
        session_start = self.comparisons.get(live_chunks[0].get('session_id', ''), {}).get('start_time', first_chunk_time)
        
        delays = []
        for i, chunk in enumerate(live_chunks):
            expected_time = session_start + (i * 2.5)  # Assuming ~2.5s chunks
            actual_time = chunk['timestamp']
            delay = actual_time - expected_time
            delays.append(delay)
        
        timing_analysis['average_delay'] = sum(delays) / len(delays) if delays else 0.0
        timing_analysis['timing_drift'] = max(delays) - min(delays) if len(delays) > 1 else 0.0
        
        return timing_analysis
    
    def generate_improvement_suggestions(self, comparison_data: Dict[str, Any]) -> List[str]:
        """Generate specific improvement suggestions based on comparison"""
        suggestions = []
        
        wer = comparison_data['word_error_rate']
        missing_words = comparison_data['missing_words']
        extra_words = comparison_data['extra_words']
        timing = comparison_data['timing_accuracy']
        
        # WER-based suggestions
        if wer > 0.3:
            suggestions.append("High word error rate detected. Consider improving audio quality or reducing background noise.")
        elif wer > 0.15:
            suggestions.append("Moderate word error rate. Review chunk size and overlap settings.")
        
        # Missing words analysis
        if len(missing_words) > len(extra_words) * 1.5:
            suggestions.append("Many words are being missed. Consider reducing VAD sensitivity or chunk duration thresholds.")
        
        # Extra words analysis
        if len(extra_words) > len(missing_words) * 1.5:
            suggestions.append("Excessive hallucination detected. Strengthen hallucination filtering or increase confidence thresholds.")
        
        # Timing analysis
        if timing['average_delay'] > 3.0:
            suggestions.append("Live transcription has significant delay. Optimize processing pipeline or reduce chunk size.")
        
        if timing['timing_drift'] > 5.0:
            suggestions.append("Inconsistent timing detected. Review WebSocket emission and chunk processing order.")
        
        # Common patterns
        if any(word in ' '.join(missing_words) for word in ['the', 'and', 'a', 'an', 'is', 'are']):
            suggestions.append("Common words are being dropped. Review minimum confidence thresholds.")
        
        return suggestions
    
    def complete_session_comparison(self, session_id: str, audio_path: str = None) -> TranscriptionComparison:
        """Complete the comparison analysis for a recording session"""
        if session_id not in self.comparisons:
            logger.error(f"[COMPARATOR] Session {session_id} not found")
            return None
        
        session_data = self.comparisons[session_id]
        live_chunks = session_data.get('live_chunks', [])
        
        # Compile live transcript
        live_transcript = ' '.join([
            chunk['text'] for chunk in live_chunks 
            if chunk['type'] == 'final' or not any(
                other['chunk_id'] == chunk['chunk_id'] and other['type'] == 'final' 
                for other in live_chunks
            )
        ])
        
        # Generate authoritative transcript
        authoritative_data = {'text': '', 'segments': [], 'duration': 0.0}
        if audio_path and os.path.exists(audio_path):
            saved_path = self.save_complete_audio(session_id, audio_path)
            if saved_path:
                authoritative_data = self.generate_authoritative_transcript(saved_path)
        
        # Perform comparison analysis
        wer, missing_words, extra_words = self.calculate_word_error_rate(
            authoritative_data['text'], live_transcript
        )
        
        timing_accuracy = self.analyze_timing_accuracy(
            live_chunks, authoritative_data['segments']
        )
        
        # Calculate quality score (0-100)
        quality_score = max(0, (1 - wer) * 100)
        if timing_accuracy['average_delay'] > 2.0:
            quality_score *= 0.9  # Penalize for delay
        if len(missing_words) > 5:
            quality_score *= 0.85  # Penalize for missing words
        
        # Create comparison result
        comparison = TranscriptionComparison(
            session_id=session_id,
            recording_duration=authoritative_data['duration'],
            live_transcript=live_transcript,
            complete_transcript=authoritative_data['text'],
            word_error_rate=wer,
            missing_words=missing_words,
            extra_words=extra_words,
            timing_accuracy=timing_accuracy,
            quality_score=quality_score,
            improvement_suggestions=self.generate_improvement_suggestions({
                'word_error_rate': wer,
                'missing_words': missing_words,
                'extra_words': extra_words,
                'timing_accuracy': timing_accuracy
            }),
            timestamp=datetime.now().isoformat()
        )
        
        # Save comparison result
        self.save_comparison_result(comparison)
        
        logger.info(f"[COMPARATOR] Completed analysis for {session_id}: WER={wer:.2f}, Quality={quality_score:.1f}")
        return comparison
        
    def complete_session(self, session_id: str, audio_path: str = None):
        """Complete a comparison session and return results"""
        return self.perform_comparison(session_id, audio_path)
    
    def save_comparison_result(self, comparison: TranscriptionComparison):
        """Save comparison result to file"""
        filename = f"comparison_{comparison.session_id}_{int(time.time())}.json"
        filepath = os.path.join(self.comparison_results_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(asdict(comparison), f, indent=2)
        
        logger.info(f"[COMPARATOR] Saved comparison result: {filepath}")
    
    def get_session_comparison(self, session_id: str) -> TranscriptionComparison:
        """Get comparison result for a specific session"""
        # Look for most recent comparison file for this session
        comparison_files = [f for f in os.listdir(self.comparison_results_dir) 
                          if f.startswith(f"comparison_{session_id}_")]
        
        if not comparison_files:
            return None
        
        latest_file = max(comparison_files)
        filepath = os.path.join(self.comparison_results_dir, latest_file)
        
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
                return TranscriptionComparison(**data)
        except Exception as e:
            logger.error(f"[COMPARATOR] Failed to load comparison: {e}")
            return None
    
    def get_quality_insights_for_qa(self) -> Dict[str, Any]:
        """Generate quality insights for QA dashboard"""
        insights = {
            'total_sessions_analyzed': 0,
            'average_wer': 0.0,
            'average_quality_score': 0.0,
            'common_issues': {},
            'improvement_trends': [],
            'top_suggestions': []
        }
        
        # Analyze all comparison files
        comparison_files = os.listdir(self.comparison_results_dir)
        comparisons = []
        
        for filename in comparison_files:
            if filename.startswith('comparison_') and filename.endswith('.json'):
                try:
                    filepath = os.path.join(self.comparison_results_dir, filename)
                    with open(filepath, 'r') as f:
                        data = json.load(f)
                        comparisons.append(data)
                except Exception as e:
                    logger.error(f"[COMPARATOR] Error loading {filename}: {e}")
                    continue
        
        if not comparisons:
            return insights
        
        insights['total_sessions_analyzed'] = len(comparisons)
        insights['average_wer'] = sum(c['word_error_rate'] for c in comparisons) / len(comparisons)
        insights['average_quality_score'] = sum(c['quality_score'] for c in comparisons) / len(comparisons)
        
        # Aggregate common issues and suggestions
        all_suggestions = []
        for comparison in comparisons:
            all_suggestions.extend(comparison.get('improvement_suggestions', []))
        
        # Count suggestion frequency
        suggestion_counts = {}
        for suggestion in all_suggestions:
            suggestion_counts[suggestion] = suggestion_counts.get(suggestion, 0) + 1
        
        insights['top_suggestions'] = sorted(
            suggestion_counts.items(), 
            key=lambda x: x[1], 
            reverse=True
        )[:5]
        
        return insights

# Global instance
transcription_comparator = TranscriptionQualityComparator()