"""
AI Classification Service for Mina Pro
Classifies transcript chunks into actionable categories using GPT-4
"""

import logging
from typing import Dict, Any, Optional
import os
from openai import OpenAI

logger = logging.getLogger(__name__)

class AIClassificationService:
    def __init__(self):
        self.openai_available = False
        self.client = None
        
        # Initialize OpenAI client
        try:
            api_key = os.environ.get("OPENAI_API_KEY")
            if api_key:
                self.client = OpenAI(api_key=api_key)
                self.openai_available = True
                logger.info("AI Classification Service initialized with OpenAI")
            else:
                logger.warning("OpenAI API key not found for classification service")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client for classification: {e}")
    
    def classify_transcript_chunk(self, transcript_text: str, context: str = "general", 
                                confidence: float = 0.0) -> Dict[str, Any]:
        """
        Classify transcript chunk into actionable categories
        
        Args:
            transcript_text: The text to classify
            context: Meeting context (standup, 1on1, retro, discovery, sales, general)
            confidence: Whisper confidence score
            
        Returns:
            Dictionary with classification results
        """
        if not self.openai_available or not transcript_text.strip():
            return self._fallback_classification(transcript_text, context)
        
        # Skip classification for very low confidence transcripts
        if confidence < 0.3:
            return {
                "classification": "neutral",
                "confidence": 0.0,
                "reasoning": "Low transcription confidence, skipped classification",
                "actionable": False
            }
        
        try:
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": self._get_classification_prompt(context)
                    },
                    {
                        "role": "user",
                        "content": f"Classify this transcript: \"{transcript_text}\""
                    }
                ],

                max_tokens=150,
                temperature=0.1
            )
            
            import json
            content = response.choices[0].message.content.strip()
            
            # Try to parse as JSON, but handle plain text responses
            try:
                result = json.loads(content)
            except json.JSONDecodeError:
                # Fallback: parse from text response
                classification = "neutral"
                confidence = 0.5
                reasoning = content
                
                # Simple keyword matching for classification
                content_lower = content.lower()
                if any(word in content_lower for word in ["task", "action", "todo", "assign"]):
                    classification = "task"
                    confidence = 0.7
                elif any(word in content_lower for word in ["decision", "decide", "choose"]):
                    classification = "decision"
                    confidence = 0.7
                elif any(word in content_lower for word in ["deadline", "due", "schedule"]):
                    classification = "deadline"
                    confidence = 0.7
                elif any(word in content_lower for word in ["follow", "next", "continue"]):
                    classification = "follow-up"
                    confidence = 0.7
                
                result = {
                    "classification": classification,
                    "confidence": confidence,
                    "reasoning": reasoning
                }
            
            # Validate and normalize result
            classification = result.get("classification", "neutral").lower()
            if classification not in ["decision", "task", "deadline", "follow-up", "neutral"]:
                classification = "neutral"
            
            return {
                "classification": classification,
                "confidence": result.get("confidence", 0.8),
                "reasoning": result.get("reasoning", ""),
                "actionable": classification in ["decision", "task", "deadline", "follow-up"]
            }
            
        except Exception as e:
            logger.warning(f"Classification failed, using fallback: {e}")
            return self._fallback_classification(transcript_text, context)
    
    def _get_classification_prompt(self, context: str) -> str:
        """Get classification prompt based on meeting context"""
        
        base_prompt = """You are an AI assistant that classifies meeting transcript segments into actionable categories. 

Classify each segment into one of these categories:
- "decision": Final decisions made or agreements reached
- "task": Action items, todos, or work to be done
- "deadline": Time-sensitive items with dates or urgency
- "follow-up": Items requiring future discussion or checking back
- "neutral": General discussion, questions, or non-actionable content

"""
        
        context_prompts = {
            "standup": "Focus on blockers, progress updates, and upcoming work.",
            "1on1": "Focus on personal development, feedback, and goal-setting items.",
            "retro": "Focus on action items for process improvement and team decisions.",
            "discovery": "Focus on requirements, decisions about features, and next steps.",
            "sales": "Focus on commitments, follow-ups, and decision points.",
            "general": "Apply general meeting classification logic."
        }
        
        context_guidance = context_prompts.get(context, context_prompts["general"])
        
        return f"""{base_prompt}

Context: This is a {context} meeting. {context_guidance}

Respond in JSON format:
{{
    "classification": "task|decision|deadline|follow-up|neutral",
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation"
}}"""
    
    def _fallback_classification(self, transcript_text: str, context: str) -> Dict[str, Any]:
        """Fallback classification using keyword heuristics"""
        
        text_lower = transcript_text.lower()
        
        # Keyword-based classification
        if any(word in text_lower for word in ["decide", "decided", "agree", "approved", "final"]):
            return {"classification": "decision", "confidence": 0.6, "reasoning": "Contains decision keywords", "actionable": True}
        
        if any(word in text_lower for word in ["todo", "action", "task", "need to", "should", "will do"]):
            return {"classification": "task", "confidence": 0.6, "reasoning": "Contains task keywords", "actionable": True}
        
        if any(word in text_lower for word in ["deadline", "by friday", "urgent", "asap", "due"]):
            return {"classification": "deadline", "confidence": 0.6, "reasoning": "Contains deadline keywords", "actionable": True}
        
        if any(word in text_lower for word in ["follow up", "check back", "revisit", "later"]):
            return {"classification": "follow-up", "confidence": 0.6, "reasoning": "Contains follow-up keywords", "actionable": True}
        
        return {"classification": "neutral", "confidence": 0.5, "reasoning": "No actionable keywords found", "actionable": False}
    
    def batch_classify_transcript(self, transcript_segments: list, context: str = "general") -> Dict[str, Any]:
        """
        Classify multiple transcript segments for summary view
        
        Args:
            transcript_segments: List of transcript segments with text and confidence
            context: Meeting context
            
        Returns:
            Summary of classifications and actionable items
        """
        classifications = []
        actionable_count = 0
        
        for segment in transcript_segments:
            text = segment.get("text", "")
            confidence = segment.get("confidence", 0.0)
            
            classification = self.classify_transcript_chunk(text, context, confidence)
            classifications.append(classification)
            
            if classification["actionable"]:
                actionable_count += 1
        
        # Summary statistics
        category_counts = {}
        for cls in classifications:
            category = cls["classification"]
            category_counts[category] = category_counts.get(category, 0) + 1
        
        return {
            "total_segments": len(transcript_segments),
            "actionable_segments": actionable_count,
            "category_distribution": category_counts,
            "classifications": classifications,
            "productivity_score": round((actionable_count / max(len(transcript_segments), 1)) * 100, 1)
        }