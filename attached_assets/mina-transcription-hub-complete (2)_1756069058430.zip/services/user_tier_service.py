"""
✅ REQUIREMENT: User Tier Logic Implementation - Phase 3 Backend Enhancement
Manages free/pro tier limits, transcription minute tracking, and usage enforcement
"""

import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import sessionmaker
from models import User, TranscriptSession

logger = logging.getLogger(__name__)

class UserTierService:
    """Manages user tiers, limits, and usage tracking for MinaTranscribe"""
    
    # ✅ REQUIREMENT: Free-tier limits (30 mins/month)
    FREE_TIER_MONTHLY_MINUTES = 30.0
    PRO_TIER_MONTHLY_MINUTES = float('inf')  # Unlimited
    
    def __init__(self, db_session):
        self.db_session = db_session
    
    def check_transcription_limits(self, user_id: str, estimated_duration_minutes: float = 0) -> dict:
        """
        ✅ REQUIREMENT: Implement limits for free-tier users (30 mins/month)
        Check if user can transcribe based on their tier and usage
        """
        try:
            user = self.db_session.query(User).filter_by(id=user_id).first()
            if not user:
                return {"allowed": False, "error": "User not found"}
            
            # Check if monthly usage needs reset
            if self._should_reset_monthly_usage(user):
                self._reset_monthly_usage(user)
            
            current_usage = user.transcribed_minutes or 0.0
            tier_limit = self._get_tier_limit(user.user_tier)
            
            # Check if adding estimated duration would exceed limit
            projected_usage = current_usage + estimated_duration_minutes
            
            if projected_usage > tier_limit:
                remaining_minutes = max(0, tier_limit - current_usage)
                return {
                    "allowed": False,
                    "error": f"Monthly limit exceeded. Used: {current_usage:.1f}/{tier_limit:.0f} minutes",
                    "remaining_minutes": remaining_minutes,
                    "tier": user.user_tier,
                    "needs_upgrade": user.user_tier == "free"
                }
            
            return {
                "allowed": True,
                "remaining_minutes": tier_limit - projected_usage if tier_limit != float('inf') else float('inf'),
                "current_usage": current_usage,
                "tier": user.user_tier,
                "tier_limit": tier_limit
            }
            
        except Exception as e:
            logger.error(f"Error checking transcription limits for user {user_id}: {e}")
            return {"allowed": False, "error": "System error checking limits"}
    
    def record_transcription_usage(self, user_id: str, duration_minutes: float) -> bool:
        """
        ✅ REQUIREMENT: Track usage and update transcribed_minutes
        Record actual transcription usage for tier enforcement
        """
        try:
            user = self.db_session.query(User).filter_by(id=user_id).first()
            if not user:
                logger.error(f"User {user_id} not found for usage recording")
                return False
            
            # Update transcribed minutes
            user.transcribed_minutes = (user.transcribed_minutes or 0.0) + duration_minutes
            user.sessions_used = (user.sessions_used or 0) + 1
            
            self.db_session.commit()
            
            logger.info(f"Recorded {duration_minutes:.2f} minutes for user {user_id} (total: {user.transcribed_minutes:.2f})")
            return True
            
        except Exception as e:
            logger.error(f"Error recording usage for user {user_id}: {e}")
            self.db_session.rollback()
            return False
    
    def get_user_tier_info(self, user_id: str) -> dict:
        """
        ✅ REQUIREMENT: User tier logic with visible tags in UI
        Get comprehensive tier information for UI display
        """
        try:
            user = self.db_session.query(User).filter_by(id=user_id).first()
            if not user:
                return {"error": "User not found"}
            
            # Check if reset needed
            if self._should_reset_monthly_usage(user):
                self._reset_monthly_usage(user)
            
            tier_limit = self._get_tier_limit(user.user_tier)
            current_usage = user.transcribed_minutes or 0.0
            
            return {
                "tier": user.user_tier,
                "tier_display": user.user_tier.upper(),
                "current_usage": current_usage,
                "tier_limit": tier_limit,
                "remaining_minutes": tier_limit - current_usage if tier_limit != float('inf') else float('inf'),
                "usage_percentage": (current_usage / tier_limit * 100) if tier_limit != float('inf') else 0,
                "sessions_used": user.sessions_used or 0,
                "monthly_reset": user.monthly_reset,
                "is_premium": user.is_premium,
                "needs_upgrade": user.user_tier == "free" and current_usage > (tier_limit * 0.8)  # 80% threshold
            }
            
        except Exception as e:
            logger.error(f"Error getting tier info for user {user_id}: {e}")
            return {"error": "System error"}
    
    def upgrade_user_tier(self, user_id: str, new_tier: str = "pro") -> bool:
        """
        ✅ REQUIREMENT: User tier management for pro upgrades
        Upgrade user to pro tier with unlimited transcription
        """
        try:
            user = self.db_session.query(User).filter_by(id=user_id).first()
            if not user:
                return False
            
            user.user_tier = new_tier
            user.is_premium = (new_tier == "pro")
            
            self.db_session.commit()
            logger.info(f"Upgraded user {user_id} to {new_tier} tier")
            return True
            
        except Exception as e:
            logger.error(f"Error upgrading user {user_id} to {new_tier}: {e}")
            self.db_session.rollback()
            return False
    
    def _get_tier_limit(self, tier: str) -> float:
        """Get monthly minute limit for user tier"""
        if tier == "pro":
            return self.PRO_TIER_MONTHLY_MINUTES
        else:  # free tier
            return self.FREE_TIER_MONTHLY_MINUTES
    
    def _should_reset_monthly_usage(self, user: User) -> bool:
        """Check if monthly usage should be reset"""
        if not user.monthly_reset:
            return True
        
        # Reset if it's been more than 30 days
        days_since_reset = (datetime.utcnow() - user.monthly_reset).days
        return days_since_reset >= 30
    
    def _reset_monthly_usage(self, user: User) -> None:
        """Reset monthly usage counters"""
        try:
            user.transcribed_minutes = 0.0
            user.sessions_used = 0
            user.monthly_reset = datetime.utcnow()
            
            self.db_session.commit()
            logger.info(f"Reset monthly usage for user {user.id}")
            
        except Exception as e:
            logger.error(f"Error resetting monthly usage for user {user.id}: {e}")
            self.db_session.rollback()

# Global service instance for app-wide usage
def get_user_tier_service(db_session):
    """Factory function to get UserTierService instance"""
    return UserTierService(db_session)