"""
Sentiment Analysis Service for Meeting Intelligence
Analyzes emotional tone and context in transcripts
"""
import os
import logging
import requests
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class SentimentAnalyzer:
    """
    Analyze sentiment and emotional context in meeting transcripts
    """
    
    def __init__(self):
        self.api_key = os.environ.get('OPENAI_API_KEY')
    
    def analyze_meeting_sentiment(self, transcript: str, context: str = "") -> Dict[str, Any]:
        """Analyze overall meeting sentiment and emotional context"""
        if not self.api_key:
            return self._fallback_sentiment_analysis(transcript)
        
        try:
            system_prompt = f"""Analyze the sentiment and emotional context of this meeting transcript.

Context: {context if context else "General meeting"}

Provide a JSON response with:
{{
  "overall_sentiment": "positive/negative/neutral/mixed",
  "confidence": 0.0-1.0,
  "emotional_indicators": ["tense", "collaborative", "frustrated", "excited", etc.],
  "conflict_level": "low/medium/high",
  "engagement_level": "low/medium/high",
  "tone_segments": [
    {{"text": "segment text", "sentiment": "positive", "timestamp": "start-end"}}
  ]
}}

Focus on professional meeting dynamics, not personal attacks."""

            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'model': 'gpt-4',
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': transcript}
                ],
                'max_tokens': 800,
                'temperature': 0.2
            }
            
            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result['choices'][0]['message']['content'].strip()
                
                try:
                    import json
                    sentiment_data = json.loads(content)
                    return sentiment_data
                except json.JSONDecodeError:
                    return self._parse_text_sentiment(content)
            else:
                logger.error(f"Sentiment API error: {response.status_code}")
                return self._fallback_sentiment_analysis(transcript)
                
        except Exception as e:
            logger.error(f"Sentiment analysis failed: {e}")
            return self._fallback_sentiment_analysis(transcript)
    
    def extract_emotional_flags(self, transcript: str) -> List[Dict[str, Any]]:
        """Extract emotional and contextual flags from transcript"""
        flags = []
        
        # Tension indicators
        tension_words = ["disagree", "wrong", "problem", "issue", "concerned", "worried"]
        positive_words = ["great", "excellent", "agree", "perfect", "love", "fantastic"]
        decision_words = ["decide", "agreed", "will do", "approved", "confirmed"]
        
        sentences = transcript.split('.')
        
        for i, sentence in enumerate(sentences):
            sentence_lower = sentence.lower().strip()
            if not sentence_lower:
                continue
                
            # Check for tension
            if any(word in sentence_lower for word in tension_words):
                flags.append({
                    "type": "tension",
                    "text": sentence.strip(),
                    "position": i,
                    "severity": "medium"
                })
            
            # Check for positive sentiment
            if any(word in sentence_lower for word in positive_words):
                flags.append({
                    "type": "positive",
                    "text": sentence.strip(),
                    "position": i,
                    "severity": "low"
                })
            
            # Check for decisions
            if any(word in sentence_lower for word in decision_words):
                flags.append({
                    "type": "decision",
                    "text": sentence.strip(),
                    "position": i,
                    "severity": "high"
                })
        
        return flags
    
    def _fallback_sentiment_analysis(self, transcript: str) -> Dict[str, Any]:
        """Fallback sentiment analysis using keyword matching"""
        positive_words = ["great", "excellent", "good", "perfect", "love", "amazing", "wonderful"]
        negative_words = ["bad", "terrible", "awful", "hate", "wrong", "problem", "issue"]
        
        words = transcript.lower().split()
        positive_count = sum(1 for word in words if word in positive_words)
        negative_count = sum(1 for word in words if word in negative_words)
        
        total_words = len(words)
        if total_words == 0:
            return {
                "overall_sentiment": "neutral",
                "confidence": 0.5,
                "emotional_indicators": [],
                "conflict_level": "low",
                "engagement_level": "medium"
            }
        
        positive_ratio = positive_count / total_words
        negative_ratio = negative_count / total_words
        
        if positive_ratio > negative_ratio * 1.5:
            sentiment = "positive"
        elif negative_ratio > positive_ratio * 1.5:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            "overall_sentiment": sentiment,
            "confidence": 0.6,
            "emotional_indicators": ["collaborative" if sentiment == "positive" else "neutral"],
            "conflict_level": "high" if negative_ratio > 0.02 else "low",
            "engagement_level": "high" if (positive_ratio + negative_ratio) > 0.02 else "medium"
        }
    
    def _parse_text_sentiment(self, content: str) -> Dict[str, Any]:
        """Parse sentiment from text response"""
        lines = content.lower().split('\n')
        sentiment = "neutral"
        confidence = 0.7
        
        for line in lines:
            if "positive" in line:
                sentiment = "positive"
            elif "negative" in line:
                sentiment = "negative"
            elif "mixed" in line:
                sentiment = "mixed"
        
        return {
            "overall_sentiment": sentiment,
            "confidence": confidence,
            "emotional_indicators": ["collaborative"],
            "conflict_level": "low",
            "engagement_level": "medium"
        }

# Global sentiment analyzer instance
sentiment_analyzer = SentimentAnalyzer()