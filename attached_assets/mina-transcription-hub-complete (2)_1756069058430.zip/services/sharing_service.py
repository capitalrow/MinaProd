"""
Sharing and Collaboration Service
Handles session sharing, permissions, and team collaboration
"""

import secrets
import string
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from models import db, SharedSession, TranscriptSession, User
from flask import url_for

class SharingService:
    """Manage session sharing and collaboration features"""
    
    def generate_share_token(self, length: int = 32) -> str:
        """Generate secure random token for sharing"""
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    
    def create_share_link(self, session_id: str, user_id: str, permission_level: str = "view", 
                         expires_hours: int = 168) -> Dict:
        """Create shareable link for transcription session"""
        try:
            # Verify user owns the session
            session = TranscriptSession.query.filter_by(id=session_id, user_id=user_id).first()
            if not session:
                return {"success": False, "error": "Session not found or access denied"}
            
            # Generate share token
            share_token = self.generate_share_token()
            
            # Set expiration (default 1 week)
            expires_at = datetime.utcnow() + timedelta(hours=expires_hours)
            
            # Create shared session record
            shared_session = SharedSession(
                session_id=session_id,
                share_token=share_token,
                permission_level=permission_level,
                expires_at=expires_at,
                created_at=datetime.utcnow()
            )
            
            db.session.add(shared_session)
            db.session.commit()
            
            # Generate public URL
            share_url = url_for('sharing.view_shared_session', token=share_token, _external=True)
            
            return {
                "success": True,
                "share_token": share_token,
                "share_url": share_url,
                "permission_level": permission_level,
                "expires_at": expires_at.isoformat(),
                "expires_hours": expires_hours
            }
            
        except Exception as e:
            db.session.rollback()
            return {"success": False, "error": f"Failed to create share link: {str(e)}"}
    
    def get_shared_session(self, share_token: str) -> Optional[Dict]:
        """Get shared session by token"""
        try:
            shared_session = SharedSession.query.filter_by(share_token=share_token).first()
            
            if not shared_session:
                return None
            
            # Check if expired
            if shared_session.expires_at and shared_session.expires_at < datetime.utcnow():
                return None
            
            # Update access tracking
            shared_session.access_count += 1
            shared_session.last_accessed = datetime.utcnow()
            db.session.commit()
            
            # Get session data
            session = TranscriptSession.query.get(shared_session.session_id)
            if not session:
                return None
            
            return {
                "session": session.to_dict(),
                "permission_level": shared_session.permission_level,
                "shared_by": session.user.get_full_name() if session.user else "Unknown",
                "access_count": shared_session.access_count,
                "expires_at": shared_session.expires_at.isoformat() if shared_session.expires_at else None
            }
            
        except Exception as e:
            return None
    
    def share_with_user(self, session_id: str, owner_user_id: str, 
                       target_email: str, permission_level: str = "view") -> Dict:
        """Share session with specific user by email"""
        try:
            # Verify session ownership
            session = TranscriptSession.query.filter_by(id=session_id, user_id=owner_user_id).first()
            if not session:
                return {"success": False, "error": "Session not found or access denied"}
            
            # Find target user
            target_user = User.query.filter_by(email=target_email).first()
            
            # Generate share token
            share_token = self.generate_share_token()
            
            # Create shared session record
            shared_session = SharedSession(
                session_id=session_id,
                shared_with_user_id=target_user.id if target_user else None,
                share_token=share_token,
                permission_level=permission_level,
                shared_by_email=target_email,
                created_at=datetime.utcnow()
            )
            
            db.session.add(shared_session)
            db.session.commit()
            
            return {
                "success": True,
                "share_token": share_token,
                "target_email": target_email,
                "target_user_exists": bool(target_user),
                "permission_level": permission_level
            }
            
        except Exception as e:
            db.session.rollback()
            return {"success": False, "error": f"Failed to share with user: {str(e)}"}
    
    def get_user_shared_sessions(self, user_id: str) -> List[Dict]:
        """Get sessions shared with a user"""
        try:
            shared_sessions = SharedSession.query.filter_by(shared_with_user_id=user_id).all()
            
            result = []
            for shared_session in shared_sessions:
                session = TranscriptSession.query.get(shared_session.session_id)
                if session:
                    result.append({
                        "session": session.to_dict(),
                        "permission_level": shared_session.permission_level,
                        "shared_by": session.user.get_full_name() if session.user else "Unknown",
                        "shared_at": shared_session.created_at.isoformat(),
                        "last_accessed": shared_session.last_accessed.isoformat() if shared_session.last_accessed else None
                    })
            
            return result
            
        except Exception as e:
            return []
    
    def get_session_shares(self, session_id: str, user_id: str) -> List[Dict]:
        """Get all shares for a session (owner only)"""
        try:
            # Verify ownership
            session = TranscriptSession.query.filter_by(id=session_id, user_id=user_id).first()
            if not session:
                return []
            
            shared_sessions = SharedSession.query.filter_by(session_id=session_id).all()
            
            result = []
            for shared_session in shared_sessions:
                share_info = {
                    "share_token": shared_session.share_token,
                    "permission_level": shared_session.permission_level,
                    "created_at": shared_session.created_at.isoformat(),
                    "expires_at": shared_session.expires_at.isoformat() if shared_session.expires_at else None,
                    "access_count": shared_session.access_count,
                    "last_accessed": shared_session.last_accessed.isoformat() if shared_session.last_accessed else None
                }
                
                if shared_session.shared_with_user_id:
                    user = User.query.get(shared_session.shared_with_user_id)
                    share_info["shared_with"] = {
                        "user_id": user.id,
                        "name": user.get_full_name(),
                        "email": user.email
                    }
                elif shared_session.shared_by_email:
                    share_info["shared_with"] = {
                        "email": shared_session.shared_by_email,
                        "type": "email"
                    }
                else:
                    share_info["shared_with"] = {
                        "type": "public_link"
                    }
                
                result.append(share_info)
            
            return result
            
        except Exception as e:
            return []
    
    def revoke_share(self, session_id: str, user_id: str, share_token: str) -> Dict:
        """Revoke a specific share"""
        try:
            # Verify ownership
            session = TranscriptSession.query.filter_by(id=session_id, user_id=user_id).first()
            if not session:
                return {"success": False, "error": "Session not found or access denied"}
            
            # Find and delete shared session
            shared_session = SharedSession.query.filter_by(
                session_id=session_id, 
                share_token=share_token
            ).first()
            
            if not shared_session:
                return {"success": False, "error": "Share not found"}
            
            db.session.delete(shared_session)
            db.session.commit()
            
            return {"success": True}
            
        except Exception as e:
            db.session.rollback()
            return {"success": False, "error": f"Failed to revoke share: {str(e)}"}
    
    def update_share_permissions(self, session_id: str, user_id: str, 
                                share_token: str, new_permission_level: str) -> Dict:
        """Update permissions for a shared session"""
        try:
            # Verify ownership
            session = TranscriptSession.query.filter_by(id=session_id, user_id=user_id).first()
            if not session:
                return {"success": False, "error": "Session not found or access denied"}
            
            # Find shared session
            shared_session = SharedSession.query.filter_by(
                session_id=session_id,
                share_token=share_token
            ).first()
            
            if not shared_session:
                return {"success": False, "error": "Share not found"}
            
            # Update permission level
            shared_session.permission_level = new_permission_level
            db.session.commit()
            
            return {"success": True, "new_permission_level": new_permission_level}
            
        except Exception as e:
            db.session.rollback()
            return {"success": False, "error": f"Failed to update permissions: {str(e)}"}

# Global sharing service instance
sharing_service = SharingService()