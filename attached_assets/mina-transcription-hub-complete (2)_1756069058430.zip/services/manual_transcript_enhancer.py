# manual_transcript_enhancer.py
# Manual transcript enhancement using rule-based improvements for cases where AI isn't available

import re
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class ManualTranscriptEnhancer:
    """
    Rule-based transcript enhancement for improving quality without AI
    Features:
    - Smart sentence reconstruction
    - Grammar and punctuation fixes
    - Fragment merging with context awareness
    - Professional formatting
    """
    
    def __init__(self):
        # Common filler words to clean up
        self.filler_words = {
            'um', 'uh', 'like', 'you know', 'so', 'basically', 'actually', 
            'literally', 'i mean', 'kind of', 'sort of'
        }
        
        # Sentence starters to capitalize
        self.sentence_starters = {
            'and', 'but', 'so', 'because', 'since', 'when', 'if', 'although',
            'however', 'therefore', 'meanwhile', 'furthermore', 'moreover'
        }
        
    def enhance_transcript(self, raw_transcript: str, context: str = "general") -> Dict[str, Any]:
        """
        Enhance transcript using rule-based improvements
        
        Args:
            raw_transcript: Raw transcript text
            context: Context for enhancement (general, meeting, interview)
            
        Returns:
            Enhanced transcript with quality metrics
        """
        try:
            if not raw_transcript or len(raw_transcript.strip()) < 10:
                return {
                    'enhanced_text': raw_transcript,
                    'original_text': raw_transcript,
                    'enhancement_applied': False,
                    'quality_score': 1.0,
                    'improvements': []
                }
            
            enhanced_text = raw_transcript
            improvements = []
            
            # Step 1: Basic cleanup
            enhanced_text, step_improvements = self._basic_cleanup(enhanced_text)
            improvements.extend(step_improvements)
            
            # Step 2: Fix fragments and merge sentences
            enhanced_text, step_improvements = self._fix_fragments(enhanced_text)
            improvements.extend(step_improvements)
            
            # Step 3: Improve punctuation
            enhanced_text, step_improvements = self._improve_punctuation(enhanced_text)
            improvements.extend(step_improvements)
            
            # Step 4: Capitalize properly
            enhanced_text, step_improvements = self._fix_capitalization(enhanced_text)
            improvements.extend(step_improvements)
            
            # Step 5: Clean up excessive filler words
            if context != "interview":  # Preserve some filler in interviews for authenticity
                enhanced_text, step_improvements = self._clean_filler_words(enhanced_text)
                improvements.extend(step_improvements)
            
            # Step 6: Final formatting
            enhanced_text, step_improvements = self._final_formatting(enhanced_text)
            improvements.extend(step_improvements)
            
            # Calculate quality improvement
            quality_score = self._calculate_quality_improvement(raw_transcript, enhanced_text)
            
            return {
                'enhanced_text': enhanced_text.strip(),
                'original_text': raw_transcript,
                'enhancement_applied': True,
                'quality_score': quality_score,
                'improvements': improvements,
                'word_count_original': len(raw_transcript.split()),
                'word_count_enhanced': len(enhanced_text.split()),
                'processing_type': f'manual_{context}'
            }
            
        except Exception as e:
            logger.error(f"Manual transcript enhancement failed: {e}")
            return {
                'enhanced_text': raw_transcript,
                'original_text': raw_transcript,
                'enhancement_applied': False,
                'quality_score': 0.5,
                'improvements': [],
                'error': str(e)
            }
    
    def _basic_cleanup(self, text: str) -> tuple[str, List[str]]:
        """Basic text cleanup"""
        improvements = []
        
        # Remove excessive spaces
        text = re.sub(r'\s+', ' ', text)
        improvements.append("Normalized spacing")
        
        # Fix common transcription artifacts
        text = re.sub(r'\b(\w)\1{2,}\b', r'\1', text)  # Remove repeated characters
        text = re.sub(r'\b(\w+)\s+\1\b', r'\1', text)  # Remove word repetitions
        improvements.append("Removed repetitions")
        
        # Fix common misheard words in music industry context
        replacements = {
            r'\bdrake gotta\b': 'Drake\'s gotta',
            r'\bwill g\b': 'Will G',
            r'\bmartinez\b': 'Martinez',
            r'\bbillboard\b': 'Billboard',
            r'\bscandadra\b': 'Scandalous',  # Likely mishearing
        }
        
        for pattern, replacement in replacements.items():
            if re.search(pattern, text, re.IGNORECASE):
                text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
                improvements.append(f"Fixed: {pattern}")
        
        return text, improvements
    
    def _fix_fragments(self, text: str) -> tuple[str, List[str]]:
        """Fix sentence fragments and merge incomplete thoughts"""
        improvements = []
        
        # Split into potential sentences
        sentences = re.split(r'[.!?]+', text)
        enhanced_sentences = []
        
        current_sentence = ""
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            # Check if this is a fragment (very short or starts with lowercase)
            is_fragment = (
                len(sentence.split()) < 3 or 
                (sentence and sentence[0].islower() and current_sentence)
            )
            
            if is_fragment and current_sentence:
                # Merge with previous sentence
                current_sentence += " " + sentence
            else:
                # Start new sentence
                if current_sentence:
                    enhanced_sentences.append(current_sentence)
                current_sentence = sentence
        
        # Add final sentence
        if current_sentence:
            enhanced_sentences.append(current_sentence)
        
        if len(enhanced_sentences) != len(sentences):
            improvements.append("Merged sentence fragments")
        
        return '. '.join(enhanced_sentences) + '.', improvements
    
    def _improve_punctuation(self, text: str) -> tuple[str, List[str]]:
        """Improve punctuation and sentence structure"""
        improvements = []
        
        # Fix common punctuation issues
        original_text = text
        
        # Add commas before coordinating conjunctions in long sentences
        text = re.sub(r'(\w+)\s+(and|but|or|so|yet)\s+(\w+)', r'\1, \2 \3', text)
        
        # Fix spacing around punctuation
        text = re.sub(r'\s+([.!?])', r'\1', text)  # Remove space before punctuation
        text = re.sub(r'([.!?])([A-Z])', r'\1 \2', text)  # Add space after punctuation
        
        # Fix question marks for obvious questions
        text = re.sub(r'(what|how|when|where|why|who|does|is|are|can|will|would)\s+.*[^?]\s*$', 
                     lambda m: m.group(0).rstrip() + '?', text, flags=re.IGNORECASE)
        
        if text != original_text:
            improvements.append("Improved punctuation")
        
        return text, improvements
    
    def _fix_capitalization(self, text: str) -> tuple[str, List[str]]:
        """Fix capitalization issues"""
        improvements = []
        original_text = text
        
        # Capitalize sentence beginnings
        sentences = re.split(r'([.!?]+\s*)', text)
        for i in range(0, len(sentences), 2):  # Every other element is a sentence
            if sentences[i]:
                sentences[i] = sentences[i][0].upper() + sentences[i][1:] if len(sentences[i]) > 0 else sentences[i]
        
        text = ''.join(sentences)
        
        # Capitalize proper nouns (names, places, etc.)
        proper_nouns = ['Drake', 'Billboard', 'Martinez', 'Will G', 'Liz']
        for noun in proper_nouns:
            text = re.sub(rf'\b{noun.lower()}\b', noun, text, flags=re.IGNORECASE)
        
        if text != original_text:
            improvements.append("Fixed capitalization")
        
        return text, improvements
    
    def _clean_filler_words(self, text: str) -> tuple[str, List[str]]:
        """Remove excessive filler words while preserving natural flow"""
        improvements = []
        original_word_count = len(text.split())
        
        # Remove standalone filler words
        for filler in self.filler_words:
            pattern = rf'\b{re.escape(filler)}\b'
            text = re.sub(pattern, '', text, flags=re.IGNORECASE)
        
        # Clean up multiple spaces left by removed words
        text = re.sub(r'\s+', ' ', text)
        
        new_word_count = len(text.split())
        if new_word_count < original_word_count:
            improvements.append(f"Removed {original_word_count - new_word_count} filler words")
        
        return text, improvements
    
    def _final_formatting(self, text: str) -> tuple[str, List[str]]:
        """Apply final formatting improvements"""
        improvements = []
        
        # Ensure text starts with capital letter
        if text and text[0].islower():
            text = text[0].upper() + text[1:]
            improvements.append("Capitalized first word")
        
        # Ensure text ends with proper punctuation
        if text and text[-1] not in '.!?':
            text += '.'
            improvements.append("Added final punctuation")
        
        # Fix double punctuation
        text = re.sub(r'[.!?]{2,}', '.', text)
        
        # Fix spacing issues
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'^\s+|\s+$', '', text)
        
        return text, improvements
    
    def _calculate_quality_improvement(self, original: str, enhanced: str) -> float:
        """Calculate quality improvement score"""
        
        # Count improvements
        original_sentences = len([s for s in original.split('.') if s.strip()])
        enhanced_sentences = len([s for s in enhanced.split('.') if s.strip()])
        
        # Count proper capitalization
        original_caps = sum(1 for s in original.split('.') if s.strip() and s.strip()[0].isupper())
        enhanced_caps = sum(1 for s in enhanced.split('.') if s.strip() and s.strip()[0].isupper())
        
        # Count punctuation
        original_punct = len(re.findall(r'[.!?]', original))
        enhanced_punct = len(re.findall(r'[.!?]', enhanced))
        
        # Calculate improvement factors
        sentence_improvement = min(1.0, enhanced_sentences / max(original_sentences, 1))
        cap_improvement = min(1.0, enhanced_caps / max(enhanced_sentences, 1))
        punct_improvement = min(1.0, enhanced_punct / max(len(enhanced.split()), 1) * 10)
        
        # Overall quality score
        quality_score = (sentence_improvement * 0.4 + cap_improvement * 0.3 + punct_improvement * 0.3)
        return min(1.0, max(0.5, quality_score))

def enhance_transcript_manual(text: str, context: str = "general") -> str:
    """Utility function for manual transcript enhancement"""
    enhancer = ManualTranscriptEnhancer()
    result = enhancer.enhance_transcript(text, context)
    return result.get('enhanced_text', text)