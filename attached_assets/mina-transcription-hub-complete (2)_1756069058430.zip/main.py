import logging
import sys

# Configure logging first
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Test critical imports with fallback to standalone mode
numpy_available = False
try:
    import numpy as np
    logger.info(f"NumPy loaded successfully: {np.__version__}")
    numpy_available = True
except Exception as e:
    logger.warning(f"NumPy import failed: {e}")
    logger.info("Starting in fallback mode without heavy dependencies")

if not numpy_available:
    logger.info("Redirecting to standalone application")
    import subprocess
    import sys
    subprocess.run([sys.executable, "app_standalone.py"])
    sys.exit(0)

# Import the properly architected app with blueprint integration  
from app_refactored import create_app, socketio

# Create application with proper integration (all setup handled in create_app)
app = create_app()

# Import successful - running full-featured standalone app
logger.info("Running in full-featured mode with all core dependencies available")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
