"""
Test endpoint for batch transcription validation
Provides /test_batch endpoint for manual WebM blob testing
"""

import os
import logging
from flask import Blueprint, request, jsonify
from routes.batch_transcription import convert_webm_to_wav_robust

logger = logging.getLogger(__name__)

# Create Blueprint for testing
routes_test_batch = Blueprint('test_batch', __name__)

# Import OpenAI client
try:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    whisper_available = True
    logger.info("Test batch: OpenAI Whisper client initialized")
except ImportError as e:
    logger.warning(f"Test batch: OpenAI client not available: {e}")
    whisper_available = False
    client = None

@routes_test_batch.route('/test_batch', methods=['POST'])
def test_batch_endpoint():
    """
    Test endpoint for batch transcription - validates WebM → WAV → Whisper pipeline
    
    Usage:
    curl -X POST http://localhost:5000/test_batch -F "audio=@test.webm"
    
    Test phrase: "Angelina… call up my temperature"
    """
    try:
        logger.info("[TEST_BATCH] Test endpoint called")
        
        # Extract audio data
        audio_data = None
        if 'audio' in request.files:
            audio_file = request.files['audio']
            audio_data = audio_file.read()
        
        if not audio_data:
            return jsonify({
                "status": "error",
                "message": "No audio data provided for testing"
            }), 400
        
        test_id = f"test_{len(audio_data)}"
        logger.info(f"[TEST_BATCH] Processing {len(audio_data)} bytes for validation")
        
        # Test WebM → WAV conversion
        try:
            wav_bytes = convert_webm_to_wav_robust(audio_data, test_id)
            logger.info(f"[TEST_BATCH] Conversion successful: {len(audio_data)} → {len(wav_bytes)} bytes")
        except RuntimeError as err:
            logger.error(f"[TEST_BATCH] Conversion failed: {err}")
            return jsonify({
                "status": "conversion_failed",
                "message": str(err),
                "test_id": test_id,
                "webm_size": len(audio_data)
            }), 500
        
        # Test Whisper transcription
        if whisper_available:
            try:
                import io
                wav_file_obj = io.BytesIO(wav_bytes)
                wav_file_obj.name = f"{test_id}.wav"
                
                transcript_response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=wav_file_obj,
                    response_format="verbose_json"
                )
                
                transcript = transcript_response.text.strip()
                duration = getattr(transcript_response, 'duration', 0.0)
                confidence = getattr(transcript_response, 'confidence', 0.85)
                
                logger.info(f"[TEST_BATCH] Transcription successful: '{transcript}'")
                
                return jsonify({
                    "status": "success",
                    "transcript": transcript,
                    "duration": duration,
                    "confidence": confidence,
                    "model": "whisper-1",
                    "test_id": test_id,
                    "webm_size": len(audio_data),
                    "wav_size": len(wav_bytes),
                    "pipeline": "✅ WebM → WAV → Whisper"
                })
            
            except Exception as e:
                logger.error(f"[TEST_BATCH] Transcription failed: {e}")
                return jsonify({
                    "status": "transcription_failed", 
                    "message": str(e),
                    "test_id": test_id,
                    "conversion": "✅ WebM → WAV successful",
                    "transcription": "❌ Whisper failed"
                }), 500
        else:
            return jsonify({
                "status": "partial_success",
                "message": "WebM conversion successful, but Whisper not available",
                "test_id": test_id,
                "webm_size": len(audio_data),
                "wav_size": len(wav_bytes),
                "conversion": "✅ WebM → WAV successful"
            })
    
    except Exception as e:
        logger.error(f"[TEST_BATCH] Unexpected error: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500