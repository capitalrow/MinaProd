"""
Transcript Enhancement Backend Routes
Supports Otter-style GPT enhancement and rewriting pipeline
"""

from flask import Blueprint, request, jsonify
from openai import OpenAI
import os
import logging

# Create blueprint
transcript_enhancement_bp = Blueprint('transcript_enhancement', __name__)

# Initialize OpenAI client
openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

logger = logging.getLogger(__name__)

@transcript_enhancement_bp.route('/api/enhance_transcript', methods=['POST'])
def enhance_transcript():
    """
    GPT-powered transcript enhancement following Otter.ai patterns
    """
    try:
        data = request.get_json()
        raw_text = data.get('text', '').strip()
        
        if not raw_text:
            return jsonify({'error': 'No text provided'}), 400
        
        logger.info(f"[TRANSCRIPT-ENHANCEMENT] Processing text: {raw_text[:100]}...")
        
        # Create enhancement prompt based on Otter behavior
        enhancement_prompt = f"""
You are an advanced transcript enhancement system similar to Otter.ai. Your job is to clean up and improve a raw speech-to-text transcript.

Rules for enhancement:
1. Fix common transcription errors and spelling mistakes
2. Remove filler words and false starts (um, uh, like)
3. Handle "let me start again" patterns by removing redundant content
4. Improve punctuation and capitalization
5. Maintain the original meaning and tone
6. Keep technical terms and proper nouns intact
7. Make sentences flow naturally

Raw transcript to enhance:
"{raw_text}"

Return ONLY the enhanced transcript text, no explanations or formatting:"""

        # Call GPT-4o for enhancement (the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user)
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": enhancement_prompt}],
            temperature=0.3,  # Lower temperature for consistent enhancements
            max_tokens=1000
        )
        
        enhanced_text = response.choices[0].message.content.strip()
        
        # Log success
        logger.info(f"[TRANSCRIPT-ENHANCEMENT] ✅ Enhanced {len(raw_text)} chars → {len(enhanced_text)} chars")
        
        return jsonify({
            'enhanced_text': enhanced_text,
            'original_length': len(raw_text),
            'enhanced_length': len(enhanced_text),
            'improvement_ratio': len(enhanced_text) / len(raw_text) if len(raw_text) > 0 else 1.0
        })
        
    except Exception as e:
        logger.error(f"[TRANSCRIPT-ENHANCEMENT] ❌ Enhancement failed: {str(e)}")
        return jsonify({'error': 'Enhancement failed', 'details': str(e)}), 500

@transcript_enhancement_bp.route('/api/transcript_rating', methods=['POST'])
def record_transcript_rating():
    """
    Record user rating for transcript quality (Otter-style feedback)
    """
    try:
        data = request.get_json()
        rating = data.get('rating', 0)
        session_duration = data.get('session_duration', '0:00')
        chunk_count = data.get('chunk_count', 0)
        timestamp = data.get('timestamp')
        
        # Log the rating for QA purposes
        logger.info(f"[TRANSCRIPT-RATING] ⭐ User rating: {rating}/5 stars, Duration: {session_duration}, Chunks: {chunk_count}")
        
        # Here you could store ratings in database for analysis
        # For now, we'll just return success
        
        return jsonify({
            'status': 'success',
            'rating_recorded': rating,
            'message': f'Thank you for rating the transcript {rating}/5 stars!'
        })
        
    except Exception as e:
        logger.error(f"[TRANSCRIPT-RATING] ❌ Rating recording failed: {str(e)}")
        return jsonify({'error': 'Rating recording failed', 'details': str(e)}), 500

@transcript_enhancement_bp.route('/api/false_start_detection', methods=['POST'])
def detect_false_starts():
    """
    Detect and handle false starts like "Oh my God, let me start again"
    """
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        # False start patterns based on Otter analysis
        false_start_patterns = [
            "oh my god, let me start again",
            "let me start again",
            "um, let me",
            "actually, let me start over",
            "wait, let me restart"
        ]
        
        detected_false_start = False
        cleaned_text = text.lower()
        
        # Check for false start patterns
        for pattern in false_start_patterns:
            if pattern in cleaned_text:
                detected_false_start = True
                # Remove everything before the false start trigger
                parts = cleaned_text.split(pattern)
                if len(parts) > 1:
                    cleaned_text = parts[-1].strip()  # Keep only text after false start
                    break
        
        # Capitalize first letter
        if cleaned_text:
            cleaned_text = cleaned_text[0].upper() + cleaned_text[1:]
        
        logger.info(f"[FALSE-START] Detected: {detected_false_start}, Original: {len(text)}, Cleaned: {len(cleaned_text)}")
        
        return jsonify({
            'false_start_detected': detected_false_start,
            'cleaned_text': cleaned_text if detected_false_start else text,
            'original_text': text,
            'should_overwrite': detected_false_start
        })
        
    except Exception as e:
        logger.error(f"[FALSE-START] ❌ Detection failed: {str(e)}")
        return jsonify({'error': 'False start detection failed', 'details': str(e)}), 500