"""
Admin Routes
Administrative functionality for system management
"""

from flask import Blueprint, render_template, request, jsonify
from services.auth_service import auth_service, login_required
from functools import wraps

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = auth_service.get_current_user()
        if not user or not user.get('is_admin', False):
            if request.is_json:
                return jsonify({'error': 'Admin access required'}), 403
            return render_template('errors/403.html'), 403
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    """Admin dashboard"""
    user = auth_service.get_current_user()
    
    # TODO: Get system statistics
    stats = {
        'total_users': 0,
        'active_sessions': 0,
        'total_transcriptions': 0,
        'system_health': 'healthy'
    }
    
    return render_template('admin/dashboard.html',
                         user=user,
                         stats=stats)

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    """User management"""
    user = auth_service.get_current_user()
    
    # TODO: Get user list
    users_list = []
    
    return render_template('admin/users.html',
                         user=user,
                         users=users_list)

@admin_bp.route('/system')
@login_required
@admin_required
def system():
    """System monitoring"""
    user = auth_service.get_current_user()
    
    # TODO: Get system metrics
    metrics = {
        'cpu_usage': 0,
        'memory_usage': 0,
        'disk_usage': 0,
        'active_connections': 0
    }
    
    return render_template('admin/system.html',
                         user=user,
                         metrics=metrics)