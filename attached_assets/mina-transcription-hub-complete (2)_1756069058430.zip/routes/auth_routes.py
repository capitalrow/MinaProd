"""
Authentication Routes
Secure user authentication and session management
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from services.auth_service import auth_service, csrf_required, rate_limit
from models import User, db
from datetime import datetime, timedelta
import uuid
import re
import logging
import secrets

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'GET':
        # Check if already authenticated
        if current_user.is_authenticated:
            return redirect(url_for('main.dashboard'))
        
        csrf_token = auth_service.generate_csrf_token() if hasattr(auth_service, 'app') else ''
        return render_template('auth/login.html', csrf_token=csrf_token)
    
    # POST - Handle login
    try:
        data = request.get_json() if request.is_json else request.form
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')
        remember_me = data.get('remember_me', False)
        
        # Validate input
        if not email or not password:
            error = 'Email and password are required'
            if request.is_json:
                return jsonify({'error': error}), 400
            flash(error, 'error')
            return render_template('auth/login.html')
        
        # Validate email format
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            error = 'Invalid email format'
            if request.is_json:
                return jsonify({'error': error}), 400
            flash(error, 'error')
            return render_template('auth/login.html')
        
        # Find user with error handling
        try:
            from models import User
            user = User.query.filter_by(email=email, is_active=True).first()
        except Exception as db_error:
            logger.error(f"Database error during login: {db_error}")
            if request.is_json:
                return jsonify({'error': 'Login failed'}), 500
            flash('Login failed. Please try again.', 'error')
            return render_template('auth/login.html')
        
        if not user or not check_password_hash(user.password_hash, password):
            error = 'Invalid email or password'
            if request.is_json:
                return jsonify({'error': error}), 401
            flash(error, 'error')
            return render_template('auth/login.html')
        
        # Update last login
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Use Flask-Login to manage session
        login_user(user, remember=remember_me)
        
        # Set session timeout
        if remember_me:
            session.permanent = True
        
        # Success response
        if request.is_json:
            return jsonify({
                'success': True,
                'user': user.to_dict(),
                'redirect': url_for('main.dashboard')
            })
        
        flash(f'Welcome back, {user.get_full_name()}!', 'success')
        next_page = request.args.get('next')
        return redirect(next_page if next_page else url_for('main.dashboard'))
        
    except Exception as e:
        error = 'Login failed. Please try again.'
        if request.is_json:
            return jsonify({'error': error}), 500
        flash(error, 'error')
        return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if request.method == 'GET':
        # Check if already authenticated
        if current_user.is_authenticated:
            return redirect(url_for('main.dashboard'))
        
        csrf_token = auth_service.generate_csrf_token() if hasattr(auth_service, 'app') else ''
        return render_template('auth/register.html', csrf_token=csrf_token)
    
    # POST - Handle registration
    try:
        data = request.get_json() if request.is_json else request.form
        
        # Extract form data
        email = data.get('email', '').strip().lower()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        confirm_password = data.get('confirm_password', '')
        first_name = data.get('first_name', '').strip()
        last_name = data.get('last_name', '').strip()
        use_case = data.get('use_case', '')
        terms_accepted = data.get('terms_accepted', False)
        
        # Validation
        errors = []
        
        if not email:
            errors.append('Email is required')
        elif not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            errors.append('Invalid email format')
        
        if not username:
            errors.append('Username is required')
        elif len(username) < 3:
            errors.append('Username must be at least 3 characters')
        elif not re.match(r'^[a-zA-Z0-9_-]+$', username):
            errors.append('Username can only contain letters, numbers, underscores, and hyphens')
        
        if not password:
            errors.append('Password is required')
        else:
            password_validation = auth_service.validate_password(password)
            if not password_validation['valid']:
                errors.extend(password_validation['errors'])
        
        if password != confirm_password:
            errors.append('Passwords do not match')
        
        if not first_name:
            errors.append('First name is required')
        
        if not terms_accepted:
            errors.append('You must accept the terms of service')
        
        # Check for existing users
        try:
            existing_email = User.query.filter_by(email=email).first()
            existing_username = User.query.filter_by(username=username).first()
            
            if existing_email:
                errors.append('Email already registered')
            if existing_username:
                errors.append('Username already taken')
        except Exception as e:
            logger.error(f"Database error checking existing users: {e}")
            errors.append('Registration temporarily unavailable')
        
        if errors:
            if request.is_json:
                return jsonify({'errors': errors}), 400
            for error in errors:
                flash(error, 'error')
            return render_template('auth/register.html')
        
        # Create new user
        user = User()
        user.id = str(uuid.uuid4())
        user.email = email
        user.username = username
        user.first_name = first_name
        user.last_name = last_name
        user.use_case = use_case
        user.is_active = True
        user.is_verified = False
        user.created_at = datetime.utcnow()
        user.set_password(password)
        
        # Save to database with proper error handling
        try:
            db.session.add(user)
            db.session.commit()
        except Exception as db_error:
            db.session.rollback()
            logger.error(f"Database error during user creation: {db_error}")
            if request.is_json:
                return jsonify({'error': 'User registration failed'}), 500
            flash('Registration failed. Please try again.', 'error')
            return render_template('auth/register.html')
        
        # Use Flask-Login to log in the new user
        login_user(user, remember=True)
        
        logger.info(f"New user registered: {email}")
        
        # Success response
        if request.is_json:
            return jsonify({
                'success': True,
                'user': user.to_dict(),
                'redirect': url_for('main.dashboard')
            })
        
        flash(f'Welcome to Mina Pro, {user.get_full_name()}!', 'success')
        return redirect(url_for('main.dashboard'))
        
    except Exception as e:
        error = 'Registration failed. Please try again.'
        if request.is_json:
            return jsonify({'error': error}), 500
        flash(error, 'error')
        return render_template('auth/register.html')

@auth_bp.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    """User logout"""
    try:
        # Get current user for goodbye message
        user_name = current_user.get_full_name() if current_user.is_authenticated else 'User'
        
        # Use Flask-Login logout
        logout_user()
        
        if request.is_json:
            return jsonify({'success': True, 'redirect': url_for('main.index')})
        
        flash(f'Goodbye, {user_name}! You have been logged out.', 'info')
        return redirect(url_for('main.index'))
        
    except Exception as e:
        if request.is_json:
            return jsonify({'error': 'Logout failed'}), 500
        flash('Logout failed. Please try again.', 'error')
        return redirect(url_for('main.dashboard'))

@auth_bp.route('/profile')
@login_required
def profile():
    """User profile page"""
    return render_template('auth/profile.html', user=current_user)

@auth_bp.route('/update_profile', methods=['POST'])
@login_required
def update_profile():
    """Update user profile"""
    try:
        # Get form data
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        username = request.form.get('username', '').strip()
        use_case = request.form.get('use_case', '')
        
        # Validation
        errors = []
        
        if not first_name:
            errors.append('First name is required')
        
        if not email:
            errors.append('Email is required')
        elif not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            errors.append('Invalid email format')
        
        if not username:
            errors.append('Username is required')
        elif len(username) < 3:
            errors.append('Username must be at least 3 characters')
        
        # Check for existing users (excluding current user)
        existing_email = User.query.filter(User.email == email, User.id != current_user.id).first()
        existing_username = User.query.filter(User.username == username, User.id != current_user.id).first()
        
        if existing_email:
            errors.append('Email already in use')
        if existing_username:
            errors.append('Username already in use')
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return redirect(url_for('auth.profile'))
        
        # Update user
        current_user.first_name = first_name
        current_user.last_name = last_name
        current_user.email = email
        current_user.username = username
        current_user.use_case = use_case
        
        db.session.commit()
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('auth.profile'))
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Profile update error: {e}")
        flash('Profile update failed. Please try again.', 'error')
        return redirect(url_for('auth.profile'))

@auth_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    """User settings page"""
    if request.method == 'GET':
        return render_template('settings.html', 
                             user=current_user,
                             csrf_token=auth_service.generate_csrf_token())
    
    # POST - Update settings
    try:
        data = request.get_json() if request.is_json else request.form
        
        # Update user settings in database
        try:
            from models import db
            user_obj = User.query.get(user['id'])
            if user_obj:
                user_obj.first_name = data.get('first_name', user_obj.first_name)
                user_obj.last_name = data.get('last_name', user_obj.last_name)
                user_obj.ui_theme = data.get('theme', user_obj.ui_theme)
                user_obj.auto_summary = data.get('auto_summary', user_obj.auto_summary)
                user_obj.enable_emotion_detection = data.get('emotion_detection', user_obj.enable_emotion_detection)
                user_obj.enable_action_extraction = data.get('action_extraction', user_obj.enable_action_extraction)
                user_obj.auto_email_transcript = data.get('email_transcript', user_obj.auto_email_transcript)
                db.session.commit()
            else:
                raise ValueError('User not found')
        except Exception as db_error:
            logger.error(f"Error updating user settings: {db_error}")
            db.session.rollback()
            if request.is_json:
                return jsonify({'error': 'Failed to update settings'}), 500
            flash('Failed to update settings', 'error')
            return render_template('auth/settings.html', user=user)
        
        if request.is_json:
            return jsonify({'success': True, 'message': 'Settings updated successfully'})
        
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('auth.settings'))
        
    except Exception as e:
        error = 'Failed to update settings'
        if request.is_json:
            return jsonify({'error': error}), 500
        flash(error, 'error')
        return render_template('auth/settings.html', user=user)

@auth_bp.route('/change-password', methods=['POST'])
@login_required
@csrf_required
@rate_limit(limit=3, window=900)  # 3 attempts per 15 minutes
def change_password():
    """Change user password"""
    try:
        user = auth_service.get_current_user()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json() if request.is_json else request.form
        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')
        confirm_password = data.get('confirm_password', '')
        
        # Validation
        if not current_password or not new_password or not confirm_password:
            return jsonify({'error': 'All password fields are required'}), 400
        
        if new_password != confirm_password:
            return jsonify({'error': 'New passwords do not match'}), 400
        
        # Verify current password and update
        try:
            from models import db
            user_obj = User.query.get(user['id'])
            if not user_obj or not user_obj.check_password(current_password):
                return jsonify({'error': 'Current password is incorrect'}), 400
            
            # Validate new password
            password_validation = auth_service.validate_password(new_password)
            if not password_validation['valid']:
                return jsonify({'errors': password_validation['errors']}), 400
            
            # Update password
            user_obj.set_password(new_password)
            db.session.commit()
        except Exception as db_error:
            logger.error(f"Error changing password: {db_error}")
            db.session.rollback()
            return jsonify({'error': 'Failed to change password'}), 500
        
        return jsonify({'success': True, 'message': 'Password changed successfully'})
        
    except Exception as e:
        return jsonify({'error': 'Failed to change password'}), 500

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
@rate_limit(limit=3, window=3600)  # 3 attempts per hour
def forgot_password():
    """Forgot password request"""
    if request.method == 'GET':
        return render_template('auth/forgot_password.html',
                             csrf_token=auth_service.generate_csrf_token())
    
    # POST - Send reset email
    try:
        data = request.get_json() if request.is_json else request.form
        email = data.get('email', '').strip().lower()
        
        if not email:
            error = 'Email is required'
            if request.is_json:
                return jsonify({'error': error}), 400
            flash(error, 'error')
            return render_template('auth/forgot_password.html')
        
        # Implement password reset email functionality
        try:
            user_obj = User.query.filter_by(email=email, is_active=True).first()
            if user_obj:
                # Generate reset token (simplified - in production use secure tokens)
                reset_token = secrets.token_urlsafe(32)
                reset_expires = datetime.utcnow() + timedelta(hours=1)
                
                # Store token in user record (would need to add reset_token and reset_expires fields to User model)
                # For now, just log the reset attempt
                logger.info(f"Password reset requested for user {user_obj.id}")
                
                # In production, send email with reset link
                # send_password_reset_email(user_obj.email, reset_token)
        except Exception as e:
            logger.error(f"Password reset error: {e}")
        
        # Always show success message for security
        message = 'If an account with that email exists, you will receive password reset instructions.'
        
        if request.is_json:
            return jsonify({'success': True, 'message': message})
        
        flash(message, 'info')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        error = 'Failed to process request'
        if request.is_json:
            return jsonify({'error': error}), 500
        flash(error, 'error')
        return render_template('auth/forgot_password.html')

# API Endpoints
@auth_bp.route('/api/validate-token', methods=['POST'])
def validate_token():
    """Validate JWT token"""
    try:
        auth_header = request.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            return jsonify({'valid': False, 'error': 'Invalid authorization header'}), 401
        
        token = auth_header[7:]
        payload = auth_service.verify_token(token)
        
        if not payload:
            return jsonify({'valid': False, 'error': 'Invalid or expired token'}), 401
        
        # Get user from database
        try:
            user_obj = User.query.get(payload['user_id'])
            if not user_obj or not user_obj.is_active:
                return jsonify({'valid': False, 'error': 'User not found or inactive'}), 401
        except Exception as e:
            logger.error(f"Database error validating token: {e}")
            return jsonify({'valid': False, 'error': 'Token validation failed'}), 500
        
        return jsonify({
            'valid': True,
            'user': {
                'id': user_obj.id,
                'username': user_obj.username,
                'email': user_obj.email,
                'full_name': user_obj.get_full_name(),
                'is_premium': user_obj.is_premium
            }
        })
        
    except Exception as e:
        return jsonify({'valid': False, 'error': 'Token validation failed'}), 500

@auth_bp.route('/api/refresh-token', methods=['POST'])
def refresh_token():
    """Refresh access token"""
    try:
        data = request.get_json()
        refresh_token = data.get('refresh_token')
        
        if not refresh_token:
            return jsonify({'error': 'Refresh token is required'}), 400
        
        new_tokens = auth_service.refresh_access_token(refresh_token)
        
        if not new_tokens:
            return jsonify({'error': 'Invalid or expired refresh token'}), 401
        
        return jsonify(new_tokens)
        
    except Exception as e:
        return jsonify({'error': 'Token refresh failed'}), 500

@auth_bp.route('/api/check-availability', methods=['POST'])
@rate_limit(limit=10, window=60)  # 10 checks per minute
def check_availability():
    """Check username/email availability"""
    try:
        data = request.get_json()
        field_type = data.get('type')  # 'email' or 'username'
        value = data.get('value', '').strip()
        
        if field_type not in ['email', 'username']:
            return jsonify({'error': 'Invalid field type'}), 400
        
        if not value:
            return jsonify({'available': False, 'error': 'Value is required'})
        
        # Check database for availability
        try:
            if field_type == 'email':
                exists = User.query.filter_by(email=value.lower()).first() is not None
            else:
                exists = User.query.filter_by(username=value).first() is not None
        except Exception as e:
            logger.error(f"Database error checking availability: {e}")
            return jsonify({'error': 'Availability check failed'}), 500
        
        return jsonify({
            'available': not exists,
            'message': f'{field_type.title()} is {"not " if exists else ""}available'
        })
        
    except Exception as e:
        return jsonify({'error': 'Availability check failed'}), 500

# Error handlers
@auth_bp.errorhandler(429)
def rate_limit_exceeded(e):
    """Rate limit exceeded"""
    if request.is_json:
        return jsonify({'error': 'Rate limit exceeded. Please try again later.'}), 429
    
    flash('Too many attempts. Please try again later.', 'error')
    return redirect(url_for('auth.login'))