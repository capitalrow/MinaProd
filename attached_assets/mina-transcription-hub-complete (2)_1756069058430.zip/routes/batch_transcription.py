"""
Clean Batch Transcription Route - Enhanced with Session Management
Handles batched audio chunks with comprehensive error handling and session tracking
"""

import os
import logging
import time
import tempfile
import subprocess
from flask import Blueprint, request, jsonify, current_app
from flask_socketio import emit
from datetime import datetime
from audio_processor import AudioProcessor
from services.session_manager import session_manager

logger = logging.getLogger(__name__)

# Create Blueprint for batch transcription
batch_transcription = Blueprint('batch_transcription', __name__)

# Initialize services
audio_processor = AudioProcessor()

# Import OpenAI client for Whisper API calls
try:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    whisper_available = True
    logger.info("OpenAI Whisper client initialized")
except ImportError as e:
    logger.warning(f"OpenAI client not available: {e}")
    whisper_available = False
    client = None

def is_hallucinated_transcript(transcript):
    """
    Filter hallucinated or invalid transcriptions
    Returns True if transcript should be discarded
    """
    if not transcript or len(transcript.strip()) < 5:
        return True
        
    text = transcript.strip().lower()
    
    # Music and sound effect hallucinations
    music_indicators = ['🎵', '♪', '♫', '[music]', '(music)', '[sound]', '(sound)', 
                       'background music', 'instrumental', 'applause', 'clapping']
    if any(indicator in text for indicator in music_indicators):
        logger.info(f"[FILTER] Music hallucination detected: {transcript[:30]}...")
        return True
    
    # Repetitive patterns
    if len(set(text.split())) < 3 and len(text) > 20:
        logger.info(f"[FILTER] Repetitive content detected: {transcript[:30]}...")
        return True
    
    # Invalid character sequences
    if len([c for c in text if not c.isalnum() and c not in ' .,!?-']) > len(text) * 0.3:
        logger.info(f"[FILTER] Invalid characters detected: {transcript[:30]}...")
        return True
        
    return False

def batch_transcribe_whisper_with_retry(audio_data, session_id, chunk_id=None, meeting_type="general", context_prompt="", max_retries=3):
    """
    Enhanced batch transcription with retry logic, hallucination filtering, and WebSocket support
    """
    if not audio_data:
        return {"status": "error", "message": "No audio data provided"}
    
    if not whisper_available or not client:
        return {"status": "error", "message": "Whisper client not available"}
    
    # Retry configuration
    retry_delays = [1000, 2000, 4000]  # Exponential backoff in ms
    
    for attempt in range(max_retries):
        try:
            with open(audio_data, 'rb') if isinstance(audio_data, str) else audio_data as audio_file:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    response_format="verbose_json",
                    temperature=0.0,
                    prompt=context_prompt if context_prompt else f"This is a {meeting_type} meeting audio segment."
                )
            
            transcript = response.text.strip() if response.text else ""
            
            # Filter hallucinations
            if is_hallucinated_transcript(transcript):
                logger.info(f"[BATCH-TRANSCRIBE] Filtered hallucination for {chunk_id}: {transcript[:30]}...")
                return {"status": "filtered", "message": "Hallucination filtered", "text": ""}
            
            # Calculate confidence from segments
            confidence = 0.0
            segments = getattr(response, 'segments', [])
            if segments:
                total_logprob = sum(getattr(seg, 'avg_logprob', -1.0) for seg in segments)
                avg_logprob = total_logprob / len(segments)
                confidence = max(0.0, min(1.0, (avg_logprob + 1.0)))
            
            result = {
                "status": "success",
                "text": transcript,
                "confidence": confidence,
                "chunk_id": chunk_id,
                "session_id": session_id,
                "segments": segments,
                "timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"[BATCH-TRANSCRIBE] Success for {chunk_id}: '{transcript}' (confidence: {confidence:.2f})")
            return result
            
        except Exception as e:
            logger.warning(f"[BATCH-TRANSCRIBE] Attempt {attempt + 1} failed for {chunk_id}: {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delays[attempt] / 1000.0)
            else:
                return {"status": "error", "message": str(e), "chunk_id": chunk_id}

def convert_webm_to_wav_robust(webm_data, output_path=None):
    """
    Robust WebM to WAV conversion with comprehensive error handling
    Missing function that app_standalone.py is trying to import
    """
    import tempfile
    import subprocess
    
    try:
        # Create temporary files
        with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as webm_temp:
            webm_temp.write(webm_data if isinstance(webm_data, bytes) else webm_data.read())
            webm_path = webm_temp.name
        
        # Output path
        if output_path is None:
            wav_temp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            output_path = wav_temp.name
            wav_temp.close()
        
        # Convert using FFmpeg
        ffmpeg_cmd = [
            'ffmpeg', '-y', '-i', webm_path,
            '-acodec', 'pcm_s16le',
            '-ar', '16000',
            '-ac', '1',
            output_path
        ]
        
        result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True)
        
        # Clean up temp webm
        os.unlink(webm_path)
        
        if result.returncode == 0:
            logger.info(f"[CONVERT] Successfully converted WebM to WAV: {output_path}")
            return output_path
        else:
            logger.error(f"[CONVERT] FFmpeg error: {result.stderr}")
            return None
            
    except Exception as e:
        logger.error(f"[CONVERT] Conversion failed: {e}")
        return None

@batch_transcription.route('/api/transcribe_batch', methods=['POST'])
def transcribe_batch():
    """
    Enhanced batch transcription endpoint
    """
    try:
        # Get audio data and session info
        audio_data = request.files.get('audio')
        session_id = request.form.get('session_id', f"session_{int(time.time())}")
        chunk_id = request.form.get('chunk_id', f"chunk_{int(time.time())}")
        meeting_type = request.form.get('meeting_type', 'general')
        context_prompt = request.form.get('context', '')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
        
        # Read audio data
        audio_bytes = audio_data.read()
        
        # Call transcription function
        result = batch_transcribe_whisper_with_retry(
            audio_bytes, session_id, chunk_id, meeting_type, context_prompt
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"[BATCH-ENDPOINT] Error: {e}")
        return jsonify({"error": str(e)}), 500