from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
import os
import json
import glob
import logging
from datetime import datetime
from audio_transcript_qa_auditor import AudioTranscriptQAuditor
from services.transcription_quality_comparator import transcription_comparator
try:
    from models import TranscriptSession as TranscriptionSession, MinaMemory
    from sqlalchemy.orm import declarative_base
    Base = declarative_base()
    
    # Create a simple database session mock
    class db:
        @staticmethod
        def session():
            return None
except ImportError:
    # Create mock classes if models aren't available
    class TranscriptionSession:
        @classmethod
        def query(cls):
            return MockQuery()
    
    class MinaMemory:
        pass
    
    class MockQuery:
        def order_by(self, *args):
            return self
        def limit(self, n):
            return self
        def all(self):
            return []
    
    class db:
        @staticmethod
        def session():
            return None

qa_auditor_bp = Blueprint('qa_auditor', __name__)
qa_auditor = AudioTranscriptQAuditor()

@qa_auditor_bp.route('/qa_auditor')
def qa_dashboard():
    """Enhanced QA Auditor dashboard with Otter.ai integration support"""
    try:
        # Get database sessions (primary source) - use file-based for now since models may not be connected
        db_sessions = []  # TranscriptionSession.query.order_by(TranscriptionSession.created_at.desc()).limit(50).all()
        
        # Get file-based sessions (legacy support)
        transcript_files = glob.glob('transcripts/*.txt')
        audio_files = glob.glob('recordings/*.wav') + glob.glob('recordings/*.mp3') + glob.glob('recordings/*.webm')
        
        sessions = []
        
        # Process database sessions
        for db_session in db_sessions:
            sessions.append({
                'session_id': db_session.session_id,
                'transcript_file': f'transcripts/{db_session.session_id}.txt',
                'audio_file': f'recordings/{db_session.session_id}.wav',
                'has_audio': os.path.exists(f'recordings/{db_session.session_id}.wav') or 
                           os.path.exists(f'recordings/{db_session.session_id}.mp3') or
                           os.path.exists(f'recordings/{db_session.session_id}.webm'),
                'timestamp': db_session.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'duration': db_session.duration_seconds if db_session.duration_seconds else 0,
                'total_words': len(db_session.final_transcript.split()) if db_session.final_transcript else 0,
                'source': 'database',
                'otter_enhanced': hasattr(db_session, 'post_processed') and db_session.post_processed,
                'user_rating': getattr(db_session, 'user_rating', None)
            })
        
        # Process file-based sessions (backward compatibility)
        for transcript_file in transcript_files:
            session_id = os.path.basename(transcript_file).replace('.txt', '')
            
            # Skip if already processed from database
            if any(s['session_id'] == session_id for s in sessions):
                continue
                
            audio_file = None
            for audio in audio_files:
                if session_id in audio:
                    audio_file = audio
                    break
            
            sessions.append({
                'session_id': session_id,
                'transcript_file': transcript_file,
                'audio_file': audio_file,
                'has_audio': audio_file is not None,
                'timestamp': datetime.fromtimestamp(os.path.getmtime(transcript_file)).strftime('%Y-%m-%d %H:%M:%S'),
                'duration': 0,
                'total_words': 0,
                'source': 'file',
                'otter_enhanced': False,
                'user_rating': None
            })
        
        # Get recent QA reports with enhanced metrics
        qa_reports = []
        if os.path.exists('feedback'):
            for report_file in glob.glob('feedback/*_qa_analysis.json'):
                try:
                    with open(report_file, 'r') as f:
                        report = json.load(f)
                        report['file'] = os.path.basename(report_file)
                        # Add quality score calculation
                        if 'word_error_rate' in report:
                            wer = report['word_error_rate']
                            if wer <= 0.05:
                                report['quality_grade'] = 'Excellent'
                                report['quality_class'] = 'score-excellent'
                            elif wer <= 0.15:
                                report['quality_grade'] = 'Good'
                                report['quality_class'] = 'score-good'
                            elif wer <= 0.30:
                                report['quality_grade'] = 'Fair'
                                report['quality_class'] = 'score-fair'
                            else:
                                report['quality_grade'] = 'Poor'
                                report['quality_class'] = 'score-poor'
                        qa_reports.append(report)
                except Exception as e:
                    logging.warning(f"Failed to load QA report {report_file}: {e}")
        
        # Calculate dashboard statistics
        total_sessions = len(sessions)
        sessions_with_audio = len([s for s in sessions if s['has_audio']])
        otter_enhanced_sessions = len([s for s in sessions if s.get('otter_enhanced')])
        avg_quality_score = 0
        
        if qa_reports:
            quality_scores = [r.get('quality_score', 0) for r in qa_reports if r.get('quality_score')]
            avg_quality_score = sum(quality_scores) / len(quality_scores) if quality_scores else 0
        
        # Get transcription quality insights from comparator
        quality_insights = {}
        try:
            quality_insights = transcription_comparator.get_quality_insights_for_qa()
        except Exception as e:
            logging.warning(f"Failed to get quality insights: {e}")
            quality_insights = {
                'total_sessions_analyzed': 0,
                'average_wer': 0.0,
                'average_quality_score': 0.0,
                'top_suggestions': []
            }
        
        stats = {
            'total_sessions': total_sessions,
            'sessions_with_audio': sessions_with_audio,
            'otter_enhanced_sessions': otter_enhanced_sessions,
            'avg_quality_score': round(avg_quality_score, 1),
            'qa_reports_count': len(qa_reports),
            'quality_analysis': {
                'sessions_analyzed': quality_insights['total_sessions_analyzed'],
                'average_wer': round(quality_insights['average_wer'], 3),
                'average_quality_score': round(quality_insights['average_quality_score'], 1),
                'top_improvements': [suggestion[0] for suggestion in quality_insights['top_suggestions'][:3]]
            }
        }
        
        return render_template('qa_auditor_dashboard.html', 
                             sessions=sessions[:50],  # Show last 50 sessions
                             qa_reports=qa_reports[:10],  # Last 10 reports
                             stats=stats)
    
    except Exception as e:
        logging.error(f"QA Dashboard error: {e}")
        return render_template('qa_auditor_dashboard.html', 
                             sessions=[], 
                             qa_reports=[], 
                             stats={}, 
                             error=f"Dashboard error: {str(e)}")

@qa_auditor_bp.route('/api/qa_audit_session', methods=['POST'])
def audit_session():
    """Enhanced audit with Otter.ai post-processing awareness"""
    try:
        # Handle both JSON and form data
        if request.is_json:
            data = request.get_json() or {}
        else:
            data = request.form.to_dict()
        
        session_id = data.get('session_id')
        include_otter_metrics = data.get('include_otter_metrics', True)
        
        logging.info(f"QA Audit request for session: {session_id}")
        
        if not session_id:
            logging.error("No session ID provided in request")
            return jsonify({'error': 'Session ID required', 'received_data': data}), 400
        
        # Check if session has Otter.ai enhancements
        # Note: For now, skip database lookup since models are file-based
        transcript_session = None
        
        # Perform standard QA audit
        result = qa_auditor.audit_session(session_id)
        
        # If audit returns None, create a basic result structure
        if result is None:
            result = {
                'session_id': session_id,
                'status': 'no_analysis',
                'message': 'No quality analysis available - audio file may be corrupted or missing',
                'quality_score': 0,
                'issues_found': 0,
                'recommendations': ['Check audio file integrity', 'Verify file format compatibility']
            }
        
        # Add Otter-specific metrics if available
        if include_otter_metrics and result:
            # Load transcript from file for analysis
            transcript_file = f"transcripts/{session_id}.txt"
            final_transcript = ""
            
            try:
                if os.path.exists(transcript_file):
                    with open(transcript_file, 'r') as f:
                        final_transcript = f.read()
            except Exception as e:
                logging.warning(f"Could not load transcript: {e}")
            
            otter_metrics = {
                'post_processed': False,  # File-based sessions are not post-processed
                'user_rating': None,
                'false_starts_detected': 0,
                'sentence_coherence_score': 0,
                'avg_word_length': 0,
            }
            
            # Calculate additional Otter metrics
            if final_transcript:
                words = final_transcript.split()
                otter_metrics['avg_word_length'] = sum(len(word) for word in words) / len(words) if words else 0
                
                # Simple false start detection (looking for patterns)
                false_start_patterns = ['let me start again', 'actually', 'I mean', 'wait']
                otter_metrics['false_starts_detected'] = sum(
                    final_transcript.lower().count(pattern) 
                    for pattern in false_start_patterns
                )
                
                # Basic sentence coherence (sentences ending with punctuation)
                sentences = [s.strip() for s in final_transcript.split('.') if s.strip()]
                otter_metrics['sentence_coherence_score'] = len(sentences) / max(len(words) / 10, 1)
            
            result['otter_metrics'] = otter_metrics
        
        return jsonify(result)
    
    except Exception as e:
        logging.error(f'Audit failed for session {session_id if "session_id" in locals() else "unknown"}: {e}')
        return jsonify({
            'error': f'Audit failed: {str(e)}',
            'session_id': session_id if 'session_id' in locals() else None,
            'status': 'error'
        }), 500

@qa_auditor_bp.route('/api/qa_submit_rating', methods=['POST'])
def submit_rating():
    """Submit user rating for Otter.ai sessions"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        rating = data.get('rating')  # 1-5 stars
        feedback = data.get('feedback', '')
        
        if not session_id or not rating:
            return jsonify({'error': 'Session ID and rating required'}), 400
        
        if not (1 <= int(rating) <= 5):
            return jsonify({'error': 'Rating must be between 1 and 5'}), 400
        
        # Update database session if exists (skip for file-based sessions)
        db_session = None  # File-based sessions don't have database records
        if db_session:
            db_session.user_rating = int(rating)
            # Add feedback field if it exists in the model
            if hasattr(db_session, 'user_feedback'):
                db_session.user_feedback = feedback
            db.session.commit()
        
        # Store rating in feedback file
        rating_data = {
            'session_id': session_id,
            'rating': int(rating),
            'feedback': feedback,
            'timestamp': datetime.now().isoformat(),
            'type': 'user_rating'
        }
        
        rating_file = f'feedback/{session_id}_user_rating.json'
        with open(rating_file, 'w') as f:
            json.dump(rating_data, f, indent=2)
        
        return jsonify({'success': True, 'message': 'Rating submitted successfully'})
    
    except Exception as e:
        logging.error(f'Rating submission failed: {e}')
        return jsonify({'error': f'Rating submission failed: {str(e)}'}), 500

@qa_auditor_bp.route('/api/qa_download_report/<session_id>')
def download_report(session_id):
    """Download QA report for a specific session"""
    try:
        report_file = f'feedback/{session_id}_qa_analysis.json'
        if os.path.exists(report_file):
            return send_file(report_file, as_attachment=True, download_name=f'{session_id}_qa_report.json')
        else:
            return jsonify({'error': 'Report not found'}), 404
    except Exception as e:
        return jsonify({'error': f'Download failed: {str(e)}'}), 500

@qa_auditor_bp.route('/qa_session/<session_id>')
def session_detail(session_id):
    """Enhanced session detail page with Otter.ai integration"""
    try:
        # Load QA report if exists
        report_file = f'feedback/{session_id}_qa_analysis.json'
        report_data = None
        if os.path.exists(report_file):
            with open(report_file, 'r') as f:
                report_data = json.load(f)
        
        # Get database session info (skip for file-based sessions)
        db_session = None  # File-based sessions don't have database records
        
        # Load user rating if exists
        rating_file = f'feedback/{session_id}_user_rating.json'
        rating_data = None
        if os.path.exists(rating_file):
            with open(rating_file, 'r') as f:
                rating_data = json.load(f)
        
        session_info = {
            'session_id': session_id,
            'database_session': db_session,
            'report': report_data,
            'rating': rating_data,
            'otter_enhanced': db_session and hasattr(db_session, 'post_processed') and db_session.post_processed,
            'transcript_available': os.path.exists(f'transcripts/{session_id}.txt'),
            'audio_available': any(os.path.exists(f'recordings/{session_id}{ext}') for ext in ['.wav', '.mp3', '.webm'])
        }
        
        return render_template('qa_session_detail.html', session=session_info)
    
    except Exception as e:
        logging.error(f"Session detail error: {e}")
        return render_template('qa_session_detail.html', 
                             session={'session_id': session_id}, 
                             error=f"Session detail error: {str(e)}")

@qa_auditor_bp.route('/api/qa_batch_audit', methods=['POST'])
def batch_audit():
    """Enhanced batch QA audit with Otter.ai support"""
    try:
        # Get all sessions with audio (database first, then files)
        sessions_to_audit = []
        
        # Database sessions (skip for file-based system)
        db_sessions = []  # File-based sessions only
        for db_session in db_sessions:
            session_id = db_session.session_id
            has_audio = any(os.path.exists(f'recordings/{session_id}{ext}') 
                          for ext in ['.wav', '.mp3', '.webm'])
            if has_audio:
                sessions_to_audit.append({
                    'session_id': session_id,
                    'source': 'database',
                    'otter_enhanced': hasattr(db_session, 'post_processed') and db_session.post_processed
                })
        
        # File-based sessions (legacy)
        transcript_files = glob.glob('transcripts/*.txt')
        audio_files = glob.glob('recordings/*.wav') + glob.glob('recordings/*.mp3') + glob.glob('recordings/*.webm')
        
        for transcript_file in transcript_files:
            session_id = os.path.basename(transcript_file).replace('.txt', '')
            # Skip if already processed from database
            if any(s['session_id'] == session_id for s in sessions_to_audit):
                continue
                
            has_audio = any(session_id in audio for audio in audio_files)
            if has_audio:
                sessions_to_audit.append({
                    'session_id': session_id,
                    'source': 'file',
                    'otter_enhanced': False
                })
        
        # Process sessions (limit to 10 to avoid timeout)
        results = []
        processed_count = 0
        
        for session_info in sessions_to_audit[:10]:
            session_id = session_info['session_id']
            try:
                # Enhanced audit with Otter metrics
                result = qa_auditor.audit_session(session_id)
                
                # Add Otter-specific metrics if enhanced
                if session_info['otter_enhanced']:
                    db_session = TranscriptionSession.query.filter_by(session_id=session_id).first()
                    if db_session and db_session.final_transcript:
                        # Calculate Otter-specific quality metrics
                        false_starts = sum(db_session.final_transcript.lower().count(pattern) 
                                         for pattern in ['let me start again', 'actually', 'I mean', 'wait'])
                        result['otter_metrics'] = {
                            'false_starts_detected': false_starts,
                            'post_processed': True,
                            'user_rating': getattr(db_session, 'user_rating', None)
                        }
                
                results.append({
                    'session_id': session_id,
                    'success': True,
                    'source': session_info['source'],
                    'otter_enhanced': session_info['otter_enhanced'],
                    'quality_score': result.get('quality_score', 0),
                    'word_error_rate': result.get('word_error_rate', 0)
                })
                processed_count += 1
                
            except Exception as e:
                logging.error(f"Batch audit failed for {session_id}: {e}")
                results.append({
                    'session_id': session_id,
                    'success': False,
                    'source': session_info['source'],
                    'otter_enhanced': session_info['otter_enhanced'],
                    'error': str(e)
                })
        
        successful_audits = len([r for r in results if r['success']])
        otter_enhanced_audits = len([r for r in results if r.get('otter_enhanced')])
        
        return jsonify({
            'processed_sessions': processed_count,
            'successful_audits': successful_audits,
            'otter_enhanced_audits': otter_enhanced_audits,
            'results': results,
            'message': f'Batch audit completed: {successful_audits}/{processed_count} successful, {otter_enhanced_audits} Otter-enhanced sessions'
        })
    
    except Exception as e:
        logging.error(f'Batch audit failed: {e}')
        return jsonify({'error': f'Batch audit failed: {str(e)}'}), 500

@qa_auditor_bp.route('/qa_session_old/<session_id>')
def qa_session_detail(session_id):
    """Legacy session detail - redirect to main session detail"""
    return redirect(url_for('qa_auditor.session_detail', session_id=session_id))

@qa_auditor_bp.route('/api/export_qa_report/<session_id>')
def export_qa_report(session_id):
    """Export QA report in various formats"""
    try:
        format_type = request.args.get('format', 'json')
        
        qa_file = f'feedback/{session_id}_qa_analysis.json'
        if not os.path.exists(qa_file):
            return jsonify({'error': 'QA report not found'}), 404
        
        with open(qa_file, 'r') as f:
            qa_report = json.load(f)
        
        if format_type == 'json':
            return jsonify(qa_report)
        elif format_type == 'markdown':
            # Convert to markdown format
            markdown_content = qa_auditor.generate_markdown_report(qa_report)
            return markdown_content, 200, {'Content-Type': 'text/markdown'}
        
        return jsonify({'error': 'Unsupported format'}), 400
    
    except Exception as e:
        return jsonify({'error': f'Export failed: {str(e)}'}), 500