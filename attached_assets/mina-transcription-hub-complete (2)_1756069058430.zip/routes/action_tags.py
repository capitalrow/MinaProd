"""
Action Tags Routes for Mina Pro
Real-time action item detection and tagging endpoints
"""

import logging
import json
from flask import Blueprint, request, jsonify
from services.action_tagger import ActionTagger

logger = logging.getLogger(__name__)

# Create Blueprint
routes_action_tags = Blueprint('action_tags', __name__)

# Initialize Action Tagger
action_tagger = ActionTagger()

@routes_action_tags.route('/api/tag_actions', methods=['POST'])
def tag_actions():
    """
    Tag transcript segments for action items
    Endpoint called after each Whisper transcription
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"status": "error", "message": "No data provided"}), 400
        
        # Extract transcript data
        text = data.get('text', '').strip()
        confidence = data.get('confidence', 0.85)
        session_id = data.get('session_id', 'unknown')
        chunk_index = data.get('chunk_index', 0)
        timestamp = data.get('timestamp')
        
        if not text:
            return jsonify({
                "status": "success",
                "has_tag": False,
                "tag_type": None,
                "message": "Empty text provided"
            })
        
        # Tag the transcript segment
        tag_result = action_tagger.tag_transcript_segment(
            text=text,
            confidence=confidence,
            timestamp=timestamp
        )
        
        # Add session metadata
        tag_result.update({
            "session_id": session_id,
            "chunk_index": chunk_index,
            "status": "success"
        })
        
        # Save tag if found (mock for now)
        if tag_result.get("has_tag"):
            action_tagger.save_session_tag(session_id, tag_result)
            logger.info(f"[TAG_ACTIONS] {session_id} chunk {chunk_index}: {tag_result['tag_type']} - {text[:50]}...")
        
        return jsonify(tag_result)
        
    except Exception as e:
        logger.error(f"Action tagging error: {e}")
        return jsonify({
            "status": "error",
            "message": str(e),
            "has_tag": False
        }), 500

@routes_action_tags.route('/api/session_tags/<session_id>', methods=['GET'])
def get_session_tags(session_id):
    """Get all action tags for a session"""
    try:
        tags = action_tagger.get_session_tags(session_id)
        summary = action_tagger.get_tag_summary(tags)
        
        return jsonify({
            "status": "success",
            "session_id": session_id,
            "tags": tags,
            "summary": summary
        })
        
    except Exception as e:
        logger.error(f"Get session tags error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@routes_action_tags.route('/api/tag_patterns', methods=['GET'])
def get_tag_patterns():
    """Get available tag patterns and configuration"""
    try:
        return jsonify({
            "status": "success",
            "tag_types": list(action_tagger.tag_config.keys()),
            "tag_config": action_tagger.tag_config,
            "patterns_count": {
                tag_type: len(patterns) 
                for tag_type, patterns in action_tagger.patterns.items()
            }
        })
        
    except Exception as e:
        logger.error(f"Get tag patterns error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500