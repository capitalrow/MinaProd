"""
API Routes for Mina Pro
RESTful API endpoints for transcription, user management, and system status
"""

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
import logging
import os
import time
from datetime import datetime
from models import db, User, TranscriptSession
logger = logging.getLogger(__name__)

api_bp = Blueprint('api', __name__, url_prefix='/api')

# Transcription service will be initialized when needed
transcriber = None

@api_bp.route('/status')
def status():
    """System status endpoint"""
    try:
        # Check database connection
        from sqlalchemy import text
        db.session.execute(text('SELECT 1'))
        db_status = "operational"
    except Exception as e:
        logger.error(f"Database check failed: {e}")
        db_status = "error"
    
    # Check OpenAI API key
    openai_status = "configured" if os.getenv('OPENAI_API_KEY') else "missing"
    
    return jsonify({
        'status': 'operational',
        'timestamp': datetime.utcnow().isoformat(),
        'services': {
            'database': db_status,
            'openai_api': openai_status,
            'transcription': 'operational'
        },
        'version': '1.0.0'
    })

# DISABLED: Conflicting route - moved to live_transcription_api_working.py
# @api_bp.route('/transcribe_chunk_streaming', methods=['POST'])
def transcribe_chunk_streaming_disabled():
    """Stream audio chunk transcription with thread-safe timeout handling"""
    import time
    import tempfile
    import os
    
    try:
        # Check if audio file is present
        if 'audio' not in request.files:
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        
        if audio_file.filename == '':
            return jsonify({'error': 'No audio file selected'}), 400
        
        # Get chunk metadata
        chunk_id = request.form.get('chunk_id', 'unknown')
        session_id = request.form.get('session_id', None)
        
        # CRITICAL: Enhanced timeout handling for production reliability
        result = None
        processing_start = time.time()
        
        try:
            # CRITICAL FIX: Replace signal timeout with thread-safe timeout
            from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
            
            from services.whisper_transcriber import WhisperTranscriber
            transcriber = WhisperTranscriber()
            
            # Save uploaded file temporarily with proper cleanup
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                temp_file_path = temp_file.name
                audio_file.save(temp_file_path)
                
                try:
                    # THREAD-SAFE TIMEOUT: Use ThreadPoolExecutor instead of signals
                    def transcribe_chunk_wrapper():
                        return transcriber.transcribe_chunk(temp_file_path, chunk_id)
                    
                    with ThreadPoolExecutor(max_workers=1) as executor:
                        future = executor.submit(transcribe_chunk_wrapper)
                        try:
                            # Increased timeout to 30 seconds for better reliability
                            result = future.result(timeout=30)  
                            result['processing_time'] = time.time() - processing_start
                            
                            # Add chunk to session for intelligent compilation
                            if session_id and result.get('text'):
                                from services.session_manager import session_manager
                                session_manager.add_chunk_to_session(session_id, result)
                                
                        except FuturesTimeoutError:
                            future.cancel()
                            raise TimeoutError("Transcription processing timed out after 30 seconds")
                
                finally:
                    # Clean up temp file
                    try:
                        os.unlink(temp_file_path)
                    except OSError:
                        pass  # File already deleted
                
        except TimeoutError as timeout_error:
            logger.error(f"TIMEOUT ERROR for chunk {chunk_id}: {timeout_error}")
            # Create timeout fallback result
            result = {
                'text': '',
                'confidence': 0.0,
                'chunk_id': chunk_id,
                'type': 'error',
                'error': 'Processing timeout - chunk took too long',
                'processing_time': time.time() - processing_start,
                'timeout': True
            }
        except Exception as transcriber_error:
            logger.error(f"Transcriber error for chunk {chunk_id}: {transcriber_error}")
            # Create error fallback result
            result = {
                'text': '',
                'confidence': 0.0,
                'chunk_id': chunk_id,
                'type': 'error',
                'error': f'Transcription failed: {str(transcriber_error)[:100]}',
                'processing_time': time.time() - processing_start
            }
        finally:
            # Thread-safe cleanup - no signal handling needed
            pass
        
        # Log the transcription attempt
        logger.info(f"Transcription request for chunk {chunk_id}: {result.get('text', 'No text')}")
        
        # ENHANCED WEBSOCKET EMISSION with timeout error handling
        try:
            from app_refactored import socketio
            
            # Create comprehensive socket data
            socket_data = {
                'text': result.get('text', ''),
                'confidence': result.get('confidence', 0),
                'timestamp': time.time(),
                'isPartial': False,
                'chunkId': chunk_id,
                'processing_time': result.get('processing_time', 0),
                'type': result.get('type', 'final'),
                'filter_reason': result.get('filter_reason', None),
                'error': result.get('error', None),
                'timeout': result.get('timeout', False)
            }
            
            # CRITICAL: Handle timeout and error cases properly
            if result.get('timeout') or result.get('error'):
                # Emit error event for timeout/error cases
                socketio.emit('transcription_error', {
                    'chunk_id': chunk_id,
                    'error': result.get('error', 'Unknown error'),
                    'stack': f"TimeoutError: {result.get('error', 'signal timed out')}",
                    'size': 24620,
                    'type': 'audio/wav',
                    'timestamp': time.time()
                })
                logger.error(f"[SOCKET-EMIT] ❌ TIMEOUT/ERROR - Emitted error for {chunk_id}: {result.get('error')}")
            else:
                # Normal transcription result
                socketio.emit('transcription_result', socket_data)
                
                # Enhanced logging
                if result.get('text', '').strip():
                    logger.info(f"[SOCKET-EMIT] ✅ SUCCESS - Emitted text for {chunk_id}: '{result['text']}'")
                else:
                    logger.warning(f"[SOCKET-EMIT] ⚠️ EMPTY - Emitted empty result for {chunk_id}: confidence={result.get('confidence', 0):.3f}, type={result.get('type', 'unknown')}")
                
            # DEBUGGING: Additional debug emit for all cases
            socketio.emit('transcription_debug', {
                'chunk_id': chunk_id,
                'success': bool(result.get('text', '').strip()) and not result.get('timeout'),
                'raw_result': result,
                'socket_data': socket_data
            })
            
        except Exception as socket_error:
            logger.error(f"[SOCKET-EMIT] ❌ CRITICAL FAILURE for {chunk_id}: {socket_error}")
            # Try fallback emit
            try:
                socketio.emit('transcription_error', {
                    'chunk_id': chunk_id,
                    'error': str(socket_error),
                    'timestamp': time.time()
                })
            except:
                logger.error(f"[SOCKET-EMIT] ❌ Even fallback emit failed for {chunk_id}")
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Transcription error: {e}")
        return jsonify({
            'error': 'Transcription failed',
            'chunk_id': request.form.get('chunk_id', 'unknown'),
            'details': str(e)
        }), 500

@api_bp.route('/user/preferences', methods=['GET', 'POST'])
@login_required
def user_preferences():
    """Get or update user preferences"""
    if request.method == 'GET':
        try:
            return jsonify({
                'preferences': {
                    'auto_summary': current_user.auto_summary,
                    'ui_theme': current_user.ui_theme,
                    'preferred_model': current_user.preferred_model,
                    'default_export_format': current_user.default_export_format,
                    'enable_emotion_detection': current_user.enable_emotion_detection,
                    'clean_filler_words': current_user.clean_filler_words
                }
            })
        except Exception as e:
            logger.error(f"Error getting preferences: {e}")
            return jsonify({'error': 'Failed to load preferences'}), 500
    
    elif request.method == 'POST':
        try:
            data = request.get_json()
            
            # Update preferences
            if 'auto_summary' in data:
                current_user.auto_summary = data['auto_summary']
            if 'ui_theme' in data:
                current_user.ui_theme = data['ui_theme']
            if 'clean_filler_words' in data:
                current_user.clean_filler_words = data['clean_filler_words']
            
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Preferences updated'})
            
        except Exception as e:
            logger.error(f"Error updating preferences: {e}")
            db.session.rollback()
            return jsonify({'error': 'Failed to update preferences'}), 500

@api_bp.route('/enhance_final_transcript', methods=['POST'])
@login_required
def enhance_final_transcript():
    """Generate enhanced final transcript from session chunks"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        
        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400
        
        # Get session from database
        session = TranscriptSession.query.filter_by(
            id=session_id,
            user_id=current_user.id
        ).first()
        
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        # Get session chunks and generate enhanced transcript
        from services.session_manager import session_manager
        session_segments = session_manager.get_session_segments(session_id)
        
        if not session_segments:
            return jsonify({'error': 'No transcript segments found'}), 404
        
        # Save enhanced final transcript
        result = session_manager.save_final_transcript(session_id)
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'enhanced_transcript': result['transcript'],
                'summary': result['summary'],
                'statistics': result['statistics']
            })
        else:
            return jsonify({'error': result.get('error', 'Enhancement failed')}), 500
            
    except Exception as e:
        logger.error(f"Final transcript enhancement error: {e}")
        return jsonify({'error': 'Enhancement processing failed'}), 500

@api_bp.route('/sessions/<session_id>', methods=['GET'])
@login_required
def get_session(session_id):
    """Get session details"""
    try:
        session = TranscriptSession.query.filter_by(
            id=session_id,
            user_id=current_user.id
        ).first_or_404()
        
        return jsonify({
            'id': session.id,
            'title': session.title,
            'transcript': session.transcript,
            'summary': session.summary,
            'created_at': session.created_at.isoformat(),
            'duration': session.duration,
            'word_count': session.word_count,
            'confidence': session.confidence
        })
        
    except Exception as e:
        logger.error(f"Error getting session {session_id}: {e}")
        return jsonify({'error': 'Session not found'}), 404

@api_bp.route('/analytics/track', methods=['POST'])
def track_analytics():
    """Track user analytics (demo mode)"""
    try:
        data = request.get_json()
        event_type = data.get('event_type')
        properties = data.get('properties', {})
        
        # Log analytics event
        logger.info(f"Analytics: {event_type} - {properties}")
        
        return jsonify({'success': True})
        
    except Exception as e:
        logger.error(f"Analytics error: {e}")
        return jsonify({'error': 'Failed to track event'}), 500

@api_bp.route('/session/create', methods=['POST'])
@login_required
def create_session():
    """Create new transcription session"""
    try:
        data = request.get_json()
        
        session = TranscriptSession(
            user_id=current_user.id,
            title=data.get('title'),
            meeting_type=data.get('meeting_type', 'general')
        )
        
        db.session.add(session)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session_id': session.id,
            'message': 'Session created successfully'
        })
        
    except Exception as e:
        logger.error(f"Error creating session: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to create session'}), 500