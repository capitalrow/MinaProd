"""
Main Application Routes
Core navigation and dashboard functionality with enterprise features
"""

from flask import Blueprint, render_template, redirect, url_for, session
from flask_login import login_required, current_user
from models import db, TranscriptSession
from services.session_manager_production import SessionManager
from datetime import datetime, timedelta

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Smart landing page - redirect authenticated users to dashboard"""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('index_professional.html')

@main_bp.route('/transcribe')
def transcribe_redirect():
    """Redirect old transcribe route to real-time transcription"""
    return redirect(url_for('transcription.real_time'))

@main_bp.route('/dashboard')
@login_required
def dashboard():
    """Enhanced dashboard with conversation management"""
    try:
        # Get recent sessions (last 10)
        raw_sessions = SessionManager.get_user_sessions(current_user.id, limit=10)
        
        # Convert session data to template-friendly format
        recent_sessions = []
        if raw_sessions:
            for session in raw_sessions:
                # Convert to consistent format with datetime objects
                session_data = {
                    'id': session.get('id', ''),
                    'title': session.get('title') or session.get('smart_title') or 'Recording Session',
                    'transcript': session.get('full_transcript') or session.get('transcript', ''),
                    'word_count': session.get('word_count', 0),
                    'confidence': session.get('confidence_average', 0) * 100 if session.get('confidence_average') else 0,
                    'created_at': session.get('created_at') if hasattr(session.get('created_at'), 'strftime') else 
                                 datetime.fromisoformat(str(session.get('created_at'))) if session.get('created_at') else datetime.now(),
                    'duration': session.get('duration', 0)
                }
                recent_sessions.append(session_data)
        
        # Calculate metrics
        total_sessions = len(recent_sessions)
        this_week_sessions = 0
        total_words = 0
        
        if recent_sessions:
            # Calculate words and this week sessions
            total_words = sum(s.get('word_count', 0) for s in recent_sessions)
            week_ago = datetime.now().date() - timedelta(days=7)
            
            for session in recent_sessions:
                try:
                    session_date = session['created_at'].date() if hasattr(session['created_at'], 'date') else session['created_at']
                    if session_date >= week_ago:
                        this_week_sessions += 1
                except (AttributeError, TypeError):
                    pass
        
        dashboard_data = {
            'recent_sessions': recent_sessions,
            'total_sessions': total_sessions,
            'this_week_sessions': this_week_sessions,
            'total_words': total_words,
            'user': current_user
        }
        
        return render_template('dashboard.html', **dashboard_data)
        
    except Exception as e:
        print(f"Dashboard error: {e}")
        # Fallback to basic dashboard
        return render_template('dashboard.html', 
                             recent_sessions=[], 
                             analytics={}, 
                             user=current_user)

@main_bp.route('/sessions')
@login_required
def sessions():
    """Conversation history page - authenticated users only"""
    try:
        # Get user's session history with proper error handling
        raw_sessions = SessionManager.get_user_sessions(current_user.id, limit=50)
        
        # Convert session data to template-friendly format (same as dashboard)
        sessions = []
        if raw_sessions:
            for session in raw_sessions:
                session_data = {
                    'id': session.get('id', ''),
                    'title': session.get('title') or session.get('smart_title') or 'Recording Session',
                    'transcript': session.get('full_transcript') or session.get('transcript', ''),
                    'word_count': session.get('word_count', 0),
                    'confidence': session.get('confidence_average', 0) * 100 if session.get('confidence_average') else 0,
                    'created_at': session.get('created_at') if hasattr(session.get('created_at'), 'strftime') else 
                                 datetime.fromisoformat(str(session.get('created_at'))) if session.get('created_at') else datetime.now(),
                    'duration': session.get('duration', 0),
                    'status': session.get('status', 'completed')
                }
                sessions.append(session_data)
        
        return render_template('sessions.html', sessions=sessions, user=current_user)
    except Exception as e:
        print(f"Sessions page error: {e}")
        return render_template('sessions.html', sessions=[], user=current_user)

@main_bp.route('/session-history')
@login_required
def session_history():
    """User session history page - avoiding conflict with /sessions"""
    try:
        # Get user's session history with proper error handling
        sessions = []
        try:
            sessions = SessionManager.get_user_sessions(current_user.id, limit=50)
        except Exception as session_error:
            print(f"Session retrieval error: {session_error}")
            sessions = []  # Fallback to empty list
        
        return render_template('sessions_history.html', sessions=sessions, user=current_user)
    except Exception as e:
        print(f"History page error: {e}")
        return render_template('sessions_history.html', sessions=[], user=current_user)

@main_bp.route('/settings')
@login_required
def settings():
    """User settings and preferences page"""
    try:
        return render_template('settings.html', user=current_user)
    except Exception as e:
        print(f"Settings page error: {e}")
        return render_template('settings.html', user=current_user)

@main_bp.route('/session/<session_id>')
def session_detail(session_id):
    """Session detail with AI intelligence tabs - public access for demo"""
    # Mock session data for demo (enterprise-style)
    session_data = {
        'demo-1': {
            'id': session_id,
            'title': 'Strategic Planning Meeting',
            'created_at': '2025-07-23',
            'duration': 45,
            'participants': 4,
            'transcript': [
                {'speaker': 'User', 'time': '0:01', 'text': 'This is a transcription, just to show that this is actually working, and we\'re taking screenshots of this in action, as well as various parts of the conversation.'},
                {'speaker': 'User', 'time': '0:20', 'text': 'Let\'s continue with the demonstration.'},
                {'speaker': 'User', 'time': '0:36', 'text': 'Here\'s another part of the conversation.'},
                {'speaker': 'User', 'time': '0:39', 'text': 'And we\'ll wrap up here.'}
            ]
        },
        'demo-2': {
            'id': session_id,
            'title': 'Client Consultation', 
            'created_at': '2025-07-23',
            'duration': 30,
            'participants': 2,
            'transcript': [
                {'speaker': 'User', 'time': '0:01', 'text': 'Welcome to our consultation session.'},
                {'speaker': 'Client', 'time': '0:05', 'text': 'Thank you for taking the time to meet with us.'}
            ]
        },
        'demo-3': {
            'id': session_id,
            'title': 'Team Standup',
            'created_at': '2025-02-10', 
            'duration': 15,
            'participants': 8,
            'transcript': [
                {'speaker': 'Manager', 'time': '0:01', 'text': 'Good morning everyone, let\'s start with our standup.'},
                {'speaker': 'Developer', 'time': '0:10', 'text': 'I completed the API integration yesterday.'}
            ]
        }
    }
    
    session = session_data.get(session_id, {
        'id': session_id,
        'title': 'Sample Meeting',
        'created_at': '2025-07-22',
        'duration': 25,
        'participants': 2,
        'transcript': [
            {'speaker': 'User', 'time': '0:01', 'text': 'This is a sample transcript to demonstrate the functionality.'}
        ]
    })
    
    return render_template('session_detail_professional.html', session=session)

@main_bp.route('/channels')
def channels():
    """Team collaboration channels (Otter-style) - public access for demo"""
    return render_template('team_collaboration.html')

@main_bp.route('/ai-chat')
@login_required
def ai_chat():
    """AI Chat interface for transcript analysis"""
    try:
        # Get user's recent sessions for AI context
        raw_sessions = SessionManager.get_user_sessions(current_user.id, limit=10)
        
        # Convert session data to template-friendly format
        sessions = []
        if raw_sessions:
            for session in raw_sessions:
                session_data = {
                    'id': session.get('id', ''),
                    'title': session.get('title') or session.get('smart_title') or 'Recording Session',
                    'transcript': session.get('full_transcript') or session.get('transcript', ''),
                    'word_count': session.get('word_count', 0),
                    'confidence': session.get('confidence_average', 0) * 100 if session.get('confidence_average') else 0,
                    'created_at': session.get('created_at') if hasattr(session.get('created_at'), 'strftime') else 
                                 datetime.fromisoformat(str(session.get('created_at'))) if session.get('created_at') else datetime.now(),
                    'duration': session.get('duration', 0),
                    'status': session.get('status', 'completed')
                }
                sessions.append(session_data)
        
        return render_template('ai_chat.html', sessions=sessions, user=current_user)
    except Exception as e:
        print(f"AI Chat error: {e}")
        return render_template('ai_chat.html', sessions=[], user=current_user)

@main_bp.route('/account')
@login_required  
def account():
    """Account management page with real usage statistics"""
    try:
        # Get user's session data for usage statistics
        user_sessions = SessionManager.get_user_sessions(current_user.id, limit=100)
        
        # Calculate usage statistics from real data
        stats = {
            'sessions_this_month': 0,
            'total_duration': 0,
            'words_transcribed': 0,
            'current_plan': 'Free'
        }
        
        if user_sessions:
            # Calculate real statistics
            from datetime import datetime, timedelta
            current_month = datetime.now().replace(day=1)
            
            for session in user_sessions:
                # Count sessions this month
                session_date = session.get('created_at')
                if session_date:
                    try:
                        if hasattr(session_date, 'replace'):
                            # It's already a datetime object
                            if session_date >= current_month:
                                stats['sessions_this_month'] += 1
                        elif isinstance(session_date, str):
                            # Parse string to datetime
                            if 'T' in session_date:
                                parsed_date = datetime.fromisoformat(session_date.replace('Z', '+00:00'))
                            else:
                                parsed_date = datetime.strptime(session_date, '%Y-%m-%d')
                            if parsed_date >= current_month:
                                stats['sessions_this_month'] += 1
                        else:
                            # Count all sessions if we can't parse the date
                            stats['sessions_this_month'] += 1
                    except Exception as date_error:
                        # Count session even if date parsing fails
                        stats['sessions_this_month'] += 1
                
                # Add duration (in seconds, convert to hours)
                duration = session.get('duration', 0)
                if isinstance(duration, (int, float)):
                    stats['total_duration'] += duration
                
                # Add word count
                word_count = session.get('word_count', 0)
                if isinstance(word_count, (int, float)):
                    stats['words_transcribed'] += int(word_count)
        
        # Format duration for display (convert seconds to hours/minutes)
        total_seconds = stats['total_duration']
        if total_seconds >= 3600:
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            stats['duration_display'] = f"{int(hours)}h {int(minutes)}m"
        elif total_seconds >= 60:
            minutes = total_seconds // 60
            stats['duration_display'] = f"{int(minutes)}m"
        else:
            stats['duration_display'] = f"{int(total_seconds)}s"
        
        return render_template('account.html', user=current_user, usage_stats=stats)
    except Exception as e:
        print(f"Account page error: {e}")
        # Fallback to default stats if error
        default_stats = {
            'sessions_this_month': 0,
            'total_duration': 0,
            'words_transcribed': 0,
            'current_plan': 'Free',
            'duration_display': '0h'
        }
        return render_template('account.html', user=current_user, usage_stats=default_stats)

@main_bp.route('/upgrade')
@login_required
def upgrade():
    """Subscription upgrade page"""
    return render_template('upgrade.html', user=current_user)

@main_bp.route('/history')
@login_required  
def history():
    """User's transcription history page"""
    try:
        # Get user's session history
        sessions = session_manager.get_user_sessions(current_user.id, limit=50)
        return render_template('history.html', sessions=sessions, user=current_user)
    except Exception as e:
        print(f"History error: {e}")
        # Fallback to empty history
        return render_template('history.html', sessions=[], user=current_user)

# Support routes moved to support_routes.py to avoid conflicts