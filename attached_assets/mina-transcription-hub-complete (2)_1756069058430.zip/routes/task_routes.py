"""
Task Management Routes
API endpoints for task extraction, management, and tracking
"""

from flask import Blueprint, request, jsonify, render_template
from flask_login import login_required, current_user
import logging
from services.task_extraction_service import task_extraction_service, TaskItem
from services.session_manager import session_manager
from models import db, TranscriptSession, TaskItem as TaskModel
from datetime import datetime
import json

logger = logging.getLogger(__name__)

task_routes = Blueprint('task_routes', __name__)

@task_routes.route('/api/extract_tasks', methods=['POST'])
@login_required
def extract_tasks():
    """Extract tasks from transcript text"""
    try:
        data = request.get_json()
        transcript = data.get('transcript', '')
        session_id = data.get('session_id')
        
        if not transcript:
            return jsonify({'error': 'Transcript text required'}), 400
        
        logger.info(f"[TASK-API] Extracting tasks from {len(transcript)} character transcript")
        
        # Get session metadata if available
        session_metadata = {}
        if session_id:
            session = TranscriptSession.query.filter_by(id=session_id, user_id=current_user.id).first()
            if session:
                session_metadata = {
                    'meeting_type': session.meeting_type,
                    'duration': session.duration,
                    'participant_count': getattr(session, 'participant_count', 1)
                }
        
        # Extract tasks using AI service
        extracted_tasks = task_extraction_service.extract_tasks_from_transcript(
            transcript, session_metadata
        )
        
        # Convert to serializable format
        tasks_data = []
        for task in extracted_tasks:
            tasks_data.append({
                'id': task.id,
                'text': task.text,
                'assignee': task.assignee,
                'deadline': task.deadline.isoformat() if task.deadline else None,
                'priority': task.priority,
                'impact_score': task.impact_score,
                'category': task.category,
                'confidence': task.confidence,
                'source_segment': task.source_segment,
                'tags': task.tags
            })
        
        logger.info(f"[TASK-API] Successfully extracted {len(tasks_data)} tasks")
        
        return jsonify({
            'success': True,
            'tasks': tasks_data,
            'total_tasks': len(tasks_data),
            'high_priority_tasks': len([t for t in extracted_tasks if t.priority in ['high', 'critical']]),
            'average_confidence': sum(t.confidence for t in extracted_tasks) / len(extracted_tasks) if extracted_tasks else 0
        })
        
    except Exception as e:
        logger.error(f"[TASK-API] Task extraction error: {e}")
        return jsonify({'error': 'Task extraction failed', 'details': str(e)}), 500

@task_routes.route('/api/save_tasks', methods=['POST'])
@login_required 
def save_tasks():
    """Save extracted tasks to database"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        tasks_data = data.get('tasks', [])
        
        if not session_id:
            return jsonify({'error': 'Session ID required'}), 400
        
        # Verify session ownership
        session = TranscriptSession.query.filter_by(id=session_id, user_id=current_user.id).first()
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        logger.info(f"[TASK-API] Saving {len(tasks_data)} tasks for session {session_id}")
        
        saved_tasks = []
        for task_data in tasks_data:
            # Create TaskItem database record
            task = TaskModel(
                session_id=session_id,
                user_id=current_user.id,
                text=task_data.get('text', ''),
                assignee=task_data.get('assignee'),
                deadline=datetime.fromisoformat(task_data['deadline']) if task_data.get('deadline') else None,
                priority=task_data.get('priority', 'medium'),
                impact_score=task_data.get('impact_score', 0.5),
                category=task_data.get('category', 'action'),
                confidence=task_data.get('confidence', 0.0),
                source_segment=task_data.get('source_segment', ''),
                tags=json.dumps(task_data.get('tags', [])),
                status='pending',
                created_at=datetime.utcnow()
            )
            
            db.session.add(task)
            saved_tasks.append(task)
        
        db.session.commit()
        
        # Update session with task count
        session.task_count = len(saved_tasks)
        db.session.commit()
        
        logger.info(f"[TASK-API] Successfully saved {len(saved_tasks)} tasks")
        
        return jsonify({
            'success': True,
            'saved_tasks': len(saved_tasks),
            'message': f'Successfully saved {len(saved_tasks)} tasks'
        })
        
    except Exception as e:
        logger.error(f"[TASK-API] Save tasks error: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to save tasks', 'details': str(e)}), 500

@task_routes.route('/api/session/<session_id>/tasks', methods=['GET'])
@login_required
def get_session_tasks(session_id):
    """Get all tasks for a specific session"""
    try:
        # Verify session ownership
        session = TranscriptSession.query.filter_by(id=session_id, user_id=current_user.id).first()
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        tasks = TaskModel.query.filter_by(session_id=session_id, user_id=current_user.id).all()
        
        tasks_data = []
        for task in tasks:
            tasks_data.append({
                'id': task.id,
                'text': task.text,
                'assignee': task.assignee,
                'deadline': task.deadline.isoformat() if task.deadline else None,
                'priority': task.priority,
                'impact_score': task.impact_score,
                'category': task.category,
                'confidence': task.confidence,
                'source_segment': task.source_segment,
                'tags': json.loads(task.tags) if task.tags else [],
                'status': task.status,
                'created_at': task.created_at.isoformat(),
                'completed_at': task.completed_at.isoformat() if task.completed_at else None
            })
        
        return jsonify({
            'success': True,
            'tasks': tasks_data,
            'total_tasks': len(tasks_data),
            'session_title': session.title or f"Session {session.id}"
        })
        
    except Exception as e:
        logger.error(f"[TASK-API] Get session tasks error: {e}")
        return jsonify({'error': 'Failed to retrieve tasks', 'details': str(e)}), 500

@task_routes.route('/api/tasks/<task_id>/update', methods=['PUT'])
@login_required
def update_task(task_id):
    """Update task status, assignee, or other properties"""
    try:
        data = request.get_json()
        
        task = TaskModel.query.filter_by(id=task_id, user_id=current_user.id).first()
        if not task:
            return jsonify({'error': 'Task not found'}), 404
        
        # Update allowed fields
        allowed_updates = ['status', 'assignee', 'deadline', 'priority', 'text']
        for field in allowed_updates:
            if field in data:
                if field == 'deadline' and data[field]:
                    task.deadline = datetime.fromisoformat(data[field])
                elif field == 'status' and data[field] == 'completed':
                    task.status = 'completed'
                    task.completed_at = datetime.utcnow()
                else:
                    setattr(task, field, data[field])
        
        task.updated_at = datetime.utcnow()
        db.session.commit()
        
        logger.info(f"[TASK-API] Updated task {task_id}")
        
        return jsonify({
            'success': True,
            'message': 'Task updated successfully'
        })
        
    except Exception as e:
        logger.error(f"[TASK-API] Update task error: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to update task', 'details': str(e)}), 500

@task_routes.route('/tasks/dashboard')
@login_required
def task_dashboard():
    """Task management dashboard"""
    try:
        # Get user's recent tasks
        recent_tasks = TaskModel.query.filter_by(user_id=current_user.id)\
                                     .order_by(TaskModel.created_at.desc())\
                                     .limit(50).all()
        
        # Get task statistics
        total_tasks = TaskModel.query.filter_by(user_id=current_user.id).count()
        completed_tasks = TaskModel.query.filter_by(user_id=current_user.id, status='completed').count()
        pending_tasks = total_tasks - completed_tasks
        high_priority_tasks = TaskModel.query.filter_by(user_id=current_user.id, priority='high').count()
        
        task_stats = {
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'pending_tasks': pending_tasks,
            'high_priority_tasks': high_priority_tasks,
            'completion_rate': (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        }
        
        return render_template('task_dashboard.html', 
                             tasks=recent_tasks,
                             task_stats=task_stats)
        
    except Exception as e:
        logger.error(f"[TASK-API] Dashboard error: {e}")
        return render_template('error.html', error="Failed to load task dashboard"), 500