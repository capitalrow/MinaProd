"""
Sharing and Collaboration Routes
Handle session sharing, public links, and team collaboration
"""

from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from services.sharing_service import sharing_service
from services.session_manager import session_manager

sharing_bp = Blueprint('sharing', __name__, url_prefix='/share')

@sharing_bp.route('/create', methods=['POST'])
@login_required
def create_share_link():
    """Create a shareable link for a session"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        permission_level = data.get('permission_level', 'view')
        expires_hours = data.get('expires_hours', 168)  # Default 1 week
        
        if not session_id:
            return jsonify({'success': False, 'error': 'Session ID is required'}), 400
        
        result = sharing_service.create_share_link(
            session_id=session_id,
            user_id=current_user.id,
            permission_level=permission_level,
            expires_hours=expires_hours
        )
        
        if result['success']:
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/user', methods=['POST'])
@login_required
def share_with_user():
    """Share session with specific user by email"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        target_email = data.get('email')
        permission_level = data.get('permission_level', 'view')
        
        if not session_id or not target_email:
            return jsonify({'success': False, 'error': 'Session ID and email are required'}), 400
        
        result = sharing_service.share_with_user(
            session_id=session_id,
            owner_user_id=current_user.id,
            target_email=target_email,
            permission_level=permission_level
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/session/<session_id>', methods=['GET'])
@login_required
def get_session_shares(session_id):
    """Get all shares for a session"""
    try:
        shares = sharing_service.get_session_shares(session_id, current_user.id)
        return jsonify({'success': True, 'shares': shares})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/revoke', methods=['POST'])
@login_required
def revoke_share():
    """Revoke a share"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        share_token = data.get('share_token')
        
        if not session_id or not share_token:
            return jsonify({'success': False, 'error': 'Session ID and share token are required'}), 400
        
        result = sharing_service.revoke_share(session_id, current_user.id, share_token)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/update-permissions', methods=['POST'])
@login_required
def update_share_permissions():
    """Update share permissions"""
    try:
        data = request.get_json()
        session_id = data.get('session_id')
        share_token = data.get('share_token')
        permission_level = data.get('permission_level')
        
        if not all([session_id, share_token, permission_level]):
            return jsonify({'success': False, 'error': 'Missing required parameters'}), 400
        
        result = sharing_service.update_share_permissions(
            session_id, current_user.id, share_token, permission_level
        )
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/my-shared', methods=['GET'])
@login_required
def get_my_shared_sessions():
    """Get sessions shared with current user"""
    try:
        shared_sessions = sharing_service.get_user_shared_sessions(current_user.id)
        return jsonify({'success': True, 'shared_sessions': shared_sessions})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@sharing_bp.route('/<token>')
def view_shared_session(token):
    """View publicly shared session"""
    try:
        shared_session_data = sharing_service.get_shared_session(token)
        
        if not shared_session_data:
            flash('This shared link is invalid or has expired.', 'error')
            return redirect(url_for('main.index'))
        
        session_data = shared_session_data['session']
        permission_level = shared_session_data['permission_level']
        
        # Render shared session template
        return render_template('shared_session.html', 
                             session=session_data,
                             permission_level=permission_level,
                             shared_by=shared_session_data['shared_by'],
                             access_count=shared_session_data['access_count'])
        
    except Exception as e:
        flash('Error loading shared session.', 'error')
        return redirect(url_for('main.index'))

@sharing_bp.route('/<token>/download')
def download_shared_session(token):
    """Download shared session transcript"""
    try:
        shared_session_data = sharing_service.get_shared_session(token)
        
        if not shared_session_data:
            return jsonify({'error': 'Invalid or expired link'}), 404
        
        # Check permissions
        if shared_session_data['permission_level'] == 'view':
            return jsonify({'error': 'Download not permitted'}), 403
        
        session_data = shared_session_data['session']
        
        # Generate download content
        content = f"# {session_data['title']}\n\n"
        content += f"Date: {session_data['created_at']}\n"
        content += f"Duration: {session_data['duration']} seconds\n"
        content += f"Shared by: {shared_session_data['shared_by']}\n\n"
        content += "## Transcript\n\n"
        
        # Get full transcript
        session_details = session_manager.get_session_by_id(session_data['id'])
        if session_details and session_details.get('transcript'):
            content += session_details['transcript']
        else:
            content += "Transcript not available"
        
        return content, 200, {
            'Content-Type': 'text/plain',
            'Content-Disposition': f'attachment; filename=shared_transcript_{session_data["id"]}.txt'
        }
        
    except Exception as e:
        return jsonify({'error': 'Download failed'}), 500