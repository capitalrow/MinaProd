"""
Clean Batch Transcription Route - Enhanced with Session Management
Handles batched audio chunks with comprehensive error handling and session tracking
"""

import os
import logging
import time
import tempfile
import subprocess
from flask import Blueprint, request, jsonify, current_app
from flask_socketio import emit
from datetime import datetime
from audio_processor import AudioProcessor
from services.session_manager import session_manager

logger = logging.getLogger(__name__)

# Create Blueprint for batch transcription
batch_transcription = Blueprint('batch_transcription', __name__)

# Initialize services
audio_processor = AudioProcessor()

# Import OpenAI client for Whisper API calls
try:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    whisper_available = True
    logger.info("OpenAI Whisper client initialized")
except ImportError as e:
    logger.warning(f"OpenAI client not available: {e}")
    whisper_available = False
    client = None

def is_hallucinated_transcript(transcript):
    """
    Filter hallucinated or invalid transcriptions
    Returns True if transcript should be discarded
    """
    if not transcript or len(transcript.strip()) < 5:
        return True
        
    text = transcript.strip().lower()
    
    # Music and sound effect hallucinations
    music_indicators = ['🎵', '♪', '♫', '[music]', '(music)', '[sound]', '(sound)', 
                       'background music', 'instrumental', 'applause', 'clapping']
    if any(indicator in text for indicator in music_indicators):
        logger.info(f"[FILTER] Music hallucination detected: {transcript[:30]}...")
        return True
    
    # Repetitive patterns
    if len(set(text.split())) < 3 and len(text) > 20:
        logger.info(f"[FILTER] Repetitive content detected: {transcript[:30]}...")
        return True
    
    # Invalid character sequences
    if len([c for c in text if not c.isalnum() and c not in ' .,!?-']) > len(text) * 0.3:
        logger.info(f"[FILTER] Invalid characters detected: {transcript[:30]}...")
        return True
        
    return False

def batch_transcribe_whisper_with_retry(audio_data, session_id, chunk_id=None, meeting_type="general", context_prompt="", max_retries=3):
    """
    Enhanced batch transcription with retry logic, hallucination filtering, and WebSocket support
    """
    if not audio_data:
        return {"status": "error", "message": "No audio data provided"}
    
    if not whisper_available or not client:
        return {"status": "error", "message": "Whisper client not available"}
    
    # Retry configuration
    retry_delays = [1000, 2000, 4000]  # Exponential backoff in ms
    
    for attempt in range(max_retries):
        try:
            with open(audio_data, 'rb') if isinstance(audio_data, str) else audio_data as audio_file:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    response_format="verbose_json",
                    temperature=0.0,
                    prompt=context_prompt if context_prompt else f"This is a {meeting_type} meeting audio segment."
                )
            
            transcript = response.text.strip() if response.text else ""
            
            # Filter hallucinations
            if is_hallucinated_transcript(transcript):
                logger.info(f"[BATCH-TRANSCRIBE] Filtered hallucination for {chunk_id}: {transcript[:30]}...")
                return {"status": "filtered", "message": "Hallucination filtered", "text": ""}
            
            # Calculate confidence from segments
            confidence = 0.0
            segments = getattr(response, 'segments', [])
            if segments:
                total_logprob = sum(getattr(seg, 'avg_logprob', -1.0) for seg in segments)
                avg_logprob = total_logprob / len(segments)
                confidence = max(0.0, min(1.0, (avg_logprob + 1.0)))
            
            result = {
                "status": "success",
                "text": transcript,
                "confidence": confidence,
                "chunk_id": chunk_id,
                "session_id": session_id,
                "segments": segments,
                "timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"[BATCH-TRANSCRIBE] Success for {chunk_id}: '{transcript}' (confidence: {confidence:.2f})")
            return result
            
        except Exception as e:
            logger.warning(f"[BATCH-TRANSCRIBE] Attempt {attempt + 1} failed for {chunk_id}: {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delays[attempt] / 1000.0)
            else:
                return {"status": "error", "message": str(e), "chunk_id": chunk_id}

def convert_webm_to_wav_robust(webm_data, output_path=None):
    """
    Robust WebM to WAV conversion with comprehensive error handling
    Missing function that app_standalone.py is trying to import
    """
    import tempfile
    import subprocess
    
    try:
        # Create temporary files
        with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as webm_temp:
            webm_temp.write(webm_data if isinstance(webm_data, bytes) else webm_data.read())
            webm_path = webm_temp.name
        
        # Output path
        if output_path is None:
            wav_temp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
            output_path = wav_temp.name
            wav_temp.close()
        
        # Convert using FFmpeg
        ffmpeg_cmd = [
            'ffmpeg', '-y', '-i', webm_path,
            '-acodec', 'pcm_s16le',
            '-ar', '16000',
            '-ac', '1',
            output_path
        ]
        
        result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True)
        
        # Clean up temp webm
        os.unlink(webm_path)
        
        if result.returncode == 0:
            logger.info(f"[CONVERT] Successfully converted WebM to WAV: {output_path}")
            return output_path
        else:
            logger.error(f"[CONVERT] FFmpeg error: {result.stderr}")
            return None
            
    except Exception as e:
        logger.error(f"[CONVERT] Conversion failed: {e}")
        return None

@batch_transcription.route('/api/transcribe_batch', methods=['POST'])
def transcribe_batch():
    """
    Enhanced batch transcription endpoint
    """
    try:
        # Get audio data and session info
        audio_data = request.files.get('audio')
        session_id = request.form.get('session_id', f"session_{int(time.time())}")
        chunk_id = request.form.get('chunk_id', f"chunk_{int(time.time())}")
        meeting_type = request.form.get('meeting_type', 'general')
        context_prompt = request.form.get('context', '')
        
        if not audio_data:
            return jsonify({"error": "No audio data provided"}), 400
        
        # Read audio data
        audio_bytes = audio_data.read()
        
        # Call transcription function
        result = batch_transcribe_whisper_with_retry(
            audio_bytes, session_id, chunk_id, meeting_type, context_prompt
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"[BATCH-ENDPOINT] Error: {e}")
        return jsonify({"error": str(e)}), 500
                logger.warning(f"[AUDIO-VALIDATE] Chunk too small: {len(audio_data)} bytes, skipping")
                return {
                    "status": "skipped", 
                    "message": f"Audio chunk too small: {len(audio_data)} bytes (minimum {min_size} bytes)"
                }
            
            # Use session manager for validation
            if session_manager.active_session != session_id:
                session_manager.start_session(session_id)
            
            # Process audio with validation
            is_valid, error_msg = audio_processor.validate_webm_chunk(audio_data)
            if not is_valid:
                logger.warning(f"[AUDIO-VALIDATE] {error_msg}")
                return {"status": "skipped", "message": error_msg}
            
            # Convert WebM to WAV
            wav_path = audio_processor.convert_webm_to_wav_robust(audio_data)
            logger.info(f"[AUDIO-PROCESS] Successfully converted to: {wav_path}")
            
            # Transcribe with Whisper-1
            with open(wav_path, 'rb') as audio_file:
                response = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=("audio.wav", audio_file, "audio/wav"),
                    response_format="verbose_json",
                    prompt=context_prompt[:224] if context_prompt else ""
                )
                
                transcript = response.text.strip()
                confidence = 0.85
                
                # Calculate confidence from word-level data if available
                if hasattr(response, 'words') and response.words:
                    confidences = [getattr(word, 'confidence', 0.85) for word in response.words if hasattr(word, 'confidence')]
                    if confidences:
                        confidence = sum(confidences) / len(confidences)
                
                # Filter hallucinated content
                if is_hallucinated_transcript(transcript):
                    logger.warning(f"[FILTER] Hallucinated transcript filtered: {transcript[:30]}...")
                    if attempt < max_retries - 1:
                        continue  # Retry
                    else:
                        return {
                            "status": "filtered",
                            "message": "Transcript filtered as hallucination after retries"
                        }
                
                # Validate transcript quality and confidence
                if transcript and len(transcript) > 3 and confidence > 0.3:
                    logger.info(f"[WHISPER SUCCESS] Transcript: {transcript[:50]}...")
                    
                    # Emit WebSocket event for interim transcript
                    try:
                        from app_standalone import emit_interim_transcript
                        if chunk_id is not None:
                            emit_interim_transcript(session_id, transcript, confidence, chunk_id)
                    except Exception as socket_error:
                        logger.warning(f"[SOCKET] Failed to emit interim transcript: {socket_error}")
                    #             })
                    #             logger.info(f"[WEBSOCKET] Emitted interim transcript for chunk {chunk_id}")
                    # except Exception as socket_error:
                    #     logger.warning(f"[WEBSOCKET] Failed to emit interim transcript: {socket_error}")
                    if chunk_id is not None:
                        logger.info(f"[INTERIM] Chunk {chunk_id} processed: {transcript[:50]}...")
                    
                    return {
                        "status": "success", 
                        "transcript": transcript,
                        "text": transcript,  # For compatibility
                        "confidence": confidence,
                        "model_used": "whisper-1",
                        "attempt": attempt + 1
                    }
                else:
                    raise ValueError(f"Low quality transcript: length={len(transcript)}, confidence={confidence}")
                    
        except Exception as e:
            logger.error(f"[RETRY-WHISPER] Attempt {attempt + 1} failed: {e}")
            
            # Cleanup on error
            if wav_path and os.path.exists(wav_path):
                try:
                    os.unlink(wav_path)
                except OSError as cleanup_error:
                    logger.warning(f"Failed to cleanup temp file {wav_path}: {cleanup_error}")
            
            # If this is the last attempt, return error
            if attempt == max_retries - 1:
                logger.error(f"[RETRY-WHISPER] Chunk {chunk_id} permanently failed after {max_retries} attempts")
                return {
                    "status": "error",
                    "message": f"Transcription failed after {max_retries} attempts: {str(e)}",
                    "final_attempt": True
                }
            
            # Wait before retry (convert ms to seconds)
            if attempt < len(retry_delays):
                import time
                delay_seconds = retry_delays[attempt] / 1000
                logger.info(f"[RETRY-WHISPER] Waiting {delay_seconds}s before retry...")
                time.sleep(delay_seconds)
    
    # This should not be reached, but just in case
    return {
        "status": "error",
        "message": "Retry logic failed unexpectedly"
    }

# Legacy function for backward compatibility
def batch_transcribe_whisper(audio_data, session_id, meeting_type="general", context_prompt=""):
    """Legacy wrapper function for backward compatibility"""
    return batch_transcribe_whisper_with_retry(audio_data, session_id, None, meeting_type, context_prompt)

@batch_transcription.route('/api/batch_transcribe', methods=['POST'])
def api_batch_transcribe():
    """Enhanced batch transcription with session management and validation"""
    try:
        logger.info(f"[BATCH_TRANSCRIBE] Request received - Content-Type: {request.content_type}")
        
        # Extract audio data from request
        audio_data = None
        audio_file = None
        
        # Try multiple field names for compatibility
        for field_name in ['audio', 'audio_chunk', 'file']:
            if field_name in request.files:
                audio_file = request.files[field_name]
                if audio_file and audio_file.filename:
                    audio_data = audio_file.read()
                    break
        
        if not audio_data:
            logger.error(f"[BATCH_TRANSCRIBE] No audio data found. Available fields: {list(request.files.keys())}")
            return jsonify({"status": "error", "message": "No audio data provided"}), 400
            
        # Extract metadata
        batch_index = request.form.get('batch_index', '0')
        chunk_index = int(request.form.get('chunk_index', batch_index))
        session_id = request.form.get('session_id', 'default')
        is_progressive = request.form.get('is_progressive', 'false').lower() == 'true'
        timestamp = request.form.get('timestamp', datetime.utcnow().isoformat())
        meeting_mode = request.form.get('meeting_mode', 'general')
        transcript_context = request.form.get('transcript_context', '')
        
        # Session management for progressive chunks
        if is_progressive:
            # Start session if not active
            if session_manager.active_session != session_id:
                session_manager.start_session(session_id)
            
            # Check if this chunk can be processed
            if not session_manager.can_process_chunk(chunk_index):
                logger.warning(f"[SESSION] Chunk {chunk_index} cannot be processed")
                return jsonify({
                    "status": "skipped",
                    "message": f"Chunk {chunk_index} already processed or failed",
                    "batch_index": batch_index,
                    "session_id": session_id
                }), 200
            
            # Mark chunk as processing
            session_manager.start_processing_chunk(chunk_index)
        
        processing_type = "PROGRESSIVE" if is_progressive else "BATCH"
        logger.info(f"[{processing_type} {batch_index}] Processing {len(audio_data)} bytes")
        
        # Call the enhanced batch transcription function with retry logic
        result = batch_transcribe_whisper_with_retry(
            audio_data=audio_data,
            session_id=session_id,
            chunk_id=chunk_index,
            meeting_type=meeting_mode,
            context_prompt=transcript_context,
            max_retries=3
        )
        
        # Handle session management for progressive chunks
        if is_progressive:
            if result.get("status") == "success":
                session_manager.finish_chunk_success(chunk_index, result)
            else:
                session_manager.finish_chunk_failure(chunk_index, result.get("message", "Unknown error"))
        
        logger.info(f"[{processing_type} {batch_index}] Result: {result.get('status')} - {result.get('message', 'Success')}")
        
        # Return enhanced response with session info
        response = {
            **result,
            "batch_index": batch_index,
            "chunk_index": chunk_index,
            "session_id": session_id,
            "processing_type": processing_type,
            "timestamp": timestamp
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"[BATCH_TRANSCRIBE] Request processing failed: {e}")
        return jsonify({
            "status": "error",
            "message": "Request processing failed"
        }), 500