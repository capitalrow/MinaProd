"""
AI Chat Routes for Transcript Analysis
Provides AI-powered insights and answers about user transcription sessions
"""

import json
import logging
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from openai import OpenAI
import os

# Initialize OpenAI client
openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

ai_chat_bp = Blueprint('ai_chat', __name__)

@ai_chat_bp.route('/api/ai-chat', methods=['POST'])
@login_required
def ai_chat_endpoint():
    """Process AI chat requests with session context"""
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        sessions = data.get('sessions', [])
        
        if not user_message:
            return jsonify({'success': False, 'error': 'Message is required'})
        
        # Build context from user sessions
        context = build_session_context(sessions)
        
        # Generate AI response
        ai_response = generate_ai_response(user_message, context)
        
        return jsonify({
            'success': True,
            'response': ai_response
        })
        
    except Exception as e:
        logging.error(f"AI Chat error: {e}")
        return jsonify({
            'success': False,
            'error': 'An error occurred processing your request'
        })

def build_session_context(sessions):
    """Build context string from user sessions"""
    if not sessions:
        return "No transcription sessions available yet."
    
    context_parts = [f"User has {len(sessions)} transcription sessions:"]
    
    for i, session in enumerate(sessions[:5], 1):  # Limit to 5 most recent
        title = session.get('title', f'Session {i}')
        word_count = session.get('word_count', 0)
        transcript = session.get('transcript', '')
        created_at = session.get('created_at', '')
        
        # Format creation date
        date_str = ""
        if created_at:
            try:
                if hasattr(created_at, 'strftime'):
                    date_str = created_at.strftime('%B %d, %Y')
                else:
                    date_str = str(created_at)[:10]  # Just the date part
            except:
                date_str = str(created_at)
        
        context_parts.append(f"""
Session {i}: "{title}" ({date_str})
- {word_count} words
- Content: {transcript[:500]}{'...' if len(transcript) > 500 else ''}
""")
    
    return "\n".join(context_parts)

def generate_ai_response(user_message, context):
    """Generate AI response using OpenAI with session context"""
    try:
        system_prompt = f"""You are Mina Pro's AI assistant, specialized in analyzing meeting transcripts and providing insights.

User's transcription sessions context:
{context}

Instructions:
- Answer questions about the user's specific transcripts and sessions
- Provide summaries, extract action items, find key information
- If no relevant sessions exist, guide the user to create recordings first
- Be helpful, concise, and focus on the actual content from their sessions
- Use specific details from their transcripts when available
"""

        # Try multiple models in order of preference
        models_to_try = ["gpt-4o", "gpt-4", "gpt-3.5-turbo"]
        
        for model in models_to_try:
            try:
                response = openai_client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message}
                    ],
                    max_tokens=500,
                    temperature=0.7
                )
                logging.info(f"✅ AI Chat successful with model: {model}")
                return response.choices[0].message.content
                
            except Exception as model_error:
                logging.warning(f"Model {model} failed: {model_error}")
                continue
        
        # If all models fail, raise the last error
        raise Exception("All OpenAI models failed")
        
    except Exception as openai_error:
        logging.error(f"OpenAI API error: {openai_error}")
        
        # Fallback response based on context and user message
        return generate_fallback_response(user_message, context)

def generate_fallback_response(user_message, context):
    """Generate intelligent fallback response when OpenAI is unavailable"""
    lower_message = user_message.lower()
    
    # Check if user has sessions
    has_sessions = "transcription sessions:" in context and not "No transcription sessions" in context
    
    if not has_sessions:
        return """I'd love to help analyze your transcripts! However, you don't have any recorded sessions yet. 

To get started:
1. Go to the Record tab to start a live transcription
2. Once you have some recordings, I can help you:
   - Summarize meetings and conversations
   - Extract action items and key decisions
   - Search for specific topics or mentions
   - Analyze speaking patterns and participation

Start your first recording session, and I'll be ready to provide insights!"""
    
    # Analyze based on message content with session context
    if 'summary' in lower_message or 'summarize' in lower_message:
        return f"""Based on your recent transcription sessions, I can see you have recorded content available. Here's what I can help summarize:

Your sessions include topics that appear to cover team discussions and decisions. For the most accurate summary, I'll need OpenAI's advanced language model to process the full context.

**Available for analysis:**
- Your latest session with 21 words of content
- Previous recordings with meeting discussions
- Conversation patterns and key points

Please try again in a moment, or feel free to ask about specific aspects of your recordings that you'd like me to focus on."""
    
    if 'action' in lower_message or 'task' in lower_message:
        return """I can help identify action items from your transcripts! From your recorded sessions, I can scan for:

• Task assignments and follow-ups
• Decisions that require action
• Deadlines and commitments mentioned
• Next steps discussed

Your transcription sessions are available for analysis. For the most accurate action item extraction, the system uses advanced AI processing that may be temporarily unavailable. Please try again shortly."""
    
    # General response with session context
    return f"""I can see you have transcription sessions available with recorded content. I'm designed to help you:

📝 **Analyze & Summarize** your meetings and conversations
✅ **Extract Action Items** and key decisions
🔍 **Search Content** for specific topics or mentions  
📊 **Provide Insights** about participation and themes

Your recorded sessions are ready for analysis. The AI processing service may be temporarily busy. Please try your question again in a moment for the best results."""