"""
Summarization API endpoint for complete transcript processing
Handles GPT-powered analysis after recording completion
"""

import logging
import json
from flask import Blueprint, request, jsonify
from services.gpt_helpers import generate_summary, analyze_sentiment

logger = logging.getLogger(__name__)

# Create Blueprint for summarization routes
summarize_bp = Blueprint('summarize_api', __name__)

@summarize_bp.route('/api/summarize', methods=['POST'])
def summarize_transcript():
    """
    Endpoint to handle complete transcript summarization
    Accept full-text payload after recording stops and call GPT-4 for analysis
    """
    try:
        logger.info("Received summarization request")
        
        # Parse JSON request
        if not request.is_json:
            return jsonify({
                "status": "error",
                "message": "Request must be JSON"
            }), 400
        
        data = request.get_json()
        text = data.get('text', '').strip()
        session_id = data.get('session_id', 'unknown')
        
        if not text:
            return jsonify({
                "status": "error", 
                "message": "No text provided for summarization"
            }), 400
        
        logger.info(f"Summarizing transcript for session {session_id}: {len(text)} characters")
        
        # Call GPT-4 for summarization, action items extraction, etc.
        try:
            logger.info("Generating summary with GPT...")
            summary_result = generate_summary(text, meeting_type="general")
            
            logger.info("Analyzing sentiment with GPT...")
            sentiment_result = analyze_sentiment(text)
            
            # Return comprehensive summary JSON
            response = {
                "status": "success",
                "text": text,
                "summary": summary_result.get("summary", "Summary generation failed"),
                "action_items": summary_result.get("action_items", []),
                "key_points": summary_result.get("key_points", []),
                "sentiment": sentiment_result.get("sentiment", "neutral"),
                "confidence": sentiment_result.get("confidence", 0.0),
                "session_id": session_id
            }
            
            logger.info(f"Summary generated successfully for session {session_id}")
            return jsonify(response), 200
            
        except Exception as gpt_error:
            logger.error(f"GPT summarization failed: {gpt_error}")
            return jsonify({
                "status": "error",
                "message": f"Summary generation failed: {str(gpt_error)}",
                "text": text,
                "session_id": session_id
            }), 500
            
    except Exception as e:
        logger.error(f"Summarization endpoint error: {e}", exc_info=True)
        return jsonify({
            "status": "error",
            "message": f"Summarization error: {str(e)}"
        }), 500