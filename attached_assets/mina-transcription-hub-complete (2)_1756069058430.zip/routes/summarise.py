"""
Post-Transcription Summary API for Mina Pro
GPT-4o powered analysis of completed transcripts
"""

import logging
from flask import Blueprint, request, jsonify
import sys
import os

# Add the parent directory to the path to import services
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logger = logging.getLogger(__name__)

# Create Blueprint
routes_summarise = Blueprint('routes_summarise', __name__)

@routes_summarise.route("/api/summarise_transcript", methods=["POST"])
def summarise_transcript():
    """Generate comprehensive analysis of completed transcript using GPT-4o"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                "status": "error", 
                "message": "No JSON data provided"
            }), 400
        
        transcript = data.get("transcript", "").strip()
        session_id = data.get("session_id", "unknown")
        
        if not transcript:
            return jsonify({
                "status": "error", 
                "message": "Transcript empty or missing"
            }), 400
        
        logger.info(f"[SUMMARY] Processing transcript for session {session_id}: {len(transcript)} characters")
        
        # Import GPT helper functions
        try:
            from services.gpt_helpers import gpt_generate_summary, gpt_extract_actions, gpt_analyse_sentiment
        except ImportError as e:
            logger.error(f"Failed to import GPT helpers: {e}")
            return jsonify({
                "status": "error",
                "message": "GPT services unavailable"
            }), 500
        
        # Generate comprehensive analysis
        summary_result = gpt_generate_summary(transcript)
        actions_result = gpt_extract_actions(transcript)
        sentiment_result = gpt_analyse_sentiment(transcript)
        
        logger.info(f"[SUMMARY] Analysis completed for session {session_id}")
        
        return jsonify({
            "status": "success",
            "session_id": session_id,
            "summary": summary_result.get("summary", ""),
            "key_points": summary_result.get("key_points", []),
            "actions": actions_result.get("actions", []),
            "sentiment": sentiment_result.get("sentiment", "neutral"),
            "sentiment_confidence": sentiment_result.get("confidence", 0.5),
            "insights": sentiment_result.get("insights", []),
            "analysis_status": {
                "summary": summary_result.get("status", "unknown"),
                "actions": actions_result.get("status", "unknown"),
                "sentiment": sentiment_result.get("status", "unknown")
            }
        }), 200
        
    except Exception as e:
        logger.error(f"[SUMMARY] Unexpected error: {str(e)}")
        return jsonify({
            "status": "error",
            "message": f"Analysis failed: {str(e)}"
        }), 200  # Return 200 with error status for graceful frontend handling