"""
Share Routes for Mina Pro
Handles creation and serving of shareable transcript links
"""

import logging
import uuid
import json
import os
from datetime import datetime
from flask import Blueprint, request, jsonify, render_template_string
from pathlib import Path

logger = logging.getLogger(__name__)

# Create Blueprint
routes_share = Blueprint('share', __name__)

# Directory for storing shared transcripts
SHARES_DIR = Path("public_shares")
SHARES_DIR.mkdir(exist_ok=True)

@routes_share.route('/api/share', methods=['POST'])
def create_share():
    """Create a shareable public link for a transcript session"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"status": "error", "message": "No data provided"}), 400
        
        # Generate unique share ID
        share_id = str(uuid.uuid4())[:8]
        
        # Create share data
        share_data = {
            "share_id": share_id,
            "session_id": data.get("session_id"),
            "meeting_mode": data.get("meeting_mode", "general"),
            "transcript_chunks": data.get("transcript_chunks", []),
            "classifications": data.get("classifications", []),
            "productivity_stats": data.get("productivity_stats", {}),
            "avg_confidence": data.get("avg_confidence", 0),
            "created_at": data.get("created_at", datetime.utcnow().isoformat()),
            "shared_at": datetime.utcnow().isoformat()
        }
        
        # Save share data to file
        share_file = SHARES_DIR / f"{share_id}.json"
        with open(share_file, 'w') as f:
            json.dump(share_data, f, indent=2)
        
        logger.info(f"[SHARE] Created share link: {share_id}")
        
        return jsonify({
            "status": "success",
            "share_id": share_id,
            "share_url": f"/share/{share_id}",
            "expires": "Never"  # For now, shares don't expire
        })
        
    except Exception as e:
        logger.error(f"Share creation error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@routes_share.route('/share/<share_id>')
def view_share(share_id):
    """View a shared transcript"""
    try:
        share_file = SHARES_DIR / f"{share_id}.json"
        
        if not share_file.exists():
            return "Shared transcript not found", 404
        
        with open(share_file, 'r') as f:
            share_data = json.load(f)
        
        # Generate HTML for the shared transcript
        html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shared Transcript - Mina AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .share-container { max-width: 800px; margin: 2rem auto; padding: 0 1rem; }
        .share-card { background: white; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }
        .share-header { background: linear-gradient(135deg, #2563eb, #1e40af); color: white; padding: 2rem; text-align: center; }
        .classification-badge { padding: 2px 8px; border-radius: 12px; font-size: 0.75em; font-weight: 500; margin-left: 8px; }
        .classification-task { background-color: #d4edda; color: #155724; }
        .classification-decision { background-color: #e2e3ff; color: #4c4c9d; }
        .classification-deadline { background-color: #f8d7da; color: #721c24; }
        .classification-follow-up { background-color: #d1ecf1; color: #0c5460; }
        .classification-neutral { background-color: #f8f9fa; color: #6c757d; }
        .transcript-item { padding: 1rem; border-bottom: 1px solid #e9ecef; }
        .transcript-item:last-child { border-bottom: none; }
        .confidence-high { color: #28a745; }
        .confidence-medium { color: #ffc107; }
        .confidence-low { color: #dc3545; }
    </style>
</head>
<body>
    <div class="share-container">
        <div class="share-card">
            <div class="share-header">
                <h1><i class="fas fa-share-alt me-2"></i>Shared Transcript</h1>
                <p class="mb-0">Meeting: {{ meeting_mode.title() }} | {{ created_date }}</p>
            </div>
            
            {% if productivity_stats %}
            <div class="p-4 bg-light border-bottom">
                <h5>Productivity Summary</h5>
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <h3 class="text-primary">{{ productivity_stats.get('total_chunks', 0) }}</h3>
                            <small class="text-muted">Total Chunks</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h3 class="text-success">{{ productivity_stats.get('actionable_chunks', 0) }}</h3>
                            <small class="text-muted">Actionable Items</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h3 class="text-info">{{ confidence_percent }}%</h3>
                            <small class="text-muted">Avg Confidence</small>
                        </div>
                    </div>
                </div>
            </div>
            {% endif %}
            
            <div class="p-4">
                <h5>Transcript</h5>
                {% for chunk in transcript_chunks %}
                {% if chunk and chunk.text %}
                <div class="transcript-item">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="fw-bold text-muted">#{{ loop.index }}</span>
                        <div>
                            {% if chunk.classification and chunk.classification.classification != 'neutral' %}
                            <span class="classification-badge classification-{{ chunk.classification.classification }}">
                                {{ chunk.classification.classification.upper() }}
                            </span>
                            {% endif %}
                            <span class="small confidence-{{ 'high' if chunk.confidence >= 0.8 else 'medium' if chunk.confidence >= 0.6 else 'low' }}">
                                {{ (chunk.confidence * 100) | round }}% confidence
                            </span>
                        </div>
                    </div>
                    <p class="mb-0">{{ chunk.text }}</p>
                </div>
                {% endif %}
                {% endfor %}
            </div>
            
            <div class="p-3 bg-light text-center">
                <small class="text-muted">
                    <i class="fas fa-robot me-1"></i>Generated by Mina AI Transcription
                    | Shared on {{ shared_date }}
                </small>
            </div>
        </div>
    </div>
</body>
</html>
        """
        
        # Format dates
        created_date = datetime.fromisoformat(share_data['created_at'].replace('Z', '+00:00')).strftime('%B %d, %Y at %I:%M %p')
        shared_date = datetime.fromisoformat(share_data['shared_at'].replace('Z', '+00:00')).strftime('%B %d, %Y at %I:%M %p')
        confidence_percent = round(share_data.get('avg_confidence', 0) * 100)
        
        from jinja2 import Template
        template = Template(html_template)
        
        return template.render(
            meeting_mode=share_data.get('meeting_mode', 'general'),
            created_date=created_date,
            shared_date=shared_date,
            confidence_percent=confidence_percent,
            productivity_stats=share_data.get('productivity_stats'),
            transcript_chunks=share_data.get('transcript_chunks', [])
        )
        
    except Exception as e:
        logger.error(f"Share view error: {e}")
        return f"Error loading shared transcript: {str(e)}", 500

@routes_share.route('/api/feedback', methods=['POST'])
def submit_feedback():
    """Submit feedback for transcript chunks"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"status": "error", "message": "No data provided"}), 400
        
        chunk_id = data.get('chunk_id')
        rating = data.get('rating')
        session_id = data.get('session_id')
        meeting_mode = data.get('meeting_mode', 'general')
        
        # Store feedback (for now, just log it - in production, save to database)
        feedback_data = {
            "chunk_id": chunk_id,
            "rating": rating,
            "session_id": session_id,
            "meeting_mode": meeting_mode,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Save to feedback log file
        feedback_file = Path("feedback_log.jsonl")
        with open(feedback_file, 'a') as f:
            f.write(json.dumps(feedback_data) + '\n')
        
        logger.info(f"[FEEDBACK] Chunk {chunk_id}: {rating} for session {session_id}")
        
        return jsonify({
            "status": "success",
            "message": "Feedback recorded successfully"
        })
        
    except Exception as e:
        logger.error(f"Feedback submission error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500