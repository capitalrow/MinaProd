"""
Buffered Transcription Route - Enhanced WebM Processing
Handles real-time audio chunk processing with robust FFmpeg conversion and local Whisper transcription
"""

import os
import logging
from flask import Blueprint, request, jsonify
from audio_processor import AudioProcessor
from pydub import AudioSegment

logger = logging.getLogger(__name__)

# Create Blueprint for buffered transcription
routes_buffered_transcription = Blueprint('buffered_transcription', __name__)

# Initialize audio processor
audio_processor = AudioProcessor()

# Import services
try:
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from services.whisper_transcriber import transcribe as whisper_transcribe
    logger.info("Local Whisper transcriber imported successfully")
    whisper_transcribe_available = True
except ImportError as e:
    logger.warning(f"Failed to import Whisper transcriber: {e}")
    whisper_transcribe = None
    whisper_transcribe_available = False

# Import streaming service
try:
    from services.whisper_streaming import transcribe_with_streaming, get_streaming_service
    import numpy as np
    import wave
    logger.info("Whisper streaming service imported successfully")
    streaming_available = True
except ImportError as e:
    logger.warning(f"Failed to import streaming service: {e}")
    streaming_available = False

# Import AI summary service
try:
    from services.gpt_helpers import gpt_generate_summary, gpt_extract_actions, gpt_analyse_sentiment
    logger.info("GPT services imported successfully")
    gpt_services_available = True
except ImportError as e:
    logger.warning(f"Failed to import GPT services: {e}")
    gpt_services_available = False

# Retry logic decorator
def retry_on_failure(max_retries: int = 1):
    """Decorator to retry function on failure"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries:
                        logger.error(f"Function {func.__name__} failed after {max_retries + 1} attempts: {e}")
                        raise
                    logger.warning(f"Function {func.__name__} failed (attempt {attempt + 1}), retrying: {e}")
                    time.sleep(0.5)  # Brief delay before retry
            return None
        return wrapper
    return decorator

def pad_wav_if_short(wav_path):
    """Pad short audio files (<2 seconds) before sending to Whisper"""
    try:
        audio = AudioSegment.from_wav(wav_path)
        if len(audio) < 2000:  # less than 2 seconds
            logger.info(f"[PADDING] Audio is {len(audio)}ms, padding to improve Whisper accuracy")
            silence = AudioSegment.silent(duration=1000)  # 1 second of silence
            padded = silence + audio + silence
            padded.export(wav_path, format="wav")
            logger.info(f"[PADDING] Audio padded successfully, new duration: {len(padded)}ms")
    except Exception as e:
        logger.warning(f"[PADDING] Failed to pad audio: {e}")

@routes_buffered_transcription.route('/api/buffered_transcribe', methods=['POST'])
def api_buffered_transcribe():
    """Enhanced buffered transcription with robust WebM processing"""
    try:
        logger.info(f"[BUFFERED_TRANSCRIBE] Request received - Content-Type: {request.content_type}")
        
        # Handle multipart/form-data with robust field detection
        audio_data = None
        audio_file = None
        field_used = None
        
        # Try multiple field names for compatibility
        for field_name in ['audio', 'audio_chunk', 'file']:
            if field_name in request.files:
                audio_file = request.files[field_name]
                if audio_file and audio_file.filename:
                    audio_data = audio_file.read()
                    field_used = field_name
                    break
        
        if not audio_data:
            logger.error(f"[BUFFERED_TRANSCRIBE] No audio data found. Available fields: {list(request.files.keys())}")
            return jsonify({"status": "error", "message": "No audio data provided"}), 400
            
        chunk_number = request.form.get('chunk_number', '0')
        chunk_index = request.form.get('chunk_index', chunk_number)
        chunk_session = request.form.get('chunk_session', request.form.get('session_id', 'default'))
        session_id = chunk_session
        is_interim = request.form.get('is_interim', 'false').lower() == 'true'
        is_batch = request.form.get('is_batch', 'false').lower() == 'true'
        
        batch_indicator = "[BATCH]" if is_batch else ""
        logger.info(f"{batch_indicator}[CHUNK {chunk_number}] (Index: {chunk_index}) Received {len(audio_data)} bytes via '{field_used}' field from session {session_id}")
        
        # Validate chunk size (16KB minimum for better reliability)
        if len(audio_data) < audio_processor.minimum_size_bytes:
            logger.warning(f"[CHUNK {chunk_number}] Audio too small: {len(audio_data)} bytes (minimum: {audio_processor.minimum_size_bytes})")
            return jsonify({
                "status": "skipped", 
                "message": f"Audio chunk too small: {len(audio_data)} bytes (minimum {audio_processor.minimum_size_bytes} for reliable processing)",
                "minimum_required": audio_processor.minimum_size_bytes
            }), 200
        
        # Validate chunk content
        if not audio_processor.is_valid_chunk(audio_data):
            logger.warning(f"[CHUNK {chunk_number}] Invalid audio chunk")
            return jsonify({
                "status": "error", 
                "message": "Invalid audio chunk format"
            }), 400
        
        # Implement batch-based buffering - require larger chunks for longer speech segments  
        MIN_REQUIRED_CHUNK_SIZE = 65536  # 64KB minimum for reliable Whisper processing (reduced for shorter recordings)
        
        # Check if chunk should be buffered (only buffer if very small and no existing buffer)
        # Skip very small chunks (<50KB) to avoid low-quality transcriptions
        if (len(audio_data) < 51200 and len(audio_processor.buffered_chunks) == 0 and not is_batch):
            audio_processor.buffer_chunk(audio_data)
            logger.info(f"[CHUNK {chunk_number}] Chunk buffered ({len(audio_data)} bytes) - too small for reliable transcription")
            return jsonify({
                "status": "buffering",
                "message": f"Chunk buffered, collecting larger segment (minimum 50KB for quality)",
                "chunk_number": chunk_number,
                "text": "",
                "transcript": "",
                "confidence": 0.0
            }), 200
        
        # Check if we should flush buffered chunks
        force_flush = request.form.get('force_flush', '').lower() == 'true'
        if audio_processor.chunk_buffer or force_flush:
            # Add current chunk and flush all buffered data
            if len(audio_data) > 0:
                audio_processor.buffer_chunk(audio_data)
            
            combined_audio = audio_processor.flush_buffered_chunks()
            if len(combined_audio) > 0:
                audio_data = combined_audio
                logger.info(f"[CHUNK {chunk_number}] Using combined buffered audio: {len(audio_data)} bytes")
            else:
                return jsonify({
                    "status": "skipped",
                    "message": "No buffered audio to process",
                    "chunk_number": chunk_number,
                    "text": "",
                    "transcript": "",
                    "confidence": 0.0
                }), 200

        # Process audio chunk with enhanced error handling
        try:
            logger.info(f"[CHUNK {chunk_number}] Starting audio processing...")
            
            # Check if audio data appears to be WebM with potential EBML issues
            if len(audio_data) >= 4:
                # Look for EBML signature in first few bytes
                ebml_signature = b'\x1A\x45\xDF\xA3'
                has_ebml = audio_data[:4] == ebml_signature or ebml_signature in audio_data[:1024]
                
                if not has_ebml:
                    logger.warning(f"[CHUNK {chunk_number}] No EBML header found in WebM chunk")
                    # Try to repair by prepending a minimal EBML header
                    minimal_ebml_header = bytes([
                        0x1A, 0x45, 0xDF, 0xA3, # EBML signature
                        0x9F, # Size
                        0x42, 0x86, 0x81, 0x01, # EBML Version
                        0x42, 0xF7, 0x81, 0x01, # EBML Read Version
                        0x42, 0xF2, 0x81, 0x04, # EBML Max ID Length
                        0x42, 0xF3, 0x81, 0x08, # EBML Max Size Length
                        0x42, 0x82, 0x84, # Doc Type
                        0x77, 0x65, 0x62, 0x6D, # "webm"
                        0x42, 0x87, 0x81, 0x04, # Doc Type Version
                        0x42, 0x85, 0x81, 0x02  # Doc Type Read Version
                    ])
                    audio_data = minimal_ebml_header + audio_data
                    logger.info(f"[CHUNK {chunk_number}] Repaired WebM with EBML header: {len(audio_data)} bytes")
            
            wav_path = audio_processor.process_audio_chunk(audio_data)
            logger.info(f"[CHUNK {chunk_number}] Audio processing completed: {wav_path}")
            
            # Pad short audio files before Whisper transcription
            pad_wav_if_short(wav_path)
            
            # Check if this is a silent audio fallback (very small file indicates FFmpeg fallback)
            if os.path.getsize(wav_path) < 2000:  # Less than 2KB indicates silent audio fallback
                logger.info(f"[CHUNK {chunk_number}] Silent audio detected, skipping transcription")
                audio_processor.cleanup_temp_file(wav_path)
                return jsonify({
                    "status": "skipped",
                    "message": "Audio chunk corrupted - generated silent placeholder",
                    "chunk_number": chunk_number,
                    "text": "",
                    "transcript": "",
                    "confidence": 0.0
                }), 200
            
            # Try streaming transcription first (preferred for real-time)
            if streaming_available:
                try:
                    logger.info(f"[CHUNK {chunk_number}] Using Whisper streaming pipeline")
                    
                    # Convert WAV to numpy array for streaming
                    with wave.open(wav_path, 'rb') as wav_file:
                        frames = wav_file.readframes(-1)
                        audio_array = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
                    
                    @retry_on_failure(max_retries=1) 
                    def streaming_transcribe():
                        import time
                        return transcribe_with_streaming(audio_array, timestamp=time.time())
                    
                    result = streaming_transcribe()
                    
                    if result and result.get("text", "").strip():
                        text = result["text"].strip()
                        
                        # Queue GPT post-processing (non-blocking)
                        summary = sentiment = ""
                        if gpt_services_available and len(text) > 10:
                            try:
                                summary_result = gpt_generate_summary(text)
                                sentiment_result = gpt_analyse_sentiment(text)
                                summary = summary_result.get("summary", "")
                                sentiment = sentiment_result.get("sentiment", "neutral")
                                logger.info(f"[CHUNK {chunk_number}] GPT post-processing completed")
                            except Exception as e:
                                logger.warning(f"GPT post-processing failed: {e}")
                        
                        logger.info(f"[CHUNK {chunk_number}] Streaming transcription successful: {text[:50]}...")
                        
                        # Clean up
                        if os.path.exists(wav_path):
                            os.unlink(wav_path)
                        
                        return jsonify({
                            "chunk_number": chunk_number,
                            "status": "success",
                            "transcript": text,
                            "confidence": result.get("confidence", 0.8),
                            "processing_time": result.get("processing_time", 0.0),
                            "summary": summary,
                            "sentiment": sentiment,
                            "model_used": f"whisper-streaming-{result.get('mode', 'unknown')}",
                            "window_length": result.get("window_length", 0.0)
                        }), 200
                    
                except Exception as e:
                    logger.warning(f"[CHUNK {chunk_number}] Streaming transcription failed: {e}")
            
            # Fallback to local Whisper transcription
            if whisper_transcribe_available and whisper_transcribe:
                logger.info(f"[CHUNK {chunk_number}] Using local Whisper model fallback")
                
                @retry_on_failure(max_retries=1)
                def local_transcribe():
                    return whisper_transcribe(wav_path)
                
                result = local_transcribe()
                
                if result and result.get("text", "").strip():
                    text = result["text"].strip()
                    confidence = result.get("confidence", 0.8)
                    
                    # Filter out low-quality transcriptions
                    if confidence < 0.2 or len(text) < 5:
                        logger.warning(f"[CHUNK {chunk_number}] Low quality transcription filtered (confidence: {confidence:.2f}, text: '{text[:30]}')")
                        audio_processor.cleanup_temp_file(wav_path)
                        return jsonify({
                            "status": "skipped",
                            "message": f"Low quality transcription filtered (confidence: {confidence:.1%})",
                            "chunk_number": chunk_number,
                            "text": "",
                            "transcript": "",
                            "confidence": confidence,
                            "processing_time": result.get("time_taken", 0.0)
                        }), 200
                    
                    # Add GPT analysis for successful transcriptions
                    summary = sentiment = ""
                    if gpt_services_available and len(text) > 10:
                        try:
                            summary_result = gpt_generate_summary(text)
                            sentiment_result = gpt_analyse_sentiment(text)
                            summary = summary_result.get("summary", "")
                            sentiment = sentiment_result.get("sentiment", "neutral")
                            logger.info(f"[CHUNK {chunk_number}] GPT analysis completed")
                        except Exception as e:
                            logger.warning(f"GPT analysis failed: {e}")
                    
                    logger.info(f"[CHUNK {chunk_number}] Local transcription successful: {text[:50]}...")
                    
                    # Clean up temporary file
                    if os.path.exists(wav_path):
                        os.unlink(wav_path)
                    
                    return jsonify({
                        "chunk_number": chunk_number,
                        "status": "success",
                        "text": text,
                        "transcript": text,
                        "confidence": confidence,
                        "processing_time": result.get("time_taken", 0.0),
                        "summary": summary,
                        "sentiment": sentiment,
                        "model_used": "whisper-local"
                    }), 200
                
                else:
                    logger.info(f"[CHUNK {chunk_number}] Local Whisper returned no result")
                    audio_processor.cleanup_temp_file(wav_path)
                    return jsonify({
                        "status": "no_transcript",
                        "message": "Local Whisper returned no transcription",
                        "chunk_number": chunk_number,
                        "text": "",
                        "transcript": "",
                        "confidence": 0.0
                    }), 200
            
            else:
                # Fallback to API transcription
                logger.info(f"[CHUNK {chunk_number}] Using API transcription fallback")
                try:
                    from app_standalone import batch_transcribe_whisper
                    
                    result = batch_transcribe_whisper(
                        audio_data=open(wav_path, 'rb').read(),
                        session_id=session_id,
                        meeting_type='live_chunk',
                        context_prompt=f"Chunk {chunk_number} interim transcription"
                    )
                    
                    # Clean up temporary file
                    if os.path.exists(wav_path):
                        os.unlink(wav_path)
                
                    if result and result.get("status") == "success":
                        transcript = result["transcript"]
                        confidence = result.get("confidence", 0.85)
                        
                        # Filter out low-quality API transcriptions
                        if confidence < 0.2 or len(transcript.strip()) < 5:
                            logger.warning(f"[CHUNK {chunk_number}] Low quality API transcription filtered (confidence: {confidence:.2f})")
                            return jsonify({
                                "status": "skipped",
                                "message": f"Low quality transcription filtered (confidence: {confidence:.1%})",
                                "chunk_number": chunk_number,
                                "text": "",
                                "transcript": "",
                                "confidence": confidence,
                                "processing_time": result.get("processing_time", 0)
                            }), 200
                        
                        logger.info(f"[CHUNK {chunk_number}] API transcription successful: {transcript[:50]}...")
                        return jsonify({
                            "status": "success",
                            "text": transcript,
                            "transcript": transcript,
                            "confidence": confidence,
                            "chunk_number": chunk_number,
                            "processing_time": result.get("processing_time", 0),
                            "model_used": result.get("model_used", "whisper-1")
                        }), 200
                    else:
                        logger.info(f"[CHUNK {chunk_number}] API transcription returned no result")
                        return jsonify({
                            "status": "no_transcript",
                            "message": "Whisper returned no transcription.",
                            "chunk_number": chunk_number,
                            "text": "",
                            "transcript": "",
                            "confidence": 0.0
                        }), 200
                        
                except Exception as api_error:
                    logger.error(f"[CHUNK {chunk_number}] API transcription failed: {api_error}")
                    import traceback
                    logger.error(f"[CHUNK {chunk_number}] Full traceback: {traceback.format_exc()}")
                    audio_processor.cleanup_temp_file(wav_path)
                    return jsonify({
                        "status": "error",
                        "message": f"API transcription failed: {str(api_error)}",
                        "chunk_number": chunk_number,
                        "text": "",
                        "transcript": "",
                        "confidence": 0.0,
                        "error_trace": traceback.format_exc()
                    }), 500
                
        except Exception as processing_error:
            logger.error(f"[CHUNK {chunk_number}] Processing error: {str(processing_error)}")
            
            # Check if it's an EBML/FFmpeg error and log FFmpeg stderr for debugging
            error_msg = str(processing_error)
            if "EBML header parsing failed" in error_msg or "Invalid data found" in error_msg:
                logger.warning(f"[CHUNK {chunk_number}] EBML corruption detected. Full error: {error_msg}")
                
                # Try to extract FFmpeg stderr for more details
                if hasattr(processing_error, 'stderr'):
                    logger.error(f"[CHUNK {chunk_number}] FFmpeg stderr: {processing_error.stderr}")
                
                # Return skipped status to continue processing other chunks
                return jsonify({
                    "status": "skipped",
                    "message": "WebM chunk corrupted - skipping to maintain stream continuity",
                    "chunk_number": chunk_number,
                    "error_type": "ebml_corruption",
                    "transcript": "",
                    "confidence": 0.0
                }), 200
            else:
                logger.error(f"[CHUNK {chunk_number}] General processing error: {error_msg}")
                return jsonify({
                    "status": "error",
                    "message": f"Audio processing failed: {str(processing_error)}",
                    "chunk_number": chunk_number,
                    "text": "",
                    "transcript": "",
                    "error_type": "processing_error"
                }), 500
            
    except Exception as e:
        logger.error(f"[BUFFERED_TRANSCRIBE] Unexpected error: {str(e)}")
        return jsonify({
            "status": "error",
            "message": f"Server error: {str(e)}"
        }), 500