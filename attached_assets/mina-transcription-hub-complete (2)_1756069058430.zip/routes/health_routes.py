"""
Health Check and Monitoring Routes
Industry-standard health monitoring endpoints
"""

from flask import Blueprint, jsonify, request
from datetime import datetime
import psutil
import os
from sqlalchemy import text
from app_refactored import db
import requests
from services.session_manager import SessionManager

health_bp = Blueprint('health', __name__)

@health_bp.route('/health', methods=['GET'])
def health_check():
    """Comprehensive health check endpoint"""
    try:
        health_status = {
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0',
            'environment': os.environ.get('FLASK_ENV', 'production'),
            'checks': {}
        }
        
        # Database connectivity check
        try:
            db.session.execute(text('SELECT 1'))
            health_status['checks']['database'] = {
                'status': 'healthy',
                'response_time_ms': 0  # Could add timing
            }
        except Exception as e:
            health_status['checks']['database'] = {
                'status': 'unhealthy',
                'error': str(e)
            }
            health_status['status'] = 'degraded'
        
        # OpenAI API check
        try:
            openai_key = os.environ.get('OPENAI_API_KEY')
            if openai_key:
                health_status['checks']['openai_api'] = {
                    'status': 'configured',
                    'key_present': True
                }
            else:
                health_status['checks']['openai_api'] = {
                    'status': 'warning',
                    'key_present': False
                }
        except Exception as e:
            health_status['checks']['openai_api'] = {
                'status': 'error',
                'error': str(e)
            }
        
        # System resources check
        try:
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            health_status['checks']['system_resources'] = {
                'status': 'healthy',
                'memory_usage_percent': memory.percent,
                'disk_usage_percent': (disk.used / disk.total) * 100,
                'cpu_count': psutil.cpu_count()
            }
            
            # Alert if resources are high
            if memory.percent > 90 or (disk.used / disk.total) * 100 > 90:
                health_status['status'] = 'warning'
                
        except Exception as e:
            health_status['checks']['system_resources'] = {
                'status': 'error',
                'error': str(e)
            }
        
        return jsonify(health_status), 200 if health_status['status'] == 'healthy' else 503
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'timestamp': datetime.utcnow().isoformat(),
            'error': str(e)
        }), 503

@health_bp.route('/metrics', methods=['GET'])
def metrics_endpoint():
    """Prometheus-style metrics endpoint"""
    try:
        metrics = []
        
        # System metrics
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        metrics.extend([
            f'# HELP system_memory_usage_percent System memory usage percentage',
            f'# TYPE system_memory_usage_percent gauge',
            f'system_memory_usage_percent {memory.percent}',
            f'',
            f'# HELP system_disk_usage_percent System disk usage percentage', 
            f'# TYPE system_disk_usage_percent gauge',
            f'system_disk_usage_percent {(disk.used / disk.total) * 100:.2f}',
            f'',
            f'# HELP system_cpu_count Number of CPU cores',
            f'# TYPE system_cpu_count gauge',
            f'system_cpu_count {psutil.cpu_count()}',
            f''
        ])
        
        # Database metrics
        try:
            db.session.execute(text('SELECT 1'))
            metrics.extend([
                f'# HELP database_status Database connectivity status (1=up, 0=down)',
                f'# TYPE database_status gauge',
                f'database_status 1',
                f''
            ])
        except:
            metrics.extend([
                f'# HELP database_status Database connectivity status (1=up, 0=down)',
                f'# TYPE database_status gauge', 
                f'database_status 0',
                f''
            ])
        
        # Application metrics (could be expanded with real usage data)
        session_count = 0
        try:
            session_manager = SessionManager()
            # This would need to be implemented to get actual session count
            session_count = 0  # Placeholder
        except:
            pass
            
        metrics.extend([
            f'# HELP active_sessions_total Number of active transcription sessions',
            f'# TYPE active_sessions_total gauge',
            f'active_sessions_total {session_count}',
            f''
        ])
        
        return '\n'.join(metrics), 200, {'Content-Type': 'text/plain; charset=utf-8'}
        
    except Exception as e:
        return f'# Error generating metrics: {str(e)}', 500, {'Content-Type': 'text/plain'}

@health_bp.route('/readiness', methods=['GET'])
def readiness_check():
    """Kubernetes readiness probe endpoint"""
    try:
        # Check if application is ready to serve requests
        db.session.execute(text('SELECT 1'))
        
        return jsonify({
            'status': 'ready',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            'status': 'not_ready',
            'timestamp': datetime.utcnow().isoformat(),
            'error': str(e)
        }), 503

@health_bp.route('/liveness', methods=['GET'])  
def liveness_check():
    """Kubernetes liveness probe endpoint"""
    return jsonify({
        'status': 'alive',
        'timestamp': datetime.utcnow().isoformat()
    }), 200