"""
Final Transcript API Routes for Mina Pro
Handles post-recording transcript refinement and finalization
"""

from flask import Blueprint, request, jsonify, session
import logging
import sys
import os
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

# Add the parent directory to the path to import services
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from services.session_manager import session_manager
    from services.transcript_enhancer import transcript_enhancer
    SESSION_MANAGER_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Import error in final transcript routes: {e}")
    SESSION_MANAGER_AVAILABLE = False
    
def get_session_segments(session_id):
    """Get session segments with proper error handling"""
    if SESSION_MANAGER_AVAILABLE and hasattr(session_manager, 'get_session_segments'):
        return session_manager.get_session_segments(session_id)
    else:
        logger.warning("Session manager not available, returning empty segments")
        return []

def save_final_transcript(session_id, result):
    """Save final transcript with proper error handling"""
    if SESSION_MANAGER_AVAILABLE and hasattr(session_manager, 'save_final_transcript'):
        return session_manager.save_final_transcript(session_id, result)
    else:
        logger.warning("Session manager not available, transcript not saved")
        return {"success": False, "error": "Session manager unavailable"}

def process_final_transcript(segments, session_id=None):
    """Process final transcript with enhancement"""
    try:
        if not segments:
            return {
                "original_text": "",
                "refined_text": "No transcript segments available for processing.",
                "summary": "No content to process",
                "key_points": [],
                "confidence_score": 0.0,
                "processing_time": 0.0,
                "improvements_made": [],
                "word_count": 0,
                "speaker_patterns": {}
            }
        
        # Combine segments into text
        original_text = " ".join([s.get('text', '') for s in segments if s.get('text')])
        
        # Use transcript enhancer if available
        if SESSION_MANAGER_AVAILABLE and hasattr(transcript_enhancer, 'enhance_transcript'):
            enhancement_result = transcript_enhancer.enhance_transcript(original_text, "general")
            refined_text = enhancement_result.get('enhanced_text', original_text)
            improvements = enhancement_result.get('improvements', [])
            quality_score = enhancement_result.get('quality_score', 0.5)
        else:
            # Fallback to manual enhancement
            from services.manual_transcript_enhancer import ManualTranscriptEnhancer
            manual_enhancer = ManualTranscriptEnhancer()
            enhancement_result = manual_enhancer.enhance_transcript(original_text, "general")
            refined_text = enhancement_result.get('enhanced_text', original_text)
            improvements = enhancement_result.get('improvements', [])
            quality_score = enhancement_result.get('quality_score', 0.5)
        
        return {
            "original_text": original_text,
            "refined_text": refined_text,
            "summary": f"Transcript enhanced with {len(improvements)} improvements",
            "key_points": improvements[:5],  # Top 5 improvements
            "confidence_score": quality_score,
            "processing_time": 1.0,
            "improvements_made": improvements,
            "word_count": len(refined_text.split()),
            "speaker_patterns": {"enhancement_applied": True, "quality_score": quality_score}
        }
        
    except Exception as e:
        logger.error(f"Error processing final transcript: {e}")
        return {
            "original_text": " ".join([s.get('text', '') for s in segments]),
            "refined_text": "Error processing transcript",
            "summary": f"Processing error: {str(e)}",
            "key_points": [],
            "confidence_score": 0.0,
            "processing_time": 0.0,
            "improvements_made": [],
            "word_count": 0,
            "speaker_patterns": {}
        }

# Create Blueprint
final_transcript_routes = Blueprint('final_transcript_routes', __name__)

@final_transcript_routes.route("/api/transcript/finalize", methods=["POST"])
def finalize_transcript():
    """
    Generate final refined transcript from session segments
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        session_id = data.get('session_id')
        segments = data.get('segments', [])
        
        # Validate input
        if not session_id and not segments:
            return jsonify({"error": "Either session_id or segments must be provided"}), 400
        
        # Get segments from session if not provided
        if not segments and session_id:
            segments = get_session_segments(session_id)
            if not segments:
                return jsonify({"error": "No segments found for session"}), 404
        
        logger.info(f"[FINAL-TRANSCRIPT-API] Processing {len(segments)} segments for session {session_id}")
        
        # Process final transcript
        result = process_final_transcript(segments, session_id)
        
        # Save final transcript to database if session_id provided
        if session_id:
            save_final_transcript(session_id, result)
        
        logger.info(f"[FINAL-TRANSCRIPT-API] ✅ Final transcript generated: {result['word_count']} words")
        
        return jsonify({
            "status": "success",
            "result": result
        })
        
    except Exception as e:
        logger.error(f"[FINAL-TRANSCRIPT-API] Error: {e}")
        return jsonify({"error": str(e)}), 500

@final_transcript_routes.route("/api/transcript/refine", methods=["POST"])
def refine_transcript_text():
    """
    Quick refinement of transcript text without full processing
    """
    try:
        data = request.get_json()
        
        if not data or 'text' not in data:
            return jsonify({"error": "Text required"}), 400
        
        text = data['text']
        
        if len(text.strip()) < 10:
            return jsonify({"error": "Text too short for refinement"}), 400
        
        logger.info(f"[REFINE-API] Refining text: {len(text)} characters")
        
        # Quick refinement
        refined_text = quick_refinement(text)
        
        return jsonify({
            "status": "success",
            "original_text": text,
            "refined_text": refined_text,
            "improvement_ratio": len(refined_text) / len(text) if len(text) > 0 else 1.0
        })
        
    except Exception as e:
        logger.error(f"[REFINE-API] Error: {e}")
        return jsonify({"error": str(e)}), 500

@final_transcript_routes.route("/api/transcript/session/<session_id>/final", methods=["GET"])
def get_final_transcript(session_id):
    """
    Retrieve final processed transcript for a session
    """
    try:
        # Get final transcript from database
        final_transcript = get_final_transcript_by_session(session_id)
        
        if not final_transcript:
            return jsonify({"error": "Final transcript not found"}), 404
        
        return jsonify({
            "status": "success",
            "session_id": session_id,
            "final_transcript": final_transcript
        })
        
    except Exception as e:
        logger.error(f"[FINAL-TRANSCRIPT-GET] Error: {e}")
        return jsonify({"error": str(e)}), 500

@final_transcript_routes.route("/api/transcript/session/<session_id>/download", methods=["GET"])
def download_final_transcript(session_id):
    """
    Download final transcript as formatted document
    """
    try:
        # Get final transcript
        final_transcript = get_final_transcript_by_session(session_id)
        
        if not final_transcript:
            return jsonify({"error": "Final transcript not found"}), 404
        
        # Format for download
        formatted_content = format_transcript_for_download(final_transcript)
        
        from flask import Response
        return Response(
            formatted_content,
            mimetype='text/plain',
            headers={
                'Content-Disposition': f'attachment; filename=transcript_{session_id}.txt'
            }
        )
        
    except Exception as e:
        logger.error(f"[TRANSCRIPT-DOWNLOAD] Error: {e}")
        return jsonify({"error": str(e)}), 500

def get_final_transcript_by_session(session_id: str) -> Dict[str, Any]:
    """Retrieve final transcript from database"""
    # This would integrate with your database layer
    # For now, return None to indicate not found
    return None

def format_transcript_for_download(transcript_data: Dict[str, Any]) -> str:
    """Format transcript for download"""
    
    content = []
    content.append("MINA PRO - FINAL TRANSCRIPT")
    content.append("=" * 40)
    content.append("")
    
    # Metadata
    content.append(f"Session ID: {transcript_data.get('session_id', 'Unknown')}")
    content.append(f"Processed: {transcript_data.get('processed_at', 'Unknown')}")
    content.append(f"Word Count: {transcript_data.get('word_count', 0)}")
    content.append(f"Confidence Score: {transcript_data.get('confidence_score', 0):.2f}")
    content.append("")
    
    # Summary
    if transcript_data.get('summary'):
        content.append("SUMMARY")
        content.append("-" * 20)
        content.append(transcript_data['summary'])
        content.append("")
    
    # Key Points
    if transcript_data.get('key_points'):
        content.append("KEY POINTS")
        content.append("-" * 20)
        for i, point in enumerate(transcript_data['key_points'], 1):
            content.append(f"{i}. {point}")
        content.append("")
    
    # Final Transcript
    content.append("REFINED TRANSCRIPT")
    content.append("-" * 20)
    content.append(transcript_data.get('refined_text', ''))
    content.append("")
    
    # Processing Information
    content.append("PROCESSING DETAILS")
    content.append("-" * 20)
    improvements = transcript_data.get('improvements_made', [])
    if improvements:
        content.append("Improvements Made:")
        for improvement in improvements:
            content.append(f"• {improvement}")
    
    processing_time = transcript_data.get('processing_time', 0)
    content.append(f"Processing Time: {processing_time:.2f} seconds")
    
    return "\n".join(content)

# Health check endpoint
@final_transcript_routes.route("/api/transcript/health", methods=["GET"])
def transcript_health():
    """Health check for final transcript service"""
    return jsonify({
        "status": "healthy",
        "service": "final_transcript_processor",
        "version": "1.0.0"
    })