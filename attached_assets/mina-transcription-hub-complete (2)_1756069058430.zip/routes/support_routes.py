from flask import Blueprint, render_template
from flask_login import login_required
import logging

logger = logging.getLogger(__name__)

support_routes = Blueprint('support', __name__)
support_bp = support_routes  # Alias for consistency with other blueprints

@support_routes.route('/features')
def features():
    """Features page showcasing platform capabilities"""
    try:
        return render_template('features.html')
    except Exception as e:
        logger.error(f"Features page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/pricing')
def pricing():
    """Pricing page with subscription options"""
    try:
        return render_template('pricing.html')
    except Exception as e:
        logger.error(f"Pricing page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/help')
def help_center():
    """Help and support center"""
    try:
        return render_template('help.html')
    except Exception as e:
        logger.error(f"Help page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/privacy')
def privacy():
    """Privacy policy page"""
    try:
        return render_template('privacy.html')
    except Exception as e:
        logger.error(f"Privacy page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/terms')
def terms():
    """Terms of service page"""
    try:
        return render_template('terms.html')
    except Exception as e:
        logger.error(f"Terms page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/about')
def about():
    """About page showcasing company information"""
    try:
        return render_template('about.html')
    except Exception as e:
        logger.error(f"About page error: {e}")
        return render_template('404.html'), 404

@support_routes.route('/contact')
def contact():
    """Contact page"""
    try:
        return render_template('contact.html')
    except Exception as e:
        logger.error(f"Contact page error: {e}")
        return render_template('404.html'), 404