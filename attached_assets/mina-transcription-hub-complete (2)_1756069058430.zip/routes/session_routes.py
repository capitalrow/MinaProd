"""
Session Management Routes for Mina Pro
Handles transcription session history, management, and viewing
"""

from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
import logging
from models import db, TranscriptSession
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

session_bp = Blueprint('session', __name__, url_prefix='/sessions')

@session_bp.route('/')
@login_required
def sessions_list():
    """Display user's transcription sessions"""
    try:
        # Get user's sessions with pagination
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        sessions = TranscriptSession.query.filter_by(user_id=current_user.id)\
                                        .order_by(TranscriptSession.created_at.desc())\
                                        .paginate(page=page, per_page=per_page, error_out=False)
        
        # Get usage statistics
        total_sessions = TranscriptSession.query.filter_by(user_id=current_user.id).count()
        total_duration = db.session.query(db.func.sum(TranscriptSession.duration))\
                                 .filter_by(user_id=current_user.id).scalar() or 0
        
        stats = {
            'total_sessions': total_sessions,
            'total_duration': total_duration,
            'avg_duration': total_duration / max(total_sessions, 1),
            'this_month': TranscriptSession.query.filter(
                TranscriptSession.user_id == current_user.id,
                TranscriptSession.created_at >= datetime.utcnow().replace(day=1)
            ).count()
        }
        
        return render_template('sessions/list.html', 
                             sessions=sessions, 
                             stats=stats,
                             user=current_user)
                             
    except Exception as e:
        logger.error(f"Error loading sessions: {e}")
        flash('Error loading sessions. Please try again.', 'error')
        return render_template('sessions/list.html', 
                             sessions=[], 
                             stats={'total_sessions': 0, 'total_duration': 0, 'avg_duration': 0, 'this_month': 0},
                             user=current_user)

@session_bp.route('/history')
@login_required
def history():
    """Alias for sessions list"""
    return redirect(url_for('session.sessions_list'))

@session_bp.route('/<session_id>')
@login_required
def view_session(session_id):
    """View individual session details"""
    try:
        session = TranscriptSession.query.filter_by(
            id=session_id, 
            user_id=current_user.id
        ).first_or_404()
        
        return render_template('sessions/detail.html', session=session, user=current_user)
        
    except Exception as e:
        logger.error(f"Error loading session {session_id}: {e}")
        flash('Session not found.', 'error')
        return redirect(url_for('session.sessions_list'))

@session_bp.route('/<session_id>/delete', methods=['POST'])
@login_required
def delete_session(session_id):
    """Delete a transcription session"""
    try:
        session = TranscriptSession.query.filter_by(
            id=session_id, 
            user_id=current_user.id
        ).first_or_404()
        
        db.session.delete(session)
        db.session.commit()
        
        flash('Session deleted successfully.', 'success')
        return jsonify({'success': True})
        
    except Exception as e:
        logger.error(f"Error deleting session {session_id}: {e}")
        db.session.rollback()
        return jsonify({'error': 'Failed to delete session'}), 500

@session_bp.route('/api/recent')
@login_required
def api_recent_sessions():
    """API endpoint for recent sessions"""
    try:
        sessions = TranscriptSession.query.filter_by(user_id=current_user.id)\
                                        .order_by(TranscriptSession.created_at.desc())\
                                        .limit(10).all()
        
        return jsonify({
            'sessions': [{
                'id': s.id,
                'title': s.title or f"Session {s.created_at.strftime('%m/%d')}",
                'created_at': s.created_at.isoformat(),
                'duration': s.duration,
                'word_count': s.word_count,
                'confidence': s.confidence
            } for s in sessions]
        })
        
    except Exception as e:
        logger.error(f"Error loading recent sessions: {e}")
        return jsonify({'sessions': []})