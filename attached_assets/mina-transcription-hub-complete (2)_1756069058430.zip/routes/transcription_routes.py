"""
Transcription Routes
Real-time and batch transcription functionality
"""

from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from flask_login import login_required, current_user
from models import User
from datetime import datetime
import logging
import uuid

logger = logging.getLogger(__name__)

transcription_bp = Blueprint('transcription', __name__, url_prefix='/transcription')

@transcription_bp.route('/real-time')
def real_time():
    """Real-time transcription interface"""
    # Allow both authenticated and demo access for testing
    if current_user.is_authenticated:
        # Check user limits for authenticated users
        if not current_user.is_premium and current_user.transcribed_minutes >= 30:
            return render_template('upgrade_required.html', 
                                 user=current_user,
                                 feature='Real-time transcription')
        return render_template('real_time_transcription_clean.html', user=current_user)
    else:
        # Demo mode for testing without authentication
        demo_user = type('obj', (object,), {
            'id': 'demo',
            'username': 'Demo User',
            'is_premium': False,
            'is_authenticated': False,
            'transcribed_minutes': 0
        })
        return render_template('real_time_transcription_clean.html', user=demo_user)

@transcription_bp.route('/upload')
@login_required 
def upload():
    """File upload transcription interface"""
    # Check user limits
    if not current_user.is_premium and current_user.transcribed_minutes >= 30:
        return render_template('upgrade_required.html',
                             user=current_user, 
                             feature='File upload transcription')
    
    return render_template('transcribe_batch.html', user=current_user)

@transcription_bp.route('/demo')
def demo():
    """Demo transcription interface - no authentication required"""
    return render_template('real_time_transcription_clean.html', user={'name': 'Demo User', 'is_demo': True})

@transcription_bp.route('/sessions')
@login_required
def sessions():
    """User transcription sessions"""
    # Get user sessions from database
    try:
        from models import TranscriptSession
        sessions = TranscriptSession.query.filter_by(user_id=current_user.id).order_by(
            TranscriptSession.created_at.desc()
        ).all()
    except Exception as e:
        logger.error(f"Error getting user sessions: {e}")
        sessions = []
    
    return render_template('session_history.html', 
                         user=current_user, 
                         sessions=sessions)