"""
Transcription API Routes Module
Provides transcription-related API endpoints for Mina Pro
"""

from flask import Blueprint, request, jsonify
import logging

# Initialize blueprint
transcription_api = Blueprint('transcription_api', __name__)
logger = logging.getLogger(__name__)

@transcription_api.route('/api/transcription/health', methods=['GET'])
def transcription_health():
    """Health check for transcription services"""
    return jsonify({
        "status": "healthy",
        "service": "transcription_api",
        "version": "1.0.0"
    })

@transcription_api.route('/api/transcription/models', methods=['GET'])
def list_transcription_models():
    """List available transcription models"""
    return jsonify({
        "models": [
            {
                "name": "whisper-1",
                "type": "openai",
                "status": "available"
            }
        ]
    })

@transcription_api.route('/api/transcription/validate', methods=['POST'])
def validate_audio():
    """Validate audio file for transcription"""
    try:
        if 'audio' not in request.files:
            return jsonify({
                "valid": False,
                "error": "No audio file provided"
            }), 400
        
        audio_file = request.files['audio']
        
        # Basic validation
        if audio_file.filename == '':
            return jsonify({
                "valid": False,
                "error": "Empty filename"
            }), 400
        
        # Check file size (limit to 25MB)
        audio_data = audio_file.read()
        if len(audio_data) > 25 * 1024 * 1024:
            return jsonify({
                "valid": False,
                "error": "File too large (max 25MB)"
            }), 400
        
        if len(audio_data) < 1024:  # Min 1KB
            return jsonify({
                "valid": False,
                "error": "File too small"
            }), 400
        
        return jsonify({
            "valid": True,
            "size": len(audio_data),
            "filename": audio_file.filename
        })
        
    except Exception as e:
        logger.error(f"Audio validation error: {e}")
        return jsonify({
            "valid": False,
            "error": "Validation failed"
        }), 500