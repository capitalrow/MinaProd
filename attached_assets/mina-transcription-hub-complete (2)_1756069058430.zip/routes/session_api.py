"""
Session API routes for saving and retrieving transcription sessions
"""
import logging
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from services.session_manager_production import SessionManager

logger = logging.getLogger(__name__)

session_api_bp = Blueprint('session_api', __name__)

@session_api_bp.route('/api/save_session', methods=['POST'])
@login_required
def save_session():
    """Save completed transcription session"""
    try:
        data = request.get_json()
        
        if not data or not data.get('transcript'):
            return jsonify({'error': 'No transcript provided'}), 400
        
        # Create session
        session_id = SessionManager.create_session(
            user_id=current_user.id,
            title=f"Recording {data.get('timestamp', 'Unknown')}"
        )
        
        if not session_id:
            return jsonify({'error': 'Failed to create session'}), 500
        
        # Complete session with transcript
        success = SessionManager.complete_session(
            session_id=session_id,
            final_transcript=data.get('transcript'),
            ai_summary=data.get('ai_summary')
        )
        
        if success:
            logger.info(f"✅ Session saved: {session_id}")
            return jsonify({
                'success': True,
                'session_id': session_id,
                'message': 'Session saved successfully'
            })
        else:
            return jsonify({'error': 'Failed to save session'}), 500
            
    except Exception as e:
        logger.error(f"❌ Session save error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

@session_api_bp.route('/api/sessions', methods=['GET'])
@login_required
def get_sessions():
    """Get user's transcription sessions"""
    try:
        limit = request.args.get('limit', 50, type=int)
        offset = request.args.get('offset', 0, type=int)
        
        sessions = SessionManager.get_user_sessions(
            user_id=current_user.id,
            limit=limit,
            offset=offset
        )
        
        return jsonify({
            'success': True,
            'sessions': sessions,
            'total': len(sessions)
        })
        
    except Exception as e:
        logger.error(f"❌ Sessions retrieval error: {e}")
        return jsonify({'error': 'Failed to retrieve sessions'}), 500

@session_api_bp.route('/api/session/<session_id>', methods=['GET'])
@login_required  
def get_session_detail(session_id):
    """Get detailed session information"""
    try:
        session = SessionManager.get_session_detail(
            session_id=session_id,
            user_id=current_user.id
        )
        
        if not session:
            return jsonify({'error': 'Session not found'}), 404
            
        return jsonify({
            'success': True,
            'session': session
        })
        
    except Exception as e:
        logger.error(f"❌ Session detail error: {e}")
        return jsonify({'error': 'Failed to retrieve session'}), 500