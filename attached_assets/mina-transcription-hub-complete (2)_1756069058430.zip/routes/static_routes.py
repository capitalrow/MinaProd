"""
Static Asset Routes
Handle favicon and static file requests
"""

from flask import Blueprint, send_from_directory, current_app
import os

static_bp = Blueprint('static_routes', __name__)

@static_bp.route('/favicon.ico')
def favicon():
    """Serve favicon"""
    try:
        return send_from_directory(
            os.path.join(current_app.root_path, 'static', 'images'), 
            'favicon.svg',
            mimetype='image/svg+xml'
        )
    except FileNotFoundError:
        # Fallback to default favicon if custom one doesn't exist
        return send_from_directory(
            os.path.join(current_app.root_path, 'static'), 
            'favicon.ico',
            mimetype='image/x-icon'
        )

@static_bp.route('/robots.txt')
def robots():
    """Serve robots.txt"""
    return """User-agent: *
Allow: /
Sitemap: /sitemap.xml"""