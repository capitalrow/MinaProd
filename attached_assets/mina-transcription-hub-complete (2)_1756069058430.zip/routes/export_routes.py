"""
Export Routes for Mina Pro
Handles transcript export and sharing functionality
"""

import logging
from flask import Blueprint, request, jsonify, render_template_string, Response
from services.export_service import export_service
from datetime import datetime

logger = logging.getLogger(__name__)

export_routes = Blueprint('export_routes', __name__)

@export_routes.route('/api/export/markdown', methods=['POST'])
def export_markdown():
    """Export transcript as Markdown format"""
    try:
        session_data = request.get_json()
        
        if not session_data:
            return jsonify({"error": "No session data provided"}), 400
        
        markdown_content = export_service.export_as_markdown(session_data)
        
        return Response(
            markdown_content,
            mimetype='text/markdown',
            headers={
                'Content-Disposition': f'attachment; filename="transcript_{session_data.get("session_id", "unknown")}.md"'
            }
        )
        
    except Exception as e:
        logger.error(f"Markdown export failed: {e}")
        return jsonify({"error": str(e)}), 500

@export_routes.route('/api/export/text', methods=['POST'])
def export_text():
    """Export transcript as plain text"""
    try:
        session_data = request.get_json()
        
        if not session_data:
            return jsonify({"error": "No session data provided"}), 400
        
        text_content = export_service.export_as_plain_text(session_data)
        
        return Response(
            text_content,
            mimetype='text/plain',
            headers={
                'Content-Disposition': f'attachment; filename="transcript_{session_data.get("session_id", "unknown")}.txt"'
            }
        )
        
    except Exception as e:
        logger.error(f"Text export failed: {e}")
        return jsonify({"error": str(e)}), 500

@export_routes.route('/api/export/json', methods=['POST'])
def export_json():
    """Export complete session data as JSON"""
    try:
        session_data = request.get_json()
        
        if not session_data:
            return jsonify({"error": "No session data provided"}), 400
        
        json_content = export_service.export_as_json(session_data)
        
        return Response(
            json_content,
            mimetype='application/json',
            headers={
                'Content-Disposition': f'attachment; filename="session_{session_data.get("session_id", "unknown")}.json"'
            }
        )
        
    except Exception as e:
        logger.error(f"JSON export failed: {e}")
        return jsonify({"error": str(e)}), 500

@export_routes.route('/api/export/share', methods=['POST'])
def create_shareable_link():
    """Create shareable link for transcript"""
    try:
        session_data = request.get_json()
        
        if not session_data:
            return jsonify({"error": "No session data provided"}), 400
        
        share_id = export_service.generate_shareable_link(session_data)
        
        # Return the shareable URL (relative path)
        share_url = f"/share/{share_id}"
        
        return jsonify({
            "share_id": share_id,
            "share_url": share_url,
            "created_at": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Share link creation failed: {e}")
        return jsonify({"error": str(e)}), 500

@export_routes.route('/share/<share_id>')
def view_shared_transcript(share_id):
    """View shared transcript"""
    try:
        session_data = export_service.get_shared_session(share_id)
        
        if not session_data:
            return render_template_string("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Transcript Not Found - Mina Pro</title>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                </head>
                <body class="bg-light">
                    <div class="container mt-5">
                        <div class="row justify-content-center">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h3 class="text-danger">Transcript Not Found</h3>
                                        <p>The shared transcript you're looking for doesn't exist or has expired.</p>
                                        <a href="/" class="btn btn-primary">Go to Mina Pro</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </body>
                </html>
            """), 404
        
        # Generate HTML view of transcript
        markdown_content = export_service.export_as_markdown(session_data)
        
        # Convert markdown to HTML for display (simple conversion)
        html_content = markdown_to_simple_html(markdown_content)
        
        return render_template_string(f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Shared Transcript - Mina Pro</title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    .transcript-content {{ font-family: 'Segoe UI', system-ui, sans-serif; line-height: 1.6; }}
                    .category-badge {{ display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 0.85em; margin-right: 8px; }}
                    .task {{ background-color: #d4edda; color: #155724; }}
                    .decision {{ background-color: #e2e3ff; color: #4c4c9d; }}
                    .deadline {{ background-color: #f8d7da; color: #721c24; }}
                    .follow-up {{ background-color: #d1ecf1; color: #0c5460; }}
                    .neutral {{ background-color: #f8f9fa; color: #6c757d; }}
                </style>
            </head>
            <body class="bg-light">
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h4 class="mb-0">Shared Transcript</h4>
                                    <div>
                                        <a href="/export/markdown/{share_id}" class="btn btn-outline-primary btn-sm">Download MD</a>
                                        <a href="/" class="btn btn-primary btn-sm">Mina Pro</a>
                                    </div>
                                </div>
                                <div class="card-body transcript-content">
                                    {html_content}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            </body>
            </html>
        """)
        
    except Exception as e:
        logger.error(f"Shared transcript view failed: {e}")
        return jsonify({"error": str(e)}), 500

@export_routes.route('/export/markdown/<share_id>')
def download_shared_markdown(share_id):
    """Download shared transcript as Markdown"""
    try:
        session_data = export_service.get_shared_session(share_id)
        
        if not session_data:
            return jsonify({"error": "Transcript not found"}), 404
        
        markdown_content = export_service.export_as_markdown(session_data)
        
        return Response(
            markdown_content,
            mimetype='text/markdown',
            headers={
                'Content-Disposition': f'attachment; filename="shared_transcript_{share_id[:8]}.md"'
            }
        )
        
    except Exception as e:
        logger.error(f"Shared markdown download failed: {e}")
        return jsonify({"error": str(e)}), 500

def markdown_to_simple_html(markdown_content):
    """Convert markdown to simple HTML for display"""
    # Simple markdown to HTML conversion
    html = markdown_content
    
    # Headers
    html = html.replace('### ', '<h5>')
    html = html.replace('## ', '<h4>')
    html = html.replace('# ', '<h3>')
    
    # Bold
    html = html.replace('**', '<strong>', 1).replace('**', '</strong>', 1)
    
    # Lists
    lines = html.split('\n')
    in_list = False
    processed_lines = []
    
    for line in lines:
        if line.strip().startswith('- '):
            if not in_list:
                processed_lines.append('<ul>')
                in_list = True
            processed_lines.append(f'<li>{line.strip()[2:]}</li>')
        else:
            if in_list:
                processed_lines.append('</ul>')
                in_list = False
            processed_lines.append(line)
    
    if in_list:
        processed_lines.append('</ul>')
    
    html = '\n'.join(processed_lines)
    
    # Blockquotes
    html = html.replace('> ', '<blockquote class="blockquote"><p>')
    html = html.replace('\n\n', '</p></blockquote>\n\n')
    
    # Line breaks
    html = html.replace('\n', '<br>')
    
    return html

@export_routes.route('/api/feedback', methods=['POST'])
def submit_chunk_feedback():
    """Submit feedback for transcript chunk"""
    try:
        data = request.get_json()
        
        chunk_id = data.get('chunk_id')
        rating = data.get('rating')  # 'thumbs_up' or 'thumbs_down'
        session_id = data.get('session_id')
        
        if not all([chunk_id, rating, session_id]):
            return jsonify({"error": "Missing required fields"}), 400
        
        # Log feedback (in production, store in database)
        logger.info(f"Chunk feedback: Session {session_id}, Chunk {chunk_id}, Rating: {rating}")
        
        return jsonify({
            "status": "success",
            "message": "Feedback recorded",
            "chunk_id": chunk_id,
            "rating": rating
        })
        
    except Exception as e:
        logger.error(f"Feedback submission failed: {e}")
        return jsonify({"error": str(e)}), 500

logger.info("Export routes registered successfully")