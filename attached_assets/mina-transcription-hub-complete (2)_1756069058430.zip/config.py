"""
Configuration settings for Mina Transcription Hub
Production-grade settings for Whisper-first architecture
"""

import os

# Core Transcription Models
MODEL_PRIMARY = "whisper-1"
MODEL_FALLBACK = "gpt-4o-transcribe"

# Session Settings
SILENCE_TIMEOUT = 5  # seconds
SUMMARY_ENABLED = True
FREE_TIER_LIMIT = 3  # sessions per month

# Productivity Features
SPEAKER_LABELING_ENABLED = True
ACTION_TAGGING_ENABLED = True
SEARCH_ENABLED = True
MOBILE_RESPONSIVE = True

# Meeting Types for Context-Aware Prompting
MEETING_TYPES = {
    "general": "Please transcribe this audio accurately with proper punctuation.",
    "meeting": "Transcribe this meeting, focusing on decisions, action items, and key discussion points.",
    "interview": "Transcribe this interview with attention to questions and responses, maintaining speaker distinction.",
    "sales": "Transcribe this sales conversation, highlighting customer needs, objections, and next steps.",
    "lecture": "Transcribe this lecture or presentation, emphasizing key concepts and explanations.",
    "brainstorm": "Transcribe this brainstorming session, capturing all ideas and creative discussions."
}

# Export Settings
EXPORT_FORMATS = ["txt", "json", "md"]
INCLUDE_TIMESTAMPS = True
INCLUDE_CONFIDENCE = True

# UI Configuration
BRAND_NAME = "Mina AI"
SHOW_USAGE_COUNTER = True
PRIVACY_BANNER = True

# Database
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///mina_transcription.db")

# API Keys
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# Security
SESSION_SECRET = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Feature Flags
ENABLE_HISTORY = True
ENABLE_USER_SESSIONS = True
ENABLE_CONFIDENCE_HEATMAP = True
ENABLE_INLINE_EDITING = False  # Future feature

# Performance
MAX_AUDIO_DURATION = 600  # 10 minutes
CHUNK_SIZE = 25 * 1024 * 1024  # 25MB for audio uploads