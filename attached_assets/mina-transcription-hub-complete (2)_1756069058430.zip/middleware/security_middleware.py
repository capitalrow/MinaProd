"""
Security Middleware
Industry-standard security headers and protections
"""

from flask import request, g
from functools import wraps
import time
import hashlib
from collections import defaultdict, deque
import threading

class SecurityMiddleware:
    def __init__(self, app=None):
        self.app = app
        self.rate_limit_storage = defaultdict(lambda: deque())
        self.rate_limit_lock = threading.Lock()
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize security middleware with Flask app"""
        app.after_request(self.add_security_headers)
        app.before_request(self.security_checks)
    
    def add_security_headers(self, response):
        """Add comprehensive security headers"""
        security_headers = {
            # Prevent MIME type sniffing
            'X-Content-Type-Options': 'nosniff',
            
            # Prevent clickjacking
            'X-Frame-Options': 'DENY',
            
            # XSS protection
            'X-XSS-Protection': '1; mode=block',
            
            # Force HTTPS
            'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
            
            # Content Security Policy
            'Content-Security-Policy': (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' https://cdn.socket.io; "
                "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                "font-src 'self' https://fonts.gstatic.com; "
                "img-src 'self' data: https:; "
                "connect-src 'self' wss: ws: https:; "
                "media-src 'self' data: blob:; "
                "worker-src 'self' blob:; "
                "frame-ancestors 'none';"
            ),
            
            # Referrer policy
            'Referrer-Policy': 'strict-origin-when-cross-origin',
            
            # Permissions policy
            'Permissions-Policy': (
                'geolocation=(), '
                'microphone=(self), '
                'camera=(), '
                'payment=(), '
                'usb=()'
            ),
            
            # Remove server information
            'Server': 'Mina Pro'
        }
        
        for header, value in security_headers.items():
            response.headers[header] = value
        
        return response
    
    def security_checks(self):
        """Pre-request security checks"""
        # Check for common security threats
        self.check_request_size()
        self.check_suspicious_patterns()
    
    def check_request_size(self):
        """Check for overly large requests"""
        if request.content_length and request.content_length > 50 * 1024 * 1024:  # 50MB limit
            from flask import abort
            abort(413)  # Request Entity Too Large
    
    def check_suspicious_patterns(self):
        """Check for suspicious request patterns"""
        suspicious_patterns = [
            'eval(',
            'javascript:',
            '<script',
            'union select',
            'drop table',
            '../../../'
        ]
        
        # Check URL and parameters
        request_data = str(request.url) + str(request.form) + str(request.args)
        request_data_lower = request_data.lower()
        
        for pattern in suspicious_patterns:
            if pattern in request_data_lower:
                # Log suspicious activity
                print(f"SECURITY ALERT: Suspicious pattern '{pattern}' detected from {request.remote_addr}")
                # Could implement more sophisticated logging/blocking here

class RateLimiter:
    def __init__(self):
        self.requests = defaultdict(lambda: deque())
        self.lock = threading.Lock()
    
    def is_allowed(self, key, limit=100, window=3600):
        """Check if request is within rate limit"""
        now = time.time()
        
        with self.lock:
            # Clean old requests
            while self.requests[key] and self.requests[key][0] <= now - window:
                self.requests[key].popleft()
            
            # Check limit
            if len(self.requests[key]) >= limit:
                return False
            
            # Add current request
            self.requests[key].append(now)
            return True

# Global rate limiter instance
rate_limiter = RateLimiter()

def rate_limit(limit=100, window=3600, key_func=None):
    """Rate limiting decorator"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Determine rate limit key
            if key_func:
                key = key_func()
            else:
                key = request.remote_addr or 'unknown'
            
            if not rate_limiter.is_allowed(key, limit, window):
                from flask import jsonify
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'message': f'Maximum {limit} requests per {window} seconds'
                }), 429
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_user_key():
    """Get rate limiting key based on user"""
    if hasattr(g, 'current_user') and g.current_user:
        return f"user:{g.current_user.id}"
    return f"ip:{request.remote_addr}"

def get_api_key():
    """Get rate limiting key for API endpoints"""
    return f"api:{request.remote_addr}"