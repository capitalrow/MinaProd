"""
Enhanced database models for session persistence
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, ForeignKey
from sqlalchemy.orm import relationship
# Import db when needed to avoid circular imports
import uuid

def create_session_models():
    from app import db
    
    class TranscriptionSession(db.Model):
    __tablename__ = 'transcription_sessions'
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey('user.id'), nullable=False)
    title = Column(String(255), nullable=False)
    
    # Session metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    duration_seconds = Column(Float, default=0.0)
    status = Column(String(50), default='active')  # active, completed, failed
    
    # Transcription data
    full_transcript = Column(Text)
    word_count = Column(Integer, default=0)
    confidence_average = Column(Float, default=0.0)
    processing_time_average = Column(Float, default=0.0)
    
    # AI Analysis
    ai_summary = Column(Text)
    key_points = Column(Text)  # JSON string
    action_items = Column(Text)  # JSON string
    
    # Session chunks (for detailed analysis)
    chunks = relationship('TranscriptionChunk', backref='session', cascade='all, delete-orphan')
    
    # User relationship
    user = relationship('User', backref='transcription_sessions')

    class TranscriptionChunk(db.Model):
    __tablename__ = 'transcription_chunks'
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String(36), ForeignKey('transcription_sessions.id'), nullable=False)
    
    # Chunk data
    chunk_index = Column(Integer, nullable=False)
    text = Column(Text)
    confidence = Column(Float)
    processing_time = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    # Audio metadata
    audio_format = Column(String(50))
    file_size = Column(Integer)
    
    return TranscriptionSession, TranscriptionChunk

# Create the models
TranscriptionSession, TranscriptionChunk = create_session_models()